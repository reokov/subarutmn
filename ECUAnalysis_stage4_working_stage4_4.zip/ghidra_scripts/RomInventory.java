// Ghidra headless inventory only. Does not decode or modify instructions.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.mem.MemoryBlock;

public class RomInventory extends GhidraScript {
    @Override
    protected void run() throws Exception {
        if (currentProgram == null) {
            println("ECU_INVENTORY: no program");
            return;
        }
        println("ECU_INVENTORY: program=" + currentProgram.getName());
        println("ECU_INVENTORY: language=" + currentProgram.getLanguageID());
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            println("ECU_INVENTORY: block=" + block.getName() +
                " start=" + block.getStart() + " end=" + block.getEnd() +
                " size=" + block.getSize() + " read=" + block.isRead() +
                " write=" + block.isWrite() + " execute=" + block.isExecute());
        }
        println("ECU_INVENTORY: auto-analysis is controlled by -noanalysis; none is requested by this script");
    }
}
