# Внутреннее ревью sh7254r-reviewer — restart этапа 4.4

12.11.2026. **FAIL проверенного среза: выявлен нормативный WAW defect.**
Полнота этапа4: **FAIL / IN_PROGRESS**. Проект: **RELEASE_BLOCKED**.

Только новый snapshot `stage4_4-20261112-0d76aae142cd`.
SHA-256 source manifest: `0d76aae142cd6c5164a801d918701ee1303bd5bd8d73f4657f746a23629472a4` (73/73 OK).
Исходники утраченного59c7 не восстановлены; его PASS сюда не переносились.
Ревью внутренним отдельным subagent, не внешним агентом/системой.
Production/docs/tests ревьювером не изменялись.

## Backup gate до начала review

Сверены 73 строки SOURCE_SHA256.txt и соответствующие bytes внутри
`ECUAnalysis_stage4_working_stage4_4-20261112-0d76aae142cd.zip`: 73/73 совпадений.
SHA ZIP: `4c51c16c8746f807a6f048b6e75a26b5d0ab9b69ec7aeeac512076f0f42f6327`.
Persistent upload подтверждён основным агентом; локальный receipt существует.
Ревью начато после этого сохранения. Автозамена рабочего дерева не выполнялась.

## Доказанный дефект

**MEDIUM, нормативный blocker pipeline — CPU WAW ошибочно использует FPU-register rule.**

SystemExceptionModel.java: ready(), строка241.
Для любого совпадающего write код выбирает `latency-2` и commit gap0 по одному
`old.fpu()`. Это ошибочно распространяется на T у FCMP и Rn у STS FPUL,Rn.

Первичное основание: SW Rev3 §8.3.3(2), pp345–346, отделяет обычные CPU-регистры/
флаги от FPU-регистров/CS; figure8.21 показывает обычный WAW wait producer latency.
SW §8.6 p358 ограничивает reduced overwrite latency регистрами FR0..FR15/FPUL.
Происхождение операции из FPU не меняет класс её CPU destination.

Независимая runtime-проба `ReviewerCpuWawBoundaryProbe.java` дала:

| Последовательность | Текущий ready | CPU WAW boundary |
|---|---:|---:|
| FCMP → SETT | 1 | 2 |
| STS FPUL,R1 → MOV #imm,R1 | 1 | 2 |

`cpu-waw-red.log` содержит AssertionError. Источник пробы не читает expected из
проверяемой формулы. Это ошибка допуска issue; отдельный numerical corruption
или физическое ECU-подтверждение не заявляются.

Минимальное исправление: классифицировать именно register destination.
Reduced WAW/gap0 только для FR/FPUL, CPU T/Rn — обычная latency/gap1.
Сохранить отдельно zero-latency FMOV→FADD same-FR coissue.
Повторное PASS этого дефекта на snapshot0d76 не получено; production не менялась.

## Самостоятельно выполненные проверки

- Все Java ядра/tools свежей компиляцией JDK21, `--release 21 -Xlint:all`: PASS.
- PipelineStage44Acceptance: 21 scenarios /49 assertions PASS.
- SystemExceptionsAcceptance: 962 scenarios /1241 checks PASS.
- ReviewerExtraCpuProbe: 34 forms /1582 cases /18524 assertions PASS.
- Новая собственная ReviewerRestartProbe: 24 scenarios /49 assertions PASS.
- Дополнительная ReviewerCpuWawBoundaryProbe: **FAIL**, описан выше.
- Исходники до/после основного review-run: source_changed_during_run=[].

Собственная общая проба проверяет RAW/WAW/zero-latency/2-ILP, shift resource,
FCMP CPU EX/EX, double-divide odd-half forwarding, actual E1/ED/SF progress,
буферные uncertainties, explicit long slots, copy/rollback/reset, SRAM delta,
FPSCR UNKNOWN→LDS PR1→double-FADD, scalar FP store/load, unknown BF/BT slot,
BSR/JSR→RTS PR, nullable SR RTE, accepted H24 frame rebase и reported IRQ после slot.

Полный25-suite regression и extension build выполнил основной агент; его журналы
содержат25/25 PASS и BUILD SUCCESSFUL. Ревьювер не заявляет их независимый повтор.
Реальные ROM/BIN, Ghidra с ROM и ECU не запускались.

## Оценка архитектурного среза и полноты

Фактическая новая реализация содержит один общий stage engine; ready forecast
использует его копию, не параллельный исполнитель. Результаты/SRAM отделены от
численного исполнения, есть E1/ED/return/E2/SF и slot/system-state counters.
Runtime UNVERIFIED_ED_E1_HANDOFF_BUFFERING честно обозначает условность latch/
queue/release policy; эти расписания не считаются уникальным аппаратным oracle.

Наличие138 profiles из253 — inventory, не нормативная coverage-приёмка.
115 обязательных profiles отсутствуют. Не закрыты общая consumer-specific матрица,
все CPU/FPU resource/2-ILP случаи, bus inference и physical H24/H34 report,
полная exception entry/cancel/retirement/saved-PC область. Все20 критериев
завершения сохраняются; SYSTEM_EXCEPTIONS_COMPLETE запрещён.

Поскольку WAW defect ещё открыт, PASS функционального среза сейчас не выдаётся.
После review реализация ревьювером не продолжалась.

## Точные hashes проверенных файлов

```text
3850499703b07a6f4b03e0f82dd0e88aba38fc7607f4883cd66a65b81de6fc82  src/main/java/ecu/independent/SystemExceptionModel.java
95f8370b85f00cacd01adb4e60a9c86721dd4543b525d951054894ed414412fb  src/main/java/ecu/independent/FirmwareGraph.java
657102f8808fcf47baffb5a562474f670396e0a7492c3942d45cab3030d64007  tools/PipelineStage44Acceptance.java
```

Доказательства: `results.json`, `source-sha256.txt`, `restart-manifest-check.log`,
`cpu-waw-red.log` и `REVIEW_EVIDENCE_SHA256.txt` в этом каталоге.
