package ecu.independent;
import java.util.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
import static ecu.independent.SystemExceptionModel.*;
public final class ReviewerCpuWawBoundaryProbe {
 public static void main(String[] args){
  var p=new Pipeline();var fcmp=ps(0xf424,A,0x40000);p.issue(fcmp,Map.of("T",1));
  long flag=p.ready(ps(0x0018,A+2,0x40000));
  p=new Pipeline();var sts=ps(0x015a,A,0x40000);p.issue(sts,Map.of("R1",7));long gpr=p.ready(ps(0xe101,A+2,0x40000));
  System.out.println("FCMP->SETT issue="+flag+"; STS FPUL,R1->MOV #imm,R1 issue="+gpr);
  if(flag!=2||gpr!=2)throw new AssertionError("SW8.3.3(2) CPU flags/GPR WAW must not use SW8.6 FR/FPUL overwrite latency reduction");
 }
}
