package ecu.independent;
import java.util.*;
import static ecu.independent.SystemExceptionModel.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
/** Independent review oracles: SW8.2,8.3,8.6,8.9.5/6/8. Synthetic data only. */
public final class ReviewerRestartProbe {
 static int cases,checks;
 static void test(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 static PipelineSpec spec(int word,int pc,int mode){byte[] r=image(word);w(r,pc,word);return pipelineSpec(new Sh2aDecoder().decode(r,pc),mode);}
 static Map<String,Integer> val(PipelineSpec s,int value){Map<String,Integer> out=new LinkedHashMap<>();for(String key:s.writes())out.put(key,value);return out;}
 static long phase(Pipeline p,int pc,PipelineStage stage){return p.steps().stream().filter(x->x.pc()==pc&&x.stage()==stage).mapToLong(PipelineStep::slot).findFirst().orElse(-1);}
 static FirmwareGraph run(AbstractCpu s,int... ops){byte[] r=image(ops[0]);for(int j=0;j<ops.length;j++)w(r,A+2*j,ops[j]);var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,64,s);return g;}
 static void scoreboard(){
  cases++;var p=new Pipeline();var move=spec(0x6323,A,0x40000);p.issue(move,val(move,7));test(p.ready(spec(0x343c,A+2,0x40000))==0,"MOV zero-latency forwarding");
  p.issue(spec(0x343c,A+2,0x40000),Map.of("R4",9));test(p.ready(spec(9,A+4,0x40000))==1,"third instruction excludes2ILP");
  p.advance(1);test(p.committed().get("R3")==7&&p.committed().get("R4")==9,"CPU commits");
  cases++;p=new Pipeline();var add=spec(0x332c,A,0x40000);p.issue(add,val(add,7));test(p.ready(spec(0x343c,A+2,0x40000))==1,"nonzero RAW");test(p.ready(spec(0xe301,A+2,0x40000))==1,"CPU WAW");
  cases++;p=new Pipeline();var shift=spec(0x4208,A,0x40000);p.issue(shift,val(shift,4));test(p.ready(spec(0x4308,A+2,0x40000))==1,"single shift resource");
  cases++;p=new Pipeline();move=spec(0xf20c,A,0x40000);p.issue(move,Map.of("FR2",1));add=spec(0xf230,A+2,0x40000);test(p.ready(add)==0,"FP WAW excluded from generic CPU rule");p.issue(add,Map.of("FR2",2));p.advance(3);test(p.committed().get("FR2")==2,"same-SF writes follow issue order");
  cases++;p=new Pipeline();var compare=spec(0xf424,A,0xc0000);p.issue(compare,Map.of("T",1));test(p.ready(spec(9,A+2,0xc0000))==1,"double FCMP cannot precede coissue");p.advance(1);test(!p.outstanding().getFirst().cpuCompleted(),"double FCMP EX/EX");p.advance(2);test(p.outstanding().getFirst().cpuCompleted(),"double FCMP CPU complete2");
  for(int[] row:new int[][]{{0xf423,24},{0xf46d,23}}){cases++;p=new Pipeline();var d=spec(row[0],A,0xc0000);p.issue(d,val(d,1));test(p.ready(spec(0xf65c,A+2,0xc0000))==row[1],"double divide/sqrt odd-half forwarding");}
  cases++;p=new Pipeline();var lds=spec(0x415a,A,0x40000);p.issue(lds,Map.of("FPUL",1));test(p.ready(spec(0x6322,A+2,0x40000))==0,"LDS+memoryREAD fig8.11");test(p.ready(spec(0x2232,A+2,0x40000))==1,"LDS+memorySTORE fig8.9");
 }
 static void actualStages(){
  cases++;var p=new Pipeline();var d=spec(0xf423,A,0xc0000);p.issue(d,val(d,1));p.advance(16);var add=spec(0xf860,A+2,0xc0000);test(p.ready(add)==16,"no future reservation16->23");p.issue(add,val(add,2));p.advance(24);
  test(phase(p,A,PipelineStage.E1_RETURN)==23,"return waits active E1 owner");test(!p.committed().containsKey("FR4")&&p.committed().get("FR8")==2,"actual ordered completion");p.advance(27);test(phase(p,A,PipelineStage.E2)==26&&phase(p,A,PipelineStage.SF)==27,"actual return/E2/SF");test(p.uncertainties().contains("UNVERIFIED_ED_E1_HANDOFF_BUFFERING"),"conditional buffering disclosed");
  cases++;p=new Pipeline();d=spec(0xf423,A,0x40000);p.issue(d,val(d,1));var second=spec(0xf863,A+2,0x40000);test(p.ready(second)==1,"second DF not delayed until ED free");p.issue(second,val(second,2));p.advance(20);test(phase(p,A+2,PipelineStage.ED)==10&&phase(p,A+2,PipelineStage.SF)==20,"ED wait actual sequence");
  cases++;p=new Pipeline(Map.of(2L,8));p.issue(d,val(d,1));p.advance(2);test(p.systemState()==9&&!p.committed().containsKey("FR4"),"ED states run inside stretched slot");p.advance(5);test(p.systemState()==12&&phase(p,A,PipelineStage.SF)==5,"E1/E2/SF stay slot based");
  cases++;var s=initial();s.pipeline=new Pipeline();s.pipeline.initialize(s);s.pipeline.issue(d,val(d,1));s.pipeline.advance(4);var copy=s.copy();copy.pipeline.advance(12);test(s.pipeline.committed().get("FR4")==0x3f800000,"copy isolation");s.restoreFaultState(copy);test(s.pipeline.committed().get("FR4")==1,"rollback phase and delta");s.pipeline.reset();s.pipeline.advance(20);test(s.pipeline.outstanding().isEmpty()&&s.pipeline.committed().isEmpty(),"reset no stale commit");
 }
 static void memoryMode(){
  cases++;var s=initial();s.r[1]=B;s.r[2]=0x12345678;s.writeRam(B,4,0x11111111,A-2);var g=run(s,0x2122,0x6312,9,9,9,9,9,9,0x001b);
  test(ram(at(g,A+4),B)==0x11111111,"RAM store remains uncommitted before MA");test(ram(at(g,A+16),B)==0x12345678&&at(g,A+16).registers().get(3)==0x12345678,"own delta and load forwarding");
  cases++;s=initial();s.fpscr=null;s.r[0]=0xc0000;s.fr[2]=s.fr[4]=0x3ff00000;s.fr[3]=s.fr[5]=0;
  g=run(s,0x406a,0xf420,0x056a,9,9,9,9,9,9,0x001b);var end=at(g,A+18);
  test(end.fr().get(4)==0x40000000&&end.fr().get(5)==0,"LDS FPSCR from UNKNOWN establishes PR1 before double execution");test(end.registers().get(5)==0xc0000,"STS FPSCR waits preceding arithmetic");
  cases++;s=initial();s.fpscr=0x40000;s.r[1]=B;s.writeRam(B,4,0,A-2);g=run(s,0xf420,0xf14a,0xf618,9,9,9,9,9,9,0x001b);end=at(g,A+18);test(ram(end,B)==0x40000000&&end.fr().get(6)==0x40000000,"FADD store bypass and scalar FP load");
 }
 static void control(){
  cases++;var s=initial();s.t=null;byte[] r=image(0x8b02);w(r,A+8,9);w(r,A+10,9);w(r,A+12,0x001b);var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,32,s);
  long id=g.pipelineStops().stream().flatMap(x->x.steps().stream()).filter(x->x.stage()==PipelineStage.ISSUE&&x.pc()==A+8).mapToLong(PipelineStep::slot).min().orElseThrow();test(id==3,"unknown BF taken fence");test(g.cpuStates().stream().anyMatch(x->x.pc()==A+2),"not-taken branch retained");
  cases++;s=initial();s.t=null;r=image(0x8d02);w(r,A+2,0x9100);w(r,A+4,0x001b);w(r,A+8,0x001b);w(r,A+10,0x1234);g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,32,s);test(g.report().issues().stream().noneMatch(x->x.reason().contains("PC_RELATIVE_DELAY_SLOT_DESTINATION_UNRESOLVED")),"BT/S preserves path condition through slot");
  for(int call:new int[]{0xb002,0x420b}){cases++;s=initial();s.r[1]=0;s.r[2]=A+8;g=run(s,call,0x7101,9,0x001b,0x000b,0x7104);test(at(g,A+4).pr()==A+4,"call PR forwarded to RTS");test(at(g,A+6).registers().get(1)==5,"call/return each slot once");}
  for(boolean partial:new boolean[]{false,true}){cases++;s=initial();if(partial)s.q=null;var p=new Pipeline();p.initialize(s);var rte=spec(0x002b,A,0x40000);s.r[15]+=8;s.writeSr(0xf0);Map<String,Integer> delta=new LinkedHashMap<>();for(String key:rte.writes())delta.put(key,Pipeline.read(s,key));p.issue(rte,delta);p.restoreCommitted(s);test(s.interruptMask==0&&s.r[15]==SP,"RTE no early SR/SP");if(partial)test(s.q==null&&Boolean.FALSE.equals(s.bankOverflow),"partial status preserved");p.advance(6);p.restoreCommitted(s);test(s.interruptMask==15&&s.r[15]==SP+8,"RTE final commit");}
 }
 static void exceptions(){
  cases++;var s=initial();s.r[2]=B+2;byte[] r=image(0x6122);w(r,H,0x002b);w(r,H+2,9);var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,32,s);test(g.systemEvents().stream().anyMatch(x->x.stage()==Stage.ACCEPTANCE&&x.event().kind()==Kind.CPU_ADDRESS),"explicit potential H24 path");test(at(g,A+2).registers().get(15)==SP,"accepted frame survives committed rebase/RTE");
  cases++;s=initial();s.r[1]=5;s.systemPending.add(new Event(1,Kind.IRQ,A-2,null,0x100,3,"explicit",Availability.REPORTED_ID).afterIssue(A));r=image(0xa002);w(r,A+2,0x7101);w(r,A+8,9);g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,32,s);var entry=at(g,H);test(ram(entry,SP-8)==A+8&&entry.registers().get(1)==6,"reported IRQ accepted after actual slot completion");
  cases++;s=initial();s.fpscr=0x40800;s.fr[6]=s.fr[8]=0;g=run(s,0xf423,0xf863,0x001b);test(g.pipelineStops().stream().anyMatch(x->x.outstanding().size()==2&&x.outstanding().stream().anyMatch(f->f.result().isEmpty())),"normal+exceptional outstanding jobs retained");test(g.systemEvents().stream().noneMatch(x->x.stage()==Stage.ACCEPTANCE&&x.event().kind()==Kind.FPU),"no invented physical H34 report");
 }
 public static void main(String[] args){scoreboard();actualStages();memoryMode();control();exceptions();System.out.println("REVIEWER_RESTART_PASS scenarios="+cases+" assertions="+checks+"; conditional buffering/explicit timing inputs only");}
}
