# Внутреннее повторное ревью sh7254r-reviewer

12.11.2026. Snapshot **stage4_4-20261112-a96749fd281b**.

**PASS проверенного функционального среза. FAIL полноты этапа4.**
Статус: **IN_PROGRESS / RELEASE_BLOCKED**. SYSTEM_EXCEPTIONS_COMPLETE не подтверждён.
Это внутреннее ревью отдельным subagent; внешнее ревью другой системой не получено.
Production/docs/tests ревьювером не изменялись; новые outputs только в reviewA967.

## Backup и привязка к bytes

Ревью начато после подтверждённого persistent backup новой исправленной пары.
Рабочий backup: `ECUAnalysis_stage4_working_stage4_4-20261112-a96749fd281b.zip`.
Его whole SHA совпал с `build/current-backup.json`; все73 source entries внутри ZIP
совпали с manifest и live bytes. Существование `build/fix-upload-result.json`
подтверждено; успешные Library uploads подтверждены основным агентом.

Source manifest: `drafts/verification/stage4_4-restart/SOURCE_SHA256.txt`.
SHA-256: `a96749fd281b71403771cee98da4cf0efddfacf1f1e964e9cb8600a98a230e16`.
Проверка **73/73 OK до review и 73/73 OK после review**.
Во время fresh compile/runtime: `source_changed_during_run=[]`.

Предварительный backup честно содержит metadata RUNNING_OR_INCOMPLETE для общего
регресса. Последующий завершённый full regression не выдаётся за результат,
уже существовавший в момент сохранения предварительной копии.

Snapshot0d76 с FAIL и RED сохранён отдельно в `../review0d76/`.
Утраченный59c7 не восстановлен; его PASS не используется.

## Что исправлено и независимо перепроверено

Архивная побайтная сверка0d76→a967 установила: единственная production Java-правка
находится в SystemExceptionModel.ready. Дополнительно изменены target acceptance
и checkpoint-export script; это не Git diff. Java diff сохранён в `fix-diff.patch`.

WAW теперь классифицируется по destination register:
`old.fpu() && (FRn || FPUL)` получает reduced overwrite delay и FP commit gap0;
CPU T/Rn получают обычную latency и gap1.

Основание: SW Rev3 §8.3.3(2), pp345–346 — CPU register/flag contention;
§8.6 p358 — reduced overwrite rule именно для FR0..FR15/FPUL.

| Независимая последовательность | Исторический0d76 | Текущийa967 |
|---|---:|---:|
| FCMP → SETT, earliest issue | 1: FAIL | 2: PASS |
| STS FPUL,R1 → MOV #imm,R1, earliest issue | 1: FAIL | 2: PASS |

Запущен тот же source независимой ReviewerCpuWawBoundaryProbe без изменения
expected values: `waw-green.log`, exit0. Старый `cpu-waw-red.log` остаётся в review0d76.

Отдельная общая собственная проба проверила, что разрешённые FPU same-slot WAW
и forwarding не потеряны: zero-latency FMOV→FADD с общей FR остаётся coissued,
итог same-SF result соответствует issue order.

## Самостоятельно выполненные проверки текущего снимка

| Проверка | Фактический результат |
|---|---|
| Fresh compile всех Java ядра/tools, JDK21 `--release 21 -Xlint:all` | PASS, warnings/errors нет |
| Независимая WAW regression probe | exit0; оба CPU issue boundary2 |
| PipelineStage44Acceptance | **23 scenarios /51 assertions PASS** |
| SystemExceptionsAcceptance | **962 scenarios /1241 checks PASS** |
| ReviewerExtraCpuProbe | **34 forms /1582 cases /18524 assertions PASS** |
| Независимая ReviewerRestartProbe | **24 scenarios /49 assertions PASS** |
| Source manifest после review | **73/73 OK** |

Собственная проба не ограничена WAW. Проверены RAW/2-ILP/shift resource,
double FCMP CPU completion, odd-half FDIV/FSQRT forwarding, actual E1/ED/return/E2/SF,
explicit stretched slots и state clock, copy/rollback/reset, SRAM own delta,
FPSCR UNKNOWN→LDS PR1→double FADD/STS, scalar FP store/load, BF/BT/S unknown-T,
BSR/JSR→RTS PR/slots, RTE nullable SR rollback/commit, accepted H24 frame→RTE и
explicit reported IRQ после slot. Нормативные references проверялись по локальным
SW8.2/8.3/8.6/8.9 и Hardware7–8.

Полный25-suite regression и extension build выполнял основной агент; их PASS
не выдаётся за независимый повтор ревьювером. Реальные ROM/BIN, Ghidra с ROM и
физический ECU не запускались.

## Границы PASS и незавершённая полнота

После точечного WAW fix новых доказанных блокирующих дефектов в проверенном
срезе не найдено. PASS относится к реализованным profiles и явно заданным входам.

Inventory253 rows: **138 PROFILE_PRESENT_NOT_FULL_ACCEPTANCE /115 NOT_IMPLEMENTED**.
PROFILE_PRESENT — наличие профиля, не PASS нормативной формы. Общая
consumer-specific матрица и115 missing profiles не закрыты. Остаются общий CPU/
FPU scheduler всех обязательных форм, весь набор memory/update/bank/system/
multicycle/32-bit исключений 2-ILP и general exception entry/cancel/retirement/resume.

ED/E1 handoff buffering/backpressure выдаётся как runtime UNVERIFIED,
а не как уникальный hardware oracle. Variable slot durations — явные scenario inputs,
не вывод bus waits/clock ratios из ROM. Physical condition→CPU-report H24/H34,
все overlap acceptance cases и общий saved-PC нормативный контракт не завершены.
Полный знаменатель20 критериев сохранён; PASS полноты не выдан.

Проверка завершена. Производственная реализация ревьювером не продолжалась.

## Актуальные Java SHA-256

```text
3850499703b07a6f4b03e0f82dd0e88aba38fc7607f4883cd66a65b81de6fc82  src/main/java/ecu/independent/SystemExceptionModel.java
95f8370b85f00cacd01adb4e60a9c86721dd4543b525d951054894ed414412fb  src/main/java/ecu/independent/FirmwareGraph.java
657102f8808fcf47baffb5a562474f670396e0a7492c3942d45cab3030d64007  tools/PipelineStage44Acceptance.java
```

Полные source hashes: `source-sha256.txt`. Результаты: `results.json` и runtime logs.
Хеши отчёта, probes и протоколов: `REVIEW_EVIDENCE_SHA256.txt`.
