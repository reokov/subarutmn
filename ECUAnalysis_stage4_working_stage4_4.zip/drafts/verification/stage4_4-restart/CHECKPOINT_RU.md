# ECUAnalysis — контрольная точка продолжения

12.11.2026. `stage4_4-20261112-a96749fd281b`. **IN_PROGRESS / RELEASE_BLOCKED**.

Это новый restart подтверждённого архива f599f87f7d7c91ae3d4c3e87f4e70f3d428cf65f688710bb77f0b6ce266ad895.
Не восстановленные bytes утраченного59c7: его восстановление RESTORE_BLOCKED, требуется
исходный рабочий ZIP stage4_4-20261111-59c7ff9175af с source manifest.

Изменены SystemExceptionModel.java и FirmwareGraph.java, acceptance и build/check scripts.
Реальные E1/ED/return/E2/SF, WAIT_RESOURCE, slot/system-state clocks, SRAM deltas, FPSCR
контекст, branch/slot/RTE и BF/BT pipeline-only refinement подключены к одному executor.
См. docs/PIPELINE_STAGE4_4_RU.md и SOURCE_SHA256.txt. Не все profiles завершены.

Текущие проверки: compile PASS; functional **PASS 25/25 listed mandatory groups**; review **PASS internal tested scope; FAIL completeness; external NOT_RUN**.
Реальные BIN/ECU/Ghidra с BIN NOT_RUN. Исторические24/24 и результаты утраченного59c7
не относятся к этому snapshot. Новые журналы отдельно от исторических.

Незакрытое: full profile/consumer-latency matrix; auto-update/indexed/multiple/double memory,
MUL/DIV/MAC/system/bank/TRAPA/SLEEP profiles; general pipeline exception entry/cancel/resume.
UNVERIFIED: ED/E1 interstage buffering/backpressure и physical H24/H34 report/accepted PC.
Следующая независимая реализация: address-update memory profiles и раздельная готовность
адресного регистра/данных. Перед ней завершить current review, исправить доказанные FAIL.

Резервная пара: ECUAnalysis_stage4_working_stage4_4-20261112-a96749fd281b.zip и
ECUAnalysis_stage4_evidence_stage4_4-20261112-a96749fd281b.zip; при финальном review второй называется review_evidence.
Для operator download пары нужен persistent upload receipt; он подтверждается в ответе
оператору. До подтверждения НЕ ВЫЗЫВАТЬ reviewer.

Восстановление: unzip рабочий ZIP в пустое дерево, sha256sum -c MANIFEST.sha256 и
sha256sum -c SOURCE_SHA256.txt; затем JDK21+ в PATH, bash scripts/verify-functional.sh.
Extension build: JDK25+, Ghidra12.2, Gradle9.1+; GHIDRA_INSTALL_DIR задаётся оператором.
Рабочий архив не содержит ECU BIN, toolchains, credentials или закрытых .codex configs.
