# Независимое review e29e38de2ba5 (parent, не current)

PASS проверенного условного среза.73sourceSHAсовпал. JDK25freshcompilePASS.
Target235/431PASS,System962/1241PASS;4дополнительныеflags/RTE/UNKNOWNпробыPASS;
64изолированные BIT_REGliteralсценарияPASS. ЧисленныеCPU/FPU/decoderнеизменны.
ПодтвержденыCSsticky/parallel/UNKNOWN→true, Q/M/Tshadow, RTEset/clearflags,
exceptionframeSR0x2000послеCLIP+DIV0U, EXTshifterresource.
ОбщаяполнотаIN_PROGRESS/RELEASE_BLOCKED:50profiles, generalentry/cancel,
multipleboundary, H24/H34report,FSCHG/EDbufferingUNVERIFIED.
Extensionreviewerсамнепересобирал.
