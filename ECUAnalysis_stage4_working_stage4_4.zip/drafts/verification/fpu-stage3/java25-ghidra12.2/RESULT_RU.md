# Сборка на Java25 / Ghidra12.2

11.11.2026. Установлено и фактически проверено в текущем рабочем окружении:

| Компонент | Версия / расположение |
|---|---|
| Microsoft Build of OpenJDK | 25.0.5.0.2+1 LTS, /home/agent/opt/jdk-25 |
| Ghidra | 12.2 PUBLIC 20261016, /home/agent/opt/ghidra-12.2 |
| Gradle | 9.8.0, официальный distribution в cache bundled wrapper |

Установка без root; SHA256 архивов JDK/Ghidra/Gradle совпали с официальными.
Официальные источники: Microsoft Learn OpenJDK downloads и
https://github.com/NationalSecurityAgency/ghidra/releases/tag/Ghidra_12.2_build .

Первый Java-wrapper download Gradle не получил прямого сетевого соединения.
Тот же официальный Gradle distribution скачан через штатно работающий curl,
проверен по официальной SHA256 и размещён в wrapper cache. Затем исходный
scripts/build-extension.sh выполнен успешно, без подмены buildExtension task.

**BUILD SUCCESSFUL, 4 actionable tasks: 4 executed.**
Протокол: BUILD_EXTENSION.txt. Gradle печатает предупреждение JVM о native access;
ошибок сборки нет. Java25 javac компилирует расширение в bytecode major69.

Результат: dist/ghidra_12.2_PUBLIC_20261111_ECUAnalysis.zip.
Проверены CRC всего ZIP и наличие FpuBinary, FpuSemantics, FpuExceptionEvent,
CpuSnapshot в ECUAnalysis.jar. Устаревший входной dist заменён новой сборкой.

Повторный scripts/verify-functional.sh с настоящими java/javac/jar Java25:
**21/21 обязательных наборов PASS, exit0**. В отличие от первого прогона этапа3,
использован штатный --release21, без временного module-launcher адаптера.
CPU205/205, decoder253/253, FPU2 146 238 +6388 проверок PASS.

scripts/verify-ghidra.sh — PASS проверки путей и версий. Это не запуск GUI,
не импорт ROM и не доказательство runtime-поведения всех возможностей Ghidra.
Реальные BIN и внешнее оборудование не запускались. Расширение собрано,
автоматическая установка плагина в пользовательский экземпляр Ghidra не выполнялась.

Для повторной работы сохранён scripts/env-java25-ghidra12.2.sh. Его копия
/home/agent/opt/ecu-analysis-env.sh подключена к login-shell: новые shell-сеансы
уже выбирают java/javac25 и GHIDRA_INSTALL_DIR. Для переноса на другую машину:
установить JDK25/Ghidra12.2 и source scripts/env-java25-ghidra12.2.sh;
ECU_JAVA_HOME/GHIDRA_INSTALL_DIR допускают свои пути.
Установленные программы доступны в этом окружении, но переживание пересоздания
вычислительной среды не гарантируется; сохранённые скрипты и отчёт позволяют
воспроизвести настройку.

Единственный формальный блокер этапа3 устранён. На основании реализации,
матрицы56 форм, выполненной функциональной приёмки, независимого reviewer PASS
и обеих успешных сборок статус этапа3 — **FPU_SEMANTICS_COMPLETE**.
Общий статус — **RELEASE_BLOCKED**: точное принятие H34/pipeline/savedPC остаётся
этапу4. FPU_COMPLETE и готовность всего эмулятора не объявлены.
