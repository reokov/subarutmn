# ECUAnalysis — этап3 FPU/FPSCR

Дата: 11.11.2026. **Итоговый статус: FPU_SEMANTICS_COMPLETE. Общий RELEASE_BLOCKED.**
Первоначальный блокер сборки снят после установки Java25/Ghidra12.2. Обе сборки PASS, повторная функциональная приёмка21/21 PASS: [дополнительный протокол](java25-ghidra12.2/RESULT_RU.md). Ниже исторические условия первого прогона явно уточнены итогом.
Это отчёт об изменённой Java-реализации и исполненных проверках, не документальный аудит.

## Реализация

| Объём | Итог |
|---|---|
| Нормативные FPU-формы, table5.9 | 48/48 имеют реализацию и исполненный нормальный путь |
| Связанные CPU-передачи, table5.10 | 8/8 имеют реализацию и исполненный путь |
| Исключённые из знаменателя сложные формы | 0 |
| Известные оставшиеся дефекты FPU-семантики | Не обнаружены после исправлений и независимого ревью |
| Статус всей системы | RELEASE_BLOCKED |

Знаменатель зафиксирован завершённым decoder253/253. Полная построчная матрица:
[56 форм](../../../docs/requirements/fpu-execution-coverage.csv).
Реализованы FADD/FSUB/FMUL/FDIV/FMAC, FSQRT, FCMP/EQ/GT, FLOAT/FTRC/FCNVSD/FCNVDS,
FABS/FNEG/FLDI0/FLDI1/FSTS/FLDS/FSCHG, все FMOV и FPSCR/FPUL CPU transfers.

Новый FpuBinary выполняет точные операции с целыми числителями/знаменателями;
округление и sqrt midpoint не используют float/double хоста. Покрыты signedzero,
DN1 flush, SH qNaN/sNaN, infinity, O/U/I, Z/V, граничные int32, RN ties-even и RZ.
Cause очищается у вычислительных операций; Flag sticky; Enable не копируется в Cause.
Генерация события не записывает результат назначения. Raw перемещения сохраняют биты.

DN0 не вычеркнут ради покрытия: SH7254R фиксирует DN1; программная запись DN0 даёт DN1.
Искусственный DN0 состояния вычисления явно отвергается. RM2/3 reserved, не режимы
поддерживаемой арифметики. Все PR/SZ комбинации проверяются в применимых формах;
запрещённые контексты распознаются общим правилом декодера.

Основной маршрут всех56 форм проходит FpuSemantics.apply. Memory adapter сохраняет
существующую SRAM/bus модель. Контекстная проверка действует для ROM/SRAM/delay slot,
масштабирование disp12 однократно. Исправлены FSCHG при PR1 и unknown FPSCR,
nullable FRm/FR0, misaligned pre/post-update в ordinary/frozen маршрутах.

## Нормативные уточнения

Основа: inputs/REN_rej09b0051_sh2a_MAH_20050708.pdf, REJ09B0051-0300 Rev3,
§2.2.5 с.8–10, §3.7.6 с.29–30, §6.2 с.77–86 и все применимые §6.5.
Hardware R01UH0480EJ0400 §2.2.5 с.39–40 подтверждает fixed DN1/QIS/FPSCR.

В Rev3 обнаружены противоречия FMAC. Они **разрешены**, а не скрыты UNVERIFIED:
[официальный R01US0031JJ0400 Rev4.00, 22.02.2011](https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual?language=ja&r=1054896),
revision list PDFphysical p7, исправленный §6.5.11 printed6-205..207.
Явное исправление имеет приоритет над оставшимися старыми ячейками таблицы6-208.
Нулевой результат zero-product/zero-accumulator имеет знак product-sign AND accumulator-sign;
infinite FR0 больше не XOR-ит знак конечного аккумулятора и проверяет invalid при
противоположных infinity. Ревьювер независимо открыл оригинальные страницы.
PDF доступен web reader; прямое локальное скачивание ответило403, обхода не было.
URL/идентификатор и точные страницы сохранены в контракте.

## Независимые функциональные проверки

| Набор | Результат |
|---|---|
| FpuStage3Acceptance | PASS: 2 146 238 проверок |
| FpuFormsAcceptance | PASS: 56/56 форм, 6388 проверок |
| FpuNormalTrapAcceptance | PASS |
| Независимое повторение ревьювером свежей компиляции этих трёх наборов | PASS |
| Полный scripts/verify-functional.sh | PASS: 21/21 обязательных наборов, fail=0, exit0 |
| Регрессия CPU | PASS: 205/205 форм, 37992 checks |
| Регрессия декодера | PASS: 253/253 форм, 50 647 552 checks |
| Сборка независимого CLI | PASS |
| Сборка Ghidra extension | PASS на Java25/Ghidra12.2/Gradle9.8.0, BUILD SUCCESSFUL; первоначальный NOT_RUN снят |

Численный эталон Python Fraction/binary-search ищет соседние представимые значения,
сравнивает midpoint (квадрат midpoint для sqrt), не импортирует Java-код:
12 944 exact vectors. Отдельные literal Renesas таблицы: 1728 двуоперандных и
1728 FMAC трёхоперандных категорий. Таблицы проходят RM0/1, QIS0/1 и все32
комбинации Enable. Unary special cases проверяют оба знака, zero/subnormal,
q/sNaN/infinity, назначения, flags и pending. Все входы синтетические.

Normal-form integration проходит ROM и SRAM, PR0/1 и SZ0/1 по применимости,
точные FR/FPUL/FPSCR/GPR/SRAM, T и отсутствие неожидаемого pending. Проверки
недопустимого контекста требуют illegal route без записи. Ошибки выравнивания
проверены при pending=false/true: нет записи GPR/FR/FPSCR/SRAM, есть H24 boundary,
нет выдуманного resumePc. Отдельно проверено generation event и frozen FCMP.

PASS означает успех перечисленного конечного набора, а не перебор всех2^32/2^64
значений. Эталон, нормативный запрет, FAIL, UNKNOWN и NOT_RUN не приравнены друг к другу.

На первом прогоне до установки Java25 системный javac launcher отсутствовал, но JDK compiler/jar modules были доступны.
Использованы `java -m jdk.compiler/com.sun.tools.javac.Main` и jdk.jartool;
для существующего скрипта build/ временный launcher переводит --release21 в
-source21/-target21 (в окружении нет ct.sym). Runtime21, Xlint:all, без предупреждений.
Пакеты системы не устанавливались: обычные apt install/download не были доступны.
Никаких разрешений не обходили. В итоговом повторном прогоне установлен полный JDK25 и использован штатный javac --release21; эти временные launchers больше не нужны.

Итоговый регрессионный протокол сохранён рядом как FUNCTIONAL.txt;
числа CPU/decoder и результаты всех обязательных наборов приведены в нём.

## Закрытые прежние ограничения

FPU_SPECIAL_OPERANDS_NOT_PROVED, FPU_SIGNED_ZERO_NOT_PROVED,
FPU_DENORMAL_OUTPUT_NOT_ROUTED, FPU_OVERFLOW_RESULT_NOT_ROUTED,
FCNVSD_NONFINITE_UNVERIFIED, FCNVDS_NONFINITE_UNVERIFIED,
FCNVDS_UNDERFLOW_NOT_ROUTED, FCNVDS_OVERFLOW_NOT_ROUTED,
FCNVDS_OVERFLOW_FLAGS_NOT_PROVED, FTRC_INVALID_OR_UNKNOWN больше не являются
заглушками численной реализации. UNKNOWN входа сохраняется как отдельная причина,
а не как выдуманный результат. В текущей нормативной FPU-области нет известных
NOT_IMPLEMENTED или UNVERIFIED реализационных случаев.

NOT_RUN остаются: GUI/runtime-проверка всех функций расширения, реальный BIN,
Ghidra с ROM, внешнее оборудование. Последние три не запускались по заданной границе.
Старый dist Ghidra из входного архива заменён новой сборкой актуального FPU-дерева.

## Изменённые Java-файлы

- src/main/java/ecu/independent/FpuSemantics.java — вычисления, FPSCR, специальные
  случаи и единый вход исполнения FPU/передач.
- src/main/java/ecu/independent/FpuBinary.java — новый exact rational binary rounding core.
- src/main/java/ecu/independent/FirmwareGraph.java — подключение всех форм, memory
  adapter/preflight, события генерации и наблюдаемые FP-снимки; frozen compatibility.
- src/main/java/ecu/independent/Sh2aDecoder.java — выделена существующая общая
  fpuContext-проверка для повторного использования исполнителем; ISA-таблицы не менялись.

AbstractCpu и FpuOperandClassifier не потребовали изменения. Контракты завершённых
этапов1/2 не переписаны. Новая приёмка: tools/FpuStage3Acceptance.java,
FpuFormsAcceptance.java, два генератора и три TSV fixture; обновлены ожидания
FpuNormalTrapAcceptance и список обязательных checks verify-functional.sh.

## Ревью и следующий этап

[Заключение sh7254r-reviewer](REVIEW_RU.md): PASS проверенной реализации, прежние
семантические блокеры закрыты. После успешной сборки расширения этот формальный блокер снят; см. дополнительный протокол.

[Текущий контракт для этапа4](../../../docs/FPU_CONTRACT_RU.md) фиксирует
FpuExceptionEvent(instructionPc,cause,flags,enable,fpscr), pending №19 и memory boundary.
Генерация подтверждена отдельно от принятия. Точный ID-stage момент H34,
exception priorities и architectural saved PC остаются этапу4; потенциальные
ветви графа не доказывают latency. Другие компоненты не разрабатывались.

Текущее дерево собрано с Ghidra12.2SDK на Java25; формат и FPU-содержимое ZIP проверены. Критерий сборки этапа3 выполнен, FPU_SEMANTICS_COMPLETE зафиксирован. Общий RELEASE_BLOCKED сохраняется до дальнейших системных этапов; разработка этапа4 не начата.
