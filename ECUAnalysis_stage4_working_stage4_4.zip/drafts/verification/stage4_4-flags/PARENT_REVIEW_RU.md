# Независимое review ec8b8407ef1e (parent, не current)

PASS проверенного условного объёма. SHA73source verified; JDK25fresh --release21
-Xlint:allcompilePASS; target176/371PASS; System962/1241PASS.
Прежние4PRprobesPASS,4новыеcontrolprobesPASS. FsLabelREDтеперьGREEN.
LDS.LVBR реально направляетillegal вновыйhandlerпослеknownbranchfence; rawbits,
UNKNOWNGBRmemoryroundtrip, misalignedSTC.LVBRH24PASS.
GeneralentryприoutstandingNOPявноUNVERIFIED_EXCEPTION_PHASE — known gap, неPASS.
Extension reviewerнепересобирал. FullstageIN_PROGRESS/RELEASE_BLOCKED.
