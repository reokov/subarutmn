# Независимое review cf3e84eab11b — исторический parent

FAIL: MEDIUM FirmwareGraph:1377. FSCHG-only программа получает ложный
PIPELINE_UNVERIFIED_ED_E1_HANDOFF_BUFFERING; независимая scratchпроба exit1.
PR/MOVA в проверенном объёме PASS. FreshJDK25compile, target131/311,
System962/1241 и4 дополнительных PR integration probes PASS.
Правка: вывод фактическихuncertainties и тест наличияFSCHG/отсутствияED.
Текущая итерация воспроизвела RED на точном priorJava из savedcf3 и GREEN
на новом source (diagnostic-red.log/diagnostic-green.log).
Review currentJava этим историческим заключением не заявляется.
MOVML/MOVMU: blanketdrain нарушаетfig8.24; толькопредыдущиеmultiple тоже
не подтверждено. Граница CPUcomplete/FPUoutstanding безнормы не выбрана.
