# ECUAnalysis — восстановимая контрольная точка этапа4.4

`stage4_4-20261112T021936Z-ec8b8407ef1e`. **IN_PROGRESS / RELEASE_BLOCKED**.
Источник: `stage4_4-20261112T021015Z-cf3e84eab11b`, source manifest `cf3e84eab11b23436856b06d0ff3092471e195723b7c0f2fff70882855269f91`.
Текущий source manifest: `ec8b8407ef1e3fb77c6ebc660f125651b09907664fdd9658e8d83de1438e4353`, entries=73.
Это продолжение подтверждённого e87, а не реконструкция утраченного59c7.

Группа: non-SR control transfers and corrected uncertainty diagnostics.
Численные CPU/FPU/decoder не изменялись. Pipeline остаётся тем же production scheduler.
Текущие compile=PASS current full core/tools --release21 -Xlint:all; functional=PASS 25/25 listed mandatory groups; extension=PASS; review=NOT_RUN.
Наличие PROFILE_PRESENT не означает полный функциональный PASS; inventory содержит253 формы.
См. docs/STAGE4_4_NONSR_RESULT_RU.md, profile-inventory.tsv и NEW_PROFILE_FORMS.tsv.

Следующее независимое требование: multiple memory и оставшиеся memory/control transfers;
затем MUL/DIV/MAC/system/bank/TRAPA/SLEEP, общая 2-ILP и exception matrix.
UNVERIFIED: ED/backpressure/capacity, physical H24/H34 condition→CPU report и некоторые savedPC.
Это не причина останавливать независимую реализацию профилей.
Реальные ROM/ECU/Ghidra с BIN NOT_RUN.

Перед reviewer обязательны постоянное сохранение обоих ZIP, receipts, повторное получение
и SHA/manifest verification. Локальные ZIP не являются подтверждённой резервной копией.
Пара: ECUAnalysis_stage4_working_stage4_4-20261112T021936Z-ec8b8407ef1e.zip и
ECUAnalysis_stage4_evidence_stage4_4-20261112T021936Z-ec8b8407ef1e.zip (после review — review_evidence).
Без successful persistent verification reviewer не вызывается: BACKUP_BLOCKED.

Восстановление: распаковать working в пустую папку, проверить MANIFEST.sha256 и SOURCE_SHA256.txt.
Сборка: JDK25/Ghidra12.2, source scripts/env-java25-ghidra12.2.sh, bash scripts/verify-functional.sh.
SDK, реальные BIN и приватные конфигурации в архивах отсутствуют.
