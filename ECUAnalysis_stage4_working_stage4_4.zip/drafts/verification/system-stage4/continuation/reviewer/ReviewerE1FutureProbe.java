package ecu.independent;
import java.util.*;
public class ReviewerE1FutureProbe {
 static Sh2aDecoder.Instruction dec(int w,int pc){byte[] b=new byte[pc+4];b[pc]=(byte)(w>>8);b[pc+1]=(byte)w;return new Sh2aDecoder().decode(b,pc);}
 public static void main(String[] args){
  var div=SystemExceptionModel.pipelineSpec(dec(0xf423,0x1000),0xc0000);
  var p=new SystemExceptionModel.Pipeline();p.issue(div,Map.of("FR4",1,"FR5",0));p.advance(16);
  var add=SystemExceptionModel.pipelineSpec(dec(0xf860,0x1002),0xc0000);
  System.out.println("FDIV ED phase, independent FADD ready="+p.ready(add)+", current=16");
  if(p.ready(add)!=16)throw new AssertionError("SW8.6(2): independent arithmetic after ED enters without delay; future terminal E1 cannot retroactively block it");
 }
}
