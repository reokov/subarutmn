package ecu.independent;
import java.util.*;
public class ReviewerFpuWawProbe {
 static Sh2aDecoder.Instruction dec(int w,int pc){byte[] b=new byte[pc+4];b[pc]=(byte)(w>>8);b[pc+1]=(byte)w;return new Sh2aDecoder().decode(b,pc);}
 public static void main(String[] args){
  var move=SystemExceptionModel.pipelineSpec(dec(0xf20c,0x1000),0x40000);
  var p=new SystemExceptionModel.Pipeline();p.issue(move,Map.of("FR2",1));
  var add=SystemExceptionModel.pipelineSpec(dec(0xf230,0x1002),0x40000);
  System.out.println("FMOV zero-latency FR2 -> FADD read/write FR2 ready="+p.ready(add));
  if(p.ready(add)!=0)throw new AssertionError("SW8.3.3(2) excludes FP registers from generic WAW; zero-latency FMOV uses distinct resource");
 }
}
