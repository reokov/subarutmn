package ecu.independent;
import java.util.*;
public class ReviewerUnverifiedBoundaryProbe {
 static Sh2aDecoder.Instruction dec(int w,int pc){byte[] b=new byte[pc+4];b[pc]=(byte)(w>>8);b[pc+1]=(byte)w;return new Sh2aDecoder().decode(b,pc);}
 static SystemExceptionModel.PipelineSpec spec(int word,int pc){return SystemExceptionModel.pipelineSpec(dec(word,pc),0xc0000);}
 static void unknown(SystemExceptionModel.Pipeline p,SystemExceptionModel.PipelineSpec s,String code){
  try{p.ready(s);throw new AssertionError("unknown assigned a fake interval");}catch(IllegalStateException e){if(!e.getMessage().equals(code))throw e;}
 }
 public static void main(String[] args){
  var div=spec(0xf423,0x1000);var p=new SystemExceptionModel.Pipeline();p.issue(div,Map.of("FR4",1,"FR5",0));p.advance(16);
  unknown(p,spec(0xf860,0x1002),"UNVERIFIED_E1_RETURN_CROSSES_ACTIVE_OPERATION");
  p=new SystemExceptionModel.Pipeline();p.issue(div,Map.of("FR4",1,"FR5",0));
  unknown(p,spec(0xf863,0x1002),"UNVERIFIED_ED_BUSY_STAGE_STALL");
  System.out.println("REVIEWER_UNKNOWN_BOUNDARIES PASS cases=2 assertions=2; support remains incomplete");
 }
}
