package ecu.independent;
import java.util.*;
public class ReviewerPipelineProbe {
 static Sh2aDecoder.Instruction dec(int w,int pc){byte[] b=new byte[pc+4];b[pc]=(byte)(w>>8);b[pc+1]=(byte)w;return new Sh2aDecoder().decode(b,pc);}
 public static void main(String[] args){
   if(args.length>0){
    for(int opcode:new int[]{0xf423,0xf46d}) {
      var op=SystemExceptionModel.pipelineSpec(dec(opcode,0x1000),0xc0000);
      var q=new SystemExceptionModel.Pipeline();Map<String,Integer> values=new LinkedHashMap<>();for(String x:op.writes())values.put(x,1);q.issue(op,values);
      var odd=SystemExceptionModel.pipelineSpec(dec(0xf65c,0x1002),0xc0000);
      long actual=q.ready(odd),expected=opcode==0xf423?24:23;
      System.out.println("opcode="+Integer.toHexString(opcode)+" odd-half-ready="+actual+" expected="+expected);
      if(actual!=expected)throw new AssertionError("SW8.6 fig8.46 / table8.8 double FDIV/FSQRT odd-half latency");
    }return;
   }
   var compare=SystemExceptionModel.pipelineSpec(dec(0xf424,0x1000),0xc0000);
   var p=new SystemExceptionModel.Pipeline();p.issue(compare,Map.of("T",1));
   var nop=SystemExceptionModel.pipelineSpec(dec(9,0x1002),0xc0000);
   System.out.println("double-FCMP cpuOffset="+compare.cpuOffset()+"; next-NOP-ready="+p.ready(nop));
   if(compare.cpuOffset()!=2||p.ready(nop)!=1)throw new AssertionError("SW8.9.8(18): double FCMP CPU EX/EX and no parallel following instruction");
 }
}
