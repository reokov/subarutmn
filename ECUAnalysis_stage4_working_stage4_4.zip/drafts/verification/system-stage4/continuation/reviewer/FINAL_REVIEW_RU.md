# Независимое ревью sh7254r-reviewer — продолжение этапа 4

11.11.2026. Вердикт проверенного функционального среза: **PASS**.
Полнота этапа 4: **FAIL / IN_PROGRESS**. Общий проект: **RELEASE_BLOCKED**.
SYSTEM_EXCEPTIONS_COMPLETE не подтверждён.

Ревью выполнено независимо: чтение production Java, сверка первичных руководств,
свежая компиляция с `--release 21 -Xlint:all` и собственные runtime-пробы.
Production-код, документация и acceptance-тесты ревьювером не изменялись.
Из-за отсутствия Git-базы исторический diff не заявляется.

## Подтверждённый объём

Проверены SystemExceptionModel.Pipeline/pipelineSpec, хранение pipeline в AbstractCpu,
интеграция в FirmwareGraph и протокол отзыва SINT в Sh7254rIntcMmio.
Это явный completed-fetch/no-wait/one-state-slot профиль существующего исполнителя.
Он не является универсальным аппаратным scheduler.

Источники: локальный REJ09B0051-0300 Rev.3.00, §§8.2,8.3,8.6,8.8,8.9.8;
локальный R01UH0480EJ0400 Rev.4.00, §8.6.1 и table8.5.
ED counts проверялись отдельно от общего определения slot.

Независимые обнаруженные ошибки первого среза и результат повторной проверки:

| Проверка | Основание | До | Текущий снимок |
|---|---|---|---|
| Double FCMP CPU completion и следующий NOP | SW8.9.8(18), pp473–474: EX/EX, запрет coissue following | cpuOffset1, ready0 — FAIL | cpuOffset2, ready1 — PASS |
| Double FDIV/FSQRT odd-half forwarding | SW8.6, SW8.8 p377: 24/23 | FDIV25 — FAIL | FDIV24, FSQRT23 — PASS |
| Power reset сохраняет выбранный pipeline profile | Согласованность API/CPU reset state | 1 pipeline snapshot / 2 CPU snapshots — FAIL | 2/2 — PASS |
| Zero-latency FMOV→FADD с FR RAW/WAW | SW8.3.3(2) исключает FPU-регистры из CPU WAW, SW8.6 | ready1 — FAIL | ready0 — PASS |
| Future terminal E1 пересекает начатую double FADD | SW8.6(2) не допускает произвольную задержку независимой FPU в ED | выдуманный перенос ready16→23 — FAIL | точный UNVERIFIED, без назначенного интервала |
| Второй FDIV при занятом ED | SW8.6(4) ограничивает вход ED, не определяет перенос всей DF | прежний resource-fit не подтверждал stage stalls | точный UNVERIFIED_ED_BUSY_STAGE_STALL |

Последние два случая не реализованы полностью. Тесты подтверждают честную остановку,
а не корректное исполнение этих случаев. Они остаются блокерами полноты.

Отзыв SINT: write0 сам не удаляет доставленный report. Завершённый read0 после
clear и последующий RTE моделируют явно рекомендованный HW8.6.1 протокол.
Reassert/unknown write снимают proof, unrelated pending сохраняется; AND proof
при join консервативен. Для этого ограниченного causal-протокола доказанного
дефекта не найдено. Числовая задержка table8.5 из количества инструкций не выведена.

## Фактически выполненные проверки

- Свежая compilation всех Java ядра и tools, включая tools/cpu-review: PASS,
  предупреждений/ошибок в final-compile.log нет.
- SystemExceptionsAcceptance: **962 сценария / 1239 checks PASS**.
- Отдельный scheduler: **27 сценариев / 64 checks PASS**.
- Отдельный withdrawal: **5 сценариев / 8 checks PASS**.
- Независимые runtime-пробы double FCMP, odd-half DIV/SQRT, power reset,
  FPU WAW и unknown E1/ED boundaries: PASS текущего ограниченного поведения.
- SHA manifest разработчика: **48/48 OK** в final-manifest-check.log.

Ревьювер не заявляет независимый повтор всех 24 functional suites или сборки
Ghidra extension: эти проверки выполняет основной агент на том же снимке.
Реальные ROM/BIN, Ghidra с ROM и физический ECU не запускались.

## Неподтверждённая полнота

Не закрыты memory/branch/RTE и весь набор многотактовых CPU pipeline profiles;
растянутые slots и независимое ED state progression при waits; stage stalls для
занятого ED и crossing E1; физические condition→CPU-report H24/H34; их общая
acceptance/cancellation/retirement/save-PC связь с overlap и RTE.

Scoreboard/forwarding/2-ILP в реализованном subset существуют и проверены.
Нельзя объявлять отсутствие всей реализации scoreboard. Но subset не закрывает
общие критерии 12–15/18 исходного задания и не заменяет полноту всех 20 критериев.
Новых доказанных Java-blocker в повторно проверенном ограниченном срезе не найдено.
Продолжать разработку разрешено; закрывать этап 4 нельзя.

## SHA-256 текущего проверенного снимка

```text
d571d505e68058a18e03bda65aaabf4b675169f9fdae6ba63eb2ac5ba6d46514  src/main/java/ecu/independent/SystemExceptionModel.java
f6b74b6d3c7c60ade8b20a762487b5bf8267349e88d49c5a9298aa7dc2fe36de  src/main/java/ecu/independent/FirmwareGraph.java
0bdaa86203819160fe968089016ef555a41bef312df7553c882eb34e662adc77  src/main/java/ecu/independent/AbstractCpu.java
820f2f522fe273a95b0590c6c0263e27913083046b4c285f5d28716b7859ed62  src/main/java/ecu/independent/Sh7254rIntcMmio.java
37c0c84e0ecbab0cf3949eff946fd1a456a513e9b8dcb08b08d8f84d52d0a8db  tools/SystemExceptionsAcceptance.java
```

Протоколы и независимые пробы находятся в этом же каталоге `build/stage4/reviewer/`.
Связанный manifest: `FINAL_REVIEW_EVIDENCE_SHA256.txt`.
