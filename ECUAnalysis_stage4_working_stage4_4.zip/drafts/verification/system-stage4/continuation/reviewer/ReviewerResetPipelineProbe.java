package ecu.independent;
public class ReviewerResetPipelineProbe {
 public static void main(String[] args){
  var s=SystemExceptionsAcceptance.initial();
  s.queueSystem(SystemExceptionModel.Kind.POWER_ON_RESET,null,null,0,0,"synthetic reset",SystemExceptionModel.Availability.REPORTED_ID);
  byte[] r=SystemExceptionsAcceptance.image(0xf420);
  var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,32,s);
  System.out.println("pipeline states="+g.pipelineStates().size()+"; CPU states="+g.cpuStates().size());
  if(g.pipelineStates().size()!=g.cpuStates().size())throw new AssertionError("no-wait profile lost after power-on reset");
 }
}
