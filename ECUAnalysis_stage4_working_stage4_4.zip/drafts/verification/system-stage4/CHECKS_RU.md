# Проверки текущего среза

11.11.2026. Точные результаты и пределы: RESULT_RU.md. Сырые протоколы:
FUNCTIONAL.txt, BUILD_EXTENSION.txt, SYSTEM_CASES.txt, fixes-20261111/.

Три HIGH и два slot-дефекта: runtime FAIL(exit1) → Java → PASS(exit0).
Текущая system-приёмка: 929 сценариев / 1164 проверки. Ограниченный normal-overlap
дополнительно проверяет FR/FPUL PR0/PR1, CPU/SRAM effects, отсутствие отката retirement
PC и отказ от переноса explicit boundary на ранний consumer.

Все 22 существующих обязательных набора повторены после последней функциональной
правки: PASS, exit0, 20261111T165510Z. Decoder253/253, CPU205/205, FPU56/56.
FPU exact corpus 2 146 238; формы 6388; decoder 50 647 552 checks.
Java25/Ghidra12.2 buildExtension PASS. Реальные BIN/ROM/Ghidra GUI не запускались.

Независимый reviewer: PASS проверенного объёма, FAIL полноты этапа.
Автоматическое физическое принятие H'24/H'34 и полный pipeline остаются
UNVERIFIED/NOT_IMPLEMENTED, не PASS. Статус IN_PROGRESS / RELEASE_BLOCKED.
