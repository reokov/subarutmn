package ecu.independent;
import java.util.*;
import static ecu.independent.SystemExceptionModel.*;
public class ReviewerCurrentStage4Probe {
 static final int A=0x1000,SP=0xfff90000,H24=0x1600,HIRQ=0x1a00,HTRAP=0x1c00;
 static void w(byte[]a,int n,int x){a[n]=(byte)(x>>>8);a[n+1]=(byte)x;}
 static void l(byte[]a,int n,int x){w(a,n,x>>>16);w(a,n+2,x);}
 static byte[] image(int op){byte[]r=new byte[0x200000];l(r,0,A);l(r,4,SP);l(r,0x10,0x1400);l(r,0x24,H24);l(r,0x34,0x1200);l(r,0x44,0x1800);l(r,0x100,HIRQ);l(r,0x80,HTRAP);w(r,A,op);w(r,A+2,9);w(r,A+4,0x1b);for(int h:new int[]{0x1200,0x1400,H24,0x1800,HIRQ,HTRAP})w(r,h,0x1b);return r;}
 static AbstractCpu state(){var s=new AbstractCpu(SP);s.writeSr(0);s.r[0]=3;s.r[1]=21;s.r[2]=A+0x100;s.fpscr=0x40001;return s;}
 static FirmwareGraph run(byte[]r,AbstractCpu s){var g=new FirmwareGraph();g.analyzeCpu(r,64,s);return g;}
 static void mmio(){var s=state();s.r[2]=0xfffe0400;var g=run(image(0x422b),s);System.out.println("MMIO_EVENTS="+g.systemEvents());System.out.println("MMIO_ISSUES="+g.report().issues());if(g.systemEvents().stream().noneMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS))throw new AssertionError("known I/O-register instruction fetch omitted H24 generation");}
 static void trap(){var s=state();s.systemPending.add(new Event(1,Kind.IRQ,A-4,null,0x100,3,"after issue IRQ",Availability.PIPELINE_UNVERIFIED).afterIssue(A));var r=image(0xc320);w(r,HIRQ,0x002b);w(r,HIRQ+2,9);var g=run(r,s);System.out.println("TRAP_STEPS="+g.executionSteps());System.out.println("TRAP_ACCEPT="+g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE).toList());long complete=g.executionSteps().stream().filter(e->e.stage()==FirmwareGraph.ExecutionStage.COMPLETE&&e.instructionPc()==A).count();if(complete!=1)throw new AssertionError("noncancellable TRAPA retired "+complete+" times without a program loop");}
 static void divfault(){var s=state();s.r[0]=0;s.systemPending.add(new Event(1,Kind.IRQ,A-4,null,0x100,3,"after issue IRQ",Availability.PIPELINE_UNVERIFIED).afterIssue(A));var g=run(image(0x4184),s);System.out.println("DIVFAULT_STEPS="+g.executionSteps());System.out.println("DIVFAULT_ACCEPT="+g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE).toList());System.out.println("DIVFAULT_STATES="+g.cpuStates().stream().filter(a->a.pc()==0x1800).toList());if(g.executionSteps().stream().noneMatch(e->e.stage()==FirmwareGraph.ExecutionStage.ISSUE&&e.instructionPc()==A))throw new AssertionError("valid DIV zero route bypassed issue checkpoint");}
 static void unknownmask(){var s=state();s.interruptMask=null;s.sr=null;s.systemPending.add(new Event(1,Kind.IRQ,A-4,null,0x100,3,"unknown mask IRQ",Availability.REPORTED_ID));var g=run(image(0x7101),s);System.out.println("UNKNOWNMASK_EVENTS="+g.systemEvents());System.out.println("UNKNOWNMASK_EDGES="+g.report().edges());}
 public static void main(String[]args){switch(args[0]){case "mmio"->mmio();case "trap"->trap();case "divfault"->divfault();case "unknownmask"->unknownmask();default->throw new AssertionError();}}
}
