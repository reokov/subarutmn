# ECUAnalysis — обновлённый отчёт о доработке этапа 4

11.11.2026. **IN_PROGRESS / RELEASE_BLOCKED. SYSTEM_EXCEPTIONS_COMPLETE не достигнут.**
Ошибка лимита больше не является действующим блокером. Независимое ревью выполнено.

## Фактические Java-изменения

- FirmwareGraph: H'24 fetch-маршруты, завершение TRAPA вместе с её transition,
  сохранение проигравшего SINT report, подписи по победителю, раздельный normal FP commit.
- Sh7254rMemoryMap: общий fetch classifier odd/I/O/последние 10 байтов SRAM (HW table7.6).
- Sh7254rInterruptController: известная ошибочная выборка handler происходит после entry.
- AbstractCpu: outstanding normal FP-result отдельно от CPU completion, copy/rollback/key.
- SystemExceptionModel: immutable FR-mask/FPUL result delta без CPU state.

С предыдущим рабочим ZIP различаются ровно эти пять production Java.
Sh2aDecoder, FpuSemantics, FpuBinary, FpuOperandClassifier не изменены.

## FAIL → правка → PASS

| Независимая runtime-проба | До правки | Текущий код |
|---|---|---|
| MMIO fetch | exit1, H'24 отсутствует | exit0 PASS |
| TRAPA/IRQ/RTE | exit1, повтор TRAPA и неверный saved PC | exit0 PASS; дополнительно два frame / два RTE |
| Проигравший SINT | exit1, пропущен первый handler ID | exit0 PASS, typed pending сохранён |
| FP-result boundary на slot-PC | exit1, commit пропущен | exit0 PASS |
| SRAM-end inline slot fetch | exit1, нет H'24 | exit0 PASS, slot не исполняется |

Пробы включены в обязательный SystemExceptionsAcceptance. Red/green журналы — fixes-20261111/.
Новая normal-overlap функциональность проверена после реализации; exploratory reflection-проба
не выдаётся за независимый аппаратный red oracle.

## Проверка последнего исходника

- Полный verify-functional.sh: **22/22 обязательных PASS**, exit0, UTC run 20261111T165510Z.
- System exceptions: **929 сценариев / 1164 проверки PASS** ограниченного объёма.
- Decoder **253/253**, 50 647 552 проверки; CPU **205/205**, 37 992 проверки;
  CPU boundary: 2992 случая / 9634 assertions.
- FPU **56/56**, 6388 form checks; exact/special corpus **2 146 238 PASS**.
- CLI и extension: **PASS**, JDK25.0.5.0.2 / Ghidra12.2 / Gradle9.8.
  Ядро и acceptance используют --release21 на JDK25.
- Реальные BIN, Ghidra с ROM, аппаратура: **NOT_RUN**. Информационный release-gate BLOCKED.

FUNCTIONAL.txt, BUILD_EXTENSION.txt, SYSTEM_CASES.txt содержат фактические протоколы.
Предыдущая версия кода не используется как доказательство актуального PASS.

## Независимое ревью

sh7254r-reviewer независимо скомпилировал актуальные ядро/acceptance, выполнил
SystemExceptionsAcceptance 929/1164 и обе дополнительные slot-пробы. Три HIGH входят
в этот повторный запуск. Полный журнал 22/22 проверен им, но не заявляется как его
независимый повтор всех 22 наборов. Новых доказанных блокирующих Java-дефектов в
проверенном срезе не найдено. **PASS проверенного объёма; FAIL полноты этапа 4.**
Сверка всех 20 критериев приведена ниже.

## Не завершено

1. **NOT_IMPLEMENTED:** общий readiness scoreboard, forwarding, ресурсные конфликты,
   несколько outstanding операций и 2-ILP. Нормативные таблицы SW §§8.3/8.6/8.9.8
   имеются; это недописанный код, а не следствие отсутствия нормы о report.
2. **UNVERIFIED:** универсальный condition→CPU-report H'24/H'34, реальный accepted ID
   и saved PC в перекрывающемся pipeline. HW7.6.6 и SW8.9.7 не устанавливают для всех
   V/Z/O/U/I/QIS конкретную фазу обнаружения/доставки. SF/result-ready/конец ED не
   назначены таймером H'34. Для доказательства нужны дополнительные применимые
   первичные свидетельства; приблизительный таймер не является исправлением.
3. **UNVERIFIED:** bus/wait/clock условия H'24, доставка/отзыв IRQ. После SINTR=0
   нужно учитывать HW8.6/table8.5. Наблюдение о stale delivered report зарегистрировано
   отдельно от доказанных HIGH; мгновенное удаление без нормы не реализовано.

Normal completion profile — ограниченный явный вход: один producer и независимый
CPU-only region, затем отдельный FR/FPUL commit без отката GPR/SR/PC/SRAM.
Он не заменяет scoreboard/forwarding/общий scheduler или автоматический report.

Контракт продолжения этапа 4: `docs/SYSTEM_EXCEPTIONS_CONTRACT_RU.md` в рабочем архиве.
Полная приёмка всех 20 критериев не достигнута; к другим компонентам работа не переходила.


## Все 20 критериев завершения исходного задания

Частичное покрытие не считается выполнением всего критерия; знаменатель не уменьшался.

| № | Критерий | Фактический итог |
|---:|---|---|
| 1 | Полный нормативный перечень | Частично: types/vectors есть, полный сценарный знаменатель не закрыт |
| 2 | Generation и acceptance в Java | Частично: explicit-ID работает, automatic report H24/H34 не завершён |
| 3 | Арбитраж и приоритеты | PASS проверенных explicit-ID конкуренций; общая полнота не доказана |
| 4 | Маскирование и вложенность | Частично: известные SR.I/nesting/LDC-window проверены; доставка/отзыв IRQ не завершены |
| 5 | Нормативный saved PC | Частично: типовые и явные ID проверены; физический ID H24/H34 не доказан |
| 6 | Delay slots | PASS исправленных проверенных случаев; полное перекрытие не покрыто |
| 7 | Правильная точка H34 | Не выполнен для automatic report |
| 8 | H24 и побочные эффекты | Частично: generation/frame/stacking/RTE проверены; completion/bus-order условны |
| 9 | Корректный pending | Частично: preservation/consumption проверены; отзыв delivered SINT требует уточнения |
| 10 | Переходы к handler | PASS проверенных известных pointer/stack/vector условий |
| 11 | Возврат | PASS проверенных RTE/nesting/TRAPA/cancelled-DIV случаев |
| 12 | Достаточная pipeline-модель | Не выполнен |
| 13 | Нет NOT_IMPLEMENTED | Не выполнен |
| 14 | Нет блокирующих UNVERIFIED | Не выполнен |
| 15 | Вся обязательная нормативная приёмка PASS | Все существующие22 набора PASS; вся нормативная область ими не доказана |
| 16 | Регрессии этапов1–3 | PASS выполненных существующих наборов |
| 17 | Сборки ядра/расширения | PASS на актуальном Java |
| 18 | Независимое ревью без blocker | Новых доказанных Java-ошибок проверенного объёма нет; полнота не подтверждена |
| 19 | Норма каждого правила | Частично: условные входы отделены от аппаратного расписания |
| 20 | Нет фиктивной тактовой точности | PASS, ограничения явно обозначены |

## Заключение sh7254r-reviewer

Независимая свежая компиляция и system929/1164 PASS. Три HIGH и два найденных им
slot-дефекта повторно GREEN. Нового доказанного Java-blocker в проверенном срезе
нет. Вердикт: **PASS проверенного объёма; FAIL завершения этапа4**.
Полный22/22 журнал проверен ревьювером, но он не заявлял независимый повтор всех22.
Актуальная сборка Ghidra выполнена основным агентом.

Ограниченный normal-completion profile не реализует forwarding, readiness scoreboard,
ресурсы, multiple outstanding и2ILP. Эти части самостоятельно реализуемы по уже
имеющимся таблицам, их нельзя списывать на отсутствие правила H34-report.

## Нормативные границы

Основной источник Hardware R01UH0480EJ0400 Rev4 §§7–8. SW Rev3 §8.9.6(16),p441
подтверждает multicycle TRAPA; §8.9.7(1),p444 — ожидание IRQ и отмену только DIVU/S.
MMIO/SRAM-end fetch следует HW7.3.1/table7.6. Manual reset и reserved exception
sources не созданы; RAME/FIFE остаются аппаратными IRQ79/82, отдельно от H24/H28.

В проверенных HW/SW не установлена универсальная фаза detect→CPU-report по всем
V/Z/O/U/I/QIS. SF и ED не превращены в timer H34. Это UNVERIFIED, отдельно от
недописанных частей scheduler. Для H24 нужны применимые bus/wait/clock условия.

Дополнительное наблюдение reviewer — UNVERIFIED, не новый доказанный HIGH:
SINTR3=0, read0, триNOP иRTE в higher-priority handler ещё оставляют typed report.
HW8.6/table8.5 требуют моделировать распространение снятия сигнала; простое мгновенное
удаление тоже не подтверждено. Source shadow и delivered CPU report не тождественны.

Численная FPU сохранена. SYSTEM_EXCEPTIONS_COMPLETE и готовность эмулятора не заявлены.
Статус последнего сохранённого среза: **IN_PROGRESS / RELEASE_BLOCKED**.
