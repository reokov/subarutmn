package ecu.independent;
import java.util.*;
public final class Stage4ReviewProbe {
 public static void main(String[] args) {
  var s=SystemExceptionsAcceptance.initial();s.r[2]=Sh7254rMemoryMap.STBCR;
  byte[] r=SystemExceptionsAcceptance.image(0x422b);SystemExceptionsAcceptance.w(r,SystemExceptionsAcceptance.A+2,0x0009);
  var g=SystemExceptionsAcceptance.graph(r,s);
  boolean generated=g.systemEvents().stream().anyMatch(e->e.stage()==SystemExceptionModel.Stage.GENERATION&&e.event().kind()==SystemExceptionModel.Kind.CPU_ADDRESS);
  System.out.println("MMIO_FETCH expected_H24_generation=true actual="+generated);
  System.out.println(g.report().issues());
  if(!generated)throw new AssertionError("Hardware Rev4 table7.6: fetch STBCR must generate CPU address error");
 }
}
