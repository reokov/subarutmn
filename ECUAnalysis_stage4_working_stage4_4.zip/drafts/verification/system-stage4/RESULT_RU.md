# Этап 4 — устранение дефектов ревью

11.11.2026. **IN_PROGRESS / RELEASE_BLOCKED. SYSTEM_EXCEPTIONS_COMPLETE не достигнут.**
Ошибка лимита больше не является действующим блокером. Независимое ревью выполнено.

## Фактические Java-изменения

- FirmwareGraph: H'24 fetch-маршруты, завершение TRAPA вместе с её transition,
  сохранение проигравшего SINT report, подписи по победителю, раздельный normal FP commit.
- Sh7254rMemoryMap: общий fetch classifier odd/I/O/последние 10 байтов SRAM (HW table7.6).
- Sh7254rInterruptController: известная ошибочная выборка handler происходит после entry.
- AbstractCpu: outstanding normal FP-result отдельно от CPU completion, copy/rollback/key.
- SystemExceptionModel: immutable FR-mask/FPUL result delta без CPU state.

С предыдущим рабочим ZIP различаются ровно эти пять production Java.
Sh2aDecoder, FpuSemantics, FpuBinary, FpuOperandClassifier не изменены.

## FAIL → правка → PASS

| Независимая runtime-проба | До правки | Текущий код |
|---|---|---|
| MMIO fetch | exit1, H'24 отсутствует | exit0 PASS |
| TRAPA/IRQ/RTE | exit1, повтор TRAPA и неверный saved PC | exit0 PASS; дополнительно два frame / два RTE |
| Проигравший SINT | exit1, пропущен первый handler ID | exit0 PASS, typed pending сохранён |
| FP-result boundary на slot-PC | exit1, commit пропущен | exit0 PASS |
| SRAM-end inline slot fetch | exit1, нет H'24 | exit0 PASS, slot не исполняется |

Пробы включены в обязательный SystemExceptionsAcceptance. Red/green журналы — fixes-20261111/.
Новая normal-overlap функциональность проверена после реализации; exploratory reflection-проба
не выдаётся за независимый аппаратный red oracle.

## Проверка последнего исходника

- Полный verify-functional.sh: **22/22 обязательных PASS**, exit0, UTC run 20261111T165510Z.
- System exceptions: **929 сценариев / 1164 проверки PASS** ограниченного объёма.
- Decoder **253/253**, 50 647 552 проверки; CPU **205/205**, 37 992 проверки;
  CPU boundary: 2992 случая / 9634 assertions.
- FPU **56/56**, 6388 form checks; exact/special corpus **2 146 238 PASS**.
- CLI и extension: **PASS**, JDK25.0.5.0.2 / Ghidra12.2 / Gradle9.8.
  Ядро и acceptance используют --release21 на JDK25.
- Реальные BIN, Ghidra с ROM, аппаратура: **NOT_RUN**. Информационный release-gate BLOCKED.

FUNCTIONAL.txt, BUILD_EXTENSION.txt, SYSTEM_CASES.txt содержат фактические протоколы.
Предыдущая версия кода не используется как доказательство актуального PASS.

## Независимое ревью

sh7254r-reviewer независимо скомпилировал актуальные ядро/acceptance, выполнил
SystemExceptionsAcceptance 929/1164 и обе дополнительные slot-пробы. Три HIGH входят
в этот повторный запуск. Полный журнал 22/22 проверен им, но не заявляется как его
независимый повтор всех 22 наборов. Новых доказанных блокирующих Java-дефектов в
проверенном срезе не найдено. **PASS проверенного объёма; FAIL полноты этапа 4.**
Таблица всех 20 критериев: review-20261111/ECUAnalysis_stage4_review_RU.md.

## Не завершено

1. **NOT_IMPLEMENTED:** общий readiness scoreboard, forwarding, ресурсные конфликты,
   несколько outstanding операций и 2-ILP. Нормативные таблицы SW §§8.3/8.6/8.9.8
   имеются; это недописанный код, а не следствие отсутствия нормы о report.
2. **UNVERIFIED:** универсальный condition→CPU-report H'24/H'34, реальный accepted ID
   и saved PC в перекрывающемся pipeline. HW7.6.6 и SW8.9.7 не устанавливают для всех
   V/Z/O/U/I/QIS конкретную фазу обнаружения/доставки. SF/result-ready/конец ED не
   назначены таймером H'34. Для доказательства нужны дополнительные применимые
   первичные свидетельства; приблизительный таймер не является исправлением.
3. **UNVERIFIED:** bus/wait/clock условия H'24, доставка/отзыв IRQ. После SINTR=0
   нужно учитывать HW8.6/table8.5. Наблюдение о stale delivered report зарегистрировано
   отдельно от доказанных HIGH; мгновенное удаление без нормы не реализовано.

Normal completion profile — ограниченный явный вход: один producer и независимый
CPU-only region, затем отдельный FR/FPUL commit без отката GPR/SR/PC/SRAM.
Он не заменяет scoreboard/forwarding/общий scheduler или автоматический report.

[Контракт продолжения этапа 4](../../../docs/SYSTEM_EXCEPTIONS_CONTRACT_RU.md).
Полная приёмка всех 20 критериев не достигнута; к другим компонентам работа не переходила.
