import ecu.independent.Sh2aDecoder;
import static ecu.independent.Sh2aDecoder.*;
import java.util.Objects;
public final class ReviewerDecoderProbe {
 static final Sh2aDecoder d=new Sh2aDecoder();
 static void ok(boolean b,String s){if(!b)throw new AssertionError(s);}
 static void put(byte[] r,int a,int v){r[a]=(byte)(v>>>8);r[a+1]=(byte)v;}
 public static void main(String[] args){
  long checks=0;
  byte[] r=new byte[16];
  for(int address:new int[]{0,2,4,6})for(int disp=0;disp<256;disp++)for(int op:new int[]{0x9000,0xd000,0xc700}){
   put(r,address,op|disp);var i=d.decode(r,address,new DecodeContext(0,false,null,false));
   int expected=(op==0x9000?address+4:((address+4)&~3))+disp*(op==0x9000?2:4);
   ok(Objects.equals(i.referenceAddress(),expected),"pc alignment");checks++;
   for(int target:new int[]{0x100,0x102,0x104,0x106}){
    var slot=d.decode(r,address,new DecodeContext(0,true,target,false));
    expected=(op==0x9000?target+2:((target+2)&~3))+disp*(op==0x9000?2:4);
    ok(Objects.equals(slot.referenceAddress(),expected),"slot pc alignment");checks++;
   }
  }
  for(int mode:new int[]{0,0x80000,0x100000,0x180000})for(int w=0;w<65536;w++)for(int typ:new int[]{0,3,7}){
   put(r,0,w);put(r,2,typ<<12);
   var active=d.decode(r,0,new DecodeContext(mode,false,null,false));
   if(active.status()!=Status.VALID&&active.status()!=Status.UNSUPPORTED_IMPLEMENTATION)continue;
   boolean fpu=(w&0xf000)==0xf000||(w&0xf00f)==0x3001&&(typ==3||typ==7);
   for(int code:new int[]{0x006a,0x005a,0x406a,0x405a,0x4062,0x4052,0x4066,0x4056})fpu|=(w&0xf0ff)==code;
   var standby=d.decode(r,0,new DecodeContext(mode,false,null,true));
   ok(standby.status()==(fpu?Status.ILLEGAL_ENCODING:active.status()),"standby "+Integer.toHexString(w));checks++;
  }
  System.out.println("REVIEWER_DECODER_PROBE: PASS checks="+checks);
 }
}
