# Приёмка этапа 1: декодер

11.11.2026. **DECODER_COMPLETE**, общий **RELEASE_BLOCKED**.

Изменены `src/main/java/ecu/independent/Sh2aDecoder.java` и
`src/main/java/ecu/independent/Sh2aOpcodeExtensions.java`.
Исправлены размеры/признаки памяти MAC, системных передач, групповых передач,
TAS/GBR bit logic и банковых обращений; сохранены операнд и Flow у PREF;
добавлена контекстная проверка PR/SZ/DR/slot/standby; исправлен MOVA immediate
в слоте и мнемоника FMOV.S/D disp12. Код исполнения CPU/FPU не изменён.

## Результаты

- Нормативный инвентарь: 253/253, 229 форм 16 бит + 24 формы 32 бит.
  Покрытие декодирования = 253 / 253 × 100 = **100%**.
- Доказанно допустимых `UNVERIFIED_ENCODING`: **0**.
- CSV: 253 строки по 13 колонкам; повторная генерация `--check` PASS.
- Отдельное извлечение Hardware/SW bitstrings: 253/253 совпадения, 0 конфликтов.
- `NormativeDecoderAcceptance`: **50 647 552 проверки PASS**. Все 65 536 первых
  слов в четырёх сочетаниях PR/SZ; 896 префиксов; все 16 operation nibbles
  продолжения; 50 331 648 полных комбинаций свободных битов всех 24 нормативных
  32-битных форм; проверены operation, mnemonic, flow, target, регистры,
  селекторы, immediate, operandWidth, referenceAddress, pre/post и ограничения.
- `scripts/verify-functional.sh`: **11/11 обязательных групп PASS**, FAIL=0,
  other=0. Дополнительный FMOV PASS; release gate ожидаемо BLOCKED/exit2.
- Финальная сборка ядра: **PASS**, Java21, `scripts/build-core.sh`.
- Финальная сборка расширения: **PASS**, Ghidra12.2, JDK25.0.5+8,
  Gradle9.8.0, `scripts/build-extension.sh`. ROM не загружался.
- `sh7254r-reviewer`: **PASS для декодера**, блокирующих дефектов не найдено.
  Независимо сверены все253 строки аппаратного руководства; проверены контексты
  и независимость тестов. Отдельный `ReviewerDecoderProbe` — **722 042 PASS**,
  включая PC-relative alignment и полный FPU standby sweep.

`DecodeSweep` и `InstructionLengthAcceptance` — структурные регрессии,
не нормативные доказательства. `SemanticsAcceptance` — ограниченная проверка
потребителей, не полная CPU/FPU-семантика. Пропущенных обязательных decoder
проверок нет. Gradle `buildModuleHelp SKIPPED` — отсутствие help-модуля,
не пропущенный тест декодера.

## Воспроизведение

Из корня проекта, с `java`, `javac`, `jar`, `pdftotext` в PATH:

```bash
python3 tools/build-isa-inventory.py --check
bash scripts/verify-functional.sh
bash scripts/build-core.sh
GHIDRA_INSTALL_DIR=/path/to/ghidra_12.2_PUBLIC bash scripts/build-extension.sh
javac -cp build/functional-classes -d build/functional-classes drafts/verification/decoder-stage1/ReviewerDecoderProbe.java
java -cp build/functional-classes ReviewerDecoderProbe
```

Для расширения требуется JDK25 и Gradle>=9.1. Ядро собирается с `--release21`.
Журналы финального прогона находятся в `logs/` рядом с этим протоколом;
исходник независимого probe сохранён рядом. Стандартный functional script
воспроизводит обязательный нормативный перебор с ограничением heap256MiB.

Рабочая копия была доступна в текущем окружении; каталог оператора
`/home/user/work/ECUAnalysis/` здесь не смонтирован. Результат передаётся архивом.
**Следующий этап — исполнение CPU и регистров; в этом задании он не выполнялся.**
