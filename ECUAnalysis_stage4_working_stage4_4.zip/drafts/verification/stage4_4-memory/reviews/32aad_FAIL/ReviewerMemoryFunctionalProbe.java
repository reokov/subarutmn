package ecu.independent;
import java.util.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
import static ecu.independent.SystemExceptionModel.*;
public final class ReviewerMemoryFunctionalProbe {
 static int cases,checks;
 static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static int signed(int raw,int bytes){return bytes==1?(byte)raw:bytes==2?(short)raw:raw;}
 static FirmwareGraph run(AbstractCpu s,int... ops){byte[] r=image(ops[0]);for(int j=0;j<16;j++)w(r,A+j*2,j<ops.length?ops[j]:9);w(r,A+32,0x001b);var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,64,s);return g;}
 static void bytes(FirmwareGraph.CpuSnapshot end,int a,int width,int raw){for(int j=0;j<width;j++)check(Objects.equals(end.ram().get(a+j),(byte)(raw>>>(8*(width-1-j)))),"stored big-endian byte "+j);}
 public static void main(String[] args){
  for(int bit=0;bit<3;bit++)for(boolean alias:new boolean[]{false,true}){
   int width=1<<bit,raw=width==1?0xa1:width==2?0xb234:0xc3456789;cases++;
   var s=initial();s.r[2]=B+16;s.writeRam(B+16,width,raw,A-2);var g=run(s,(alias?0x6224:0x6324)+bit,0x6423);var end=at(g,A+32);
   check(end.registers().get(2)==(alias?signed(raw,width):B+16+width),"postinc load alias/update");
   check(end.registers().get(alias?2:3)==signed(raw,width),"postinc load signed datum");
   check(end.registers().get(4).equals(end.registers().get(2)),"forwarded address/data value");
  }
  for(int bit=0;bit<3;bit++)for(boolean alias:new boolean[]{false,true}){
   int width=1<<bit;cases++;var s=initial();s.r[2]=B+16;s.r[3]=0x89abcdef;var end=at(run(s,(alias?0x2224:0x2234)+bit),A+32);
   check(end.registers().get(2)==B+16-width,"predec pointer");bytes(end,B+16-width,width,alias?B+16:0x89abcdef);
  }
  for(int bit=0;bit<3;bit++)for(int base:new int[]{0,2}){
   int width=1<<bit,raw=width==1?0xa2:width==2?0xb345:0xc456789a;cases++;var s=initial();s.r[base]=B+width;s.writeRam(B,width,raw,A-2);
   var end=at(run(s,0x40cb+(base<<8)+(bit<<4)),A+32);check(end.registers().get(0)==signed(raw,width),"reverse load datum");
   if(base!=0)check(end.registers().get(base)==B,"reverse load pointer");
   cases++;s=initial();s.r[base]=B;s.r[0]=base==0?B:0x98abcdef;end=at(run(s,0x408b+(base<<8)+(bit<<4)),A+32);
   bytes(end,B,width,base==0?B:0x98abcdef);check(end.registers().get(base)==B+width,"reverse store pointer");
  }
  for(int bit=0;bit<3;bit++){
   int width=1<<bit;cases++;var s=initial();s.r[0]=8;s.r[2]=B;s.r[3]=0x98abcdef;
   var end=at(run(s,0x0234+bit,0x042c+bit),A+32);bytes(end,B+8,width,0x98abcdef);check(end.registers().get(4)==signed(0x98abcdef,width),"indexed R0 addressing");
   cases++;s=initial();s.gbr=B;s.r[0]=0x87abcdef;end=at(run(s,0xc001+(bit<<8),0xe000,0xc401+(bit<<8)),A+32);
   bytes(end,B+width,width,0x87abcdef);check(end.registers().get(0)==signed(0x87abcdef,width),"GBR displacement scaling");
  }
  for(boolean pair:new boolean[]{false,true}){
   cases++;int width=pair?8:4;var s=initial();s.fpscr=pair?0x140000:0x40000;s.r[2]=B;s.r[3]=B+32;s.writeRam(B,4,0xcafebabe,A-2);s.writeRam(B+4,4,0x00112233,A-2);
   var end=at(run(s,0xf429,0xf34b,0x6623),A+32);check(end.fr().get(4)==0xcafebabe,"FMOV memory high/single word");if(pair)check(end.fr().get(5)==0x00112233,"FMOV double low word");
   check(end.registers().get(2)==B+width&&end.registers().get(6)==B+width,"FMOV address forwarding");check(end.registers().get(3)==B+32-width,"FMOV predec store");
   bytes(end,B+32-width,4,0xcafebabe);if(pair)bytes(end,B+32-width+4,4,0x00112233);
  }
  cases++;var s=initial();s.fpscr=0x140000;s.r[2]=B+4;var g=run(s,0xf429);
  check(g.systemEvents().stream().anyMatch(x->x.stage()==Stage.GENERATION&&x.event().kind()==Kind.CPU_ADDRESS),"double misalignment H24 generated");
  var entry=at(g,H);check(entry.registers().get(2)==B+4&&entry.fr().equals(Arrays.asList(s.fr)),"fault rollback keeps pointer/FR");
  cases++;var p=new Pipeline();var lds=ps(0x415a,A,0x40000);p.issue(lds,values(lds,1));check(p.ready(ps(0x025a,A+2,0x40000))==1,"existing LDS->STS FPUL reduction masked by resource conflict");
  System.out.println("REVIEWER_MEMORY_FUNCTIONAL_PASS scenarios="+cases+" assertions="+checks);
 }
}
