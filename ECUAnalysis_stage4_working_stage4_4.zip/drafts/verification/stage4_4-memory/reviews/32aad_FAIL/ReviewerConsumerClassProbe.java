package ecu.independent;
import static ecu.independent.SystemExceptionModel.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
public final class ReviewerConsumerClassProbe {
 public static void main(String[] args){
  var load=ps(0xf428,A,0x140000);var p=new Pipeline();p.issue(load,values(load,1));
  var singleAdd=ps(0xf540,A+2,0x140000);long next=p.ready(singleAdd);
  System.out.println("FMOV.D @R2,DR4 -> FADD FR4,FR5 PR0/SZ1: reads="+singleAdd.reads()+" ready="+next+" expected3");
  if(next!=3)throw new AssertionError("SWtable8.1 note4: two separate single-FR operands do not become one DR source; max(even2,odd3)=3");
 }
}
