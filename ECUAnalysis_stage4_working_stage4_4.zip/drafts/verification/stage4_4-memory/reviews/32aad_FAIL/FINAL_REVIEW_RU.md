# Внутреннее ревью memory iteration этапа4.4

12.11.2026. Snapshot **stage4_4-20261112-32aad3c45347**.

**FAIL текущего memory subset: два воспроизводимых дефекта readiness.**
Полнота этапа4: **FAIL / IN_PROGRESS**. Проект: **RELEASE_BLOCKED**.
Внутреннее самостоятельное ревью subagent; не внешнее ревью другой системой.
Production/docs/tests ревьювером не изменялись.

## Backup и целостность

До review подтверждён persistent backup с обратным получением пары ZIP.
`drafts/verification/stage4_4-memory/BACKUP_RETRIEVAL.json` сообщает PASS whole SHA
и internal manifests. Ревьювер отдельно сравнил73 source bytes возвращённого
working ZIP с source manifest: mismatch0.

Source manifest SHA-256:
`32aad3c453479e47aa1c7967f397762c562830a889ef087e9cd4cb2226014799`.
Все73 строки сверены до и после review: **73/73 OK**.
`source_changed_during_review=[]`; `integrity.json`.
Предыдущие a967/0d76 verdict не подменяют проверку текущего snapshot.

## Новые доказанные блокеры проверяемого memory subset

### M1 — неверная классификация DR consumer

**MEDIUM, blocker нормативного readiness.**
SystemExceptionModel.java:104–108, `PipelineSpec.readLatency()`.
Наличие двух соседних FR в read-set ошибочно считается одним DR source.
Но `FADD FR4,FR5` при PR0 использует два отдельных single операнда, даже если SZ1.

Первичное основание: SW Rev3 table8.1 p376, note4 p377: у memory-loaded DR
раздельно предусмотрены single even latency2, single odd3 и double-register4.
Для single FADD, читающей FR4 иFR5, нужно max(2,3)=3.

Независимая `ReviewerConsumerClassProbe.java`:
`FMOV.D @R2,DR4 → FADD FR4,FR5 (PR0,SZ1)` выдаёт **ready4 вместо3**.
`consumer-class-red.log` и повтор `consumer-class.log`: exit1.

Минимальное исправление: явно хранить semantic double-source operand/group
consumer; не выводить DR usage из пересечения множеств соседних FR.

### M2 — готовый EX/address result сдвигается из-за последующего MA stall

**MEDIUM, blocker нормативного readiness.**
SystemExceptionModel.java:250, общая формула
`finish - resultOffset + registerLatency`.

Первичное основание: SW table8.1 p367 — predecrement store address latency1;
§8.9.1(7), pp385–386 — EX/MA store, address calculation относится к EX.
Раздельные EX/address и MA/memory результаты нельзя привязывать к одному final finish.

Независимая `ReviewerAddressForwardingProbe.java`:

| Событие | Фактическое значение |
|---|---:|
| Предыдущая FMOV.D load issue | 0 |
| CPU MOV.L R5,@-R3 issue | 1 |
| CPU store EX/address phase | 2 |
| CPU store MA, после resource stall | 4 |
| Consumer MOV R3,R6 ready текущего кода | **3** |
| Consumer boundary для address latency1 | **2** |

`address-forwarding-red.log` и повтор `address-forwarding.log`: exit1.
MA stall не должен переносить forwarding уже выполненного EX результата.
Это не требование сокращать CPU load address latency2 или делать architectural
commit pointer раньше подтверждённой границы.

Минимальное исправление: готовность отдельных результатов должна опираться на
фактическую производящую фазу того же stage engine, с copy/forecast/rollback.

## Отдельное ранее существовавшее замечание

**MEDIUM, вне новых memory changes:** SWAP.B/SWAP.W/XTRCT profiles не резервируют SHIFT.
SW8.9.1(3) p380 прямо указывает использование shifter.
`ReviewerShiftClassProbe.java`: SWAP.B R1,R2 → SHLL2 R4 даёт ready0 вместо1;
`shift-class.log` exit1. Первый контрпример достаточен; последующие опкоды этого
probe после assertion не выполнялись. Это не новая ошибка memory delta.

Предположение о чрезмерно широком FPUL→CPU latency−2 guard для старого LDS FPUL
не подтверждено как текущий runtime defect: LDS→STS остаётся ready1 из-за
структурных ограничений, что отдельно проверено. Гипотеза не названа HIGH.
MEMORY pseudo-register ordering отдельно не проходило полное нормативное review.

## Самостоятельно выполненные проверки

| Проверка | Результат |
|---|---|
| Fresh compile core/tools, JDK21 `--release 21 -Xlint:all` | PASS, warnings/errors нет |
| PipelineStage44Acceptance | **52 scenarios /109 assertions PASS** |
| SystemExceptionsAcceptance | **962 scenarios /1241 checks PASS** |
| ReviewerExtraCpuProbe | **34 forms /1582 cases /18524 assertions PASS** |
| Собственная ReviewerMemoryFunctionalProbe | **34 scenarios /109 assertions PASS** |
| DR consumer classification probe | **FAIL M1** |
| EX/address forwarding with MA stall probe | **FAIL M2** |
| Pre-existing SHIFT resource probe | **FAIL отдельного замечания** |

Собственный executor probe проверяет byte/word/long load postincrement с m=n и m≠n,
store predecrement с alias/source capture, reverse load/store с R0 alias,
indexed и GBR displacement scaling, scalar/double FMOV update/store/load,
misalignment H24 и сохранение pointer/FR при rollback.

Функциональные значения проверенных memory операций верны. M1/M2 — ошибки
pipeline admission/timing; numerical corruption либо аппаратная ECU проверка
не заявляются. Все текущие acceptance PASS не опровергают независимые counterexamples.
Полный25-suite run и Ghidra extension build выполнял основной агент, не ревьювер.
Реальные ROM, Ghidra с BIN и физический ECU не запускались.

## Полнота и границы проверки

Текущая инвентаризация172 registered profiles/253 не является normative coverage.
81 отсутствующий profile остаётся NOT_IMPLEMENTED. ED/E1 handoff/backpressure и
physical H24/H34 report/saved-PC остаются UNVERIFIED.

Полная consumer-specific матрица, все сочетания алиасов/32-bit/resource constraints,
остальные system/bank/multiple-memory families и общее exception cancellation/resume
в этой проверке не закрывались: **NOT_REVIEWED / NOT_IMPLEMENTED по контракту**.
Дополнительное расширение на новые feature families не выполнялось.
Все20 критериев сохраняются; SYSTEM_EXCEPTIONS_COMPLETE запрещён.

Проверка frozen32aad завершена. Новые исходники после возможных исправлений
этим FAIL/PASS не подтверждаются; обязательный backup gate должен соблюдаться заново.

## SHA-256 проверенного Java-среза

```text
a8cb6995143a4d37e0b520216b079fdb574c6fe29b56b2f66f0502029b6536e1  src/main/java/ecu/independent/SystemExceptionModel.java
fd2d75c87320ba460e58472412f82b4dc3b3f7af49f87795552abbfca2a36df5  src/main/java/ecu/independent/FirmwareGraph.java
88cfd372e09ba59a8f3c1f65bfdf19fd95e3295253d59fcb702ed72cae0938d5  tools/PipelineStage44Acceptance.java
```

Доказательства: `results.json`, `integrity.json`, `source-before-sha256.txt`,
source-before/after-check logs и `REVIEW_EVIDENCE_SHA256.txt` в этом каталоге.
