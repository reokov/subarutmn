package ecu.independent;
import static ecu.independent.SystemExceptionModel.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
public final class DeveloperAddressStageProbe {
 public static void main(String[] args){
  var p=new Pipeline();var a=ps(0xf428,A,0x140000);p.issue(a,values(a,1));
  var b=ps(0x2346,A+2,0x140000);System.out.println("second store issue="+p.ready(b));p.issue(b,values(b,2));
  long t=p.ready(ps(0x6533,A+4,0x140000));System.out.println("address ready="+t+" expected2 (EX2, MA waits for slot4)");
  if(t!=2)throw new AssertionError("MA hold must not postpone already available EX address");
 }
}
