package ecu.independent;
import static ecu.independent.SystemExceptionsAcceptance.*;
import static ecu.independent.SystemExceptionModel.*;
public final class ReviewerShiftClassProbe {
 public static void main(String[] args){
  for(int op:new int[]{0x6218,0x6219,0x221d}){var p=new Pipeline();var first=ps(op,A,0x40000);p.issue(first,values(first,1));long ready=p.ready(ps(0x4408,A+2,0x40000));System.out.println(Integer.toHexString(op)+" -> SHLL2 ready="+ready);if(ready!=1)throw new AssertionError("SW8.9.1(3)p380 SWAP.B/W/XTRCT share shifter");}
 }
}
