package ecu.independent;
import java.util.*;
import static ecu.independent.SystemExceptionModel.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
public final class ReviewerAddressForwardingProbe {
 public static void main(String[] args){
  var p=new Pipeline();var first=ps(0xf428,A,0x140000);p.issue(first,values(first,1));
  var store=ps(0x2356,A+2,0x140000);long issue=p.ready(store);p.issue(store,values(store,1));
  long read=p.ready(ps(0x6633,A+4,0x140000));
  p.advance(4);
  long ex=p.steps().stream().filter(x->x.pc()==A+2&&x.stage()==PipelineStage.CPU_EX).mapToLong(PipelineStep::slot).findFirst().orElseThrow();
  long commit=p.steps().stream().filter(x->x.pc()==A+2&&x.stage()==PipelineStage.RESULT_COMMIT).mapToLong(PipelineStep::slot).findFirst().orElseThrow();
  System.out.println("double FMOV load -> CPU predec store: issue="+issue+" EX="+ex+" result="+commit+"; address consumer ready="+read+" expected2");
  if(issue!=1||ex!=2||commit!=4||read!=2)throw new AssertionError("SWtable8.1 predec Rn latency1 belongs to EX address, not stalled memory-result completion");
 }
}
