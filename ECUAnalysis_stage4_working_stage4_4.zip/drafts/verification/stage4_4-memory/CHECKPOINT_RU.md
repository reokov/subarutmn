# ECUAnalysis — контрольная точка продолжения

12.11.2026. `stage4_4-20261112-e87c1b136568`. **IN_PROGRESS / RELEASE_BLOCKED**.

Продолжение подтверждённого a96749fd281b (73/73 source SHA совпали до правок).
Не восстановленные bytes утраченного59c7: его восстановление RESTORE_BLOCKED, требуется
исходный рабочий ZIP stage4_4-20261111-59c7ff9175af с source manifest.

Изменены SystemExceptionModel.java и FirmwareGraph.java, acceptance и build/check scripts.
Добавлены CPU auto-update/reverse/indexed/GBR и scalar/double FMOV memory profiles.
Раздельные register/consumer latencies, MA/FP_LS reservations, effective-address guard.
Review32aad M1/M2 исправлены: явные DR-sources и готовность по фактической стадии;
SWAP/XTRCT резервируют SHIFT.
E1/ED/return, branch/slot/RTE и BF/BT сохранены.
См. docs/PIPELINE_STAGE4_4_RU.md и SOURCE_SHA256.txt. Не все profiles завершены.

Текущие проверки: compile PASS; functional **PASS 25/25 listed mandatory groups**; review **NOT_RUN current corrected snapshot; 32aad FAIL historical, M1/M2 and SHIFT corrected**.
Реальные BIN/ECU/Ghidra с BIN NOT_RUN. Исторические24/24 и результаты утраченного59c7
не относятся к этому snapshot. Новые журналы отдельно от исторических.

Незакрытое: full profile/consumer-latency matrix; multiple memory,
MUL/DIV/MAC/system/bank/TRAPA/SLEEP profiles; general pipeline exception entry/cancel/resume.
UNVERIFIED: ED/E1 interstage buffering/backpressure и physical H24/H34 report/accepted PC.
Следующая независимая реализация: memory FPU system-register transfers и FSCHG,
после current review и исправления доказанных замечаний.

Резервная пара: ECUAnalysis_stage4_working_stage4_4-20261112-e87c1b136568.zip и
ECUAnalysis_stage4_evidence_stage4_4-20261112-e87c1b136568.zip; при финальном review второй называется review_evidence.
Для operator download пары нужен persistent upload receipt; он подтверждается в ответе
оператору. До подтверждения НЕ ВЫЗЫВАТЬ reviewer.

Восстановление: unzip рабочий ZIP в пустое дерево, sha256sum -c MANIFEST.sha256 и
sha256sum -c SOURCE_SHA256.txt; затем JDK21+ в PATH, bash scripts/verify-functional.sh.
Extension build: JDK25+, Ghidra12.2, Gradle9.1+; GHIDRA_INSTALL_DIR задаётся оператором.
Рабочий архив не содержит ECU BIN, toolchains, credentials или закрытых .codex configs.
