# Независимоеreview2369a2092ab3 — FAIL (историческийparent)

HIGH:SystemExceptionModel.ready265–268 используетissued+executionStates
вместо actual-stage progress после MAwait.
FMOV.D@R2,DR4 ID0; LDC.L@R3+,SR ID1; actualEX2/WAIT_MA3/MA4/EX5/EX6/EX7;
ноNOPдопускалсяID5 вместоID6. Независимыеhelper/integration REDexit1.
SW8.3.4(2–3)pp347–348 и8.9.6(5)p426.
SHA73entriesverified; JDK25compilePASS; target362/570PASS; System962/1241PASS;
предыдущие4flagsprobesPASS; FSCHGdiagnosticsPASS. ЭтиPASSнеустраняютHIGH.
Mask/windowотдельногоcodeFAILневыявил; physicalINTCsyncUNVERIFIED.
Productionreviewerнеизменял.
