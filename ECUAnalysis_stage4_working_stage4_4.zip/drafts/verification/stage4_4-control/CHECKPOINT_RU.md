# ECUAnalysis — восстановимая контрольная точка этапа4.4

`stage4_4-20261112T020246Z-28d5e0efda14`. **IN_PROGRESS / RELEASE_BLOCKED**.
Источник: `stage4_4-20261112-e87c1b136568`, source manifest `e87c1b13656871060126339356f64f559c6b74c4e28b7e894e68faf67eb0a759`.
Текущий source manifest: `28d5e0efda142e388ffbf18c78844b9c391ef83bbb35f9f04dd443aba079fa51`, entries=73.
Это продолжение подтверждённого e87, а не реконструкция утраченного59c7.

Группа: memory FPUL/FPSCR transfers + FSCHG SZ dependencies.
Численные CPU/FPU/decoder не изменялись. Pipeline остаётся тем же production scheduler.
Текущие compile=PASS current full core/tools --release21 -Xlint:all; functional=PASS 25/25 listed mandatory groups; extension=PASS; review=NOT_RUN.
Наличие PROFILE_PRESENT не означает полный функциональный PASS; inventory содержит253 формы.
См. docs/STAGE4_4_CONTROL_RESULT_RU.md, profile-inventory.tsv и NEW_PROFILE_FORMS.tsv.

Следующее независимое требование: multiple memory и оставшиеся memory/control transfers;
затем MUL/DIV/MAC/system/bank/TRAPA/SLEEP, общая 2-ILP и exception matrix.
UNVERIFIED: ED/backpressure/capacity, physical H24/H34 condition→CPU report и некоторые savedPC.
Это не причина останавливать независимую реализацию профилей.
Реальные ROM/ECU/Ghidra с BIN NOT_RUN.

Перед reviewer обязательны постоянное сохранение обоих ZIP, receipts, повторное получение
и SHA/manifest verification. Локальные ZIP не являются подтверждённой резервной копией.
Пара: ECUAnalysis_stage4_working_stage4_4-20261112T020246Z-28d5e0efda14.zip и
ECUAnalysis_stage4_evidence_stage4_4-20261112T020246Z-28d5e0efda14.zip (после review — review_evidence).
Без successful persistent verification reviewer не вызывается: BACKUP_BLOCKED.

Восстановление: распаковать working в пустую папку, проверить MANIFEST.sha256 и SOURCE_SHA256.txt.
Сборка: JDK25/Ghidra12.2, source scripts/env-java25-ghidra12.2.sh, bash scripts/verify-functional.sh.
SDK, реальные BIN и приватные конфигурации в архивах отсутствуют.
