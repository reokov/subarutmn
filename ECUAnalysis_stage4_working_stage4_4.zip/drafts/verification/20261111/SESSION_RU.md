# Контрольная точка автономной разработки — 11.11.2026

**IN_PROGRESS / RELEASE_BLOCKED. READY_TO_RUN универсального эмулятора не достигнут.**
Работа выполнена над приложенным ECUAnalysis.zip. Пользовательский каталог
`/home/user/work/ECUAnalysis/` в этой среде не смонтирован; его изменение не заявляется.
В архиве отсутствуют AGENTS.md и конфигурация OpenCode. Соблюдены инструкции текущего
поручения; agents/*.md и конфигурация не изменялись.

## Выполненные изменения

| Требование | Первичный источник, условия | Реализация и доказательство |
|---|---|---|
| Компилируемый FPU dispatch | Синтаксис Java21; прежняя frozen-семантика не менялась | FirmwareGraph.fpuFrozenExecute: две arrow-ветки с return обёрнуты блоками. Исходный архив воспроизводимо не компилировался |
| R-CPU-002, PC-relative delay slot | REJ09B0051-0300 Rev3 §§6.4.31 с219–221,6.4.34 с228; доказанная цель выполненного delayed transfer | Sh2aDecoder.pcRelativeSlot → FirmwareGraph delay dispatch → execute MOV_PC/MOVA → loadState/reference. База target+2, затем &~3 для longword/MOVA и масштаб disp8 |
| RTS target snapshot | Тот же документ §6.4.49 с246–247 | FirmwareGraph снимает PR до исполнения слота; JMP тест также перезаписывает target-регистр в слоте, не меняя выбранную цель |
| R-CPU-004, normal FPU enable traps | §§6.5.2/4/6/11/13/18; check_single/double_exception с83–84: O/U/I normal trap независимо от реального cause. FSQRT §6.5.16 с312 — I; FLOAT §6.5.10 с296–297 — I только PR0 | FpuSemantics.finish получает mask по операции; FCNVDS normal путь аналогичен. exceptionGenerated обновляет фактический Cause (возможен0), сохраняет sticky Flag, ставит pending, не пишет destination |
| FDIV zero/zero | §6.5.6 с289–292, invalid(0/±0), не divide-by-zero | При V enable генерируется V; иначе явный fail-closed, неподтверждённый disabled-invalid результат не выдумывается |
| FSQRT signed zero | §6.5.16 с312, PZERO/NZERO обходят normal_fsqrt | Сохраняются raw bits ±0, очищается Cause; normal-path I trap не применяется |
| FCNVSD/FCNVDS ±0 | §§6.5.4 с284–285 и6.5.5 с287–288 | Знак сохраняется при RM0/1; FCNVDS учитывает O/U/I normal trap |
| FCNVSD denormal input | §6.5.5 с288, fpul_type, DN1→signedzero, DN0→DENORM | DN1 flush с сохранением знака; DN0 останов FCNVSD_DENORMAL_INPUT_NOT_PROVED, не Java-cast в нормализованный double |
| STBCR read path | R01UH0480EJ0400 Rev4 §§29.3.1–29.3.2 с1425–1428 | Восемь прежних сценариев decode→execute→loadState→loadStbcr→CPU прошли. В тесте исправлена только длина диагностического hex с6 на8 цифр; аппаратные ожидания и YES/NO guards сохранены |
| CLI и экспорт | Синтетический исследовательский режим, без физических источников | StandaloneCliAcceptance запускает фактический собранный JAR дважды, проверяет SHA, точные2 инструкции, отсутствие truncation/CONFIRMED_CODE, два отчёта и неизменность input |
| Машинный ISA реестр | Структура CSV, не полнота нормативного набора | В11 строках отсутствовало пустое поле second_value: колонки сдвигались. Исправлена сериализация35 строк, маски/значения/статусы не повышались. scripts/verify-isa-catalog.py проверяет структуру |
| Актуальность вывода | Фактическая интеграция | ReportWriter metadata больше не утверждает отсутствие автоматического SINT/STBCR; tests явно относится к текущему invocation анализа |

## Фактически выполненные проверки

- Исходная компиляция: FAIL в двух arrow-return; сохранён исходный журнал.
- После минимального синтаксического исправления: COMPILE_PASS,6/7 обязательных PASS,
  STBCR marker FAIL; отладкой независимо подтверждено значение0 и MMIO чтение,
  несовпадение было только0x000000 против0x00000000.
- Итоговый `scripts/verify-functional.sh`: **10/10 обязательных групп PASS,0 FAIL**.
  `decode-sweep`327680 пар, `instruction-length`65536 первых полуслов, `semantics`47
  ограниченных проверок; остальные группы и ограничения перечислены в logs/functional-latest.txt.
- PC-relative:28 синтетических сценариев; RTE/BRAF/BSRF этим новым набором не проверены.
- FPU normal trap, signedzero, DN1/DN0, zero FDIV/FSQRT и potential H34 integration PASS.
- FMOV disp12 дополнительная информационная группа PASS.
- `scripts/build-core.sh`: PASS; обновлён artifacts/ecu-analysis-cli-unreleased.jar.
- `scripts/build-extension.sh`: **BLOCKED/exit2**, Ghidra12.2 отсутствует.
- `scripts/verify-isa-catalog.py`: PASS35 строк, только схема, не semantic oracle.
- `FullCoverageReleaseGate`: ожидаемый **BLOCKED/exit2**, не PASS.
- Реальные firmware/* не запускались. Ghidra с ROM, ECU и внешние симуляторы NOT_RUN.

Среда: OpenJDK21.0.13. В системной поставке не было launcher javac/jar иct.sym;
для выполнения исходных --release21 сборочных скриптов использованы локальные launchers
штатных модулей jdk.compiler/jdk.jartool иct.sym из Debian OpenJDK21.0.13+9.
Параметры исходной сборки не ослаблялись, глобальная Java/OpenCode не менялась.
Даты stdout среды сохранены буквально; пользовательская дата сессии11.11.2026.

## Независимое ревью

Штатный вызов `opencode run --agent code-reviewer` невозможен: executable отсутствует,
exit127; журнал logs/opencode-review-attempt.txt. **OPEN_CODE_REVIEW_BLOCKED**.
Использован независимый субагент доступной среды `code_reviewer`, только чтение;
его PASS относится к заявленным изменениям, не всему проекту и не штатной приёмке OpenCode.
Протоколы ревью: REVIEW_RU.md. Собственная оценка не выдаётся за независимый PASS.

## Блокеры и точная следующая задача

1. **R-ISA-001:** завершить первичный декларативный каталог допустимых16/32-битных
   кодировок по таблицам5.3–5.11 и§6 Software Manual. Начать с полного16-битного
   набора: записать mask/value/status/source/режим/семантику, затем сопоставить
   все65536 слов с декодером. Диагностические predicate-строки существующего CSV
   не считать opcode-строками. Любое отличие — нормативно разобрать, не заменять
   UNKNOWN на illegal без основания. Это ближайшая независимая задача.
2. FPU: полноценные NaN/Inf/denormal, disabled-invalid, overflow/underflow и округление
   остаются неполными. Новые normal masks не закрывают эти пути.
3. События: точный pipeline, IRQ/NMI арбитраж, принятие H34, nested/bank overflow,
   unknown/nontaken conditional PC-relative processing требуют дальнейшей реализации.
4. Нет полного CPU+таймеры/WDT/CPG/ADC/ATU/DMA/A-DMAC/RCAN и их программных эффектов.
5. Не завершены доказанные калибровки и XML. Текущий CLI — абстрактное исследование.
6. Нет текущей сборки/загрузки Ghidra12.2; независимая аппаратная/симуляторная сверка
   требует внешней среды и отдельного разрешения. Эти условия не заменяются синтетикой.

Новый запуск синтетических проверок после установки JDK21: `bash scripts/verify-functional.sh`.
Проверка CSV: `python3 scripts/verify-isa-catalog.py`.
Воспроизведение фактически проверенного CLI: сначала build-core и verify-functional;
путь синтетического input и output записан в logs/standalone-cli.out. В пределах корня:
`java -jar build/ecu-analysis-cli-unreleased.jar <synthetic_input> <new_output> --limit 16`.
Команда для реального ROM не проверялась и здесь не выдаётся как готовый сценарий.

Исторические документы сохранены в drafts/history. Эталонные inputs/firmware/XML,
agents/*.md и конфигурация не изменялись. Git-коммит не создавался: в архиве нет .git.
