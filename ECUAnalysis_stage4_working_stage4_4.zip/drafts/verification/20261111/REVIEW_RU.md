# Независимое ревью изменений

11.11.2026. Независимый субагент `code_reviewer`, только чтение, доступный механизм
среды ChatGPT Work. Это не запуск штатного OpenCode; он недоступен, executable opencode
отсутствует. OPEN_CODE_REVIEW_BLOCKED сохранён. Git diff не заявляется: сравнение с
первоначальными файлами из приложенного ZIP и контрольными копиями исходников.

| Группа | Независимый вывод | Подтверждённая граница |
|---|---|---|
| Два arrow-return в frozen FPU dispatch | PASS | Добавлены только Java-блоки, исходная семантика не менялась |
| STBCR диагностические hex markers | PASS | Различие6/8 цифр, ожидаемые аппаратные значения и YES/NO ветви сохранены |
| PC-relative delay slots | PASS | destination+2, затем alignment; контекст достигает execute/loadState. PR и JMP target сняты до слота. Неизвестные/nontaken conditional случаи остановлены |
| Упакованный CLI | PASS | Подпроцесс настоящего JAR, синтетические данные, SHA/два отчёта/неизменный input, без firmware/* |
| FPU normal traps и signed zeros | PASS | OUI/I masks по инструкции, cause0 не подменён enable, stickyflags сохранены, destination на trap не меняется |
| FDIV0/0, FSQRT±0, FCNVSD denormal DN1/DN0 | PASS | Проверены по первичным§6.5.6 с289–290,§6.5.16 с312,§6.5.5 с288 |

Доказанные замечания, учтённые при работе:

- Для BF/S/BT/S nottaken и unknown T нельзя применять taken-target PC к общему слоту.
  Оставлен консервативный останов; IRQ timing не ослаблялся по неоднозначной норме.
- Номера разделов исправлены: RTS6.4.49, FADD6.5.2, FMUL6.5.13, FSUB6.5.18.
- Добавлены отдельные guards unknown T/nontaken PC-relative slots (28 сценариев).
- Первоначальный новый H34 тест ошибочно требовал детерминированного принятия на
  первой следующей инструкции. Исправлен по нормативной границе: potential H34 edge
  и явная диагностическая неопределённость. Системный pipeline не изменён.
- Предшествующий дефект FCNVSD subnormal исправлен: DN1→signedzero, DN0→fail-closed.

Ревьювер прочитал актуальный functional-latest:10/10mandatoryPASS, FMOVinfoPASS,
release gateBLOCKED. PASS относится только к перечисленным изменениям. Полнота
ISA/FPU, hardware equivalence, периферия, Ghidra и точное принятие событий не приняты.

Финальная проверка документации/CSV/metadata: **scoped PASS**. Ревьювер независимо
сравнил35 строк с исходным ZIP: только11 вставок пустого second_value и notes трёх
явно перечисленных групп. Маски/value/status/source не сдвинуты. Документы различают
core/extension, synthetic/real, potential H34 и доступный reviewer/OpenCode.
Ссылка REVIEW_RU.md закрыта созданием этого протокола перед упаковкой.
