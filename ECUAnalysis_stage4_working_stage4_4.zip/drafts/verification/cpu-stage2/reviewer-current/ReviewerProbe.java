package ecu.independent;
public class ReviewerProbe {
 public static void main(String[] args) {
 byte[] rom=CpuExecutionAcceptance.image();
 CpuExecutionAcceptance.word(rom,0x100,0xc320);
 CpuExecutionAcceptance.word(rom,0x400,0x001b);
 AbstractCpu s=CpuExecutionAcceptance.initial();s.vbr=CpuExecutionAcceptance.B;
 CpuExecutionAcceptance.memory(s,CpuExecutionAcceptance.B+0x80,4,0x400);
 FirmwareGraph g=CpuExecutionAcceptance.graph(rom,s);
 System.out.println("TRAPA SRAM handler reached="+g.cpuStates().stream().anyMatch(x->Integer.valueOf(0x400).equals(x.pc())));
 System.out.println(g.cpuBoundaries());System.out.println(g.report());
 }
}
