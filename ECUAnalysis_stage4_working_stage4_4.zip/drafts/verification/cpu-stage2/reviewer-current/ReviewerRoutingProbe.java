package ecu.independent;
import static ecu.independent.CpuExecutionAcceptance.*;
import java.util.*;
public class ReviewerRoutingProbe {
 static int checks;
 static void yes(boolean v,String l){if(!v)throw new AssertionError(l);checks++;}
 static boolean reaches(FirmwareGraph g,int a){return g.cpuStates().stream().anyMatch(x->Objects.equals(x.pc(),a));}
 static FirmwareGraph run(AbstractCpu s,int code){byte[] rom=image();word(rom,A,code);word(rom,A+2,0x001b);longword(rom,0x44,0x400);longword(rom,0x48,0x500);word(rom,0x400,0x001b);word(rom,0x500,0x001b);return graph(rom,s);}
 public static void main(String[] args){
  for(boolean signed:new boolean[]{false,true}){AbstractCpu s=initial();s.r[0]=0;FirmwareGraph g=run(s,signed?0x4194:0x4184);yes(reaches(g,0x400),"DIV0 handler");yes(!reaches(g,A+2),"DIV0 cannot retire");var q=at(g,0x400);yes(q.registers().get(1)==s.r[1],"DIV fault preserves dividend");}
  AbstractCpu s=initial();s.r[0]=-1;s.r[1]=Integer.MIN_VALUE;var g=run(s,0x4194);yes(reaches(g,0x500)&&!reaches(g,A+2),"signed overflow exception only");
  for(int divisor:new int[]{1,2,-2}){s=initial();s.r[0]=divisor;s.r[1]=null;g=run(s,0x4194);yes(!reaches(g,0x400)&&!reaches(g,0x500)&&reaches(g,A+2),"nonzero nonMIN divisor excludes exceptions");}
  s=initial();s.r[0]=null;g=run(s,0x4094);yes(reaches(g,0x400)&&!reaches(g,0x500)&&reaches(g,A+2),"DIVS R0 alias no overflow");
  for(int handler:new int[]{0x400,B+0x400}){
   s=initial();s.vbr=B;memory(s,B+0x80,4,handler);byte[] rom=image();word(rom,A,0xc320);word(rom,0x400,0x001b);memory(s,B+0x400,2,0xe12a);memory(s,B+0x402,2,0x001b);
   g=graph(rom,s);yes(reaches(g,handler),"TRAPA relocatable table/handler");var q=at(g,handler);yes(q.registers().get(15)==SP-8,"trap pushes 8");int saved=0;for(int j=0;j<4;j++)saved=(saved<<8)|(q.ram().get(SP-8+j)&255);yes(saved==A+2,"trap saved continuation");if(handler<0)yes(at(g,handler+2).registers().get(1)==42,"SRAM handler decode execute");
  }
  for(int address:new int[]{0x1000,0x00800000,0x20000000}){s=initial();s.r[1]=address;g=run(s,0x2122);yes(!reaches(g,A+2),"unknown flash/external effect no retirement");yes(g.cpuBoundaries().stream().anyMatch(x->x.kind().equals("UNMODELED_MEMORY_WRITE")),"explicit unresolved write boundary");}
  System.out.println("REVIEWER_ROUTING_PROBE PASS assertions="+checks);
 }
}
