package ecu.independent;
import static ecu.independent.CpuExecutionAcceptance.*;
public class ReviewerSystemProbe {
 static int checks;
 static void check(boolean v,String label){if(!v)throw new AssertionError(label);checks++;}
 public static void main(String[] z){
  int[] stores={0x4003,0x4013,0x4023,0x4002,0x4012,0x4022};
  int[] loads={0x4007,0x4017,0x4027,0x4006,0x4016,0x4026};
  for(int kind=0;kind<6;kind++)for(int n=0;n<16;n++){
   AbstractCpu s=initial();s.r[n]=B;s.writeSr(0x63f3);int val=switch(kind){case 0->0x63f3;case 1->s.gbr;case 2->s.vbr;case 3->s.mach;case 4->s.macl;default->s.pr;};
   byte[] rom=image();word(rom,A,stores[kind]|(n<<8));word(rom,A+2,0x001b);var o=at(graph(rom,s),A+2);
   check(o.registers().get(n)==B-4,"predecrement");int mem=0;for(int j=0;j<4;j++)mem=(mem<<8)|(o.ram().get(B-4+j)&255);check(mem==val,"stored source");
   s=initial();s.r[n]=B;memory(s,B,4,0x6abc1234);rom=image();word(rom,A,loads[kind]|(n<<8));word(rom,A+2,0x001b);o=at(graph(rom,s),A+2);
   check(o.registers().get(n)==B+4,"postincrement");int got=switch(kind){case 0->o.sr();case 1->o.gbr();case 2->o.vbr();case 3->o.mach();case 4->o.macl();default->o.pr();};
   check(got==(kind==0?0x6abc1234&0x63f3:0x6abc1234),"loaded target");
  }
  System.out.println("REVIEWER_SYSTEM_PROBE PASS assertions="+checks);
 }
}
