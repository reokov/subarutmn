package ecu.independent;
import java.math.BigInteger;
import java.util.*;
import static ecu.independent.CpuExecutionAcceptance.*;
public class ReviewerAliasProbe {
 static int count;
 static void test(boolean b,String msg){if(!b)throw new AssertionError(msg);count++;}
 static FirmwareGraph.CpuSnapshot run(AbstractCpu s,int code){byte[] rom=image();word(rom,A,code);word(rom,A+2,0x001b);return at(graph(rom,s),A+2);}
 public static void main(String[] args){
 // All endpoint encodings for multiple-transfer. Norm SW6.3.23-24 pp133-138.
 for(boolean upper:new boolean[]{false,true})for(int n=0;n<16;n++){
  AbstractCpu s=initial();int low=upper?n:0,high=upper?15:n,k=high-low+1;
  int push=0x4000|(n<<8)|(upper?0xf0:0xf1);
  var p=run(s,push);test(p.registers().get(15)==SP-k*4,"push SP");
  for(int r=low;r<=high;r++){
   int addr=SP-(high-r+1)*4,exp=r==15?s.pr:s.r[r],val=0;
   for(int j=0;j<4;j++)val=(val<<8)|(p.ram().get(addr+j)&255);
   test(val==exp,"push ordering n="+n+" r="+r);
  }
  s=initial();for(int r=low;r<=high;r++)memory(s,SP+(r-low)*4,4,0x77700000+r);
  var q=run(s,0x4000|(n<<8)|(upper?0xf4:0xf5));
  test(q.registers().get(15)==SP+k*4,"pop SP");
  for(int r=low;r<=high;r++)test((r==15?q.pr():q.registers().get(r))==0x77700000+r,"pop ordering");
 }
 // MAC alias including R15, both sizes, signed extremes, upper MACH preservation SW6.4.28-29.
 for(int r=0;r<16;r++)for(int w:new int[]{2,4})for(boolean sat:new boolean[]{false,true}){
  AbstractCpu s=initial();s.r[r]=B;s.mach=0xabcd8000;s.macl=0xfffffff0;s.saturation=sat;
  int x=w==2?-32768:Integer.MIN_VALUE,y=w==2?32767:Integer.MAX_VALUE;
  memory(s,B,w,x);memory(s,B+w,w,y);
  var q=run(s,(w==2?0x400f:0x000f)|(r<<8)|(r<<4));
  test(q.registers().get(r)==B+2*w,"MAC alias address r"+r);
  BigInteger product=BigInteger.valueOf(x).multiply(BigInteger.valueOf(y));
  BigInteger acc=sat&&w==2?BigInteger.valueOf(s.macl):sat?BigInteger.valueOf((short)(int)s.mach).shiftLeft(32).add(BigInteger.valueOf(Integer.toUnsignedLong(s.macl))):BigInteger.valueOf(s.mach).shiftLeft(32).add(BigInteger.valueOf(Integer.toUnsignedLong(s.macl)));
  BigInteger sum=acc.add(product);int mh;
  if(sat){int bits=w==2?32:48;BigInteger lo=BigInteger.ONE.shiftLeft(bits-1).negate(),hi=BigInteger.ONE.shiftLeft(bits-1).subtract(BigInteger.ONE);boolean over=sum.compareTo(lo)<0||sum.compareTo(hi)>0;sum=sum.max(lo).min(hi);mh=w==2?(over?1:s.mach):(s.mach&0xffff0000)|(sum.shiftRight(32).intValue()&0xffff);}
  else mh=sum.shiftRight(32).intValue();
  test(q.mach()==mh&&q.macl()==sum.intValue(),"MAC oracle r"+r+" w"+w+" sat"+sat);
 }
 // Restore all architecture BN slots without internal savedBanks history. HW8.8.2.
 for(int bn=1;bn<=15;bn++){
  AbstractCpu s=initial();s.nextBank=bn;for(int e=0;e<20;e++)s.writeBank(((bn-1)<<7)|(e<<2),1000+e);
  var q=run(s,0x005b);test(q.nextBank()==bn-1,"BN decrement");
  for(int r=0;r<15;r++)test(q.registers().get(r)==1000+r,"RESBANK GPR");
  test(q.mach()==1015&&q.pr()==1017&&q.gbr()==1018&&q.macl()==1019,"RESBANK control");
 }
 System.out.println("REVIEWER_ALIAS_PROBE PASS assertions="+count);
 }
}
