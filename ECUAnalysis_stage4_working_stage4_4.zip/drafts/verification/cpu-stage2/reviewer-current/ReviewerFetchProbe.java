package ecu.independent;
public class ReviewerFetchProbe {
 public static void main(String[] args){
  Sh2aDecoder d=new Sh2aDecoder();byte[] rom=new byte[0x104],bytes=new byte[4];int tests=0;
  for(int w=0;w<65536;w++)for(int v:new int[]{0,0xffff,0x1234,0x8000,0x7fff}){
   bytes[0]=rom[0x100]=(byte)(w>>>8);bytes[1]=rom[0x101]=(byte)w;bytes[2]=rom[0x102]=(byte)(v>>>8);bytes[3]=rom[0x103]=(byte)v;
   if(!d.decode(rom,0x100).equals(d.decodeFetched(bytes,0x100)))throw new AssertionError("divergent "+w+" "+v);tests++;
  }
  System.out.println("REVIEWER_FETCH_PROBE PASS equivalence="+tests);
 }
}
