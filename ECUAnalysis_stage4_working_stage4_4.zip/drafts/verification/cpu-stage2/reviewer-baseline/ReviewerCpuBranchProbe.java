import ecu.independent.FirmwareGraph;
public final class ReviewerCpuBranchProbe {
 static void w(byte[] r,int a,int v){r[a]=(byte)(v>>>8);r[a+1]=(byte)v;}
 static void l(byte[] r,int a,int v){w(r,a,v>>>16);w(r,a+2,v);}
 static byte[] rom(){byte[] r=new byte[0x200000];l(r,0,0x100);l(r,4,0xfff90000);return r;}
 public static void main(String[] args){
  byte[] r=rom();w(r,0x100,0x0008);w(r,0x102,0x8d10);w(r,0x104,0x0000);w(r,0x106,1);w(r,0x108,0x001b);
  var x=new FirmwareGraph().analyze(r,30);
  System.out.println("BT_S_NOT_TAKEN_NEXT32 reached108="+x.instructions().containsKey(0x108)+" expected=true issues="+x.issues());
  r=rom();w(r,0x100,0x0180);w(r,0x102,0);w(r,0x104,0x414a);w(r,0x106,0x0200);w(r,0x108,0x200);w(r,0x10a,0x2122);w(r,0x10c,0x8300);w(r,0x10e,0x001b);w(r,0x200,0x001b);
  x=new FirmwareGraph().analyze(r,30);
  System.out.println("TBR_SRAM_TARGET reached200="+x.instructions().containsKey(0x200)+" expected=true issues="+x.issues());
 }
}
