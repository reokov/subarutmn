package ecu.independent;
import java.lang.reflect.*;
public final class ReviewerCpuGapProbe {
 static final int RAM=0xfff80000;
 static final Sh2aDecoder d=new Sh2aDecoder();
 static Method exec; static Field bus;
 static boolean step(FirmwareGraph g,AbstractCpu s,int op)throws Exception{byte[] b={(byte)(op>>>8),(byte)op};return (boolean)exec.invoke(g,s,d.decode(b,0));}
 public static void main(String[] args)throws Exception{
  exec=FirmwareGraph.class.getDeclaredMethod("execute",AbstractCpu.class,Sh2aDecoder.Instruction.class);exec.setAccessible(true);
  bus=FirmwareGraph.class.getDeclaredField("bus");bus.setAccessible(true);
  var g=new FirmwareGraph();bus.set(g,new Sh7254rMemoryMap(new byte[0x200000]));
  var s=new AbstractCpu();s.r[1]=RAM+4;
  boolean ret=step(g,s,0x2116);
  System.out.println("MOVPRE_ALIAS actual="+s.readRam(RAM,4)+" expected="+(RAM+4)+" next="+ret);
  s=new AbstractCpu();s.r[1]=RAM;s.r[2]=RAM+4;s.writeRam(RAM,4,2,0);s.writeRam(RAM+4,4,3,0);s.mach=0;s.macl=0;s.saturation=true;
  ret=step(g,s,0x012f);
  System.out.println("MACL_S1 actual="+s.macl+" expected=6 next="+ret);
  s=new AbstractCpu();s.r[0]=RAM+1;
  ret=step(g,s,0x6102);
  System.out.println("MISALIGNED_LOAD next="+ret+" expected_no_normal_successor");
  s=new AbstractCpu();s.r[0]=7;s.r[1]=null;s.writeRam(RAM,4,1,0);
  ret=step(g,s,0x2102);
  System.out.println("UNKNOWN_STORE stale="+s.readRam(RAM,4)+" expected_unknown_or_halt next="+ret);
 }
}
