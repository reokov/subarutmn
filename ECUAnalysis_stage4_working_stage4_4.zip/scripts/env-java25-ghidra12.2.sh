#!/usr/bin/env bash
# Source this file before builds; override paths when using a different installation.
export JAVA_HOME="${ECU_JAVA_HOME:-$HOME/opt/jdk-25}"
export GHIDRA_INSTALL_DIR="${GHIDRA_INSTALL_DIR:-$HOME/opt/ghidra-12.2}"
case ":$PATH:" in
  *":$JAVA_HOME/bin:"*) ;;
  *) export PATH="$JAVA_HOME/bin:$PATH" ;;
esac
