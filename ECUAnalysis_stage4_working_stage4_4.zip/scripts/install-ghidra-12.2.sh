#!/usr/bin/env bash
set -euo pipefail
# Manual opt-in installation. No sudo. Downloads only official pinned Ghidra 12.2 release.
DEST="${GHIDRA_INSTALL_DIR:-$HOME/opt/ghidra-12.2}"
ZIP_NAME='ghidra_12.2_PUBLIC_20261016.zip'
SHA='2c2cd776db3c1f6a097ba418922378ac3649cadd5e844a6f5f088ae628a7be67'
URL="https://github.com/NationalSecurityAgency/ghidra/releases/download/Ghidra_12.2_build/$ZIP_NAME"
CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/ecu-analysis/ghidra"
for binary in curl sha256sum unzip mktemp find; do
  command -v "$binary" >/dev/null || { echo "Missing: $binary" >&2; exit 2; }
done
if [[ -e "$DEST" ]]; then
  echo "Target exists: $DEST; nothing overwritten" >&2
  exit 2
fi
mkdir -p "$CACHE" "$(dirname "$DEST")"
FILE="$CACHE/$ZIP_NAME"
if [[ ! -f "$FILE" ]]; then
  echo "Downloading official Ghidra $ZIP_NAME..."
  curl --fail --location --retry 3 --continue-at - --output "$FILE" "$URL"
fi
if ! printf '%s  %s\n' "$SHA" "$FILE" | sha256sum --check --status; then
  echo "SHA-256 mismatch; remove bad download manually: $FILE" >&2; exit 3
fi
STAGING="$(mktemp -d "$(dirname "$DEST")/.ghidra-staging.XXXXXXXX")"
trap 'rm -rf "$STAGING"' EXIT
unzip -q "$FILE" -d "$STAGING"
mapfile -d '' FOUND < <(find "$STAGING" -mindepth 2 -maxdepth 3 -name ghidraRun -type f -print0)
if [[ ${#FOUND[@]} -ne 1 ]]; then
  echo "Unexpected archive structure; refusing installation" >&2; exit 4
fi
ROOT_DIR="$(dirname "${FOUND[0]}")"
if [[ ! -f "$ROOT_DIR/support/buildExtension.gradle" ]]; then
  echo "Missing Ghidra buildExtension.gradle" >&2; exit 4
fi
mv -- "$ROOT_DIR" "$DEST"
chmod +x "$DEST/ghidraRun" "$DEST/support/analyzeHeadless" || true
echo "Installed: $DEST"
echo "Export: export GHIDRA_INSTALL_DIR=\"$DEST\""
