#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ $# -lt 1 ]]; then
  echo "Usage: $0 /path/to/firmware.bin [--entry 0xADDRESS] [--limit N]" >&2; exit 2
fi
ROM="$(realpath -- "$1")"; shift
[[ -f "$ROM" ]] || { echo "ROM not found: $ROM" >&2; exit 2; }
JAR="$ROOT/build/ecu-analysis-cli-unreleased.jar"
if [[ ! -f "$JAR" ]]; then echo "Run scripts/build-core.sh first" >&2; exit 2; fi
name="$(basename -- "$ROM")"; name="${name%.*}"; name="$(printf '%s' "$name" | tr -c 'a-zA-Z0-9_-' '_')"
sha="$(sha256sum -- "$ROM" | cut -d' ' -f1)"
stamp="$(date -u +%Y%m%d_%H%M%S)"
output="$ROOT/reports/${name}_${sha:0:12}_${stamp}_$$"
mkdir -p "$output"
java -jar "$JAR" "$ROM" "$output" "$@"
