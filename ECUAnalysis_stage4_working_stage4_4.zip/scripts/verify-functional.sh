#!/usr/bin/env bash
# Автоматическая ФУНКЦИОНАЛЬНАЯ проверка независимого Java-ядра ECUAnalysis.
#
# ГРАНИЦЫ (совпадают с AGENTS.md проекта):
#   - только синтетические данные: образы генерируются самими инструментами
#     (new byte[0x200000]); только CLI-проверка сохраняет свой синтетический
#     образ в build/cli-acceptance/; исходные файлы firmware/ не читаются;
#   - Ghidra (verify-ghidra.sh, headless-import.sh), analyze-rom.sh и сеть НЕ запускаются;
#   - артефакты пишутся только в build/ (каталог результатов инструментов);
#   - успешный выход НЕ означает соответствия ISA или релиза: RELEASE_BLOCKED сохраняется
#     до выполнения критериев docs/FULL_COVERAGE_RELEASE_GATE_RU.md.
#
# КОДЫ ВЫХОДА:
#   0 — все обязательные (tier=M) проверки PASS;
#   1 — хотя бы одна обязательная проверка FAIL/TIMEOUT/SKIP/NOT_RUN;
#   2 — сбой окружения или компиляции (проверки фактически не выполнялись).
#
# Повторный запуск не требует ручной очистки: каталог классов, .out-файлы и отчёт
# перезаписываются на каждом прогоне.
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 2

CLASS_DIR="build/functional-classes"
REPORT_DIR="build/reports"
RUN_TAG="$(date -u +%Y%m%dT%H%M%SZ)"
REPORT="$REPORT_DIR/functional-$RUN_TAG.txt"
LATEST="$REPORT_DIR/functional-latest.txt"

# --- acceptance-инструменты: имя|класс|tier|обязательный маркер|ожидаемый exit ---
# M = обязательная; I = информационная (не влияет на код выхода; PASS не заявляется).
TOOL_SPECS=(
  "system-exceptions|ecu.independent.SystemExceptionsAcceptance|M|SYSTEM_EXCEPTIONS_ACCEPTANCE: PASS|0"
  "pipeline-stage44|ecu.independent.PipelineStage44Acceptance|M|PIPELINE_STAGE44_ACCEPTANCE: PASS|0"
  "system-pipeline|ecu.independent.SystemExceptionsAcceptance|M|PIPELINE_ACCEPTANCE: PASS|0"
  "system-withdrawal|ecu.independent.SystemExceptionsAcceptance|M|WITHDRAWAL: PASS|0"
  "fpu-stage3-exact|ecu.independent.FpuStage3Acceptance|M|FPU_STAGE3_ACCEPTANCE: PASS|0"
  "fpu-stage3-forms|ecu.independent.FpuFormsAcceptance|M|FPU_FORMS_ACCEPTANCE: PASS|0"
  "cpu-review-extra|ecu.independent.ReviewerExtraCpuProbe|M|REVIEWER_EXTRA_CPU_PROBE PASS|0"
  "cpu-review-routing|ecu.independent.ReviewerRoutingProbe|M|REVIEWER_ROUTING_PROBE PASS|0"
  "cpu-review-alias|ecu.independent.ReviewerAliasProbe|M|REVIEWER_ALIAS_PROBE PASS|0"
  "cpu-review-system|ecu.independent.ReviewerSystemProbe|M|REVIEWER_SYSTEM_PROBE PASS|0"
  "cpu-review-fetch|ecu.independent.ReviewerFetchProbe|M|REVIEWER_FETCH_PROBE PASS|0"
  "cpu-review-pure|ecu.independent.ReviewerPureCpuProbe|M|REVIEWER_PURE_CPU_PROBE PASS|0"
  "cpu-execution|ecu.independent.CpuExecutionAcceptance|M|CPU_EXECUTION_ACCEPTANCE: PASS|0"
  "cpu-boundary|ecu.independent.CpuBoundaryAcceptance|M|CPU_BOUNDARY_ACCEPTANCE: PASS|0"
  "standalone-cli|StandaloneCliAcceptance|M|STANDALONE_CLI_ACCEPTANCE: PASS|0"
  "decode-sweep|DecodeSweep|M|Evaluated 327680 prefix/continuation pairs|0"
  "normative-decoder|NormativeDecoderAcceptance|M|NORMATIVE_DECODER_ACCEPTANCE: PASS|0"
  "instruction-length|InstructionLengthAcceptance|M|instruction length classifications|0"
  "semantics|SemanticsAcceptance|M|NOT comprehensive ISA verification|0"
  "fpu-normal-trap|ecu.independent.FpuNormalTrapAcceptance|M|FPU_NORMAL_TRAP_ACCEPTANCE: PASS|0"
  "fpu-bit-classification|ecu.independent.FpuClassificationAcceptance|M|FPU_BIT_CLASSIFICATION: PASS|0"
  "software-irq-boundary|ecu.independent.SoftwareInterruptBoundaryAcceptance|M|SOFTWARE_IRQ_BOUNDARY_ACCEPTANCE: PASS|0"
  "peripheral-fail-closed|PeripheralFailClosedAcceptance|M|PERIPHERAL_FAIL_CLOSED_ACCEPTANCE: PASS|0"
  "pc-relative-slot|ecu.independent.PcRelativeSlotAcceptance|M|PC_RELATIVE_SLOT_ACCEPTANCE: PASS|0"
  "stbcr-read-path|ecu.independent.StbcrReadPathAcceptance|M|STBCR_READ_PATH_ACCEPTANCE: PASS|0"
  "fmov-displacement|FmovDisplacementAcceptance|I|PASS synthetic FMOV disp12|0"
  "release-gate|FullCoverageReleaseGate|I|RELEASE_BLOCKED:|2"
)

# Сознательно вне запуска — чтобы отсутствие проверки было видно, а не выглядело как PASS.
EXCLUDED=(
  "analyze-rom|NOT_RUN|scripts/analyze-rom.sh — реальный BIN и эмуляция; требуется отдельное разрешение оператора"
  "headless-import|NOT_RUN|scripts/headless-import.sh — импорт BIN в Ghidra; запрещено поручением"
  "verify-ghidra|NOT_RUN|scripts/verify-ghidra.sh — Ghidra 12.2 не запускается"
  "verify-package|NOT_RUN|scripts/verify-package.sh — контроль целостности поставки, не функции ядра"
)

mand_total=0; mand_pass=0; mand_fail=0; mand_other=0
info_total=0; info_pass=0; info_other=0
ROWS=()

run_all() {
  echo "=== ECUAnalysis functional verification (SYNTHETIC DATA ONLY) ==="
  echo "utc=$RUN_TAG root=$ROOT"
  echo "javac=$(javac -version 2>&1 | head -n1)"
  echo "java=$(java -version 2>&1 | head -n1)"
  echo "scope=decoding/CFG/MMIO invariants on synthetic images; NOT ISA completeness; NOT a release claim"
  echo ""

  echo "--- COMPILE (javac -proc:none -Xlint:all -> $CLASS_DIR) ---"
  rm -rf "$CLASS_DIR"
  mkdir -p "$CLASS_DIR" || { echo "COMPILE_FAIL: cannot create $CLASS_DIR"; return 2; }
  mapfile -d '' SOURCES < <(find src/main/java/ecu/independent tools -type f -name '*.java' -print0 | sort -z)
  if [[ ${#SOURCES[@]} -eq 0 ]]; then echo "COMPILE_FAIL: no sources"; return 2; fi
  echo "sources=${#SOURCES[@]}"
  javac -proc:none -encoding UTF-8 --release 21 -Xlint:all -d "$CLASS_DIR" "${SOURCES[@]}" 2>&1 | sed 's/^/  javac| /'
  if [[ ${PIPESTATUS[0]} -ne 0 ]]; then
    echo "COMPILE_FAIL: javac non-zero exit — проверки не выполнялись"
    return 2
  fi
  if ! bash scripts/build-core.sh; then
    echo "COMPILE_FAIL: packaged CLI build failed"; return 2
  fi
  echo "COMPILE_PASS"
  echo ""

  echo "--- RUN ---"
  local timeout_cmd=()
  command -v timeout >/dev/null && timeout_cmd=(timeout 600)
  local spec name klass tier marker want_exit out code verdict
  for spec in "${TOOL_SPECS[@]}"; do
    IFS='|' read -r name klass tier marker want_exit <<<"$spec"
    out="$CLASS_DIR/$name.out"
    local jvm_options=()
    [[ "$name" == cpu-* || "$name" == fpu-stage3-* || "$name" == system-exceptions ]] && jvm_options=(-Xmx512m)
    [[ "$name" == "normative-decoder" ]] && jvm_options=(-Xmx256m)
    local tool_arguments=()
    [[ "$name" == "system-pipeline" ]] && tool_arguments=(scheduler)
    [[ "$name" == "system-withdrawal" ]] && tool_arguments=(withdrawal)
    [[ "$name" == "cpu-review-extra" ]] && tool_arguments=(build/cpu-independent-extra-coverage.csv)
    "${timeout_cmd[@]}" java "${jvm_options[@]}" -cp "$CLASS_DIR" "$klass" "${tool_arguments[@]}" >"$out" 2>&1
    code=$?
    local found="no"
    grep -qF -- "$marker" "$out" && found="yes"
    if [[ $code -eq 124 ]]; then
      verdict="TIMEOUT"
    elif [[ $want_exit != "0" ]]; then
      # Информационный релизный гейт обязан блокировать: ожидаем НЕ-ноль + маркер.
      if [[ $code -eq $want_exit && $found == "yes" ]]; then verdict="BLOCKED"; else verdict="FAIL"; fi
    elif [[ $code -eq 0 && $found == "yes" ]]; then
      verdict="PASS"
    else
      verdict="FAIL"
    fi
    if [[ $tier == "M" ]]; then
      mand_total=$((mand_total+1))
      if [[ $verdict == "PASS" ]]; then mand_pass=$((mand_pass+1))
      elif [[ $verdict == "FAIL" || $verdict == "TIMEOUT" ]]; then mand_fail=$((mand_fail+1))
      else mand_other=$((mand_other+1)); fi
    else
      info_total=$((info_total+1))
      if [[ $verdict == "PASS" ]]; then info_pass=$((info_pass+1)); else info_other=$((info_other+1)); fi
    fi
    ROWS+=("$(printf '%-9s %-8s %-24s exit=%-4s marker=%-3s %s' "$verdict" "$tier" "$name" "$code" "$found" "$klass")")
    printf '%-9s %-8s %-24s exit=%-4s marker=%-3s %s\n' "$verdict" "$tier" "$name" "$code" "$found" "$klass"
    if [[ $verdict == "FAIL" || $verdict == "TIMEOUT" ]]; then
      echo "  ---- tail $name ----"
      tail -n 30 "$out" | sed 's/^/  | /'
      echo "  --------------------"
    fi
  done
  echo ""

  echo "--- EXCLUDED / NOT_RUN (явно, чтобы пропуск не выглядел PASS) ---"
  local ex en ev er
  for ex in "${EXCLUDED[@]}"; do
    IFS='|' read -r en ev er <<<"$ex"
    printf '%-9s %-24s %s\n' "$ev" "$en" "$er"
  done
  echo ""

  echo "--- RESULTS (machine-readable) ---"
  local row
  for row in "${ROWS[@]}"; do echo "$row"; done
  echo ""
  echo "--- SUMMARY ---"
  echo "mandatory: total=$mand_total pass=$mand_pass fail=$mand_fail other=$mand_other"
  echo "informational: total=$info_total pass=$info_pass blocked_or_fail=$info_other"
  return 0
}

mkdir -p "$REPORT_DIR" || { echo "ENV_FAIL: cannot create $REPORT_DIR" >&2; exit 2; }
if ! command -v javac >/dev/null || ! command -v java >/dev/null; then
  echo "ENV_FAIL: javac/java not found" >&2; exit 2
fi

# run_all пишет в отчёт и затем печатается: без конвейера, чтобы счётчики (mand_*)
# остались в текущей оболочке и сформировали честный код выхода.
run_all >"$REPORT" 2>&1
rc=$?
cat "$REPORT"

if [[ $rc -ne 0 ]]; then
  exit_code=2; verdict="NOT_RUN"
elif [[ $mand_fail -gt 0 || $mand_other -gt 0 ]]; then
  exit_code=1; verdict="FUNCTIONAL_FAIL_OR_INCOMPLETE"
else
  exit_code=0; verdict="FUNCTIONAL_PASS_LISTED_SYNTHETIC_CHECKS_ONLY"
fi

{
  echo ""
  echo "VERDICT: $verdict"
  echo "exit_code=$exit_code"
  echo "mandatory: total=$mand_total pass=$mand_pass fail=$mand_fail other=$mand_other"
  echo "informational: total=$info_total pass=$info_pass blocked_or_fail=$info_other"
  echo "RELEASE_BLOCKED: сохранён — критерии docs/FULL_COVERAGE_RELEASE_GATE_RU.md (полная ISA/FPU, системный планировщик, периферия, реальная ROM) не выполнены"
} | tee -a "$REPORT"
cp "$REPORT" "$LATEST"
echo "report=$REPORT"
echo "latest=$LATEST"
exit $exit_code
