#!/usr/bin/env python3
"""Build/verify a self-contained source/evidence pair. Upload is a separate mandatory step."""
from pathlib import Path
import argparse,hashlib,json,zipfile,re
from datetime import datetime,timezone
p=argparse.ArgumentParser();p.add_argument('--review-status',default='NOT_RUN');p.add_argument('--phase',default='pre-review');p.add_argument('--group',default='FPUL/FPSCR memory transfers + FSCHG');p.add_argument('--result-doc',default='docs/STAGE4_4_CONTROL_RESULT_RU.md');p.add_argument('--log-dir',default='build/stage4_4/continuation');p.add_argument('--evidence-dir',default='drafts/verification/stage4_4-control');a=p.parse_args()
root=Path(__file__).resolve().parent.parent
base=root/a.evidence_dir;base.mkdir(parents=True,exist_ok=True)
parent=json.loads((root/'SNAPSHOT.json').read_text())
source=sorted({f for name in ['src','tools','scripts'] for f in (root/name).rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix not in {'.pyc','.class'}}|{root/n for n in ['build.gradle','settings.gradle','extension.properties'] if (root/n).is_file()})
manifest=''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(root).as_posix()+'\n' for f in source)
sha=hashlib.sha256(manifest.encode()).hexdigest();sid='stage4_4-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+sha[:12]
(base/'SOURCE_SHA256.txt').write_text(manifest)
logs=root/a.log_dir
functional=logs/'functional.log';full='NOT_RUN'
if functional.exists():
 text=functional.read_text()
 if 'VERDICT: FUNCTIONAL_PASS_LISTED_SYNTHETIC_CHECKS_ONLY' in text:
  counts=re.search(r'mandatory: total=(\d+) pass=(\d+) fail=0 other=0',text)
  full='PASS '+counts[2]+'/'+counts[1]+' listed mandatory groups' if counts else 'UNVERIFIED_SUMMARY'
 elif 'VERDICT: FUNCTIONAL_FAIL_OR_INCOMPLETE' in text:full='FAIL'
 else:full='RUNNING_OR_INCOMPLETE'
state={'snapshot_id':sid,'phase':a.phase,'source_manifest_sha256':sha,'source_entries':len(source),'project_status':'RELEASE_BLOCKED','stage_status':'IN_PROGRESS','lost_snapshot':'stage4_4-20261111-59c7ff9175af','lost_snapshot_restore':'RESTORE_BLOCKED','restart_base_sha256':'f599f87f7d7c91ae3d4c3e87f4e70f3d428cf65f688710bb77f0b6ce266ad895','compile':'PASS current full core/tools --release21 -Xlint:all' if functional.exists() and 'COMPILE_PASS' in functional.read_text() else 'NOT_RUN_OR_FAILED','functional':full,'extension':'PASS' if (logs/'extension.log').exists() and 'BUILD SUCCESSFUL' in (logs/'extension.log').read_text() else 'NOT_RUN_OR_FAILED','parent_snapshot_id':parent['snapshot_id'],'parent_source_manifest_sha256':parent['source_manifest_sha256'],'profile_inventory':(logs/'inventory.log').read_text().strip() if (logs/'inventory.log').exists() else 'NOT_RUN','target_acceptance':(logs/'target-green.log').read_text().strip() if (logs/'target-green.log').exists() else (logs/'fp-control-green.log').read_text().strip() if (logs/'fp-control-green.log').exists() else 'NOT_RUN','review':a.review_status,'backup_publication':'requires persistent upload receipt; local ZIP alone insufficient'}
(base/'SNAPSHOT.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
for name in ['compile.log','red.log','diagnostic-red.log','diagnostic-green.log','double-red.log','shift-red.log','review-fixes-green.log','target-green.log','functional.log','extension.log','inventory.log','profile-inventory.tsv','input-integrity.log','fp-control-red.log','fp-control-green.log','sz-shadow-green.log','baseline-target.log','baseline-functional-jdk25.log']:
 f=logs/name
 if f.exists():(base/name).write_bytes(f.read_bytes())
testlogs=base/'test-logs';testlogs.mkdir(exist_ok=True)
for f in (root/'build/functional-classes').glob('*.out'):(testlogs/f.name).write_bytes(f.read_bytes())
report=root/'build/reports/functional-latest.txt'
if report.exists():(base/'functional-report.txt').write_bytes(report.read_bytes())
checkpoint=f'''# ECUAnalysis — восстановимая контрольная точка этапа4.4

`{sid}`. **IN_PROGRESS / RELEASE_BLOCKED**.
Источник: `{parent['snapshot_id']}`, source manifest `{parent['source_manifest_sha256']}`.
Текущий source manifest: `{sha}`, entries={len(source)}.
Это продолжение подтверждённого e87, а не реконструкция утраченного59c7.

Группа: {a.group}.
Численные CPU/FPU/decoder не изменялись. Pipeline остаётся тем же production scheduler.
Текущие compile={state['compile']}; functional={full}; extension={state['extension']}; review={a.review_status}.
Наличие PROFILE_PRESENT не означает полный функциональный PASS; inventory содержит253 формы.
См. {a.result_doc}, profile-inventory.tsv и NEW_PROFILE_FORMS.tsv.

Следующее независимое требование: multiple memory и оставшиеся memory/control transfers;
затем MUL/DIV/MAC/system/bank/TRAPA/SLEEP, общая 2-ILP и exception matrix.
UNVERIFIED: ED/backpressure/capacity, physical H24/H34 condition→CPU report и некоторые savedPC.
Это не причина останавливать независимую реализацию профилей.
Реальные ROM/ECU/Ghidra с BIN NOT_RUN.

Перед reviewer обязательны постоянное сохранение обоих ZIP, receipts, повторное получение
и SHA/manifest verification. Локальные ZIP не являются подтверждённой резервной копией.
Пара: ECUAnalysis_stage4_working_{sid}.zip и
ECUAnalysis_stage4_evidence_{sid}.zip (после review — review_evidence).
Без successful persistent verification reviewer не вызывается: BACKUP_BLOCKED.

Восстановление: распаковать working в пустую папку, проверить MANIFEST.sha256 и SOURCE_SHA256.txt.
Сборка: JDK25/Ghidra12.2, source scripts/env-java25-ghidra12.2.sh, bash scripts/verify-functional.sh.
SDK, реальные BIN и приватные конфигурации в архивах отсутствуют.
'''
(base/'CHECKPOINT_RU.md').write_text(checkpoint);(root/'ECUAnalysis_stage4_4_result_RU.md').write_text(checkpoint)
index=root/'drafts/index.md';s=index.read_text() if index.exists() else '# Drafts\n';s='\n'.join(x for x in s.splitlines() if not x.startswith(('> Актуальный restart checkpoint:','> Актуальная контрольная точка:')))
index.write_text(f'> Актуальная контрольная точка: [{sid}]({base.relative_to(root/"drafts").as_posix()}/CHECKPOINT_RU.md). {full}; review {a.review_status}.\n'+s)
(base/'EVIDENCE_SHA256.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(base).as_posix()+'\n' for f in sorted(base.rglob('*')) if f.is_file() and f.name!='EVIDENCE_SHA256.txt'))
files=[]
for name in ['src','tools','scripts','docs','drafts','inputs','agents','ghidra_scripts']:
 files += [f for f in (root/name).rglob('*') if f.is_file() and f.suffix.lower() not in ['.bin','.rom','.zip','.class','.pyc'] and not any(t.startswith('.') or t=='__pycache__' for t in f.relative_to(root).parts)]
files += [root/n for n in ['build.gradle','settings.gradle','extension.properties','README_RU.md'] if (root/n).is_file()]
working=root/f'ECUAnalysis_stage4_working_{sid}.zip'
evidence=root/f'ECUAnalysis_stage4_{"review_evidence" if a.phase=="final" else "evidence"}_{sid}.zip'
with zipfile.ZipFile(working,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(set(files)):z.write(f,f.relative_to(root).as_posix())
 for n in ['SNAPSHOT.json','SOURCE_SHA256.txt','CHECKPOINT_RU.md']:z.write(base/n,n)
 z.writestr('MANIFEST.sha256',''.join(hashlib.sha256(z.read(n)).hexdigest()+'  '+n+'\n' for n in sorted(z.namelist())))
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(base.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(base).as_posix())
 z.write(root/'docs/PIPELINE_STAGE4_4_RU.md','NORMATIVE_CONTRACT_RU.md')
 z.writestr('MANIFEST.sha256',''.join(hashlib.sha256(z.read(n)).hexdigest()+'  '+n+'\n' for n in sorted(z.namelist())))
for f in [working,evidence]:
 with zipfile.ZipFile(f) as z:
  assert z.testzip() is None
  for row in z.read('MANIFEST.sha256').decode().splitlines():
   h,n=row.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
  assert json.loads(z.read('SNAPSHOT.json'))==state
  if f==working:
   for row in z.read('SOURCE_SHA256.txt').decode().splitlines():
    h,n=row.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
result={**state,'working':working.name,'evidence':evidence.name,'report':'ECUAnalysis_stage4_4_result_RU.md','working_sha256':hashlib.sha256(working.read_bytes()).hexdigest(),'evidence_sha256':hashlib.sha256(evidence.read_bytes()).hexdigest(),'zip_manifest_check':'PASS'}

for name in ['SNAPSHOT.json','SOURCE_SHA256.txt','CHECKPOINT_RU.md']:(root/name).write_bytes((base/name).read_bytes())
with zipfile.ZipFile(working) as z:(root/'MANIFEST.sha256').write_bytes(z.read('MANIFEST.sha256'))
(root/'build/current-backup.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
