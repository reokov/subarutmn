#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ $# -ne 1 ]]; then echo "Usage: $0 /path/to/firmware.bin" >&2; exit 2; fi
ROM="$(realpath -- "$1")"
[[ -f "$ROM" ]] || { echo "ROM not found: $ROM" >&2; exit 2; }
GDIR="${GHIDRA_INSTALL_DIR:-$HOME/opt/ghidra-12.2}"
HEADLESS="$GDIR/support/analyzeHeadless"
[[ -x "$HEADLESS" ]] || { echo "Ghidra headless executable not found: $HEADLESS" >&2; exit 2; }
BASENAME="$(basename -- "$ROM")"; BASENAME="${BASENAME%.*}"
BASENAME="$(printf '%s' "$BASENAME" | tr -c 'A-Za-z0-9_-' '_')"
SHA="$(sha256sum -- "$ROM" | cut -d' ' -f1)"
PROJECT="ECU_${BASENAME}_${SHA:0:12}"
PROJECT_HOME="$ROOT/ghidra-projects"
mkdir -p "$PROJECT_HOME" "$ROOT/reports"
if [[ -e "$PROJECT_HOME/$PROJECT.gpr" || -d "$PROJECT_HOME/$PROJECT.rep" ]]; then
  echo "Project exists: $PROJECT. Refusing silent overwrite." >&2; exit 3
fi
"$HEADLESS" "$PROJECT_HOME" "$PROJECT" \
  -import "$ROM" -loader BinaryLoader -loader-baseAddr 0 \
  -processor 'SuperH:BE:32:SH-2A' -noanalysis \
  -scriptPath "$ROOT/ghidra_scripts" -postScript RomInventory.java \
  -log "$ROOT/reports/${PROJECT}_headless.log" \
  -scriptlog "$ROOT/reports/${PROJECT}_script.log"
echo "Imported into $PROJECT_HOME/$PROJECT without standard auto-analysis."
