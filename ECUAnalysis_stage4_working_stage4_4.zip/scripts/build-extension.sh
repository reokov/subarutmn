#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GDIR="${GHIDRA_INSTALL_DIR:-$HOME/opt/ghidra-12.2}"
[[ -f "$GDIR/support/buildExtension.gradle" ]] || { echo "Ghidra not installed: $GDIR" >&2; exit 2; }
if [[ -x "$GDIR/support/gradle/gradlew" ]]; then
  GRADLE=("$GDIR/support/gradle/gradlew")
elif command -v gradle >/dev/null; then
  GRADLE=(gradle)
else
  echo "Gradle 9.1+ not available; use Ghidra 12.2 bundled support/gradle/gradlew" >&2; exit 2
fi
cd "$ROOT"
"${GRADLE[@]}" --no-daemon -PGHIDRA_INSTALL_DIR="$GDIR" buildExtension
printf 'Only built extension. No automatic installation. Check dist/ and install via Ghidra GUI.\n'
