#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if sha256sum --check --status MANIFEST.sha256; then
  echo "PACKAGE_SHA256_PASS: initial snapshot matches MANIFEST.sha256"
else
  echo "PACKAGE_SHA256_FAIL: files missing or changed since packing" >&2
  exit 1
fi
