#!/usr/bin/env python3
"""Validate catalog serialization, not completeness or correctness of SH-2A ISA."""
import csv
from pathlib import Path

path = Path(__file__).resolve().parents[1] / 'docs/requirements/isa-encodings.csv'
with path.open(encoding='utf-8', newline='') as stream:
    reader = csv.DictReader(stream)
    assert reader.fieldnames and len(reader.fieldnames) == 13, 'Invalid CSV header'
    seen = set()
    count = 0
    for row in reader:
        assert None not in row and None not in row.values(), f'CSV field count: line {reader.line_num}'
        group = row['group']
        assert group and group not in seen, f'Duplicate/empty group: {group}'
        seen.add(group)
        width = int(row['length_bytes'])
        assert width in (2, 4), f'Invalid width: {group}'
        for prefix in ('first', 'second'):
            mask, value = row[prefix + '_mask'], row[prefix + '_value']
            assert bool(mask) == bool(value), f'Incomplete mask/value: {group}'
            if mask:
                mask, value = int(mask, 16), int(value, 16)
                assert 0 <= mask <= 0xffff and 0 <= value <= 0xffff, f'Out of range: {group}'
                assert value & ~mask == 0, f'Value outside mask: {group}'
                assert prefix != 'second' or width == 4, f'Second word in 16-bit row: {group}'
        assert row['mnemonic'] and row['semantics_verified'], f'Missing identity/status: {group}'
        count += 1
print(f'ISA_CATALOG_SCHEMA: PASS ({count} rows; completeness and semantics NOT verified)')
