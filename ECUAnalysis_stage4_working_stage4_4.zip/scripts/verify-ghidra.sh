#!/usr/bin/env bash
set -euo pipefail
GDIR="${GHIDRA_INSTALL_DIR:-$HOME/opt/ghidra-12.2}"
echo "GHIDRA_INSTALL_DIR=$GDIR"
if [[ -x "$GDIR/support/analyzeHeadless" ]]; then
  echo "OK: headless executable present"
else
  echo "MISSING: $GDIR/support/analyzeHeadless" >&2; exit 2
fi
if [[ ! -f "$GDIR/support/buildExtension.gradle" ]]; then
  echo "MISSING: support/buildExtension.gradle" >&2; exit 2
fi
if [[ ! -x "$GDIR/support/gradle/gradlew" ]]; then
  echo "NOTE: no bundled gradle wrapper; install Gradle 9.1+"
fi
java -version 2>&1 | head -3
javac -version
if ! java -version 2>&1 | head -1 | grep -Eq '(version "25\.|openjdk 25\.|version 25\.)'; then
  echo "ERROR: Ghidra 12.2 requires JDK 25. Select JDK 25 using JAVA_HOME/PATH." >&2; exit 3
fi
printf 'Environment paths present; execution compatibility NOT tested.\n'
