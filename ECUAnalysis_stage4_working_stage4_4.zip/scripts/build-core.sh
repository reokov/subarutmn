#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v javac >/dev/null || { echo "ERROR: javac not found" >&2; exit 2; }
command -v jar >/dev/null || { echo "ERROR: jar not found" >&2; exit 2; }
OUT="$ROOT/build"
mkdir -p "$OUT"
TMP="$(mktemp -d "$OUT/.classes.XXXXXXXX")"
trap 'rm -rf "$TMP"' EXIT
mapfile -d '' SOURCES < <(find "$ROOT/src/main/java/ecu/independent" -type f -name '*.java' -print0 | sort -z)
if [[ ${#SOURCES[@]} -eq 0 ]]; then echo "No sources" >&2; exit 2; fi
javac -encoding UTF-8 --release 21 -Xlint:all -d "$TMP" "${SOURCES[@]}"
JAR="$OUT/ecu-analysis-cli-unreleased.jar"
jar --create --file "$JAR" --main-class ecu.independent.StandaloneMain -C "$TMP" .
echo "Built independent CLI: $JAR (NOT a completed ECU emulator)"
