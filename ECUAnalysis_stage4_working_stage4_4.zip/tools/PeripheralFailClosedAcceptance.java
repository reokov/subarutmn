import ecu.independent.FirmwareGraph;

/** Synthetic MMIO fail-closed acceptance; NOT a peripheral correctness oracle. */
public final class PeripheralFailClosedAcceptance {
    private static void word(byte[] rom,int a,int value) {
        rom[a]=(byte)(value>>>8);rom[a+1]=(byte)value;
    }
    private static void dword(byte[] rom,int a,int value) {
        word(rom,a,value>>>16);word(rom,a+2,value);
    }
    public static void main(String[] args) {
        byte[] rom=new byte[0x200000];
        dword(rom,0,0x100);dword(rom,4,0xFFF9FFF0);
        word(rom,0x100,0xD10F); // MOV.L @(0x140,PC),R1
        word(rom,0x102,0xE001); // MOV #1,R0
        word(rom,0x104,0x2100); // MOV.B R0,@R1
        word(rom,0x106,0x0009); // NOP: must NOT be assumed reachable
        dword(rom,0x140,0xFFFC9000); // Unmodelled MMIO region
        var report=new FirmwareGraph().analyze(rom,100);
        boolean flagged=report.issues().stream().anyMatch(i->
                i.reason().startsWith("UNMODELED_PERIPHERAL_WRITE_"));
        if(!flagged)throw new AssertionError("Unmodelled MMIO write not diagnosed");
        boolean reached=report.instructions().containsKey(0x106);
        if(reached)throw new AssertionError("CFG must not continue through unknown MMIO effect");
        System.out.println("PERIPHERAL_FAIL_CLOSED_ACCEPTANCE: PASS (unknown MMIO stops branch)");
    }
}
