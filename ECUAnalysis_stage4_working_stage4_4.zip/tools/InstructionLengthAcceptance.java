import ecu.independent.Sh2aDecoder;

/**
 * Structural FIRST-HALFWORD length regression. The masks are transcribed from
 * Renesas REJ09B0051-0300 and Linux arch/sh opcode_helper.c (NOT Ghidra).
 * Masks resemble the implementation; this is NOT an independent normative oracle.
 * NormativeDecoderAcceptance uses cross-checked primary bitstrings instead.
 * Does not prove instruction legality, semantic equivalence or timing.
 */
public final class InstructionLengthAcceptance {
    private InstructionLengthAcceptance() {}
    public static void main(String[] args) {
        Sh2aDecoder decoder = new Sh2aDecoder();
        byte[] window = new byte[4];
        int checked = 0;
        for (int first = 0; first <= 0xFFFF; first++) {
            window[0] = (byte)(first >>> 8);
            window[1] = (byte)first;
            window[2] = (byte)0xFF;
            window[3] = (byte)0xFF;
            boolean is32 = (first & 0xF00F) == 0x0000
                    || (first & 0xF00F) == 0x0001
                    || (first & 0xF00F) == 0x3001
                    || (first & 0xF08F) == 0x3009;
            var instruction = decoder.decode(window,0);
            int expected = is32 ? 4 : 2;
            if (instruction.width() != expected)
                throw new AssertionError(String.format("first=0x%04X expected=%d got=%d %s",
                        first, expected, instruction.width(), instruction.mnemonic()));
            checked++;
        }
        System.out.println("PASS " + checked + " instruction length classifications; NOT semantic coverage");
    }
}
