import ecu.independent.FirmwareGraph;
import ecu.independent.Sh2aDecoder;
import java.util.Arrays;
import java.util.List;

/**
 * Explicitly requested semantic verification, synthetic instructions only.
 * Oracles are transcribed from Renesas REJ09B0051-0300 tables 5.3-5.9,
 * NOT from Ghidra/SLEIGH or this decoder.
 * This verifies only the listed cases, not ISA completeness or emulator correctness.
 */
public final class SemanticsAcceptance {
    private static int pass;
    private static void check(boolean ok, String title) {
        if (!ok) throw new AssertionError(title);
        pass++;
    }
    private static byte[] bytes(int... halfwords) {
        byte[] result=new byte[halfwords.length*2];
        for(int i=0;i<halfwords.length;i++) {
            result[i*2]=(byte)(halfwords[i]>>>8);
            result[i*2+1]=(byte)halfwords[i];
        }
        return result;
    }
    private static void decoded(String name, int width, boolean supported, int... words) {
        Sh2aDecoder.Instruction i=new Sh2aDecoder().decode(bytes(words),0);
        check(i.width()==width && i.supported()==supported && i.mnemonic().startsWith(name),
                "opcode " + name + " got " + i);
    }
    private static FirmwareGraph.Report graph(int... words) {
        byte[] rom=new byte[0x200000];
        rom[0]=0;rom[1]=0;rom[2]=1;rom[3]=0; // PC=0x100
        rom[4]=(byte)0xFF;rom[5]=(byte)0xF9;rom[6]=0;rom[7]=0; // SP=0xFFF90000
        byte[] code=bytes(words);
        System.arraycopy(code,0,rom,0x100,code.length);
        return new FirmwareGraph().analyze(rom,64);
    }
    public static void main(String[] args) {
        decoded("MOVI20",4,true,0x0180,0x0000);
        decoded("MOVI20S",4,true,0x0181,0x0000);
        decoded("MOV.B",4,true,0x3121,0x0003);
        decoded("MOV.W",4,true,0x3121,0x1003);
        decoded("MOV.L",4,true,0x3121,0x2003);
        decoded("MOV.B",4,true,0x3121,0x4003);
        decoded("MOVU.B",4,true,0x3121,0x8003);
        decoded("MOVU.W",4,true,0x3121,0x9003);
        decoded("FMOV",4,true,0x3121,0x7003);
        decoded("FMOV",4,true,0x3121,0x3003);
        decoded("CMP/HS",2,true,0x3122,0x0009);
        decoded("MOVML.L",2,true,0x47F1);
        decoded("MOVMU.L",2,true,0x47F0);
        decoded("BCLR",2,true,0x8600);
        decoded("BSET",2,true,0x8608);
        decoded("BST",2,true,0x8700);
        decoded("BLD",2,true,0x8708);
        decoded("BCLR.B",4,true,0x3009,0x0005);
        decoded("BAND.B",4,true,0x3009,0x4005);
        decoded("BANDNOT.B",4,true,0x3009,0xC005);
        decoded("BORNOT.B",4,true,0x3009,0xD005);
        decoded("MOVRT",2,true,0x0039);
        decoded("NOTT",2,true,0x0068);
        decoded("RTV/N",2,true,0x007B);
        decoded("JSR/N @@",2,true,0x8312);
        decoded("CLIPS.B",2,true,0x4091);
        decoded("DIVU",2,true,0x4084);
        decoded("MULR",2,true,0x4080);
        decoded("CLIPU.B",2,true,0x4081);
        decoded("MOV GBR STORE",2,true,0xC001);
        decoded("MOV GBR LOAD",2,true,0xC402);
        decoded("FADD",2,true,0xF120);
        decoded("RTE",2,true,0x002B);
        decoded("BRA",2,true,0xA001);
        decoded("BSR",2,true,0xB001);
        decoded("RTS/N",2,true,0x006B);
        decoded("MOV",2,true,0xE001);
        decoded("CMP/EQ",2,true,0x8801);
        var i=new Sh2aDecoder().decode(bytes(0x0181,0x0000),0);
        check(i.imm()==0xF8000000,"MOVI20S sign-extend then shift8");
        var j=new Sh2aDecoder().decode(bytes(0x3121,0x9003),0);
        check(j.operandWidth()==2 && j.imm()==6,"MOVU.W displacement = 3 * 2");
        var fmovLoad=new Sh2aDecoder().decode(bytes(0x3121,0x7003),0);
        check(fmovLoad.imm()==3 && fmovLoad.operandWidth()==0 && fmovLoad.regM()==2,
                "FMOV disp12 load preserves unscaled displacement for FPSCR.SZ");
        var fmovStore=new Sh2aDecoder().decode(bytes(0x3121,0x3003),0);
        check(fmovStore.imm()==3 && fmovStore.operandWidth()==0 && fmovStore.regN()==1,
                "FMOV disp12 store preserves unscaled displacement for FPSCR.SZ");
        var k=new Sh2aDecoder().decode(bytes(0xAFFF),0);
        check(k.target()!=null && k.target()==2 && k.delaySlot(),"BRA sign-extended displacement -1");
        var report=graph(0xE001,0x7001,0x8802,0x8901,0x0009,0x001B);
        check(report.edges().stream().anyMatch(e->e.from()==0x106 && e.to()==0x10C
                && e.kind().equals("CONDITIONAL_TAKEN")),"T flag branch following arithmetic");
        check(report.edges().stream().noneMatch(e->e.from()==0x106 && e.to()==0x108
                && e.kind().equals("CONDITIONAL_NOT_TAKEN")),"known true branch must not fork false path");
        var report2=graph(0xA001,0x0009,0xF120,0x001B);
        check(report2.instructions().containsKey(0x100) && report2.instructions().containsKey(0x102)
                && !report2.instructions().containsKey(0x104),"nonexecuted FPU-like calibration bytes not decoded");
        var op= new Sh2aDecoder().decode(bytes(0x3059,0xD123),0);
        check(op.width()==4 && op.imm()==((5<<12)|0x123) && op.regN()==0,
                "BORNTO? 32-bit bit op splits imm3 and disp12 correctly");
        System.out.println("PASS " + pass + " Renesas-table and synthetic-CFG checks; NOT comprehensive ISA verification");
    }
}
