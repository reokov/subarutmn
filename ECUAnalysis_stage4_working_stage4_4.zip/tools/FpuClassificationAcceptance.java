package ecu.independent;

/** Independent bit-pattern checks, not an FPU arithmetic conformance suite. */
public final class FpuClassificationAcceptance {
    private static void expect(FpuOperandClassifier.Value value,
                               FpuOperandClassifier.Kind kind, boolean negative) {
        if(value.kind()!=kind || value.negative()!=negative)
            throw new AssertionError("Expected "+kind+" sign "+negative+", got "+value);
    }
    public static void main(String[] args) {
        var K=FpuOperandClassifier.Kind.ZERO;
        expect(FpuOperandClassifier.binary32(0),K,false);
        expect(FpuOperandClassifier.binary32(0x80000000),K,true);
        expect(FpuOperandClassifier.binary32(0x00000001),FpuOperandClassifier.Kind.SUBNORMAL,false);
        expect(FpuOperandClassifier.binary32(0x80800000),FpuOperandClassifier.Kind.NORMAL,true);
        expect(FpuOperandClassifier.binary32(0x7F800000),FpuOperandClassifier.Kind.INFINITY,false);
        expect(FpuOperandClassifier.binary32(0xFFC00000),FpuOperandClassifier.Kind.NAN,true);
        expect(FpuOperandClassifier.binary64(0x80000000,0),K,true);
        expect(FpuOperandClassifier.binary64(0x00000000,1),FpuOperandClassifier.Kind.SUBNORMAL,false);
        expect(FpuOperandClassifier.binary64(0x7FF00000,0),FpuOperandClassifier.Kind.INFINITY,false);
        expect(FpuOperandClassifier.binary64(0x7FF80000,0),FpuOperandClassifier.Kind.NAN,false);
        expect(FpuOperandClassifier.binary64(null,0),FpuOperandClassifier.Kind.UNKNOWN,false);
        System.out.println("FPU_BIT_CLASSIFICATION: PASS 11 patterns; arithmetic/exception semantics NOT verified");
    }
}
