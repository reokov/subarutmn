package ecu.independent;

import java.nio.file.*;
import java.util.*;

/** Each of the 48+8 primary-table forms executes through the production worklist,
 * in ROM and SRAM. Expectations below are literal normal-result/manual effects. */
public final class FpuFormsAcceptance {
    static final int PC=0x100,B=0xfff82000,SP=B+0x1000;
    static int checks,forms;
    static void ok(boolean x,String msg){checks++;if(!x)throw new AssertionError(msg);}
    static void w(byte[] r,int a,int b){r[a]=(byte)(b>>>8);r[a+1]=(byte)b;}
    static void l(byte[] r,int a,int b){w(r,a,b>>>16);w(r,a+2,b);}
    static void memory(Map<Integer,Byte> ram,int a,int value){for(int i=0;i<4;i++)ram.put(a+i,(byte)(value>>>(24-8*i)));}
    static int encoding(String bits){
        int result=0;Map<Character,Integer> shifts=new HashMap<>();
        for(int j=bits.length()-1;j>=0;j--){char c=bits.charAt(j);int value;
            if(c=='0'||c=='1')value=c-'0';else{int shift=shifts.getOrDefault(c,0);int field=c=='n'?(bits.chars().filter(x->x=='n').count()==3?2:4):c=='m'?(bits.chars().filter(x->x=='m').count()==3?1:2):c=='d'?1:0;value=field>>>shift&1;shifts.put(c,shift+1);}
            result|=value<<(bits.length()-1-j);
        }return result;
    }
    static void run(String[] row,int sz,int rm,int qis,boolean sram,boolean extraPr)throws Exception {
        String id=row[0],format=row[1],name=format.split(" ")[0];
        boolean dbl=row[3].equals("PR1"),pair=row[3].equals("SZ1");
        int mode=0x40000|(dbl||extraPr?0x80000:0)|sz|rm|qis;
        int code=encoding(row[2]),length=row[2].length()/8,start=sram?B+0x100:PC;
        var s=new AbstractCpu(SP);s.writeSr(0);s.fpscr=mode;s.fpul=1;
        Arrays.fill(s.fr,0x3f800000);s.fr[4]=0x40800000;s.fr[2]=0x40000000;
        if(dbl){s.fr[4]=0x40100000;s.fr[5]=0;s.fr[2]=0x40000000;s.fr[3]=0;}
        Arrays.fill(s.r,0);s.r[2]=B;s.r[4]=B;
        if(name.equals("FCNVSD"))s.fpul=0x3f800000;
        if(name.equals("LDS")&&!format.contains("@"))s.r[2]=format.contains("FPSCR")?0x40001:0x12345678;
        for(int a=B-32;a<B+64;a+=4)memory(s.ram,a,0x40001);
        byte[] image=new byte[0x200000];l(image,0,start);l(image,4,SP);
        byte[] ins=new byte[length+2];if(length==4)l(ins,0,code);else w(ins,0,code);w(ins,length,0x001b);
        if(sram)for(int j=0;j<ins.length;j++)s.ram.put(start+j,ins[j]);else System.arraycopy(ins,0,image,start,ins.length);
        var instruction=new Sh2aDecoder().decode(ins,0);
        int n=instruction.regN(),m=instruction.regM();
        s.fpscr|=0x18044;
        Integer[] fr=s.fr.clone(),gpr=s.r.clone();Integer fpul=s.fpul;int fpscr=s.fpscr;boolean t=false;
        if(Set.of(Sh2aDecoder.Operation.FPU_ARITHMETIC,Sh2aDecoder.Operation.FPU_COMPARE,Sh2aDecoder.Operation.FPU_CONVERT,Sh2aDecoder.Operation.FPU_SQRT,Sh2aDecoder.Operation.FPU_FMAC).contains(instruction.operation()))fpscr=mode|0x44;
        Map<Integer,Byte> ram=new HashMap<>(s.ram);
        switch(instruction.operation()) {
            case FPU_ARITHMETIC -> fr[n]=switch(name){case "FADD"->dbl?0x40180000:0x40c00000;case "FSUB"->dbl?0x40000000:0x40000000;case "FMUL"->dbl?0x40200000:0x41000000;case "FDIV"->dbl?0x40000000:0x40000000;default->throw new AssertionError(name);};
            case FPU_COMPARE -> t=name.equals("FCMP/GT");
            case FPU_SQRT -> fr[n]=dbl?0x40000000:0x40000000;
            case FPU_FMAC -> fr[n]=0x40c00000;
            case FPU_CONVERT -> {switch(name){
                case "FLOAT" -> {fr[n]=dbl?0x3ff00000:0x3f800000;if(dbl)fr[n+1]=0;}
                case "FTRC" -> fpul=2;
                case "FCNVSD" -> {fr[n]=0x3ff00000;fr[n+1]=0;}
                case "FCNVDS" -> fpul=0x40000000;
                default -> throw new AssertionError(name);
            }}
            case FPU_SIGN -> fr[n]=name.equals("FNEG")?fr[n]^0x80000000:fr[n]&0x7fffffff;
            case FPU_IMMEDIATE -> fr[n]=name.equals("FLDI0")?0:0x3f800000;
            case FPU_MODE -> fpscr^=0x100000;
            case FPU_REG_MOVE -> {if(name.equals("FLDS"))fpul=fr[n];else if(name.equals("FSTS"))fr[n]=fpul;else{fr[n]=fr[m];if(pair)fr[n+1]=fr[m+1];}}
            case FPU_REGISTER_TRANSFER -> {switch(m){
                case 0 -> gpr[n]=fpscr;case 1 -> gpr[n]=fpul;case 2 -> fpscr=0x40001;case 3 -> fpul=0x12345678;
                case 4,5 -> {gpr[n]-=4;memory(ram,gpr[n],m==4?fpscr:fpul);}
                case 6,7 -> {gpr[n]+=4;if(m==6)fpscr=0x40001;else fpul=0x40001;}
                default -> throw new AssertionError("transfer");
            }}
            case FPU_MEM_LOAD,FPU_MEM_STORE -> {
                int width=pair?8:4,offset=format.contains("disp")?width:0;
                if(instruction.operation()==Sh2aDecoder.Operation.FPU_MEM_LOAD){fr[n]=0x40001;if(pair)fr[n+1]=0x40001;if(instruction.postIncrement())gpr[m]+=width;}
                else {int a=B+offset;if(instruction.preDecrement()){a=B-width;gpr[n]=a;}memory(ram,a,fr[m]);if(pair)memory(ram,a+4,fr[m+1]);}
            }
            default -> throw new AssertionError("missing oracle "+format);
        }
        var graph=new FirmwareGraph();var report=graph.analyzeCpu(image,8,s);
        var after=graph.cpuStates().stream().filter(x->Objects.equals(x.pc(),start+length)).findFirst().orElseThrow(()->new AssertionError(id+" missing successor "+report.issues()));
        String label=id+" "+format+" mode="+Integer.toHexString(mode)+" SRAM="+sram;
        ok(after.fr().equals(Arrays.asList(fr)),label+" FR expected "+Arrays.toString(fr)+" got "+after.fr());
        ok(after.registers().equals(Arrays.asList(gpr)),label+" GPR");
        ok(Objects.equals(after.fpul(),fpul)&&Objects.equals(after.fpscr(),fpscr),label+" FPUL/FPSCR");
        ok(Objects.equals(after.t(),t),label+" T");ok(after.ram().equals(ram),label+" SRAM");ok(after.fpuPending()==null,label+" pending");
    }
    static void illegal(int opcode,int mode)throws Exception {
        byte[] image=new byte[0x200000];l(image,0,PC);l(image,4,SP);l(image,0x10,0x200);w(image,PC,opcode);w(image,PC+2,0x001b);w(image,0x200,0x001b);
        var s=new AbstractCpu(SP);s.writeSr(0);s.fpscr=0x40000|mode;s.fr[0]=0;
        var graph=new FirmwareGraph();var report=graph.analyzeCpu(image,8,s);
        ok(report.edges().stream().anyMatch(e->e.from()==PC&&e.to()==0x200),"missing illegal route "+Integer.toHexString(opcode)+report.issues());
        ok(graph.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),PC+2)),"illegal continued");
        var handler=graph.cpuStates().stream().filter(x->Objects.equals(x.pc(),0x200)).findFirst().orElseThrow();
        ok(handler.fpscr()==(0x40000|mode),"illegal altered FPSCR");
    }
    static void eventAndBoundary() throws Exception {
        byte[] image=new byte[0x200000];l(image,0,PC);l(image,4,SP);l(image,0x34,0x200);w(image,PC,0xf020);w(image,PC+2,0xf025);w(image,PC+4,0x001b);w(image,0x200,0x001b);
        var s=new AbstractCpu(SP);s.writeSr(0);s.t=true;s.fpscr=0x40080;s.fr[0]=0x3f800000;s.fr[2]=0x40000000;
        var graph=new FirmwareGraph();graph.analyzeCpu(image,12,s);
        ok(graph.fpuEvents().size()==1,"generation event count");var event=graph.fpuEvents().getFirst();
        ok(event.instructionPc()==PC&&event.cause()==0&&event.flags()==0&&event.enable()==0x80,"generation event fields");
        var next=graph.cpuStates().stream().filter(x->Objects.equals(x.pc(),PC+2)).findFirst().orElseThrow();
        ok(next.fr().get(0)==0x3f800000&&next.fpuPending()!=null,"event suppressed destination");
        var frozen=graph.cpuStates().stream().filter(x->Objects.equals(x.pc(),PC+4)).findFirst().orElseThrow();
        ok(!frozen.t()&&frozen.fpscr()==0x40080&&frozen.fpuPending()!=null,"pending FCMP changed flags or failed T");
        for(boolean pending:new boolean[]{false,true})for(int opcode:new int[]{0xf42b,0xf428,0x4266,0x4262}) {
            image=new byte[0x200000];l(image,0,PC);l(image,4,SP);w(image,PC,opcode);w(image,PC+2,0x001b);
            s=new AbstractCpu(SP);s.writeSr(0);s.fpscr=0x140000;s.r[2]=B+2;s.r[4]=B+2;s.fr[2]=0x12345678;s.fr[3]=0xabcdef00;
            if(pending)s.fpuExceptionPending=AbstractCpu.FPU_PENDING;
            graph=new FirmwareGraph();graph.analyzeCpu(image,8,s);
            ok(graph.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),PC+2)),"misaligned FPU continued");
            ok(graph.cpuBoundaries().stream().anyMatch(x->Objects.equals(x.vectorOffset(),0x24)),"misaligned FPU missing H24 boundary");
            var beforeR=s.r.clone();var beforeFr=s.fr.clone();var beforeRam=new HashMap<>(s.ram);int beforeFpscr=s.fpscr;
            var execute=FirmwareGraph.class.getDeclaredMethod("execute",AbstractCpu.class,Sh2aDecoder.Instruction.class);execute.setAccessible(true);
            byte[] bytes={(byte)(opcode>>>8),(byte)opcode};
            ok(!(boolean)execute.invoke(graph,s,new Sh2aDecoder().decode(bytes,0)),"misaligned execute succeeded");
            ok(Arrays.equals(beforeR,s.r)&&Arrays.equals(beforeFr,s.fr)&&beforeRam.equals(s.ram)&&s.fpscr==beforeFpscr,"misaligned transfer changed architectural state; pending="+pending);

        }
    }
    public static void main(String[] args)throws Exception {
        for(String line:Files.readAllLines(Path.of("tools/fixtures/renesas-isa.tsv")).subList(1,254)){
            String[] row=line.split("\t");if(!row[4].equals("5.9")&&!row[4].equals("5.10"))continue;
            forms++;
            int[] sizes=row[3].equals("SZ1")?new int[]{0x100000}:row[3].equals("SZ0")?new int[]{0}:new int[]{0,0x100000};
            for(int sz:sizes)for(int rm:new int[]{0,1})for(int qis:new int[]{0,0x400000})for(boolean ram:new boolean[]{false,true}){
                run(row,sz,rm,qis,ram,false);
                if(row[3].equals("ANY")||row[3].startsWith("SZ"))run(row,sz,rm,qis,ram,true);
            }
        }
        eventAndBoundary();
        ok(forms==56,"denominator="+forms);
        illegal(0xf3fd,0x80000);illegal(0xf0ad,0);illegal(0xf02e,0x80000);illegal(0xf19d,0x80000);illegal(0xf120,0x80000);
        System.out.println("FPU_FORMS_ACCEPTANCE: PASS forms="+forms+"/56 checks="+checks+" normal execution in ROM/SRAM; not exhaustive special-case proof");
    }
}
