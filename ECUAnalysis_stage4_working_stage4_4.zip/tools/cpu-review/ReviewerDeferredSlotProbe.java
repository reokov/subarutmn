package ecu.independent;
import java.util.*;
public class ReviewerDeferredSlotProbe {
 static final int A=0x1000,T=0x1100,SP=0xfff90000;
 static void w(byte[]a,int n,int x){a[n]=(byte)(x>>>8);a[n+1]=(byte)x;}static void l(byte[]a,int n,int x){w(a,n,x>>>16);w(a,n+2,x);}
 public static void main(String[]x){byte[]r=new byte[0x200000];l(r,0,A);l(r,4,SP);w(r,A,0xf420);w(r,A+2,0xa07d);w(r,A+4,9);w(r,T,0xf41d);w(r,T+2,0x1b);var s=new AbstractCpu(SP);s.writeSr(0);s.fpscr=0x40000;s.fr[4]=0x40800000;s.fr[2]=0x40000000;s.fpuCompletionBeforePc=Map.of(A,A+4);var g=new FirmwareGraph();g.analyzeCpu(r,32,s);var entry=g.cpuStates().stream().filter(a->a.pc()==T).findFirst().orElseThrow();System.out.println("TARGET FR4="+Integer.toHexString(entry.fr().get(4))+" deferred="+entry.deferredFpuResult());System.out.println("steps="+g.executionSteps());System.out.println("issues="+g.report().issues());if(entry.fr().get(4)!=0x40c00000||entry.deferredFpuResult()!=null)throw new AssertionError("explicit FP completion boundary at executed delay-slot PC was skipped");}
}
