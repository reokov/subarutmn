package ecu.independent;
import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;

/** Independent concrete oracles from Renesas SW instruction descriptions, not CPU outputs. */
public final class ReviewerPureCpuProbe {
 static final int A=0x100,B=0xfff81000,SP=0xfff82000,MH=0x12345678,ML=0x89abcdef;
 static final int[] V={0,1,-1,127,128,255,256,32767,32768,65535,65536,Integer.MAX_VALUE,Integer.MIN_VALUE,0x55555555,0xaaaaaaaa};
 static final BigInteger MASK=BigInteger.ONE.shiftLeft(32).subtract(BigInteger.ONE);
 static int pos,assertions,totalCases;static byte[] rom;static List<Want> wants;static List<String> rows=new ArrayList<>();
 record Want(int pc,int r0,int r1,int r2,int sr,int mh,int ml,Integer mem,String label){}
 static void word(byte[] a,int p,int v){a[p]=(byte)(v>>>8);a[p+1]=(byte)v;}
 static void lng(byte[] a,int p,int v){word(a,p,v>>>16);word(a,p+2,v);}
 static void emit(int w){word(rom,pos,w);pos+=2;}
 static void constant(int r,int v){if((pos&3)!=0)emit(9);emit(0xd001|(r<<8));emit(0xa003);emit(9);emit(9);lng(rom,pos,v);pos+=4;}
 static void start(){rom=new byte[0x200000];lng(rom,0,A);lng(rom,4,SP);pos=A;wants=new ArrayList<>();}
 static void setup(int x,int y,int sr){constant(0,x);constant(1,x);constant(2,y);constant(3,sr);emit(0x430e);constant(4,MH);emit(0x440a);constant(5,ML);emit(0x451a);}
 static void expect(int x,int r1,int y,int sr,int mh,int ml,Integer mem,String l){wants.add(new Want(pos,x,r1,y,sr,mh,ml,mem,l));}
 static void check(boolean v,String l){if(!v)throw new AssertionError(l);assertions++;}
 static void finish(String name,String source)throws Exception{
  emit(0x001b);AbstractCpu s=new AbstractCpu(SP);s.writeSr(0);FirmwareGraph g=new FirmwareGraph();g.analyzeCpu(rom,200000,s);
  Map<Integer,FirmwareGraph.CpuSnapshot> map=new HashMap<>();for(var q:g.cpuStates())map.put(q.pc(),q);
  int before=assertions;
  for(var e:wants){var q=map.get(e.pc);check(q!=null,name+" missing "+e.label+" pc="+Integer.toHexString(e.pc));
   check(Objects.equals(q.registers().get(0),e.r0)&&Objects.equals(q.registers().get(1),e.r1)&&Objects.equals(q.registers().get(2),e.r2),name+" GPR "+e.label+" "+q.registers());
   check(Objects.equals(q.sr(),e.sr),name+" SR "+e.label+" expected="+Integer.toHexString(e.sr)+" actual="+q.sr());
   check(Objects.equals(q.mach(),e.mh)&&Objects.equals(q.macl(),e.ml),name+" MAC "+e.label);
   if(e.mem!=null)check(q.ram().get(B)!=null&&(q.ram().get(B)&255)==e.mem,name+" RAM "+e.label);
  }
  totalCases+=wants.size();rows.add(name+","+wants.size()+","+(assertions-before)+",PASS,"+source);System.out.println(name+" cases="+wants.size()+" PASS");
 }
 static int sr(int t){return 0x3f2|t;}
 static void comparisons()throws Exception{
  String[] names={"CMP/EQ Rm,Rn","CMP/HS Rm,Rn","CMP/GE Rm,Rn","CMP/HI Rm,Rn","CMP/GT Rm,Rn","CMP/STR Rm,Rn","TST Rm,Rn"};
  int[] codes={0x3120,0x3122,0x3123,0x3126,0x3127,0x212c,0x2128};
  for(int k=0;k<codes.length;k++){start();for(int x:V)for(int yy:V)for(boolean alias:new boolean[]{false,true}){int y=alias?x:yy;setup(x,y,sr(1));int code=alias?(codes[k]&~0xf0)|0x10:codes[k];emit(code);
   boolean b=switch(k){case 0->x==y;case 1->Integer.toUnsignedLong(x)>=Integer.toUnsignedLong(y);case 2->x>=y;case 3->Integer.toUnsignedLong(x)>Integer.toUnsignedLong(y);case 4->x>y;case 5->{boolean equal=false;for(int j=0;j<4;j++)if(((x>>>(j*8))&255)==((y>>>(j*8))&255))equal=true;yield equal;}default->(x&y)==0;};
   expect(x,x,y,(sr(1)&~1)|(b?1:0),MH,ML,null,"x="+x+" y="+y+" alias="+alias);
  }finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  for(int k=0;k<2;k++){start();for(int x:V)for(int t=0;t<2;t++){setup(x,3,sr(t));emit(k==0?0x4115:0x4111);boolean b=k==0?x>0:x>=0;expect(x,x,3,(sr(t)&~1)|(b?1:0),MH,ML,null,"x="+x);}finish(k==0?"CMP/PL Rn":"CMP/PZ Rn","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  start();for(int x:V)for(int imm:new int[]{0,1,127,128,255}){setup(x,3,sr(1));emit(0x8800|imm);int v=imm>=128?imm-256:imm;expect(x,x,3,(sr(1)&~1)|(x==v?1:0),MH,ML,null,"x="+x+" imm="+imm);}finish("CMP/EQ #imm,R0","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");
 }
 static void extendLogic()throws Exception{
  String[] names={"EXTS.B Rm,Rn","EXTS.W Rm,Rn","EXTU.B Rm,Rn","EXTU.W Rm,Rn","SWAP.B Rm,Rn","SWAP.W Rm,Rn","NOT Rm,Rn","NEG Rm,Rn","XTRCT Rm,Rn","AND Rm,Rn","OR Rm,Rn","XOR Rm,Rn"};
  int[] codes={0x612e,0x612f,0x612c,0x612d,0x6128,0x6129,0x6127,0x612b,0x212d,0x2129,0x212b,0x212a};
  for(int k=0;k<codes.length;k++){start();for(int x:V)for(int yy:V)for(boolean alias:new boolean[]{false,true}){int y=alias?x:yy;setup(x,y,sr(1));emit(alias?(codes[k]&~0xf0)|0x10:codes[k]);int result=switch(k){case 0->(int)(byte)y;case 1->(int)(short)y;case 2->y&255;case 3->y&65535;case 4->(y&0xffff0000)|((y&255)<<8)|((y>>>8)&255);case 5->Integer.rotateLeft(y,16);case 6->~y;case 7->BigInteger.valueOf(y).negate().intValue();case 8->(int)((Integer.toUnsignedLong(x)/65536)+((Integer.toUnsignedLong(y)%65536)*65536));case 9->x&y;case 10->x|y;default->x^y;};expect(x,result,y,sr(1),MH,ML,null,"x="+x+" y="+y+" alias="+alias);}finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
 }
 static void multiplies()throws Exception{
  String[] names={"DMULS.L Rm,Rn","DMULU.L Rm,Rn","MUL.L Rm,Rn","MULS.W Rm,Rn","MULU.W Rm,Rn","MULR R0,Rn"};int[] codes={0x312d,0x3125,0x0127,0x212f,0x212e,0x4180};
  for(int k=0;k<codes.length;k++){start();for(int x:V)for(int yy:V)for(boolean alias:new boolean[]{false,true}){int y=alias?x:yy;setup(x,y,sr(1));if(k==5)constant(0,y);emit(k==5?codes[k]:alias?(codes[k]&~0xf0)|0x10:codes[k]);
   BigInteger a,b;if(k==1){a=BigInteger.valueOf(Integer.toUnsignedLong(x));b=BigInteger.valueOf(Integer.toUnsignedLong(y));}else if(k==3){a=BigInteger.valueOf((short)x);b=BigInteger.valueOf((short)y);}else if(k==4){a=BigInteger.valueOf(x&65535);b=BigInteger.valueOf(y&65535);}else{a=BigInteger.valueOf(x);b=BigInteger.valueOf(y);}BigInteger product=a.multiply(b);
   expect(k==5?y:x,k==5?product.intValue():x,y,sr(1),k<2?product.shiftRight(32).intValue():MH,k==5?ML:product.intValue(),null,"x="+x+" y="+y+" alias="+alias);
  }finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
 }
 static void rotationsShifts()throws Exception{
  String[] names={"ROTL Rn","ROTR Rn","ROTCL Rn","ROTCR Rn","SHAL Rn","SHAR Rn","SHLL Rn","SHLR Rn","SHLL2 Rn","SHLR2 Rn","SHLL8 Rn","SHLR8 Rn","SHLL16 Rn","SHLR16 Rn"};int[] codes={0x4104,0x4105,0x4124,0x4125,0x4120,0x4121,0x4100,0x4101,0x4108,0x4109,0x4118,0x4119,0x4128,0x4129};
  for(int k=0;k<codes.length;k++){start();for(int x:V)for(int t=0;t<2;t++){setup(x,3,sr(t));emit(codes[k]);boolean left=k%2==0;int amount=k<8?1:k<10?2:k<12?8:16;BigInteger u=BigInteger.valueOf(Integer.toUnsignedLong(x));int result;boolean flag=t!=0;
   if(k<4){String bits=String.format("%32s",Integer.toBinaryString(x)).replace(' ','0');if(k>=2)bits=left?bits+t:t+bits;String rolled=left?bits.substring(1)+bits.charAt(0):bits.charAt(bits.length()-1)+bits.substring(0,bits.length()-1);String out=k<2?rolled:left?rolled.substring(0,32):rolled.substring(1);result=new BigInteger(out,2).intValue();flag=left?x<0:(x&1)!=0;}
   else{result=left?u.shiftLeft(amount).intValue():k==5?BigInteger.valueOf(x).shiftRight(1).intValue():u.shiftRight(amount).intValue();if(k<8)flag=left?x<0:(x&1)!=0;}
   expect(x,result,3,(sr(t)&~1)|(flag?1:0),MH,ML,null,"x="+x+" t="+t);
  }finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
 }
 static void clips()throws Exception{
  String[] names={"CLIPS.B Rn","CLIPS.W Rn","CLIPU.B Rn","CLIPU.W Rn"};int[] codes={0x4191,0x4195,0x4181,0x4185};int[] extra={-32769,-32768,-129,-128,-1,0,127,128,255,256,32767,32768,65535,65536,Integer.MIN_VALUE,Integer.MAX_VALUE};
  for(int k=0;k<4;k++){start();for(int x:extra)for(int cs=0;cs<2;cs++){int oldsr=sr(1)|(cs<<13);setup(x,3,oldsr);emit(codes[k]);int bits=k%2==0?8:16;BigInteger v=k<2?BigInteger.valueOf(x):BigInteger.valueOf(Integer.toUnsignedLong(x));BigInteger lo=k<2?BigInteger.ONE.shiftLeft(bits-1).negate():BigInteger.ZERO,hi=BigInteger.ONE.shiftLeft(k<2?bits-1:bits).subtract(BigInteger.ONE);int out=v.max(lo).min(hi).intValue();expect(x,out,3,oldsr|(out!=x?0x2000:0),MH,ML,null,"x="+x+" cs="+cs);}finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
 }
 static void bits()throws Exception{
  String[] names={"BCLR #imm3,Rn","BSET #imm3,Rn","BST #imm3,Rn","BLD #imm3,Rn"};int[] codes={0x8610,0x8618,0x8710,0x8718};
  for(int k=0;k<4;k++){start();for(int x:V)for(int bit=0;bit<8;bit++)for(int t=0;t<2;t++){setup(x,3,sr(t));emit(codes[k]|bit);int out=x,flags=sr(t);if(k==0)out=x&~(1<<bit);if(k==1)out=x|(1<<bit);if(k==2)out=(x&~(1<<bit))|(t<<bit);if(k==3)flags=(flags&~1)|((x>>>bit)&1);expect(x,out,3,flags,MH,ML,null,"x="+x+" bit="+bit+" t="+t);}finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  String[] mn={"BCLR.B #imm3,@(disp12,Rn)","BSET.B #imm3,@(disp12,Rn)","BST.B #imm3,@(disp12,Rn)","BLD.B #imm3,@(disp12,Rn)","BAND.B #imm3,@(disp12,Rn)","BOR.B #imm3,@(disp12,Rn)","BXOR.B #imm3,@(disp12,Rn)","BLDNOT.B #imm3,@(disp12,Rn)","BANDNOT.B #imm3,@(disp12,Rn)","BORNOT.B #imm3,@(disp12,Rn)"};int[] second={0,1,2,3,4,5,6,11,12,13};
  for(int k=0;k<10;k++){start();for(int x:new int[]{0,255,0x55,0xaa})for(int bit=0;bit<8;bit++)for(int t=0;t<2;t++)for(int disp:new int[]{0,4095}){setup(x,3,sr(t));constant(1,B-disp);constant(6,B);emit(0x2600);emit(0x3109|(bit<<4));emit((second[k]<<12)|disp);int out=x,flags=sr(t),b=(x>>>bit)&1;if(k==0)out=x&~(1<<bit);if(k==1)out=x|(1<<bit);if(k==2)out=(x&~(1<<bit))|(t<<bit);if(k==3)flags=(flags&~1)|b;if(k==4)flags=(flags&~1)|(t&b);if(k==5)flags=(flags&~1)|(t|b);if(k==6)flags=(flags&~1)|(t^b);if(k==7)flags=(flags&~1)|(b^1);if(k==8)flags=(flags&~1)|(t&(b^1));if(k==9)flags=(flags&~1)|(t|(b^1));expect(x,B-disp,3,flags,MH,ML,out,"x="+x+" bit="+bit+" t="+t+" disp="+disp);}finish(mn[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
 }

 static void others()throws Exception{
  String[] names={"AND #imm,R0","OR #imm,R0","XOR #imm,R0","TST #imm,R0"};int[] codes={0xc900,0xcb00,0xca00,0xc800};
  for(int k=0;k<4;k++){start();for(int x:V)for(int imm:new int[]{0,1,127,128,255})for(int t=0;t<2;t++){setup(x,3,sr(t));emit(codes[k]|imm);int out=k==0?x&imm:k==1?x|imm:k==2?x^imm:x;int flags=k==3?(sr(t)&~1)|((x&imm)==0?1:0):sr(t);expect(out,x,3,flags,MH,ML,null,"x="+x+" imm="+imm+" t="+t);}finish(names[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  String[] memnames={"AND.B #imm,@(R0,GBR)","OR.B #imm,@(R0,GBR)","XOR.B #imm,@(R0,GBR)","TST.B #imm,@(R0,GBR)"};int[] memcodes={0xcd00,0xcf00,0xce00,0xcc00};
  for(int k=0;k<4;k++){start();for(int x:new int[]{0,1,127,128,255})for(int imm:new int[]{0,1,127,128,255})for(int t=0;t<2;t++){setup(x,3,sr(t));constant(6,B);emit(0x2600);constant(7,B-5);emit(0x471e);constant(0,5);emit(memcodes[k]|imm);int out=k==0?x&imm:k==1?x|imm:k==2?x^imm:x;int flags=k==3?(sr(t)&~1)|((x&imm)==0?1:0):sr(t);expect(5,x,3,flags,MH,ML,out,"x="+x+" imm="+imm+" t="+t);}finish(memnames[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  start();for(int x:new int[]{0,1,127,128,255})for(int t=0;t<2;t++){setup(x,3,sr(t));constant(1,B);emit(0x2100);emit(0x411b);expect(x,B,3,(sr(t)&~1)|(x==0?1:0),MH,ML,x|128,"x="+x+" t="+t);}finish("TAS.B @Rn","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");
  String[] flagnames={"CLRT","SETT","NOTT","MOVT Rn","MOVRT Rn","DT Rn","CLRMAC","DIV0U"};int[] flagcodes={0x0008,0x0018,0x0068,0x0129,0x0139,0x4110,0x0028,0x0019};
  for(int k=0;k<flagcodes.length;k++){start();for(int x:V)for(int t=0;t<2;t++){setup(x,3,sr(t));emit(flagcodes[k]);int r=x,flags=sr(t);if(k==0)flags&=~1;if(k==1)flags|=1;if(k==2)flags^=1;if(k==3)r=t;if(k==4)r=1-t;if(k==5){r=BigInteger.valueOf(x).subtract(BigInteger.ONE).intValue();flags=(flags&~1)|(r==0?1:0);}if(k==7)flags&=~0x301;expect(x,r,3,flags,k==6?0:MH,k==6?0:ML,null,"x="+x+" t="+t);}finish(flagnames[k],"Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  start();for(int x:V)for(int yy:V)for(boolean alias:new boolean[]{false,true}){int y=alias?x:yy;setup(x,y,sr(1));emit(alias?0x2117:0x2127);int flags=(sr(1)&~0x301)|(x<0?0x100:0)|(y<0?0x200:0)|((x<0)!=(y<0)?1:0);expect(x,x,y,flags,MH,ML,null,"x="+x+" y="+y);}finish("DIV0S Rm,Rn","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");
  for(boolean sub:new boolean[]{false,true}){start();for(int x:V)for(int yy:V)for(boolean alias:new boolean[]{false,true}){int y=alias?x:yy;setup(x,y,sr(1));emit((sub?0x3128:0x312c)-(alias?0x10:0));int out=(sub?BigInteger.valueOf(x).subtract(BigInteger.valueOf(y)):BigInteger.valueOf(x).add(BigInteger.valueOf(y))).intValue();expect(x,out,y,sr(1),MH,ML,null,"x="+x+" y="+y);}finish(sub?"SUB Rm,Rn":"ADD Rm,Rn","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  for(boolean mov:new boolean[]{false,true}){start();for(int x:V)for(int imm:new int[]{0,1,127,128,255}){setup(x,3,sr(1));emit((mov?0xe100:0x7100)|imm);int v=imm<128?imm:imm-256;expect(x,mov?v:BigInteger.valueOf(x).add(BigInteger.valueOf(v)).intValue(),3,sr(1),MH,ML,null,"x="+x+" imm="+imm);}finish(mov?"MOV #imm,Rn":"ADD #imm,Rn","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  for(boolean shifted:new boolean[]{false,true}){start();for(int imm:new int[]{0,1,127,255,0x7ffff,0x80000,0xfffff}){setup(7,3,sr(1));emit(0x0100|((imm>>>16)<<4)|(shifted?1:0));emit(imm&65535);int signed=imm>=0x80000?imm-0x100000:imm;int out=BigInteger.valueOf(signed).shiftLeft(shifted?8:0).intValue();expect(7,out,3,sr(1),MH,ML,null,"imm="+imm);}finish(shifted?"MOVI20S #imm,Rn":"MOVI20 #imm,Rn","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");}
  start();for(int x:V){setup(x,3,sr(1));emit(0x4080);expect(BigInteger.valueOf(x).pow(2).intValue(),x,3,sr(1),MH,ML,null,"x="+x);}finish("MULR R0,R0 (alias)","Renesas SW Rev3.00 instruction descriptions; exact per-form pages in isa-encodings.csv");
 }
 public static void main(String[] args)throws Exception{comparisons();extendLogic();multiplies();rotationsShifts();clips();bits();others();Files.write(Path.of("build/cpu-independent-pure-coverage.csv"),concat());System.out.println("REVIEWER_PURE_CPU_PROBE PASS forms="+rows.size()+" cases="+totalCases+" assertions="+assertions);}
 static List<String> concat(){List<String> all=new ArrayList<>();all.add("mnemonic,cases,assertions,status,source");for(String line:rows){int first=line.indexOf(','); // Quote the mnemonic because operands contain commas.
  // Rows are assembled with mnemonic commas; find trailing case count from the right marker.
  int marker=line.indexOf(",PASS,");int prev=line.lastIndexOf(',',marker-1),prev2=line.lastIndexOf(',',prev-1);all.add("\""+line.substring(0,prev2)+"\""+line.substring(prev2));}return all;}
}
