package ecu.independent;

import java.nio.file.*;
import java.util.*;

/** Primary-manual CPU oracles. Executes only the production decode/worklist/execute path. */
public final class CpuExecutionAcceptance {
    static final int A=0x100, B=0xFFF81000, SP=B+0x1000;
    static int checks,forms;
    static final List<String> covered=new ArrayList<>();
    static void ok(boolean value,String reason){ if(!value)throw new AssertionError(reason);checks++; }
    static void word(byte[] rom,int address,int value){rom[address]=(byte)(value>>>8);rom[address+1]=(byte)value;}
    static void longword(byte[] rom,int address,int value){word(rom,address,value>>>16);word(rom,address+2,value);}
    static byte[] image(){byte[] rom=new byte[0x200000];longword(rom,0,A);longword(rom,4,SP);return rom;}
    static AbstractCpu initial(){
        AbstractCpu s=new AbstractCpu(SP);
        for(int r=0;r<15;r++)s.r[r]=0x10+r;
        s.r[0]=3;s.r[1]=7;s.r[2]=-5;s.writeSr(0);
        s.pr=0x500;s.gbr=B;s.tbr=B;s.vbr=0;s.mach=1;s.macl=2;s.fpul=0x12345678;
        return s;
    }
    static void memory(AbstractCpu s,int address,int width,int value){
        for(int j=0;j<width;j++)s.ram.put(address+j,(byte)(value>>>(8*(width-1-j))));
    }
    static final class Expected {
        Integer[] r; Integer pr,gbr,vbr,tbr,mach,macl;int sr,pc,bn;
        Map<Integer,Byte> ram; Map<Integer,Integer> bank;
        Expected(AbstractCpu s,int pc){
            r=s.r.clone();pr=s.pr;gbr=s.gbr;vbr=s.vbr;tbr=s.tbr;mach=s.mach;macl=s.macl;
            sr=0;this.pc=pc;bn=s.nextBank;ram=new HashMap<>(s.ram);bank=new HashMap<>(s.bankCells);
        }
        void flag(int bit,boolean value){sr=value?sr|bit:sr&~bit;}
        void put(int address,int width,int value){for(int j=0;j<width;j++)ram.put(address+j,(byte)(value>>>(8*(width-1-j))));}
    }
    static FirmwareGraph graph(byte[] rom,AbstractCpu s){FirmwareGraph g=new FirmwareGraph();g.analyzeCpu(rom,32,s);return g;}
    static FirmwareGraph.CpuSnapshot at(FirmwareGraph graph,int pc){
        return graph.cpuStates().stream().filter(x->Objects.equals(x.pc(),pc)).findFirst().orElseThrow(()->new AssertionError("Missing CPU state at "+Integer.toHexString(pc)));
    }
    static void compare(FirmwareGraph g,Expected e,String label){
        var actual=at(g,e.pc);
        ok(actual.registers().equals(Arrays.asList(e.r)),label+" GPR expected="+Arrays.toString(e.r)+" actual="+actual.registers());
        ok(Objects.equals(actual.sr(),e.sr),label+" SR expected="+Integer.toHexString(e.sr)+" actual="+actual.sr());
        ok(Objects.equals(actual.pr(),e.pr)&&Objects.equals(actual.gbr(),e.gbr)&&Objects.equals(actual.vbr(),e.vbr)&&Objects.equals(actual.tbr(),e.tbr),label+" control registers "+actual);
        ok(Objects.equals(actual.mach(),e.mach)&&Objects.equals(actual.macl(),e.macl),label+" MAC registers "+actual);
        ok(actual.ram().equals(e.ram),label+" RAM");
        ok(actual.bankCells().equals(e.bank)&&Objects.equals(actual.nextBank(),e.bn),label+" banks");
    }
    static int encoding(String bits){
        int code=0;Map<Character,Integer> positions=new HashMap<>();
        for(int j=bits.length()-1;j>=0;j--){char c=bits.charAt(j);int b;
            if(c=='0'||c=='1')b=c-'0';else{int shift=positions.getOrDefault(c,0);int value=c=='n'?1:c=='m'?2:c=='i'?3:4;b=(value>>>shift)&1;positions.put(c,shift+1);}
            code|=b<<(bits.length()-1-j);
        }return code;
    }
    static int loadValue(int width){return width==1?-128:width==2?-32513:0x80FF1234;}
    static void instruction(String[] row){instruction(row,null);}
    static void instruction(String[] row,int[] registerMap){instruction(row,registerMap,4);}
    static void instruction(String[] row,int[] registerMap,int displacement){
        String id=row[0], f=row[1].replace("@( R0","@(R0"), name=f.split(" ")[0], bits=row[2];
        int length=bits.length()/8, code=encoding(bits), width=name.endsWith(".B")?1:name.endsWith(".W")?2:4;
        int displacementShift=0;
        for(int j=bits.length()-1;j>=0;j--)if(bits.charAt(j)=='d'){
            int bit=bits.length()-1-j;code=(code&~(1<<bit))|(((displacement>>>displacementShift++)&1)<<bit);
        }
        byte[] rom=image();if(length==4)longword(rom,A,code);else word(rom,A,code);word(rom,A+length,0x001b);
        AbstractCpu s=initial();Expected e=new Expected(s,A+length);
        // Tables5.3-5.11 and the matching detailed section6 descriptions: explicit CPU observations.
        if(name.equals("MOV")){e.r[1]=f.contains("#")?3:-5;}
        else if(name.equals("MOVI20"))e.r[1]=3;
        else if(name.equals("MOVI20S"))e.r[1]=768;
        else if(name.equals("MOVA"))e.r[0]=0x104+displacement*4;
        else if(name.startsWith("MOV.")||name.startsWith("MOVU.")){
            boolean store=f.indexOf('@')>f.indexOf(',');int address=B;int value=3;
            if(f.contains("PC")){
                address=0x104+displacement*width;
                if(width==2)word(rom,address,0x80ff);else longword(rom,address,0x80ff1234);
                e.r[1]=width==2?-32513:0x80ff1234;
            }else{
                if(f.contains("GBR")){address=B+displacement*width;if(!store)e.r[0]=loadValue(width);}
                else if(f.contains("@(R0")){
                    address=B+3;
                    // Align the effective indexed address without changing the encoded registers.
                    if(store){s.r[1]=B-3;e.r[1]=B-3;value=-5;}
                    else{s.r[2]=B-3;e.r[2]=B-3;e.r[1]=loadValue(width);}address=B;
                }else if(f.contains("@Rn+")){
                    s.r[1]=B;e.r[1]=B+width;
                }else if(f.contains("@-Rm")){
                    s.r[2]=B+width;e.r[2]=B;e.r[0]=loadValue(width);
                }else if(store){
                    s.r[1]=B;e.r[1]=B;value=f.startsWith(name+" Rm")?-5:3;
                    if(f.contains("@-Rn")){address=B-width;e.r[1]=address;}
                    else if(f.contains("disp"))address=B+displacement*width;
                }else{
                    s.r[2]=B;e.r[2]=B;if(f.contains("disp"))address=B+displacement*width;
                    if(f.contains("@Rm+"))e.r[2]=B+width;
                    if(f.endsWith(", R0")||f.endsWith(",R0"))e.r[0]=loadValue(width);else e.r[1]=loadValue(width);
                }
                if(store)e.put(address,width,value);
                else{
                    memory(s,address,width,width==1?0x80:width==2?0x80ff:0x80ff1234);e.ram=new HashMap<>(s.ram);
                    if(name.startsWith("MOVU"))e.r[1]=width==1?128:33023;
                }
            }
        }else if(name.startsWith("MOVML")||name.startsWith("MOVMU")){
            boolean lower=name.startsWith("MOVML"), push=f.contains("@-R15");int count=lower?(push?3:2):(push?14:15);
            if(push){
                e.r[15]=SP-4*count;
                if(lower){e.put(SP-12,4,3);e.put(SP-8,4,7);e.put(SP-4,4,-5);}
                else{for(int j=2;j<=14;j++)e.put(SP-56+4*(j-2),4,s.r[j]);e.put(SP-4,4,0x500);}
            }else{
                for(int j=0;j<count;j++)memory(s,SP+4*j,4,100+j);e.ram=new HashMap<>(s.ram);e.r[15]=SP+4*count;
                if(lower){e.r[0]=100;e.r[1]=101;}else{for(int j=1;j<=14;j++)e.r[j]=99+j;e.pr=114;}
            }
        }else if(name.startsWith("CMP")){
            boolean t=switch(name){case "CMP/EQ"->f.contains("#");case "CMP/GE","CMP/GT","CMP/PL","CMP/PZ"->true;default->false;};e.flag(1,t);
        }else if(name.startsWith("CLIP")){
            // Baseline positive7 is already in range; stickyCS and clipping boundaries below.
        }else if(name.equals("MAC.L")||name.equals("MAC.W")){
            s.r[1]=B;s.r[2]=B+8;e.r[1]=B+width;e.r[2]=B+8+width;
            memory(s,B,width,3);memory(s,B+8,width,-4);e.ram=new HashMap<>(s.ram);e.mach=0;e.macl=-10;
        }else if(name.equals("MUL.L")||name.equals("MULS.W")){e.macl=-35;}
        else if(name.equals("MULU.W"))e.macl=458717;
        else if(name.equals("DMULS.L")){e.mach=-1;e.macl=-35;}
        else if(name.equals("DMULU.L")){e.mach=6;e.macl=-35;}
        else if(name.startsWith("B") && !Set.of("BRA","BRAF","BSR","BSRF","BT","BT/S","BF","BF/S").contains(name)){
            int action=switch(name.replace(".B","")){case "BCLR"->0;case "BSET"->1;case "BST"->2;case "BLD"->3;case "BAND"->4;case "BOR"->5;case "BXOR"->6;case "BLDNOT"->11;case "BANDNOT"->12;default->13;};
            if(name.endsWith(".B")){
                s.r[1]=B;e.r[1]=B;memory(s,B+4,1,0xa5);e.ram=new HashMap<>(s.ram);
                if(action==1)e.put(B+4,1,0xad);
                if(action==11||action==13)e.flag(1,true);
            }else{if(action==1)e.r[1]=15;}
        }else if(Set.of("BRA","BRAF","BSR","BSRF","BT","BT/S","BF","BF/S","JMP","JSR","JSR/N","RTS","RTS/N","RTV/N","RTE","TRAPA").contains(name)){
            int destination=0x400;
            if(name.equals("BRA")||name.equals("BSR")||Set.of("BT","BT/S","BF","BF/S").contains(name))destination=0x10c;
            if(name.equals("BRAF")||name.equals("BSRF")){s.r[2]=0x2fc;e.r[2]=0x2fc;}
            if(name.equals("JMP")||name.equals("JSR")||(name.equals("JSR/N")&&!f.contains("TBR"))){s.r[2]=destination;e.r[2]=destination;}
            if(name.startsWith("RT")&&!name.equals("RTE"))destination=0x500;
            if(name.equals("RTV/N"))e.r[0]=-5;
            if(name.equals("JSR/N")&&f.contains("TBR")){memory(s,B+16,4,destination);e.ram=new HashMap<>(s.ram);}
            if(Set.of("BSR","BSRF","JSR").contains(name))e.pr=0x104;
            if(name.equals("JSR/N"))e.pr=0x102;
            if(name.equals("RTE")){memory(s,SP,4,destination);memory(s,SP+4,4,0x63f3);e.ram=new HashMap<>(s.ram);e.sr=0x63f3;e.r[15]=SP+8;}
            if(name.equals("TRAPA")){longword(rom,12,destination);e.put(SP-4,4,0);e.put(SP-8,4,0x102);e.r[15]=SP-8;}
            boolean delayed=Set.of("BRA","BRAF","BSR","BSRF","JMP","JSR","RTS","RTE","BT/S","BF/S").contains(name);
            if(delayed)word(rom,0x102,0x0009);
            if(name.equals("BT")||name.equals("BT/S")){destination=0x102;word(rom,0x102,0x001b);}
            word(rom,destination,0x001b);e.pc=destination;
        }else if(name.startsWith("LDC")||name.startsWith("STC")||name.startsWith("LDS")||name.startsWith("STS")){
            String sys=f.contains("FPSCR")?"FPSCR":f.contains("FPUL")?"FPUL":f.contains("MACH")?"MACH":f.contains("MACL")?"MACL":f.contains("PR")?"PR":f.contains("GBR")?"GBR":f.contains("VBR")?"VBR":f.contains("TBR")?"TBR":"SR";
            boolean load=name.startsWith("LD"),mem=name.endsWith(".L");
            int old=switch(sys){case "FPSCR"->0x40001;case "FPUL"->0x12345678;case "MACH"->1;case "MACL"->2;case "PR"->0x500;case "GBR","TBR"->B;default->0;};
            int value=mem?0x12345678:-5; // Source m is encodedasR2 forloads, n=R1 forstores.
            if(load && !mem){s.r[2]=-5;e.r[2]=-5;}
            if(mem){
                int reg=load?2:1;s.r[reg]=B;e.r[reg]=load?B+4:B-4;
                if(load){memory(s,B,4,value);e.ram=new HashMap<>(s.ram);}else e.put(B-4,4,old);
            }
            if(load){switch(sys){case "SR"->e.sr=value&0x63f3;case "GBR"->e.gbr=value;case "VBR"->e.vbr=value;case "TBR"->e.tbr=value;case "PR"->e.pr=value;case "MACH"->e.mach=value;case "MACL"->e.macl=value;default->{}}}
            else if(!mem)e.r[1]=old;
        }else if(name.equals("LDBANK")){
            s.r[2]=0x10c;e.r[2]=0x10c;s.bankCells.put(43,0xcafe);e.bank=new HashMap<>(s.bankCells);e.r[0]=0xcafe;
        }else if(name.equals("STBANK")){
            s.r[1]=0x10c;e.r[1]=0x10c;e.bank.put(43,3);
        }else if(name.equals("RESBANK")){
            s.nextBank=1;for(int j=0;j<20;j++)s.bankCells.put(j,1000+j);e.bank=new HashMap<>(s.bankCells);e.bn=0;
            for(int j=0;j<15;j++)e.r[j]=1000+j;e.mach=1015;e.pr=1017;e.gbr=1018;e.macl=1019;
        }else switch(name){
            case "ADD"->e.r[1]=f.contains("#")?10:2;
            case "ADDC"->{e.r[1]=2;e.flag(1,true);}case "ADDV"->e.r[1]=2;
            case "SUB"->e.r[1]=12;case "SUBC"->{e.r[1]=12;e.flag(1,true);}case "SUBV"->e.r[1]=12;
            case "AND"->{if(f.contains("#"))e.r[0]=3;else e.r[1]=3;}
            case "OR"->{if(f.contains("#"))e.r[0]=3;else e.r[1]=-1;}
            case "XOR"->{if(f.contains("#"))e.r[0]=0;else e.r[1]=-4;}
            case "TST"->e.flag(1,false);
            case "AND.B","OR.B","XOR.B","TST.B"->{
                memory(s,B+3,1,0x85);e.ram=new HashMap<>(s.ram);
                if(!name.equals("TST.B"))e.put(B+3,1,name.equals("AND.B")?1:name.equals("OR.B")?0x87:0x86);
            }
            case "TAS.B"->{s.r[1]=B;e.r[1]=B;memory(s,B,1,0);e.ram=new HashMap<>(s.ram);e.put(B,1,0x80);e.flag(1,true);}
            case "CLRMAC"->{e.mach=0;e.macl=0;}
            case "MULR"->e.r[1]=21;case "DIVS","DIVU"->e.r[1]=2;
            case "DIV0U"->{}case "DIV0S"->{e.flag(0x200,true);e.flag(1,true);}
            case "DIV1"->{e.r[1]=19;e.flag(0x100,true);}
            case "DT"->{e.r[1]=6;e.flag(1,false);}
            case "NEG"->e.r[1]=5;case "NEGC"->{e.r[1]=5;e.flag(1,true);}case "NOT"->e.r[1]=4;
            case "EXTS.B","EXTS.W"->e.r[1]=-5;case "EXTU.B"->e.r[1]=251;case "EXTU.W"->e.r[1]=65531;
            case "SWAP.B"->e.r[1]=0xfffffbff;case "SWAP.W"->e.r[1]=0xfffbffff;case "XTRCT"->e.r[1]=0xfffb0000;
            case "MOVRT"->e.r[1]=1;case "MOVT"->e.r[1]=0;case "NOTT","SETT"->e.flag(1,true);case "CLRT"->{}
            case "ROTL","ROTCL","SHLL","SHAL"->e.r[1]=14;
            case "ROTR"->{e.r[1]=0x80000003;e.flag(1,true);}case "ROTCR","SHLR","SHAR"->{e.r[1]=3;e.flag(1,true);}
            case "SHLL2"->e.r[1]=28;case "SHLR2"->e.r[1]=1;case "SHLL8"->e.r[1]=1792;case "SHLL16"->e.r[1]=0x70000;
            case "SHLR8","SHLR16","SHAD","SHLD"->e.r[1]=0;
            case "NOP","PREF"->{}case "SLEEP"->e.pc=A;
            default->throw new AssertionError("No independent CPU oracle for "+id+" "+f);
        }
        if(registerMap!=null){
            // Bijection over explicit register fields; fixed R0 retains its architectural role.
            Integer[] before=s.r.clone(),after=e.r.clone();
            for(int r=0;r<16;r++){s.r[registerMap[r]]=before[r];e.r[registerMap[r]]=after[r];}
            int mapped=0;Map<Character,Integer> shifts=new HashMap<>();
            for(int j=bits.length()-1;j>=0;j--){char c=bits.charAt(j);int bit;
                if(c=='0'||c=='1')bit=c-'0';else{
                    int shift=shifts.getOrDefault(c,0);
                    int value=c=='n'?registerMap[1]:c=='m'?registerMap[2]:c=='i'?3:displacement;
                    bit=(value>>>shift)&1;shifts.put(c,shift+1);
                }mapped|=bit<<(bits.length()-1-j);
            }
            if(length==4)longword(rom,A,mapped);else word(rom,A,mapped);
        }
        FirmwareGraph g=graph(rom,s);compare(g,e,id+" "+f+(registerMap==null?"":" mapped="+Arrays.toString(registerMap)));
        if(registerMap==null && displacement==4){covered.add(id);forms++;}
        if(row[4].equals("5.10")){
            // CPU-to-FPU writes observed through STS after the originalLDS, not a secondCPU executor.
            if(name.startsWith("LDS")){
                word(rom,A+length,sysWord(f.contains("FPSCR")));word(rom,A+length+2,0x001b);
                int expected=f.contains("FPSCR")?((name.endsWith(".L")?0x12345678:-5)&0x005bffff)|0x40000:name.endsWith(".L")?0x12345678:-5;
                ok(at(graph(rom,s),A+length+2).registers().get(3)==expected,id+" FPU-related CPU bit transfer");
            }
        }
    }
    static int sysWord(boolean fpscr){return fpscr?0x036a:0x035a;}
    static int[] permutation(int n,int m){
        int[] map=new int[16];for(int r=0;r<16;r++)map[r]=r;
        for(int role:new int[]{1,2}){
            int wanted=role==1?n:m,found=0;while(map[found]!=wanted)found++;
            int old=map[role];map[role]=map[found];map[found]=old;
        }return map;
    }
    static void addressingRegisters(List<String> lines)throws Exception{
        int scenarios=0;List<String> tested=new ArrayList<>();
        for(String line:lines){String[] row=line.split("\t");String name=row[1].split(" ")[0];
            if(!(name.matches("MOV\\.[BWL]")||name.matches("MOVU\\.[BW]")))continue;
            String bits=row[2];boolean hasN=bits.indexOf('n')>=0,hasM=bits.indexOf('m')>=0;
            if(bits.indexOf('d')>=0){
                int count=(int)bits.chars().filter(c->c=='d').count();
                for(int displacement:new int[]{0,1,(1<<count)-1}){instruction(row,null,displacement);scenarios++;}
            }
            if(!hasN&&!hasM){tested.add(row[0]);continue;}
            if(hasN&&hasM){
                for(int n=1;n<16;n++)for(int m=1;m<16;m++)if(n!=m){instruction(row,permutation(n,m));scenarios++;}
            }else for(int r=1;r<16;r++){
                instruction(row,permutation(hasN?r:(r==1?2:1),hasM?r:(r==2?1:2)));scenarios++;
            }
            tested.add(row[0]);
        }
        Files.write(Path.of("build/cpu-addressing-register-forms.txt"),tested);
        Files.writeString(Path.of("build/cpu-addressing-register-count.txt"),"forms="+tested.size()+" scenarios="+scenarios+"; distinct explicit R1-R15 and displacement0/1/max; aliases and R0 are separate cases\n");
    }
    public static void main(String[] args)throws Exception{
        for(String line:Files.readAllLines(Path.of("tools/fixtures/renesas-isa.tsv")).subList(1,254)){
            String[] row=line.split("\t");if(!row[4].equals("5.9"))instruction(row);
        }
        ok(forms==205,"Full applicable CPU denominator205");
        Files.write(Path.of("build/cpu-covered-forms.txt"),covered);
        addressingRegisters(Files.readAllLines(Path.of("tools/fixtures/renesas-isa.tsv")).subList(1,254));
        ok(forms==205,"Register/displacement cases cannot change normative denominator");
        System.out.println("CPU_EXECUTION_ACCEPTANCE: PASS forms="+forms+"/205 checks="+checks+"; baseline per-form, boundary acceptance required separately");
    }
}
