package ecu.independent;

/**
 * Synthetic acceptance of the STBCR READ path:
 *   decode -> execute -> loadState -> loadStbcr -> CPU register,
 * plus the write half (store -> storeStbcr) that the read path observes.
 *
 * Oracle: R01UH0480EJ0400 Rev.4.00 (SH7254R Hardware Manual) section 29.3.1/29.3.2,
 * build/hw-manual-full.txt txt 64868-64999:
 *   - STBCR is a 16-bit register readable at sizes 8 and 16 (table 29.4 txt 64868;
 *     "Both word and byte accesses are available to read STBCR" txt 64882-64883);
 *   - bits 15:8 STBCRKEY always read H'00, written values are not retained
 *     (txt 64895-64916); bits 7:5 reserved read 0 (txt 64914-64916);
 *   - bits 4:0 are MSTP4..MSTP0 (txt 64917-64975);
 *   - a transfer wider than a word is not a defined STBCR access (table 29.4 lists
 *     sizes 8 and 16 only);
 *   - only a WORD transfer whose upper byte is H'3C modifies the MSTP bits;
 *     a byte transfer is ignored (txt 64878-64880 / 64994-64996);
 *   - MSTP1 (FPU) is irreversible except by power-on reset (txt 64960-64967).
 *
 * Expected values are derived from the manual, NOT from the implementation.
 * Each scenario ends every admissible path with SLEEP so the frontier cannot run
 * into the zero-filled ROM tail; the YES/NO markers distinguish a proven read
 * value from an UNKNOWN one (an UNKNOWN register drives BOTH conditional edges).
 *
 * SYNTHETIC control-flow/state check on an in-memory image; not a Renesas
 * cycle-accurate simulator oracle and not a release claim.
 */
public final class StbcrReadPathAcceptance {
    private static final int LIT=0x180;   // literal pool: STBCR base address
    private static final int YES=0x1C0;   // marker reached iff read value == expected, or UNKNOWN
    private static final int NO =0x1C6;   // marker reached iff read value != expected (or UNKNOWN)
    private static final int STBCR=0xFFFE0400;

    private StbcrReadPathAcceptance() {}

    private static void word(byte[] rom,int a,int value) {
        rom[a]=(byte)(value>>>8);rom[a+1]=(byte)value;
    }
    private static void dword(byte[] rom,int a,int value) {
        word(rom,a,value>>>16);word(rom,a+2,value);
    }
    /** 32-bit MOVI20 (Renesas table 5.3): first word 0000nnnniiii0000, second = bits 15:0. */
    private static void movi20(byte[] rom,int a,int n,int value) {
        int v=value&0xFFFFF;
        word(rom,a,(n<<8)|(((v>>>16)&15)<<4));
        word(rom,a+2,v&0xFFFF);
    }
    /**
     * "R0 == X?" probe at cmp: CMP/EQ #X,R0; BT -> YES; BF -> NO; SLEEP after each
     * marker and at cmp+6, the BF fall-through (end, FirmwareGraph.java:286). SLEEP is
     * Flow.STOP (Sh2aDecoder.java:179, FirmwareGraph.java:518), so every admissible
     * path closes instead of running into the zero-filled ROM tail.
     * BT/BF test the post-CMP T flag (FirmwareGraph.java:1373, null when R0 is unknown):
     * a proven comparison reaches exactly one marker; an UNKNOWN comparison emits both
     * edges of each conditional (FirmwareGraph.java:457-461), so YES, NO and the SLEEP
     * at cmp+6 are all reached. The cmp+6 fall-through belongs to the UNKNOWN-T item
     * only: for T=true the BT prunes its own fall-through, so the BF is never visited,
     * and for T=false the BF prunes its skip edge to end.
     */
    private static void probe(byte[] rom,int cmp,int x) {
        word(rom,cmp,0x8800|(x&0xFF));                       // CMP/EQ #X,R0
        word(rom,cmp+2,0x8900|((YES-cmp-6)>>1));             // BT YES
        word(rom,cmp+4,0x8B00|((NO-cmp-8)>>1));              // BF NO
        word(rom,cmp+6,0x001B);                              // SLEEP (UNKNOWN-T fall-through)
        word(rom,YES,0x0009);word(rom,YES+2,0x001B);         // YES marker + SLEEP
        word(rom,NO,0x0009);word(rom,NO+2,0x001B);           // NO marker + SLEEP
    }
    /** Fresh ROM: reset PC=0x100, reset SP=0xFFF90000 (SRAM), R1=STBCR base. */
    private static byte[] baseRom() {
        byte[] rom=new byte[0x200000];
        dword(rom,0,0x100);dword(rom,4,0xFFF90000);
        word(rom,0x100,0xD11F);                              // MOV.L @(0x180,PC),R1
        dword(rom,LIT,STBCR);
        return rom;
    }
    private static FirmwareGraph.Report run(byte[] rom) {
        return new FirmwareGraph().analyze(rom,64);
    }
    private static boolean hasIssue(FirmwareGraph.Report r,String reason) {
        return r.issues().stream().anyMatch(i->i.reason().equals(reason));
    }
    private static boolean reached(FirmwareGraph.Report r,int a) {
        return r.instructions().containsKey(a);
    }
    private static void require(boolean b,String message) {
        if(!b)throw new AssertionError(message);
    }

    public static void main(String[] args) {
        // A: reset state, word read -> PROVEN 0x00000000 (all modules running at power-on
        //    reset; both tracked fields established, so no H'0000 is fabricated).
        {
            byte[] rom=baseRom();
            word(rom,0x102,0x6011);                          // MOV.W @R1,R0
            probe(rom,0x104,0x00);
            var r=run(rom);
            require(hasIssue(r,"STBCR_READ_2_MSTP_BITS_PROVEN_VALUE_0x00000000"),
                    "A: reset word read must be PROVEN 0x00000000");
            require(reached(r,YES)&&!reached(r,NO),
                    "A: read value must flow into R0 as 0 (both/none branches = UNKNOWN)");
        }
        // B: WORD write 0x3C02 (key H'3C, MSTP1=1) -> FPU standby, then word read -> 0x00000002.
        {
            byte[] rom=baseRom();
            movi20(rom,0x102,0,0x3C02);                      // MOVI20 #0x3C02,R0
            word(rom,0x106,0x2101);                          // MOV.W R0,@R1 (write)
            word(rom,0x108,0x6011);                          // MOV.W @R1,R0 (read)
            probe(rom,0x10A,0x02);
            var r=run(rom);
            require(hasIssue(r,"FPU_MODULE_STANDBY_ENTERED_STBCR_MSTP1_IRREVERSIBLE_UNTIL_POR"),
                    "B: key-correct MSTP1 write must enter FPU standby");
            require(hasIssue(r,"STBCR_READ_2_MSTP_BITS_PROVEN_VALUE_0x00000002"),
                    "B: word read after standby must be PROVEN 0x00000002 (MSTP1 set)");
            require(reached(r,YES)&&!reached(r,NO),
                    "B: read value must flow into R0 as 0x02");
        }
        // C: write 0x3C02 (standby) then 0x3C00 (MSTP1=0) -> clear IGNORED (sticky),
        //    word read still 0x00000002.
        {
            byte[] rom=baseRom();
            movi20(rom,0x102,0,0x3C02);                      // standby
            word(rom,0x106,0x2101);                          // MOV.W R0,@R1
            movi20(rom,0x108,0,0x3C00);                      // MOVI20 #0x3C00,R0
            word(rom,0x10C,0x2101);                          // MOV.W R0,@R1
            word(rom,0x10E,0x6011);                          // MOV.W @R1,R0 (read)
            probe(rom,0x110,0x02);
            var r=run(rom);
            require(hasIssue(r,"STBCR_CLEAR_OF_MSTP1_IGNORED_IRREVERSIBLE_FPU_STANDBY_RETAINED"),
                    "C: clearing MSTP1 must be ignored, standby retained");
            require(hasIssue(r,"STBCR_READ_2_MSTP_BITS_PROVEN_VALUE_0x00000002"),
                    "C: read after ignored clear must stay PROVEN 0x00000002");
            require(reached(r,YES)&&!reached(r,NO),
                    "C: read value must stay 0x02");
        }
        // D: BYTE write to H'FFFE0401 (second byte of STBCR) -> ignored, state unchanged;
        //    byte read of the same address -> PROVEN 0x00000000.
        {
            byte[] rom=baseRom();
            word(rom,0x102,0x7101);                          // ADD #1,R1 -> H'FFFE0401
            word(rom,0x104,0xE055);                          // MOV #H'55,R0
            word(rom,0x106,0x2100);                          // MOV.B R0,@R1 (byte write)
            word(rom,0x108,0x6010);                          // MOV.B @R1,R0 (byte read)
            probe(rom,0x10A,0x00);
            var r=run(rom);
            require(hasIssue(r,"STBCR_BYTE_WRITE_IGNORED_STATE_UNCHANGED"),
                    "D: byte write must be ignored");
            require(hasIssue(r,"STBCR_READ_1_MSTP_BITS_PROVEN_VALUE_0x00000000"),
                    "D: byte read after ignored write must be PROVEN 0x00000000");
            require(reached(r,YES)&&!reached(r,NO),
                    "D: read value must flow into R0 as 0");
        }
        // E: in standby, byte read of the KEY byte H'FFFE0400 -> always H'00, not retained.
        {
            byte[] rom=baseRom();
            movi20(rom,0x102,0,0x3C02);                      // standby
            word(rom,0x106,0x2101);                          // MOV.W R0,@R1
            word(rom,0x108,0x6010);                          // MOV.B @R1,R0 (key byte)
            probe(rom,0x10A,0x00);
            var r=run(rom);
            require(hasIssue(r,"STBCR_KEY_READS_H00_NOT_RETAINED"),
                    "E: key byte must read H'00 (not retained), even in standby");
            require(reached(r,YES)&&!reached(r,NO),
                    "E: key byte value must flow into R0 as 0");
        }
        // F: WORD write with wrong key 0x0002 (upper byte H'00) -> modify ignored,
        //    word read still 0x00000000.
        {
            byte[] rom=baseRom();
            movi20(rom,0x102,0,0x0002);                      // MOVI20 #0x0002,R0
            word(rom,0x106,0x2101);                          // MOV.W R0,@R1 (write)
            word(rom,0x108,0x6011);                          // MOV.W @R1,R0 (read)
            probe(rom,0x10A,0x00);
            var r=run(rom);
            require(hasIssue(r,"STBCR_KEY_NOT_H3C_MODIFY_IGNORED"),
                    "F: wrong-key write must be ignored");
            require(hasIssue(r,"STBCR_READ_2_MSTP_BITS_PROVEN_VALUE_0x00000000"),
                    "F: read after ignored write must be PROVEN 0x00000000");
            require(reached(r,YES)&&!reached(r,NO),
                    "F: read value must flow into R0 as 0");
        }
        // G: in standby, byte read of H'FFFE0401 (MSTP byte) -> PROVEN 0x00000002.
        {
            byte[] rom=baseRom();
            movi20(rom,0x102,0,0x3C02);                      // standby
            word(rom,0x106,0x2101);                          // MOV.W R0,@R1
            word(rom,0x108,0x7101);                          // ADD #1,R1 -> H'FFFE0401
            word(rom,0x10A,0x6010);                          // MOV.B @R1,R0 (MSTP byte)
            probe(rom,0x10C,0x02);
            var r=run(rom);
            require(hasIssue(r,"STBCR_READ_1_MSTP_BITS_PROVEN_VALUE_0x00000002"),
                    "G: byte read of MSTP byte in standby must be PROVEN 0x00000002");
            require(reached(r,YES)&&!reached(r,NO),
                    "G: read value must flow into R0 as 0x02");
        }
        // H: 32-bit (MOV.L) transfer to STBCR -> not a defined size (table 29.4: 8/16 only):
        //    path poisoned, the following instruction is NOT decoded.
        {
            byte[] rom=baseRom();
            word(rom,0x102,0xE000);                          // MOV #0,R0 (value irrelevant)
            word(rom,0x104,0x2102);                          // MOV.L R0,@R1 (width-4 store)
            word(rom,0x106,0x0009);                          // NOP: must NOT be reached
            var r=run(rom);
            require(hasIssue(r,"STBCR_ACCESS_WIDTH_UNDEFINED_4_PATH_POISONED"),
                    "H: width-4 STBCR access must poison the path");
            require(reached(r,0x104),
                    "H: the width-4 store itself is decoded before the outcome is known");
            require(!reached(r,0x106),
                    "H: CFG must not continue through an undefined-width STBCR access");
        }
        System.out.println("STBCR_READ_PATH_ACCEPTANCE: PASS (synthetic, not real ECU validation)");
    }
}
