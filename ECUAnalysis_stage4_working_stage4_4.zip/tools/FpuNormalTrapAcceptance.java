package ecu.independent;

/** Primary oracle: REJ09B0051-0300 Rev.3.00 §§6.5.2/4/6/10/11/13/16/18.
 * Enables O/U/I trap even with an exact normal result; sqrt only I; FLOAT only I/PR0.
 * Cause reflects actual arithmetic, not the enabled bit. Signed-zero conversion
 * bit patterns from special-case tables §§6.5.4 pp284-285 and 6.5.5 pp287-288.
 */
public final class FpuNormalTrapAcceptance {
    private FpuNormalTrapAcceptance() {}
    private static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
    private static Sh2aDecoder.Instruction inst(int op){return new Sh2aDecoder().decode(new byte[]{(byte)(op>>>8),(byte)op},0);}
    private static AbstractCpu state(int mode){
        var s=new AbstractCpu(0xFFF90000);s.fpscr=mode|0x40000|0x10040; // stale Cause V + sticky Flag V
        s.fr[0]=0x3F800000;s.fr[2]=0x40000000;s.fpul=1;return s;
    }
    private static void exact(int op,int enable,int mode,boolean trap){
        var s=state(mode|enable);
        if(op==0xF0BD){s.fr[0]=0x3FF00000;s.fr[1]=0;} // exact double 1.0
        int before=s.fr[0],beforeFpul=s.fpul;
        String result=FpuSemantics.apply(s,inst(op));
        if(trap){
            require(result!=null&&result.startsWith("FPU_EXCEPTION_GENERATED_"),"exact result did not trap op="+Integer.toHexString(op));
            require(s.fpuExceptionPending!=null,"pending event absent");
            require(s.fr[0]==before&&s.fpul==beforeFpul,"trap changed destination");
        }else require(result==null&&s.fpuExceptionPending==null,"unexpected exact trap op="+Integer.toHexString(op)+" "+result);
        require((s.fpscr&0x3F000)==0,"enable invented a cause or stale cause survived");
        require((s.fpscr&0x40)!=0,"sticky V flag lost");
    }
    private static void w(byte[] r,int a,int v){r[a]=(byte)(v>>>8);r[a+1]=(byte)v;}
    private static void l(byte[] r,int a,int v){w(r,a,v>>>16);w(r,a+2,v);}
    public static void main(String[] args){
        for(int enable:new int[]{0x80,0x100,0x200}){
            exact(0xF020,enable,0,true); // 1+2=3
            exact(0xF022,enable,0,true); // 1*2=2
            exact(0xF023,enable,0,true); // 1/2=0.5
            exact(0xF0BD,enable,0x80000,true); // double 1.0 -> float 1.0
        }
        exact(0xF06D,0x80,0,true);exact(0xF06D,0x200,0,false); // sqrt(1)
        exact(0xF02D,0x80,0,true);exact(0xF02D,0x80,0x80000,false); // FLOAT 1
        exact(0xF020,0,0,false);
        for(int rm:new int[]{0,1})for(int sign:new int[]{0,0x80000000}){
            var s=state(0x80000|rm);s.fpul=sign;
            require(FpuSemantics.apply(s,inst(0xF0AD))==null,"FCNVSD zero failed");
            require(s.fr[0]==sign&&s.fr[1]==0,"FCNVSD zero sign wrong");
            s=state(0x80000|rm);s.fr[0]=sign;s.fr[1]=0;
            require(FpuSemantics.apply(s,inst(0xF0BD))==null&&s.fpul==sign,"FCNVDS zero sign wrong");
        }
        for(int sign:new int[]{0,0x80000000}){
            for(int tiny:new int[]{1,0x7FFFFF}){
                var s=state(0xC0000);s.fpul=sign|tiny;
                require(FpuSemantics.apply(s,inst(0xF0AD))==null&&s.fr[0]==sign&&s.fr[1]==0,"FCNVSD DN1 must flush signed denormal");
                s=state(0x80000);s.fpscr&=~0x40000;s.fpul=sign|tiny;
                require("FPSCR_DN0_RESERVED".equals(FpuSemantics.apply(s,inst(0xF0AD)))&&s.fr[0]==0x3F800000,"FCNVSD DN0 must not invent a normalized result");
            }
            for(int pr:new int[]{0,0x80000}){
                var s=state(pr|0x80);s.fr[0]=sign;s.fr[1]=0;
                require(FpuSemantics.apply(s,inst(0xF06D))==null&&s.fr[0]==sign&&s.fr[1]==0&&s.fpuExceptionPending==null,"sqrt signed zero must bypass normal path even with I enabled");
            }
        }
        var invalid=state(0xC00);invalid.fr[0]=0;invalid.fr[2]=0x80000000;
        require(FpuSemantics.apply(invalid,inst(0xF023)).startsWith("FPU_EXCEPTION_GENERATED_V"),"0/-0 must generate V, never Z");
        require((invalid.fpscr&0x3F000)==0x10000,"invalid division cause must be V only");
        invalid=state(0x400);invalid.fr[0]=0;invalid.fr[2]=0;
        require(FpuSemantics.apply(invalid,inst(0xF023))==null&&invalid.fr[0]==0x7fbfffff&&(invalid.fpscr&0x3f000)==0x10000&&invalid.fpuExceptionPending==null,"disabled V yields canonical qNaN; Z must not trap 0/0");
        // End-to-end exact FADD generates pending H'34; acceptance time remains
        // potential because this analyzer does not prove a concrete pipeline latency.
        byte[] r=new byte[0x200000];l(r,0,0x1000);l(r,4,0xFFF90000);l(r,0x34,0x1200);
        int[] program={0xE000,0x400E,0x0040,0x0201,0x406A,0xF09D,0xF19D,0xF010,0x001B};
        for(int i=0;i<program.length;i++)w(r,0x1000+i*2,program[i]);w(r,0x1200,0x001B);
        var g=new FirmwareGraph().analyze(r,60);
        require(g.instructions().containsKey(0x1200),"exact FADD did not enter H34 handler: "+g.issues());
        require(g.edges().stream().anyMatch(e->e.from()==0x1010&&e.to()==0x1200),"pending H34 edge missing");
        require(g.issues().stream().anyMatch(i->i.reason().startsWith("FPU_EXCEPTION_PENDING_ACCEPTED_POTENTIAL_")),"acceptance uncertainty not recorded");
        System.out.println("FPU_NORMAL_TRAP_ACCEPTANCE: PASS (normal exact enables, signed-zero conversions, H34 integration)");
    }
}
