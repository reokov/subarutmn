package ecu.independent;

import java.util.*;
import static ecu.independent.SystemExceptionModel.*;

/** Hardware Rev4 §§7–8 oracles. Only synthetic images. No real ROM/GUI.
 * ID-report tests explicitly supply report availability, not a fabricated latency. */
public final class SystemExceptionsAcceptance {
    static final int A=0x1000,H=0x1200,SP=0xfff90000,B=0xfff82000;
    static int checks,scenarios;
    static void ok(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
    static void w(byte[] r,int a,int v){r[a]=(byte)(v>>>8);r[a+1]=(byte)v;}
    static void l(byte[] r,int a,int v){w(r,a,v>>>16);w(r,a+2,v);}
    static byte[] image(int opcode){byte[] r=new byte[0x200000];l(r,0,A);l(r,4,SP);w(r,A,opcode);w(r,A+2,0x001b);for(int v:new int[]{0x10,0x18,0x24,0x28,0x2c,0x30,0x34,0x3c,0x40,0x44,0x48,0x100,0x1a4})l(r,v,H);w(r,H,0x001b);return r;}
    static AbstractCpu initial(){var s=new AbstractCpu(SP);s.writeSr(0);for(int i=0;i<15;i++)s.r[i]=0x10+i;Arrays.fill(s.fr,0x3f800000);s.fpul=0x12345678;s.pr=0x444;s.gbr=B;s.mach=0x111;s.macl=0x222;return s;}
    static FirmwareGraph graph(byte[] r,AbstractCpu s){var g=new FirmwareGraph();g.analyzeCpu(r,32,s);return g;}
    static FirmwareGraph.CpuSnapshot at(FirmwareGraph g,int pc){return g.cpuStates().stream().filter(x->Objects.equals(x.pc(),pc)).findFirst().orElseThrow(()->new AssertionError("missing "+Integer.toHexString(pc)+g.report().issues()));}
    static int ram(FirmwareGraph.CpuSnapshot s,int address){int v=0;for(int i=0;i<4;i++){Byte b=s.ram().get(address+i);if(b==null)throw new AssertionError("unknown RAM "+Integer.toHexString(address+i));v=v<<8|Byte.toUnsignedInt(b);}return v;}
    static Event event(Kind kind,int generator,int vector,int level,Availability a){return new Event(1,kind,generator,null,vector,level,"synthetic explicit report",a);}
    static void h24(){
        for(int opcode:new int[]{0x6121,0x6122,0x6126,0x2212,0x2216,0xf428,0xf42b,0x4266,0x4262}) {
            scenarios++;var s=initial();s.r[2]=(opcode==0x2216||opcode==0xf42b||opcode==0x4262)?B+6:opcode==0x6121?B+1:B+2;
            if(opcode==0xf42b)s.r[4]=B+6;
            byte[] r=image(opcode);w(r,H,0x002b);w(r,H+2,0x0009);
            var g=graph(r,s);var entry=at(g,H);
            ok(ram(entry,SP-8)==A+2,"H24 saved next completed instruction boundary");
            ok(ram(entry,SP-4)==0,"H24 saved SR");
            ok(entry.registers().get(2).equals(s.r[2]),"H24 address register changed");
            ok(entry.fr().equals(Arrays.asList(s.fr))&&entry.fpul().equals(s.fpul)&&entry.fpscr().equals(s.fpscr),"H24 FPU side effect");
            var returned=at(g,A+2);ok(returned.registers().get(15)==SP&&returned.sr()==0,"H24 RTE restoration");
            ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS),"H24 generation absent");
            ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.CPU_ADDRESS),"H24 acceptance absent");
        }
    }
    static void reported(){
        for(Kind kind:new Kind[]{Kind.CPU_ADDRESS,Kind.DMAC_ADDRESS,Kind.FPU,Kind.DIV_ZERO,Kind.DIV_OVERFLOW,Kind.BANK_UNDERFLOW,Kind.GENERAL_ILLEGAL,Kind.NMI,Kind.USER_BREAK,Kind.IRQ,Kind.MEMORY_ERROR}) {
            scenarios++;int vector=switch(kind){case CPU_ADDRESS->0x24;case DMAC_ADDRESS->0x28;case FPU->0x34;case DIV_ZERO->0x44;case DIV_OVERFLOW->0x48;case BANK_UNDERFLOW->0x40;case GENERAL_ILLEGAL->0x10;case NMI->0x2c;case USER_BREAK->0x30;case IRQ->0x100;case MEMORY_ERROR->79*4;default->throw new AssertionError();};
            var s=initial();s.systemPending.add(event(kind,0x80,vector,kind==Kind.NMI?16:interrupt(kind)?15:0,Availability.REPORTED_ID));
            if(kind==Kind.FPU){s.fpuExceptionPending=AbstractCpu.FPU_PENDING;s.fpscr|=0x10040;}
            byte[] r=image(0xe001);l(r,vector,H);var g=graph(r,s);var out=at(g,H);
            int expected=Set.of(Kind.DIV_ZERO,Kind.DIV_OVERFLOW,Kind.BANK_UNDERFLOW,Kind.GENERAL_ILLEGAL).contains(kind)?0x80:A;
            ok(ram(out,SP-8)==expected,"savedPC by type "+kind);
            ok(ram(out,SP-4)==0,"savedSR "+kind);
            ok(out.registers().get(0).equals(s.r[0]),"accepting instruction executed "+kind);
            ok(out.systemPending().isEmpty(),"pending not consumed "+kind);
            if(kind==Kind.FPU)ok(out.fpuPending()==null&&out.fpscr().equals(s.fpscr),"FPU FPSCR/pending");
        }
    }
    static void competition(){
        scenarios++;byte[] r=image(0xffff);l(r,0x10,0x280);w(r,0x280,0x001b);
        var s=initial();s.fpuExceptionPending=AbstractCpu.FPU_PENDING;s.systemPending.add(event(Kind.FPU,0x80,0x34,0,Availability.PIPELINE_UNVERIFIED));
        var g=graph(r,s);
        ok(g.report().edges().stream().anyMatch(e->e.from()==A&&e.to()==H),"higher FPU timing alternative lost at illegal ID");
        ok(g.report().edges().stream().anyMatch(e->e.from()==A&&e.to()==0x280),"lower illegal timing alternative lost");
        scenarios++;s=initial();s.softwareInterrupts[2]=1;s.fpuExceptionPending=AbstractCpu.FPU_PENDING;s.systemPending.add(event(Kind.FPU,0x80,0x34,0,Availability.PIPELINE_UNVERIFIED));
        r=image(0x0009);l(r,0x1a4,0x280);w(r,0x280,0x001b);g=graph(r,s);
        ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.FPU&&Objects.equals(e.decodePc(),A+2)),"SINT bypassed FPU competitor");
        ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.SOFTWARE),"SINT alternative lost");
    }
    static void outsideAccess(){
        for(int opcode:new int[]{0x002b,0x8300,0x422b}) {
            scenarios++;var s=initial();byte[] r=image(opcode);w(r,A+2,0x0009);w(r,A+4,0x001b);
            if(opcode==0x002b)s.r[15]=SP+1;
            if(opcode==0x8300)s.tbr=B+2;
            if(opcode==0x422b)s.r[2]=A+0x101;
            var g=graph(r,s);
            ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS),"outside-execute H24 generation omitted: "+Integer.toHexString(opcode));
            if(opcode==0x002b)ok(g.systemEvents().stream().noneMatch(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.CPU_ADDRESS),"RTE unknown target assigned a guessed resume PC");
        }
    }
    static void reserved() throws Exception {
        var assigned=new HashSet<Integer>();for(String row:java.nio.file.Files.readAllLines(java.nio.file.Path.of("tools/fixtures/sh7254r-interrupt-vectors.tsv")).subList(1,274))assigned.add(Integer.parseInt(row.split("\t")[0]));
        for(int vector=0;vector<=511;vector++) {
            scenarios++;boolean module=assigned.contains(vector)&&vector>=108,accepted=true;
            try{event(Kind.PERIPHERAL,A,vector*4,1,Availability.REPORTED_ID);}catch(IllegalArgumentException ex){accepted=false;}
            ok(accepted==module,"reserved/non-module vector accepted: "+vector);
        }
    }
    static void unknownSr(){
        scenarios++;var s=initial();s.t=null;
        s.queueSystem(Kind.DIV_ZERO,A,null,0x44,0,"explicit report",Availability.REPORTED_ID);
        byte[] r=image(0x7001);w(r,H,0x002b);w(r,H+2,0x0009);
        var g=graph(r,s);var handler=at(g,H);
        ok(ram(handler,SP-8)==A,"unknown SR fabricated PC");
        for(int i=0;i<4;i++)ok(!handler.ram().containsKey(SP-4+i),"unknown SR fabricated stack bytes");
    }
    static void maskWindow(){
        scenarios++;var s=initial();s.writeSr(0xf0);s.r[0]=0xa0;s.r[1]=0x50;
        byte[] r=image(0x400e);w(r,A+2,0x410e);w(r,A+4,0x001b);
        var g=graph(r,s);ok(at(g,A+2).irqMaskChangeWindow()==5,"first mask window");
        ok(at(g,A+4).irqMaskChangeWindow()==5,"mask window not rearmed by second enabling LDC");
    }
    static void bankOverflow(){
        for(boolean trap:new boolean[]{false,true}) {
            scenarios++;var s=initial();s.bankEnable=1;s.nextBank=15;s.bankOverflowException=trap;
            byte[] r=image(0x0009);l(r,0x100,0x1400);w(r,0x1400,0x001b);
            var entry=new Sh7254rInterruptController().enter(s,new Sh7254rInterruptController.Event(A+2,0x100,3,false,true),new Sh7254rMemoryMap(r));
            ok(entry.disposition()==Sh7254rInterruptController.Disposition.ENTERED,"bank overflow entry");
            ok(entry.vectorOffset()==(trap?0x3c:0x100),"bank overflow vector");
            ok(s.nextBank==15&&s.interruptMask==3,"bank state/mask");
            ok(s.r[15]==SP-(trap?8:84),"bank stack size");
            if(!trap){ok(s.readRam(SP-84,4)==0x10&&s.readRam(SP-28,4)==0x1e,"bank GPR spill order");ok(s.readRam(SP-24,4)==0x444&&s.readRam(SP-20,4)==B,"bank PR/GBR order");ok(s.readRam(SP-16,4)==0x111&&s.readRam(SP-12,4)==0x222,"bank MACH/MACL order");}
            ok(s.readRam(SP-8,4)==A+2&&s.readRam(SP-4,4)==0,"bank SR/PC frame");
        }
        scenarios++;var s=initial();s.bankEnable=1;s.nextBank=15;s.bankOverflowException=true;s.softwareInterrupts[2]=1;
        byte[] r=image(0x0009);l(r,0x3c,B+0x100);var g=graph(r,s);
        ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.BANK_OVERFLOW),"BOVE generation hidden by unavailable handler");
    }
    static void entryFaults(){
        for(boolean vector:new boolean[]{false,true}){
            scenarios++;var s=initial();if(vector)s.vbr=2;else s.r[15]=SP+1;
            s.queueSystem(Kind.IRQ,A,null,0x100,3,"reported IRQ",Availability.REPORTED_ID);
            var g=graph(image(0x0009),s);
            ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS),"exception-entry access omitted H24 generation");
        }
    }
    static void nestedReturn(){
        scenarios++;var s=initial();s.fpscr|=0x10040;s.fpuExceptionPending=AbstractCpu.FPU_PENDING;
        s.queueSystem(Kind.FPU,A-2,null,0x34,0,"reported FPU",Availability.REPORTED_ID);
        s.queueSystem(Kind.IRQ,A,null,0x100,3,"reported IRQ",Availability.REPORTED_ID);
        byte[] r=image(0x7001);w(r,H,0x002b);w(r,H+2,0x0009);l(r,0x100,0x1400);w(r,0x1400,0x002b);w(r,0x1402,0x0009);
        var g=graph(r,s);var irq=at(g,0x1400);
        ok(ram(irq,SP-16)==H&&ram(irq,SP-12)==0,"nested IRQ saved FPU handler ID");
        ok(ram(irq,SP-8)==A&&ram(irq,SP-4)==0,"outer FPU frame");
        var returned=at(g,A+2);ok(returned.registers().get(0)==0x11&&returned.registers().get(15)==SP&&returned.sr()==0,"nested RTE execution duplicated/lost");
        ok(returned.fpuPending()==null&&returned.systemPending().isEmpty()&&returned.fpscr().equals(s.fpscr),"nested pending/FPSCR");
    }
    static void delayedFault(){
        int target=A+0x100;
        for(int branch:new int[]{0xa07e,0xb07e,0x0223,0x0203,0x422b,0x420b,0x000b,0x002b,0x8d7e,0x8f7e}) {
            scenarios++;var s=initial();s.r[3]=B+2;s.r[2]=(branch==0x0223||branch==0x0203)?0xfc:target;s.pr=target;
            if(branch==0x8d7e)s.t=true;
            byte[] r=image(branch);w(r,A+2,0x6132);w(r,target,0x001b);
            if(branch==0x002b){s.writeRam(SP,4,target,A);s.writeRam(SP+4,4,0,A);}
            var g=graph(r,s);var h=at(g,H);int frame=branch==0x002b?SP:SP-8;
            ok(ram(h,frame)==target,"delay H24 hypothesis must use branch destination "+Integer.toHexString(branch));
            ok(h.registers().get(1)==0x11&&h.registers().get(3)==B+2,"slot H24 partial write");
        }
        scenarios++;var s=initial();s.fpscr=0x40080;s.fr[0]=0x3f800000;s.fr[2]=0x40000000;
        byte[] r=image(0xa07e);w(r,A+2,0xf020);w(r,target,0xe107);w(r,target+2,0x001b);
        var g=graph(r,s);
        ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.FPU&&Objects.equals(e.decodePc(),target)),"unproved extra FPU bar after slot");
        ok(g.fpuEvents().size()==1&&g.fpuEvents().getFirst().instructionPc()==A+2,"slot FPU event provenance/duplicate");
    }
    static void stackingTransitions(){
        for(boolean alreadyH24:new boolean[]{false,true}) {
            scenarios++;var s=initial();int sp=SP+1;s.r[15]=sp;
            for(int a=SP-32;a<=SP;a++)s.ram.put(a,(byte)0x5a);
            s.queueSystem(alreadyH24?Kind.CPU_ADDRESS:Kind.IRQ,A,null,alreadyH24?0x24:0x100,alreadyH24?0:3,"reported input",Availability.REPORTED_ID);
            byte[] r=image(0x0009);l(r,0x100,0x1400);w(r,0x1400,0x001b);
            var g=graph(r,s);var h=at(g,H);int bytes=alreadyH24?8:16;
            ok(h.registers().get(15)==sp-bytes,"undefined stacking must decrement SP");
            for(int i=1;i<=bytes;i++)ok(!h.ram().containsKey(sp-i),"stacking manufactured defined byte");
            ok(h.sr()==(alreadyH24?0:0x30),"stacking interrupt mask");
            ok(g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.CPU_ADDRESS).count()==1,"recursive stacking H24 reaccepted");
            if(!alreadyH24)ok(g.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),0x1400)),"first IRQ handler executed before mandatory H24");
        }
    }
    static void completionOrder(){
        for(Kind kind:new Kind[]{Kind.CPU_ADDRESS,Kind.NMI}){
            scenarios++;var e=event(kind,A,kind==Kind.NMI?0x2c:0x24,kind==Kind.NMI?16:0,Availability.REPORTED_ID);
            ok(select(List.of(e),0,new Boundary(A,false,false)).status().name().equals("WAIT_COMPLETION"),"accepted before current multicycle completion");
            ok(select(List.of(e),0,new Boundary(A,false,false,true)).status()==Status.ACCEPT,"DIV cancellation permitted for IRQ/H24");
        }
    }
    static void branchWindow(){
        scenarios++;var s=initial();s.writeSr(0xf0);s.r[0]=0;
        byte[] r=image(0x400e);w(r,A+2,0xa00d);w(r,A+4,0x0009);w(r,A+0x20,0x001b);
        var g=graph(r,s);ok(at(g,A+0x20).irqMaskChangeWindow()==3,"branch and its slot must count as two completed instructions");
    }
    static void fpuStacking(){
        scenarios++;var s=initial();s.r[15]=SP+1;s.fpuExceptionPending=AbstractCpu.FPU_PENDING;s.fpscr|=0x10040;
        s.queueSystem(Kind.FPU,A-2,null,0x34,0,"reported FPU",Availability.REPORTED_ID);
        byte[] r=image(0x0009);l(r,0x34,0x1400);w(r,0x1400,0x001b);var g=graph(r,s);
        ok(g.cpuStates().stream().filter(x->Objects.equals(x.pc(),H)).allMatch(x->x.fpuPending()==null),"accepted FPU latch survived stacking H24");
        ok(g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.FPU).count()==1,"FPU event reaccepted after stacking H24");
        ok(at(g,H).fpscr().equals(s.fpscr),"stacking changed FPU Cause/Flag/Enable");
    }
    static void bankReport(){
        scenarios++;var s=initial();s.queueSystem(Kind.BANK_OVERFLOW,A-2,null,0x3c,3,"origin IRQ priority3",Availability.REPORTED_ID);
        var h=at(graph(image(0x0009),s),H);ok(h.sr()==0x30,"reported bank-overflow did not copy origin priority");
        boolean rejected=false;try{event(Kind.BANK_OVERFLOW,A,0x3c,0,Availability.REPORTED_ID);}catch(IllegalArgumentException e){rejected=true;}
        ok(rejected,"bank overflow accepted without a valid triggering priority");
    }
    static Event afterIssue(Event e,int pc){
        return e.afterIssue(pc);
    }
    static void issueArrival(){
        for(Kind kind:new Kind[]{Kind.IRQ,Kind.CPU_ADDRESS,Kind.FPU}) {
            scenarios++;var s=initial();s.r[0]=3;s.r[1]=21;
            int vector=kind==Kind.IRQ?0x100:kind==Kind.FPU?0x34:0x24;
            s.systemPending.add(afterIssue(event(kind,A-4,vector,kind==Kind.IRQ?3:0,Availability.PIPELINE_UNVERIFIED),A));
            byte[] r=image(0x4184);w(r,H,0x002b);w(r,H+2,0x0009);
            var g=graph(r,s);var entry=at(g,H);
            boolean cancelled=kind!=Kind.FPU;
            ok(ram(entry,SP-8)==(cancelled?A:A+2),"report during DIV savedPC "+kind);
            ok(entry.registers().get(1)==(cancelled?21:7),"report during DIV quotient "+kind);
            ok(at(g,A+2).registers().get(1)==7,"RTE did not restart cancelled DIV once "+kind);
            ok(g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==kind).count()==1,"report reaccepted "+kind);
            ok(g.executionSteps().stream().filter(e->e.stage()==FirmwareGraph.ExecutionStage.CANCELLED&&e.instructionPc()==A).count()==(cancelled?1:0),"DIV cancellation execution route "+kind);
            ok(g.executionSteps().stream().filter(e->e.stage()==FirmwareGraph.ExecutionStage.COMPLETE&&e.instructionPc()==A).count()==1,"DIV must retire exactly once "+kind);
        }
        scenarios++;var s=initial();s.r[0]=3;s.r[1]=7;
        s.systemPending.add(afterIssue(event(Kind.IRQ,A-4,0x100,3,Availability.PIPELINE_UNVERIFIED),A));
        var g=graph(image(0x0117),s);var h=at(g,H); // MUL.L R1,R1, noncancellable
        ok(ram(h,SP-8)==A+2&&h.macl()==49,"non-DIV must complete before acceptance");
        scenarios++;s=initial();s.systemPending.add(afterIssue(event(Kind.IRQ,A-4,0x100,3,Availability.PIPELINE_UNVERIFIED),A+2));
        byte[] r=image(0xa006);w(r,A+2,0x7101);w(r,A+16,0x001b);g=graph(r,s);h=at(g,H);
        ok(ram(h,SP-8)==A+16&&h.registers().get(1)==18,"slot report must wait through slot to target ID");
    }
    static void bankUnusedConfiguration(){
        for(int be:new int[]{0,1,3}){
            scenarios++;var s=initial();s.bankEnable=be;s.bankPriorityMask=be==3?0:null;
            s.bankOverflowException=null;s.nextBank=be==1?0:null;
            s.queueSystem(Kind.IRQ,A-4,null,0x100,3,"IRQ report",Availability.REPORTED_ID);
            var h=at(graph(image(0x0009),s),H);
            ok(h.registers().get(15)==SP-8,"unused bank control must not block interrupt BE"+be);
            ok(h.nextBank()==(be==1?Integer.valueOf(1):null),"bank use BE"+be);
        }
    }
    static void issueEdges(){
        for(int op:new int[]{0x4184,0x4194})for(Kind kind:new Kind[]{Kind.IRQ,Kind.NMI,Kind.CPU_ADDRESS,Kind.DMAC_ADDRESS,Kind.FPU}) {
            scenarios++;var s=initial();s.r[0]=3;s.r[1]=21;
            int v=switch(kind){case IRQ->0x100;case NMI->0x2c;case CPU_ADDRESS->0x24;case DMAC_ADDRESS->0x28;case FPU->0x34;default->throw new AssertionError();};
            s.systemPending.add(afterIssue(event(kind,A-4,v,kind==Kind.NMI?16:kind==Kind.IRQ?3:0,Availability.PIPELINE_UNVERIFIED),A));
            var g=graph(image(op),s);var h=at(g,H);
            ok(ram(h,SP-8)==(kind==Kind.FPU?A+2:A),"DIVS/DIVU arrival saved PC "+kind);
            ok(h.registers().get(1)==(kind==Kind.FPU?7:21),"DIVS/DIVU arrival result "+kind);
            ok(Objects.equals(h.t(),s.t)&&Objects.equals(h.q(),s.q)&&Objects.equals(h.m(),s.m),"DIV cancellation changed flags "+kind);
        }
        for(int op:new int[]{0xf423,0xf46d}){
            scenarios++;var s=initial();s.fr[4]=op==0xf423?0x40c00000:0x40800000;s.fr[2]=0x40400000;
            s.systemPending.add(afterIssue(event(Kind.IRQ,A-4,0x100,3,Availability.PIPELINE_UNVERIFIED),A));
            var g=graph(image(op),s);var h=at(g,H);
            ok(ram(h,SP-8)==A+2&&h.fr().get(4)==0x40000000,"IRQ must wait for FDIV/FSQRT result");
            ok(g.executionSteps().stream().noneMatch(e->e.stage()==FirmwareGraph.ExecutionStage.CANCELLED),"non-DIV integer cancellation of FPU instruction");
        }
        scenarios++;var s=initial();s.r[0]=3;s.r[1]=21;s.writeSr(0x30);
        s.systemPending.add(afterIssue(event(Kind.IRQ,A-4,0x100,3,Availability.PIPELINE_UNVERIFIED),A));
        var g=graph(image(0x4184),s);var next=at(g,A+2);
        ok(next.registers().get(1)==7&&next.systemPending().size()==1,"masked issue report must remain pending without cancelling DIV");
        ok(g.systemEvents().stream().noneMatch(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.IRQ),"masked report accepted");
        scenarios++;s=initial();s.queueSystem(Kind.POWER_ON_RESET,null,null,0,0,"reset during issue",Availability.PIPELINE_UNVERIFIED);
        s.systemPending.replaceAll(e->e.afterIssue(A));g=graph(image(0x0117),s);
        ok(g.executionSteps().stream().anyMatch(e->e.stage()==FirmwareGraph.ExecutionStage.CANCELLED&&e.instructionPc()==A),"reset must cancel non-DIV");
        ok(g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.POWER_ON_RESET).count()==1,"reset report consumed once");
        ok(g.cpuStates().stream().filter(x->Objects.equals(x.pc(),A)&&x.systemPending().isEmpty()).anyMatch(x->x.registers().get(15)==SP&&x.fpscr()==0x40001),"reset must not stack and must restore FPSCR");
        scenarios++;boolean rejected=false;try{afterIssue(event(Kind.GENERAL_ILLEGAL,A,0x10,0,Availability.PIPELINE_UNVERIFIED),A);}catch(IllegalArgumentException ex){rejected=true;}
        ok(rejected,"decode-illegal cannot first report after its own issue");
    }
    static void scheduledFpuLatch(){
        scenarios++;var s=initial();s.fpuExceptionPending=AbstractCpu.FPU_PENDING;s.fpscr|=0x10040;
        s.systemPending.add(afterIssue(event(Kind.FPU,A-4,0x34,0,Availability.PIPELINE_UNVERIFIED),A+2));
        byte[] r=image(0x7101);w(r,A+2,0x7101);w(r,A+4,0x001b);var g=graph(r,s);
        ok(g.systemEvents().stream().filter(e->e.stage()==Stage.ACCEPTANCE&&e.event().kind()==Kind.FPU).allMatch(e->Objects.equals(e.decodePc(),A+4)),"legacy FPU fork ignored explicit later report");
        var h=at(g,H);ok(ram(h,SP-8)==A+4&&h.registers().get(1)==19,"scheduled FPU report CPU-side effects/savedPC");
        ok(h.fpuPending()==null&&h.fpscr().equals(s.fpscr),"scheduled FPU latch/FPSCR");
    }
    static void policy(){
        Kind[] order={Kind.CPU_ADDRESS,Kind.DMAC_ADDRESS,Kind.FPU,Kind.DIV_ZERO,Kind.DIV_OVERFLOW,Kind.BANK_UNDERFLOW,Kind.BANK_OVERFLOW,Kind.NMI,Kind.TRAPA,Kind.GENERAL_ILLEGAL,Kind.SLOT_ILLEGAL};
        int[] vectors={0x24,0x28,0x34,0x44,0x48,0x40,0x3c,0x2c,0x80,0x10,0x18};
        for(int i=0;i<order.length;i++)for(int j=i+1;j<order.length;j++){
            scenarios++;var a=event(order[i],A,vectors[i],order[i]==Kind.NMI?16:order[i]==Kind.BANK_OVERFLOW?3:0,Availability.REPORTED_ID);var b=event(order[j],A,vectors[j],order[j]==Kind.NMI?16:order[j]==Kind.BANK_OVERFLOW?3:0,Availability.REPORTED_ID);
            ok(select(List.of(b,a),0,new Boundary(A,false,true)).winner().kind()==order[i],"priority table order");
        }
        for(int level=0;level<=15;level++)for(int mask=0;mask<=15;mask++) {
            scenarios++;var irq=event(Kind.IRQ,A,0x100,level,Availability.REPORTED_ID);
            ok(select(List.of(irq),mask,new Boundary(A,false,true)).status()==(level>mask?Status.ACCEPT:Status.NONE),"mask comparison");
        }
        for(Kind kind:new Kind[]{Kind.CPU_ADDRESS,Kind.DMAC_ADDRESS,Kind.FPU,Kind.BANK_OVERFLOW,Kind.NMI,Kind.IRQ}) {
            scenarios++;int vector=switch(kind){case CPU_ADDRESS->0x24;case DMAC_ADDRESS->0x28;case FPU->0x34;case BANK_OVERFLOW->0x3c;case NMI->0x2c;default->0x100;};
            var e=event(kind,A,vector,kind==Kind.NMI?16:kind==Kind.IRQ?15:kind==Kind.BANK_OVERFLOW?3:0,Availability.REPORTED_ID);
            ok(select(List.of(e),0,new Boundary(A,true,false)).status()==Status.DEFERRED_SLOT,"slot bar "+kind);
        }
    }
    public static void main(String[] args) throws Exception {
        if(args.length>0&&args[0].equals("withdrawal")){withdrawal();withdrawalProofs();System.out.println("WITHDRAWAL: PASS scenarios="+scenarios+" checks="+checks);return;}
        if(args.length>0&&args[0].equals("doublecompare")){doubleCompareIssue();System.out.println("DOUBLE_COMPARE: PASS scenarios="+scenarios+" checks="+checks);return;}
        if(args.length>0&&args[0].equals("scheduler")){scheduler();System.out.println("PIPELINE_ACCEPTANCE: PASS scenarios="+scenarios+" checks="+checks+"; one-state/no-wait profile only");return;}
        if(args.length>0&&args[0].equals("iofetch")){ioFetchPaths();System.out.println("IO_FETCH_PATHS: PASS checks="+checks);return;}
        if(args.length>0&&args[0].equals("readiness")){readiness();System.out.println("NORMAL_OVERLAP_PROFILE: PASS checks="+checks+" explicit boundary only");return;}
        if(args.length==0){
            ReviewerCurrentStage4Probe.main(new String[]{"mmio"});
            ReviewerCurrentStage4Probe.main(new String[]{"trap"});
            ReviewerPendingSIntProbe.main(new String[0]);scenarios+=3;checks+=3;
            ReviewerDeferredSlotProbe.main(new String[0]);scenarios++;checks++;
            ReviewerSramSlotFetchProbe.main(new String[0]);scenarios++;checks++;
            trapFrames();readiness();ioFetchPaths();scheduler();withdrawal();withdrawalProofs();doubleCompareIssue();
        }
        if(args.length>0&&args[0].equals("scheduledfpu")){scheduledFpuLatch();System.out.println("SCHEDULED_FPU: PASS checks="+checks);return;}
        if(args.length>0&&args[0].equals("issue")){issueArrival();issueEdges();System.out.println("ISSUE_ARRIVAL: PASS checks="+checks);return;}
        if(args.length>0&&args[0].equals("bankunused")){bankUnusedConfiguration();System.out.println("BANK_UNUSED: PASS checks="+checks);return;}
        if(args.length>0&&args[0].equals("h24")){h24();}else if(args.length>0&&args[0].equals("outside")){outsideAccess();}else if(args.length>0&&args[0].equals("reserved")){reserved();}else if(args.length>0&&args[0].equals("unknownsr")){unknownSr();}else if(args.length>0&&args[0].equals("maskwindow")){maskWindow();}else if(args.length>0&&args[0].equals("bank")){bankOverflow();}else if(args.length>0&&args[0].equals("entryfault")){entryFaults();}else if(args.length>0&&args[0].equals("stacking")){stackingTransitions();}else if(args.length>0&&args[0].equals("completion")){completionOrder();}else if(args.length>0&&args[0].equals("branchwindow")){branchWindow();}else if(args.length>0&&args[0].equals("fpustacking")){fpuStacking();}else if(args.length>0&&args[0].equals("bankreport")){bankReport();}else{reported();competition();policy();h24();outsideAccess();reserved();unknownSr();maskWindow();bankOverflow();entryFaults();nestedReturn();delayedFault();stackingTransitions();completionOrder();branchWindow();fpuStacking();bankReport();issueArrival();bankUnusedConfiguration();issueEdges();scheduledFpuLatch();}
        System.out.println("SYSTEM_EXCEPTIONS_ACCEPTANCE: PASS scenarios="+scenarios+" checks="+checks+"; architectural/explicit-ID cases only, physical latency not proved");
    }
    static void trapFrames(){
        scenarios++;var s=initial();int trap=H+0x200,irq=H+0x100;
        s.systemPending.add(afterIssue(event(Kind.IRQ,A-4,0x100,3,Availability.PIPELINE_UNVERIFIED),A));
        byte[] r=image(0xc320);l(r,0x80,trap);l(r,0x100,irq);
        w(r,irq,0x002b);w(r,irq+2,0x0009);w(r,trap,0x002b);w(r,trap+2,0x0009);
        var g=graph(r,s);var h=at(g,irq);
        ok(ram(h,SP-8)==A+2&&ram(h,SP-4)==0,"TRAPA frame must precede IRQ");
        ok(ram(h,SP-16)==trap&&ram(h,SP-12)==0,"IRQ must save TRAPA handler ID");
        ok(h.registers().get(15)==SP-16&&h.sr()==0x30,"nested IRQ state");
        var out=at(g,A+2);ok(out.registers().get(15)==SP&&out.sr()==0,"two RTE restore original PC/SR/SP");
        ok(g.executionSteps().stream().filter(e->e.stage()==FirmwareGraph.ExecutionStage.COMPLETE&&e.instructionPc()==A).count()==1,"TRAPA repeated");
    }
    static void readiness() {
        for(int op:new int[]{0xf420,0xf423,0xf43d})for(boolean dbl:new boolean[]{false,true}){
            scenarios++;var s=initial();s.r[2]=B;s.fpscr=0x40001|(dbl?FpuSemantics.PR:0);
            s.fr[4]=dbl?0x40100000:0x40800000;s.fr[5]=0;s.fr[2]=0x40000000;s.fr[3]=0;
            s.fpuCompletionBeforePc=Map.of(A,A+6);
            byte[] r=image(op);w(r,A+2,0x7101);w(r,A+4,0x2212);w(r,A+6,0x001b);
            var g=graph(r,s);var during=at(g,A+2);var after=at(g,A+6);
            ok(during.deferredFpuResult()!=null&&during.fr().get(4).equals(s.fr[4]),"CPU completion must not commit FP result");
            ok(during.fpscr()==null,"FPSCR temporal value must not be fabricated before explicit completion");
            if(op==0xf43d)ok(during.fpul().equals(s.fpul)&&after.fpul()==4,"FPUL result completion");
            else ok(after.fr().get(4)==(op==0xf423?0x40000000:dbl?0x40180000:0x40c00000),"normal FR result completion");
            ok(after.registers().get(1)==18&&ram(after,B)==18,"FP commit rolled back CPU/SRAM effects");
            ok(after.lastRetiredPc()==A+4&&after.deferredFpuResult()==null,"FP completion rewound CPU retirement");
            ok(g.executionSteps().stream().filter(e->e.stage()==FirmwareGraph.ExecutionStage.FPU_RESULT&&e.instructionPc()==A).count()==1,"FP result completion missing/repeated");
        }
        scenarios++;var s=initial();s.fpuCompletionBeforePc=Map.of(A,A+6);
        byte[] r=image(0xf420);w(r,A+2,0xf64c);w(r,A+4,0x0009);w(r,A+6,0x001b);
        var g=graph(r,s);
        ok(g.report().issues().stream().anyMatch(e->e.reason().contains("FPU_COMPLETION_PROFILE_DEPENDENCY_UNVERIFIED")),"early consumer silently moved explicit completion");
        ok(g.executionSteps().stream().noneMatch(e->e.stage()==FirmwareGraph.ExecutionStage.FPU_RESULT),"unsupported consumer forced SF commit");
    }
    static void ioFetchPaths(){
        for(int op:new int[]{0x422b,0x420b,0x000b,0x002b,0x8300,0xc320}){
            scenarios++;var s=initial();s.r[2]=Sh7254rMemoryMap.STBCR;s.pr=Sh7254rMemoryMap.STBCR;s.tbr=B;
            s.writeRam(B,4,Sh7254rMemoryMap.STBCR,A-2);
            s.writeRam(SP,4,Sh7254rMemoryMap.STBCR,A-2);s.writeRam(SP+4,4,0,A-2);
            byte[] r=image(op);w(r,A+2,0x0009);if(op==0xc320)l(r,0x80,Sh7254rMemoryMap.STBCR);
            var g=graph(r,s);
            ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS),"I/O fetch H24 missing for "+Integer.toHexString(op));
        }
        scenarios++;byte[] r=image(0x0009);l(r,0,Sh7254rMemoryMap.STBCR);var g=graph(r,initial());
        ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS),"reset target I/O fetch H24 missing");
        for(int offset:new int[]{2,4,6,8,10}){
            scenarios++;int pc=(int)Sh7254rMemoryMap.SRAM_END_EXCLUSIVE-offset;
            var s=initial();s.writeRam(pc,2,0x0009,A-2);r=image(0x0009);l(r,0,pc);g=graph(r,s);
            final int faultPc=pc;
            ok(g.systemEvents().stream().anyMatch(e->e.stage()==Stage.GENERATION&&e.event().kind()==Kind.CPU_ADDRESS&&Objects.equals(e.event().dataAddress(),faultPc)),"SRAM prefetch boundary H24 missing");
        }
    }
    /** Independent constants below transcribe SW figures8.19/8.35/8.36/8.38/8.42–50,
     * and §8.9.8. Expected intervals are not read from PipelineSpec. */
    static SystemExceptionModel.PipelineSpec ps(int opcode,int pc,int mode) {
        byte[] r=image(opcode);w(r,pc,opcode);
        return pipelineSpec(new Sh2aDecoder().decode(r,pc),mode);
    }
    static Map<String,Integer> values(SystemExceptionModel.PipelineSpec spec,int value) {
        Map<String,Integer> v=new LinkedHashMap<>();for(String name:spec.writes())v.put(name,value);return v;
    }
    static void scheduler(){
        final int SINGLE=0x40000,DOUBLE=0xc0000;
        // MOV R2,R3 -> ADD R3,R4: zero-latency bypass in the same ID slot.
        scenarios++;var p=new Pipeline();var first=ps(0x6323,A,SINGLE);var next=ps(0x343c,A+2,SINGLE);
        p.issue(first,values(first,7));ok(p.ready(next)==0,"MOV zero-latency forwarding");
        p.issue(next,values(next,9));ok(p.outstanding().size()==2,"two outstanding CPU instructions");
        ok(p.ready(ps(0x0009,A+4,SINGLE))==1,"2-ILP cap");p.advance(1);
        ok(p.committed().get("R3")==7&&p.committed().get("R4")==9,"CPU commit order");
        ok(p.steps().stream().filter(x->x.stage()==PipelineStage.RETIREMENT).count()==2,"two retirements");
        // ADD result is not zero-latency; WAW also excludes same-slot issue.
        scenarios++;p=new Pipeline();first=ps(0x332c,A,SINGLE);p.issue(first,values(first,7));
        ok(p.ready(ps(0x343c,A+2,SINGLE))==1,"ADD RAW");
        ok(p.ready(ps(0xe301,A+2,SINGLE))==1,"CPU WAW");
        // two shift instructions share one shift pipeline.
        scenarios++;p=new Pipeline();first=ps(0x4208,A,SINGLE);p.issue(first,values(first,4));
        ok(p.ready(ps(0x4308,A+2,SINGLE))==1,"shift structural hazard");
        // 32-bit instruction excludes parallel issue even without a data hazard.
        scenarios++;first=new PipelineSpec(A,4,Set.of(),Set.of(),List.of(),0,1,false,false,false,false,false,true,1,1,0);
        p=new Pipeline();p.issue(first,Map.of());ok(p.ready(ps(0x0009,A+4,SINGLE))==1,"32-bit preceding");
        p=new Pipeline();p.issue(ps(0x0009,A,SINGLE),Map.of());ok(p.ready(first)==1,"32-bit succeeding");
        scenarios++;p=new Pipeline();first=ps(0xe301,A,SINGLE);p.issue(first,values(first,1));
        ok(p.ready(ps(0x343c,A+2,SINGLE))==1,"MOV immediate is latency1, not MOV register bypass");
        // FCMP T forwarding waits2(single)/3(double), through ordinary MOVT consumer.
        for(int mode:new int[]{SINGLE,DOUBLE}) {
            scenarios++;p=new Pipeline();first=ps(0xf424,A,mode);p.issue(first,values(first,1));
            ok(p.ready(ps(0x0329,A+2,mode))==(mode==SINGLE?2:3),"FCMP->MOVT T-bit readiness");
        }
        scenarios++;p=new Pipeline();first=ps(0xf420,A,SINGLE);p.issue(first,values(first,1));
        ok(p.ready(ps(0x036a,A+2,SINGLE))==4,"FPSCR read waits arithmetic latency+1");
                // FADD has latency3; FMOV bypass has latency0, regardless of later SF.
        scenarios++;p=new Pipeline();first=ps(0xf420,A,SINGLE);p.issue(first,values(first,0x40000000));
        ok(p.ready(ps(0xf64c,A+2,SINGLE))==3,"FADD to FMOV RAW=3");
        ok(p.ready(ps(0xf43c,A+2,SINGLE))==1,"FADD WAW shortened to1");
        p.advance(1);ok(p.outstanding().getFirst().cpuCompleted()&&!p.outstanding().getFirst().resultCommitted(),"CPU complete before SF");
        ok(!p.committed().containsKey("FR4"),"FR result committed before SF");p.advance(3);
        ok(p.committed().get("FR4")==0x40000000,"FADD SF");
        scenarios++;p=new Pipeline();first=ps(0xf42c,A,SINGLE);p.issue(first,values(first,0x40000000));
        ok(p.ready(ps(0xf640,A+2,SINGLE))==0,"FMOV zero-latency FPU forwarding");
        scenarios++;p=new Pipeline();first=ps(0xf20c,A,SINGLE);p.issue(first,values(first,0x3f800000));
        next=ps(0xf230,A+2,SINGLE);ok(p.ready(next)==0,"zero-latency FPU WAW may coissue");
        p.issue(next,values(next,0x40000000));p.advance(3);
        ok(p.committed().get("FR2")==0x40000000,"same-slot SF writes must retain issue order");
        // FTRC->STS FPUL,R3 uses two-slot forwarding reduction (fig8.38).
        scenarios++;p=new Pipeline();first=ps(0xf03d,A,SINGLE);p.issue(first,values(first,1));
        ok(p.ready(ps(0x035a,A+2,SINGLE))==1,"FTRC FPUL forwarding");
        // FADD double occupies E1 for6, WAR source hold2, odd-half RAW7/even8.
        scenarios++;p=new Pipeline();first=ps(0xf420,A,DOUBLE);p.issue(first,values(first,1));
        ok(p.ready(ps(0xf860,A+2,DOUBLE))==6,"double E1 six slots");
        ok(p.ready(ps(0xf38c,A+2,DOUBLE))==2,"double source WAR");
        ok(p.ready(ps(0xf65c,A+2,DOUBLE))==7,"double odd-half forwarding");
        ok(p.ready(ps(0xf64c,A+2,DOUBLE))==8,"double even-half RAW");
        // FDIV/FSQRT: exact one-state profile counts, unrelated FADD overlaps ED.
        for(int[] row:new int[][]{{0xf423,SINGLE,12},{0xf46d,SINGLE,11},{0xf423,DOUBLE,25},{0xf46d,DOUBLE,24}}) {
            scenarios++;p=new Pipeline();first=ps(row[0],A,row[1]);p.issue(first,values(first,1));
            ok(p.ready(ps(0xf64c,A+2,row[1]))==row[2],"FDIV/FSQRT dependent latency "+row[2]);
            p.advance(1);ok(p.outstanding().getFirst().cpuCompleted(),"multicycle FP CPU completion");
            p.advance(row[2]-1);ok(!p.committed().containsKey("FR4"),"long FP result early");
            p.advance(row[2]);ok(p.committed().get("FR4")==1,"long FP result late");
        }
        scenarios++;p=new Pipeline();first=ps(0xf423,A,SINGLE);p.issue(first,values(first,1));
        next=ps(0xf860,A+2,SINGLE);ok(p.ready(next)==1,"independent FADD overlaps ED");
        p.issue(next,values(next,2));ok(p.outstanding().size()==2,"multiple outstanding FPU producers");
        p.advance(4);ok(p.committed().get("FR8")==2&&!p.committed().containsKey("FR4"),"out-of-order FP completion");
        ok(p.ready(ps(0xfa60,A+4,SINGLE))==4,"no forced drain of unrelated divide");
        for(int[] row:new int[][]{{0xf423,24},{0xf46d,23}}) {
            scenarios++;p=new Pipeline();first=ps(row[0],A,DOUBLE);p.issue(first,values(first,1));
            ok(p.ready(ps(0xf65c,A+2,DOUBLE))==row[1],"double FDIV/FSQRT odd-half forwarding");
        }
        // FDIV writeback E1 is reserved at10, so new FADD DF requested at9 waits to10 (E1 at11).
        scenarios++;p=new Pipeline();first=ps(0xf423,A,SINGLE);p.issue(first,values(first,1));p.advance(9);
        ok(p.ready(ps(0xf860,A+2,SINGLE))==10,"FDIV terminal E1 priority");
        scenarios++;p=new Pipeline();first=ps(0xf423,A,SINGLE);p.issue(first,values(first,1));
        next=ps(0xf863,A+2,SINGLE);ok(p.ready(next)==1,"busy ED retains post-issue waiting stage");p.issue(next,values(next,2));
        scenarios++;var crossing=new Pipeline();first=ps(0xf423,A,DOUBLE);crossing.issue(first,values(first,1));crossing.advance(16);next=ps(0xf860,A+2,DOUBLE);
        ok(crossing.ready(next)==16,"future E1 return must not move independent ready16 to23");crossing.issue(next,values(next,2));crossing.advance(25);ok(!crossing.committed().containsKey("FR4"),"no fictitious result before actual E1 return");crossing.advance(27);ok(crossing.committed().get("FR4")==1,"actual late SF");
                // Copies are independent, reset cancels every outstanding job without stale commit.
        scenarios++;var copied=p.copy();p.reset();p.advance(50);
        ok(p.outstanding().isEmpty()&&p.committed().isEmpty(),"reset prevents stale result commit");
        ok(copied.outstanding().size()==2,"pipeline copy isolation");
        ok(p.steps().stream().filter(x->x.stage()==PipelineStage.CANCELLED).count()==2,"reset cancellation trace");
        // Graph path uses the same scoreboard/commit, not a test-only executor.
        scenarios++;var s=initial();s.fpscr=SINGLE;byte[] rom=image(0xf423);
        w(rom,A+2,0xf860);w(rom,A+4,0xf64c);w(rom,A+6,0x0009);w(rom,A+8,0x001b);
        var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(rom,32,s);
        ok(g.pipelineStates().stream().anyMatch(x->x.outstanding().size()>=2),"graph multiple outstanding absent");
        ok(g.pipelineStates().stream().flatMap(x->x.steps().stream()).anyMatch(x->x.stage()==PipelineStage.RESULT_COMMIT&&x.pc()==A),"graph delayed divide commit absent");
        ok(at(g,A+6).fr().get(4)==0x3f800000,"graph divide result");
        ok(g.report().issues().stream().anyMatch(x->x.reason().startsWith("PIPELINE_NOT_IMPLEMENTED_PROFILE_")),"unsupported timing invented");
        scenarios++;s=initial();s.queueSystem(Kind.POWER_ON_RESET,A,null,0,0,"explicit reset",Availability.REPORTED_ID);
        rom=image(0xf420);g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(rom,32,s);
        ok(g.pipelineStates().size()==g.cpuStates().size(),"power reset lost pipeline profile");
                // H34 condition records generation and halts precise timing without guessing a report.
        scenarios++;s=initial();s.fpscr=SINGLE|0x800;Arrays.fill(s.fr,0);rom=image(0xf423);
        g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(rom,32,s);
        ok(g.systemEvents().stream().anyMatch(x->x.stage()==Stage.GENERATION&&x.event().kind()==Kind.FPU),"scheduler H34 generation");
        ok(g.systemEvents().stream().noneMatch(x->x.stage()==Stage.ACCEPTANCE&&x.event().kind()==Kind.FPU),"scheduler invented H34 report");
        ok(g.report().issues().stream().anyMatch(x->x.reason().contains("PIPELINE_H34_REPORT_UNVERIFIED")),"H34 uncertainty hidden");
        ok(g.pipelineStops().stream().anyMatch(x->x.outstanding().stream().anyMatch(f->f.spec().pc()==A&&f.result().isEmpty())),"H34 outstanding condition context lost");
    }
    static void withdrawal(){
        for(boolean readback:new boolean[]{false,true}) {
            scenarios++;var s=initial();s.r[1]=0xfffe0812;s.softwareInterrupts[2]=1;
            s.queueSystem(Kind.SOFTWARE,A-2,null,0x1a4,3,"SINTR3",Availability.REPORTED_ID);
            s.queueSystem(Kind.IRQ,A-2,null,0x100,6,"higher IRQ",Availability.REPORTED_ID);
            byte[] rom=image(0x0009);l(rom,0x100,H);l(rom,0x1a4,0x1400);w(rom,0x1400,0x001b);
            w(rom,H,0xe000);w(rom,H+2,0x2100);w(rom,H+4,readback?0x6010:0x0009);
            for(int j=6;j<=10;j+=2)w(rom,H+j,0x0009);
            w(rom,H+12,0x002b);w(rom,H+14,0x0009);
            var g=graph(rom,s);
            boolean accepted=g.systemEvents().stream().anyMatch(x->x.stage()==Stage.ACCEPTANCE&&x.event().kind()==Kind.SOFTWARE);
            if(readback)ok(!accepted,"cleared/read0 SINTR3 delivered report survived RTE");
            else ok(accepted,"clear alone silently retracts already delivered report without propagation evidence");
        }
    }
    static void withdrawalProofs(){
        for(boolean reassert:new boolean[]{false,true}) {
            scenarios++;var s=initial();s.softwareInterrupts[1]=1;s.softwareInterrupts[2]=1;
            s.queueSystem(Kind.SOFTWARE,A,null,0x1a4,3,"SINTR3",Availability.REPORTED_ID);
            s.queueSystem(Kind.SOFTWARE,A,null,0x1a8,2,"SINTR2",Availability.REPORTED_ID);
            Sh7254rIntcMmio.write(s,0xfffe0812,1,0);
            Sh7254rIntcMmio.read(s,0xfffe0812,1);
            if(reassert)Sh7254rIntcMmio.write(s,0xfffe0812,1,1);
            Sh7254rIntcMmio.reconcileBeforeRte(s);
            ok(s.systemPending.stream().anyMatch(e->e.level()==2),"withdrawal removed unrelated SINT");
            ok(s.systemPending.stream().anyMatch(e->e.level()==3)==reassert,"reassert invalidates earlier withdrawal proof");
        }
        scenarios++;var s=initial();s.softwareInterrupts[2]=1;
        Sh7254rIntcMmio.write(s,0xfffe0812,1,0);var copy=s.copy();Sh7254rIntcMmio.read(copy,0xfffe0812,1);
        ok(s.softwareClearRead==0&&copy.softwareClearRead!=0,"read proof leaked between copies");
        s.restoreFaultState(copy);ok(s.softwareClearRead==copy.softwareClearRead,"rollback lost read proof");
    }
    static void doubleCompareIssue(){
        scenarios++;var p=new Pipeline();var spec=ps(0xf424,A,0xc0000);p.issue(spec,values(spec,1));
        ok(p.ready(ps(0x0009,A+2,0xc0000))==1,"double FCMP preceding must not coissue following NOP");
        p.advance(1);ok(!p.outstanding().getFirst().cpuCompleted(),"double FCMP CPU requires EX/EX");
        p.advance(2);ok(p.outstanding().getFirst().cpuCompleted(),"double FCMP CPU completion offset2");
    }
}
