package ecu.independent;

import java.nio.file.Files;
import java.nio.file.Path;

/** Independent fixed Renesas vectors plus Fraction/binary-search oracle fixtures. */
public final class FpuStage3Acceptance {
    private FpuStage3Acceptance() {}
    private static int checks;
    private static void check(boolean b,String text){checks++;if(!b)throw new AssertionError(text);}
    private static Sh2aDecoder.Instruction inst(int op){return new Sh2aDecoder().decode(new byte[]{(byte)(op>>>8),(byte)op},0);}
    private static AbstractCpu state(int mode){var s=new AbstractCpu(0xfff90000);s.fpscr=mode|0x40000;s.fpul=0x12345678;s.fr[0]=0;s.fr[1]=0;s.fr[2]=0;s.fr[3]=0;return s;}
    private static void put(AbstractCpu s,int n,boolean d,long b){s.fr[n]=d?(int)(b>>>32):(int)b;if(d)s.fr[n+1]=(int)b;}
    private static long get(AbstractCpu s,int n,boolean d){return d?Integer.toUnsignedLong(s.fr[n])<<32|Integer.toUnsignedLong(s.fr[n+1]):Integer.toUnsignedLong(s.fr[n]);}
    private static void vector(int opcode,int mode,long a,long b,long result,int flags,boolean fpul){
        boolean d=(mode&0x80000)!=0;var s=state(mode);put(s,0,d,a);put(s,2,d,b);
        if(opcode==0xf02d||opcode==0xf0ad)s.fpul=(int)a;
        String error=FpuSemantics.apply(s,inst(opcode));
        check(error==null,"unrouted "+Integer.toHexString(opcode)+": "+error);
        check((fpul?Integer.toUnsignedLong(s.fpul):get(s,0,d))==result,"bits "+Integer.toHexString(opcode)+" expected="+Long.toHexString(result)+" actual="+Long.toHexString(fpul?Integer.toUnsignedLong(s.fpul):get(s,0,d)));
        check((s.fpscr&0x3f07c)==flags,"flags "+Integer.toHexString(opcode)+" expected="+Integer.toHexString(flags)+" actual="+Integer.toHexString(s.fpscr));
        check(s.fpuExceptionPending==null,"unexpected pending");
    }
    private static void unary(int code,boolean d,long input,long expected,int flags,int normalMask,boolean sourceSpecial,boolean fpul,boolean sourceFpul) {
        for(int rm:new int[]{0,1})for(int qis:new int[]{0,0x400000})for(int en=0;en<32;en++) {
            int enable=en<<7;var s=state((d?0x80000:0)|rm|qis|enable);
            if(sourceFpul)s.fpul=(int)input;else put(s,0,d,input);
            long before=get(s,0,d);int beforeFpul=s.fpul;
            boolean override=sourceSpecial&&qis!=0&&(enable&0x800)!=0;
            int actualFlags=override?0x10040:flags;
            boolean trap=override||(flags&0x10000)!=0&&(enable&0x800)!=0||(normalMask&enable)!=0;
            String error=FpuSemantics.apply(s,inst(code));
            String label="unary "+Integer.toHexString(code)+" input="+Long.toHexString(input)+" mode="+Integer.toHexString(enable|qis|rm);
            check(trap?error!=null&&error.startsWith("FPU_EXCEPTION_GENERATED_"):error==null,label+" route");
            check((s.fpscr&0x3f07c)==actualFlags,label+" flags");
            check(trap?s.fpuExceptionPending!=null:s.fpuExceptionPending==null,label+" pending");
            if(trap)check(get(s,0,d)==before&&s.fpul==beforeFpul,label+" destination suppressed");
            else if(fpul)check(Integer.toUnsignedLong(s.fpul)==expected,label+" FPUL bits");
            else check(get(s,0,d)==expected,label+" FR bits");
        }
    }
    public static void main(String[] args)throws Exception {
        for(String row:Files.readAllLines(Path.of("tools/fixtures/fpu-exact.tsv"))){
            String[] cells=row.split("\t");long[] v=new long[cells.length];for(int i=0;i<v.length;i++)v[i]=Long.parseUnsignedLong(cells[i],16);
            int op=(int)v[0],mode=(v[1]==1?0x80000:0)|(int)v[2];
            vector(op<4?0xf020|op:0xf000|op,mode,v[3],v[4],v[5],(int)v[6],op==0xbd);
        }
        for(String row:Files.readAllLines(Path.of("tools/fixtures/fpu-special-tables.tsv"))) {
            String[] cells=row.split("\t");long[] v=new long[cells.length];for(int i=0;i<v.length;i++)v[i]=Long.parseUnsignedLong(cells[i],16);
            int op=(int)v[0];boolean d=v[1]==1;
            for(int rm:new int[]{0,1})for(int qis:new int[]{0,0x400000})for(int en=0;en<32;en++) {
                int enable=en<<7;var st=state((d?0x80000:0)|rm|qis|enable);put(st,0,d,v[2]);put(st,2,d,v[3]);st.t=true;
                int flags=(int)v[5];boolean override=qis!=0&&(enable&0x800)!=0&&v[8]==1;
                if(override)flags=0x10040;
                boolean trap=override||(flags&0x10000)!=0&&(enable&0x800)!=0||(flags&0x8000)!=0&&(enable&0x400)!=0||(enable&(int)v[7])!=0;
                String err=FpuSemantics.apply(st,inst(0xf020|op));
                String context="table op="+op+" d="+d+" a="+Long.toHexString(v[2])+" b="+Long.toHexString(v[3])+" enable="+enable+" qis="+qis;
                check(trap?err!=null&&err.startsWith("FPU_EXCEPTION_GENERATED_"):err==null,context+" route "+err);
                check(get(st,0,d)==(trap?v[2]:v[4]),context+" destination");
                check((st.fpscr&0x3f07c)==flags,context+" flags");
                check(trap?st.fpuExceptionPending!=null:st.fpuExceptionPending==null,context+" pending");
                if(op>=4)check(st.t==(trap||v[6]==1),context+" T");
            }
        }
        for(String row:Files.readAllLines(Path.of("tools/fixtures/fpu-fmac-special.tsv"))) {
            String[] cells=row.split("\t");long[] v=new long[cells.length];for(int i=0;i<v.length;i++)v[i]=Long.parseUnsignedLong(cells[i],16);
            for(int rm:new int[]{0,1})for(int qis:new int[]{0,0x400000})for(int en=0;en<32;en++) {
                int enable=en<<7;var st=state(rm|qis|enable);st.fr[4]=(int)v[0];st.fr[2]=(int)v[1];st.fr[0]=(int)v[2];
                int flags=(int)v[4];boolean override=qis!=0&&(enable&0x800)!=0&&v[6]==1;
                if(override)flags=0x10040;
                boolean trap=override||(flags&0x10000)!=0&&(enable&0x800)!=0||(enable&(int)v[5])!=0;
                String err=FpuSemantics.apply(st,inst(0xf42e));
                String context="FMAC a="+Long.toHexString(v[0])+" b="+Long.toHexString(v[1])+" c="+Long.toHexString(v[2])+" enable="+enable+" qis="+qis;
                check(trap?err!=null&&err.startsWith("FPU_EXCEPTION_GENERATED_"):err==null,context+" route "+err);
                check(Integer.toUnsignedLong(st.fr[4])==(trap?v[0]:v[3]),context+" destination");
                check((st.fpscr&0x3f07c)==flags,context+" flags");
                check(trap?st.fpuExceptionPending!=null:st.fpuExceptionPending==null,context+" pending");
                check(Integer.toUnsignedLong(st.fr[0])==v[2]&&Integer.toUnsignedLong(st.fr[2])==v[1],context+" sources mutated");
            }
        }
        // Tables §§6.5.2–6.5.19, including SH canonical qNaN (quiet bit clear).
        for(int rm:new int[]{0,1}) {
            vector(0xf020,rm,0x80000000L,0,0,0,false);
            vector(0xf020,rm,0x80000000L,0x80000000L,0x80000000L,0,false);
            vector(0xf021,rm,0x80000000L,0,0x80000000L,0,false);
            vector(0xf022,rm,0x80000000L,0x40000000,0x80000000L,0,false);
            vector(0xf023,rm,0x3f800000,0,0x7f800000,0x8020,false);
            vector(0xf023,rm,0,0,0x7fbfffff,0x10040,false);
            vector(0xf022,rm,0x7f800000,0,0x7fbfffff,0x10040,false);
            vector(0xf020,rm,0x7f800000,0xff800000L,0x7fbfffff,0x10040,false);
            vector(0xf020,rm,0x7fb12345,0x3f800000,0x7fbfffff,0,false);
            vector(0xf020,rm,0x7fc12345,0x3f800000,0x7fbfffff,0x10040,false);
            vector(0xf020,rm,1,0x80000001L,0,0,false);
            vector(0xf06d,rm,0x80000001L,0,0x80000000L,0,false);
            vector(0xf03d,rm,0x7fbfffff,0,0x80000000L,0x10040,true);
            vector(0xf03d,rm,0x7f800000,0,0x7fffffff,0x10040,true);
            vector(0xf03d,rm,0xcf000000L,0,0x80000000L,0,true);
            vector(0xf03d,0x80000|rm,0xc1e0000000100000L,0,0x80000000L,0,true); // -2147483648.5
            vector(0xf03d,0x80000|rm,0xc1e0000000200000L,0,0x80000000L,0x10040,true);
        }
        for(boolean d:new boolean[]{false,true}) {
            long inf=d?0x7ff0000000000000L:0x7f800000L, nan=d?0x7ff7ffffffffffffL:0x7fbfffffL;
            var cmp=state(d?0x80000:0);put(cmp,0,d,inf);put(cmp,2,d,inf);
            check(FpuSemantics.apply(cmp,inst(0xf024))==null&&cmp.t,"infinity EQ");
            put(cmp,0,d,nan);check(FpuSemantics.apply(cmp,inst(0xf024))==null&&!cmp.t&&(cmp.fpscr&0x3f000)==0,"qNaN EQ");
            check(FpuSemantics.apply(cmp,inst(0xf025))==null&&!cmp.t&&(cmp.fpscr&0x10040)==0x10040,"qNaN GT invalid");
        }
        for(long special:new long[]{0x7f800000L,0xff800000L,0x7fbfffffL,0x7fc00000L}) {
            var cvt=state(0x80000);cvt.fpul=(int)special;
            check(FpuSemantics.apply(cvt,inst(0xf0ad))==null,"FCNVSD special");
            long expected=special==0x7f800000L?0x7ff0000000000000L:special==0xff800000L?0xfff0000000000000L:0x7ff7ffffffffffffL;
            check(get(cvt,0,true)==expected,"FCNVSD special bits");
            check((cvt.fpscr&0x3f07c)==(special==0x7fc00000L?0x10040:0),"FCNVSD special flags");
        }
        for(long special:new long[]{0x7ff0000000000000L,0xfff0000000000000L,0x7ff7ffffffffffffL,0x7ff8000000000000L}) {
            long expected=special==0x7ff0000000000000L?0x7f800000L:special==0xfff0000000000000L?0xff800000L:0x7fbfffffL;
            vector(0xf0bd,0x80000,special,0,expected,special==0x7ff8000000000000L?0x10040:0,true);
        }
        // Actual O/U/I, all enable bits individually, exact cause/flag and no write on trap.
        for(long[] v:new long[][]{{0x7f7fffffL,0x40000000L,0x5014},{0x800000L,0x3f000000L,0x300c},{0x3f800001L,0x3f800001L,0x1004}}) {
            for(int enable:new int[]{0,0x80,0x100,0x200,0x400,0x800}) {
                var ex=state(enable);ex.fr[0]=(int)v[0];ex.fr[2]=(int)v[1];ex.fpscr|=0x40;
                String error=FpuSemantics.apply(ex,inst(0xf022));
                boolean trap=(enable&0x380)!=0;
                check(trap?error!=null&&error.startsWith("FPU_EXCEPTION_GENERATED_"):error==null,"OUI trap route");
                check((ex.fpscr&0x3f07c)==((int)v[2]|0x40),"OUI exact flags");
                if(trap)check(ex.fr[0]==(int)v[0]&&ex.fpuExceptionPending!=null,"OUI suppressed destination");
            }
        }
        for(boolean dbl:new boolean[]{false,true})for(int rm:new int[]{0,1})for(int qis:new int[]{0,0x400000}) {
            long inf=dbl?0x7ff0000000000000L:0x7f800000L;
            long qnan=dbl?0x7ff7ffffffffffffL:0x7fbfffffL;
            long snan=dbl?0x7ff8000000000001L:0x7fc00001L;
            long one=dbl?0x3ff0000000000000L:0x3f800000L;
            for(long a:new long[]{inf,qnan,snan})for(int enable:new int[]{0,0x800}) {
                int mode=(dbl?0x80000:0)|rm|qis|enable;
                var s=state(mode);put(s,0,dbl,a);put(s,2,dbl,one);s.fpscr|=0x8020;
                boolean trap=enable!=0&&(a==snan||qis!=0);
                String error=FpuSemantics.apply(s,inst(0xf020));
                check(trap?error!=null&&error.startsWith("FPU_EXCEPTION_GENERATED_V"):error==null,"QIS/NaN route");
                check((s.fpscr&0x20)!=0,"sticky Z lost");
                check(trap?s.fpuExceptionPending!=null&&get(s,0,dbl)==a:s.fpuExceptionPending==null,"trap destination/pending");
            }
        }
        for(boolean d:new boolean[]{false,true}) {
            long sign=d?Long.MIN_VALUE:0x80000000L,inf=d?0x7ff0000000000000L:0x7f800000L;
            long quiet=d?0x7ff7ffffffffffffL:0x7fbfffffL,signal=d?0x7ff8000000000001L:0x7fc00001L;
            for(long input:new long[]{0,sign,1,sign|1,inf,sign|inf,quiet,sign|quiet,signal,sign|signal}) {
                boolean nan=(input&~sign)>inf,snan=(input&~sign)>=signal,special=(input&~sign)>=inf;
                boolean negative=(input&sign)!=0;
                long sqrt=nan||input==(sign|inf)?quiet:(input&~sign)<inf?input&sign:inf;
                int sqrtFlags=snan||input==(sign|inf)?0x10040:0;
                unary(0xf06d,d,input,sqrt,sqrtFlags,0,special,false,false);
                long truncated=nan||negative&&special?0x80000000L:special?0x7fffffff:0;
                unary(0xf03d,d,input,truncated,special?0x10040:0,0,special,true,false);
                if(d) {
                    long converted=nan?0x7fbfffffL:(negative?0x80000000L:0)|(special?0x7f800000L:0);
                    unary(0xf0bd,true,input,converted,snan?0x10040:0,special?0:0x380,special,true,false);
                }
            }
        }
        for(long input:new long[]{0,0x80000000L,1,0x80000001L,0x7f800000L,0xff800000L,0x7fbfffffL,0x7fc00001L}) {
            long magnitude=input&0x7fffffffL;boolean nan=magnitude>0x7f800000L;
            long converted=nan?0x7ff7ffffffffffffL:((input&0x80000000L)!=0?Long.MIN_VALUE:0)|(magnitude==0x7f800000L?0x7ff0000000000000L:0);
            unary(0xf0ad,true,input,converted,magnitude>=0x7fc00000L?0x10040:0,0,magnitude>=0x7f800000L,false,true);
        }
        // Rev.4 explicitly corrects the conflicting Rev.3 FMAC rules.
        for(boolean as:new boolean[]{false,true})for(boolean bs:new boolean[]{false,true})for(boolean cs:new boolean[]{false,true}) {
            var mac=state(0);mac.fr[4]=as?0x80000000:0;mac.fr[2]=bs?0x80000000:0;mac.fr[0]=cs?0x80000000:0;
            check(FpuSemantics.apply(mac,inst(0xf42e))==null,"FMAC corrected zero route");
            check(mac.fr[4]==(as&&(bs^cs)?0x80000000:0),"FMAC corrected zero sign");
        }
        var infinityMac=state(0);infinityMac.fr[0]=0x7f800000;infinityMac.fr[2]=0x3f800000;infinityMac.fr[4]=0xbf800000;
        check(FpuSemantics.apply(infinityMac,inst(0xf42e))==null&&infinityMac.fr[4]==0x7f800000,"FMAC corrected infinite product");
        for(int opcode:new int[]{0xf020,0xf02e}) {
            var s=state(0);s.fr[2]=null;
            check("FPU_INPUT_UNKNOWN".equals(FpuSemantics.apply(s,inst(opcode))),"unknown FRm");
        }
        var s=state(0);s.fr[0]=null;
        check("FPU_INPUT_UNKNOWN".equals(FpuSemantics.apply(s,inst(0xf22e))),"unknown FR0");
        s=state(0);s.fpscr=0;check("FPSCR_DN0_RESERVED".equals(FpuSemantics.apply(s,inst(0xf020))),"DN0 reserved");
        for(int rm:new int[]{2,3}){s=state(rm);check("FPSCR_ROUNDING_RESERVED".equals(FpuSemantics.apply(s,inst(0xf020))),"RM reserved");}
        System.out.println("FPU_STAGE3_ACCEPTANCE: PASS checks="+checks+" (listed vectors only; full matrix acceptance separate)");
    }
}
