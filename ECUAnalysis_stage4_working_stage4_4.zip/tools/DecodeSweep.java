import ecu.independent.Sh2aDecoder;

/** Structural decoder sanity sweep, NOT an oracle for whether opcodes are valid. */
public final class DecodeSweep {
    public static void main(String[] args) {
        byte[] bytes=new byte[4];
        Sh2aDecoder decoder=new Sh2aDecoder();
        int supported16=0,supported32=0,opaque16=0,opaque32=0,unknown=0;
        for(int first=0;first<=0xFFFF;first++) {
            bytes[0]=(byte)(first>>>8);bytes[1]=(byte)first;
            for(int second : new int[]{0x0000,0x0123,0x4ABC,0xDFFF,0xFFFF}) {
                bytes[2]=(byte)(second>>>8);bytes[3]=(byte)second;
                Sh2aDecoder.Instruction inst=decoder.decode(bytes,0);
                if(inst.width()!=2 && inst.width()!=4)
                    throw new AssertionError("Invalid instruction width " + inst);
                if(inst.supported() && inst.flow()==Sh2aDecoder.Flow.UNKNOWN)
                    throw new AssertionError("Semantically supported UNKNOWN flow " + inst);
                if(inst.supported()) {
                    if(inst.width()==2)supported16++;else supported32++;
                } else if(inst.operation()==Sh2aDecoder.Operation.OPAQUE) {
                    if(inst.width()==2)opaque16++;else opaque32++;
                } else unknown++;
            }
        }
        System.out.println("Evaluated 327680 prefix/continuation pairs");
        System.out.printf("supported16=%d supported32=%d opaque16=%d opaque32=%d invalid_or_unknown=%d%n",
                supported16,supported32,opaque16,opaque32,unknown);
        System.out.println("WARNING: These are encoding counts, NOT ISA completeness/semantic correctness metrics");
    }
}
