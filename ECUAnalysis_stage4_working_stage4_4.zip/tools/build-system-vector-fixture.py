#!/usr/bin/env python3
"""Extract assigned target vectors from Hardware Rev4 Table8.4, not Java code."""
import re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
pdf=root/'inputs/SH7254R Group User’s Manual%3A Hardware.pdf'
h=subprocess.check_output(['pdftotext','-layout',str(pdf),'-'],text=True)
m=re.search(r'Table 8\.4\s+Interrupt Exception Handling Vectors and Priority Levels',h)
if m is None:raise SystemExit('Table8.4 missing')
b=h[m.end():h.index('8.6       Operation',m.end())]
v=sorted({int(x,16)//4 for x in re.findall(r"H'([0-9A-F]{8})",b) if int(x,16)%4==0})
assert 11 in v and 12 in v and 64 in v and 79 in v and 82 in v and 488 in v
out=root/'tools/fixtures/sh7254r-interrupt-vectors.tsv'
out.write_text('vector\toffset\tsource\n'+''.join(f'{i}\t0x{i*4:03X}\tR01UH0480EJ0400 Table8.4 pp143-160\n' for i in v))
print(f'Extracted {len(v)} assigned vectors')
