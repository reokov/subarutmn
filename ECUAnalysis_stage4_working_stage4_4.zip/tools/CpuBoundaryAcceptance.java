package ecu.independent;

import java.math.BigInteger;
import java.nio.file.*;
import java.util.*;
import static ecu.independent.CpuExecutionAcceptance.*;

/** Independent mathematical/primary-manual boundary oracles, production CPU path only. */
public final class CpuBoundaryAcceptance {
    static final BigInteger MOD=BigInteger.ONE.shiftLeft(32), MASK=MOD.subtract(BigInteger.ONE);
    static int checks; static int pos;static byte[] program;
    record MathCase(int pc,int reg,int value,int sr,String label){}
    static final List<MathCase> math=new ArrayList<>();
    static void require(boolean x,String label){if(!x)throw new AssertionError(label);checks++;}
    static void emit(int code){word(program,pos,code);pos+=2;}
    static void constant(int reg,int value){
        if((pos&3)!=0)emit(0x0009);
        emit(0xd001|(reg<<8));emit(0xa003);emit(0x0009);emit(0x0009);
        longword(program,pos,value);pos+=4;
    }
    static BigInteger unsigned(int x){return BigInteger.valueOf(Integer.toUnsignedLong(x));}
    static void arithmetic(){
        program=image();pos=A;int[] values={0,1,-1,2,-2,0x7fffffff,0x80000000,0x7ffffffe,0x80000001,0x55555555,0xaaaaaaaa};
        int[] ops={0x312c,0x312e,0x312f,0x3128,0x312a,0x312b,0x612a};
        for(int op:ops)for(int x:values)for(int y:values)for(int t=0;t<2;t++){
            constant(1,x);constant(2,y);emit(t==0?0x0008:0x0018);emit(op);
            boolean neg=op==0x612a,sub=neg||op==0x3128||op==0x312a||op==0x312b;
            boolean carry=neg||op==0x312e||op==0x312a,overflow=op==0x312f||op==0x312b;
            BigInteger lhs=neg?BigInteger.ZERO:unsigned(x),rhs=unsigned(y);
            BigInteger result=sub?lhs.subtract(rhs):lhs.add(rhs);
            if(carry)result=result.add(BigInteger.valueOf(sub?-t:t));
            int out=result.and(MASK).intValue();boolean flag=t!=0;
            if(carry)flag=result.signum()<0||result.compareTo(MOD)>=0;
            if(overflow){BigInteger signed=BigInteger.valueOf(x).add(BigInteger.valueOf(sub?-(long)y:y));flag=signed.compareTo(BigInteger.valueOf(Integer.MIN_VALUE))<0||signed.compareTo(BigInteger.valueOf(Integer.MAX_VALUE))>0;}
            math.add(new MathCase(pos,1,out,flag?1:0,"arith "+Integer.toHexString(op)+" "+x+" "+y+" T"+t));
        }
        for(int op:new int[]{0x412c,0x412d})for(int x:values)for(int shift:new int[]{Integer.MIN_VALUE,-65,-64,-63,-33,-32,-31,-1,0,1,31,32,33,63,Integer.MAX_VALUE}){
            constant(1,x);constant(2,shift);emit(0x0018);emit(op);
            int amount=shift>=0?Math.floorMod(shift,32):Math.floorMod(-(long)shift,32);
            if(shift<0&&amount==0)amount=32;
            BigInteger v=op==0x412c?BigInteger.valueOf(x):unsigned(x);
            int out=(shift>=0?v.shiftLeft(amount):v.shiftRight(amount)).intValue();
            math.add(new MathCase(pos,1,out,1,"dynamic shift "+x+" "+shift));
        }
        // DIV1: exact-width arithmetic, no copy of the executor's four-case algorithm.
        for(int x:values)for(int y:values)for(int flags=0;flags<8;flags++){
            int sr=(flags&1)|((flags&2)!=0?0x100:0)|((flags&4)!=0?0x200:0);
            constant(1,x);constant(2,y);constant(3,sr);emit(0x430e);emit(0x3124);
            boolean q=(flags&2)!=0,m=(flags&4)!=0;
            BigInteger before=unsigned(x).shiftLeft(1).and(MASK).add(BigInteger.valueOf(flags&1));
            BigInteger after=q==m?before.subtract(unsigned(y)):before.add(unsigned(y));
            boolean carry=after.signum()<0||after.compareTo(MOD)>=0;
            boolean newQ=(x<0)^carry^m;int expectedSr=(newQ?0x100:0)|(m?0x200:0)|(newQ==m?1:0);
            math.add(new MathCase(pos,1,after.and(MASK).intValue(),expectedSr,"DIV1 x="+x+" y="+y+" flags="+flags));
        }
        emit(0x001b);AbstractCpu initial=initial();FirmwareGraph g=new FirmwareGraph();g.analyzeCpu(program,100000,initial);
        Map<Integer,FirmwareGraph.CpuSnapshot> states=new HashMap<>();for(var s:g.cpuStates())states.put(s.pc(),s);
        for(var c:math){var s=states.get(c.pc);require(s!=null,c.label+" no retirement");require(Objects.equals(s.registers().get(c.reg),c.value),c.label+" result "+s.registers().get(c.reg)+" expected "+c.value);require(Objects.equals(s.sr(),c.sr),c.label+" flags "+s.sr()+" expected "+c.sr);}
        require(!g.report().truncated(),"math instruction limit");
    }
    static FirmwareGraph one(AbstractCpu s,int code){byte[] r=image();word(r,A,code);word(r,A+2,0x001b);return graph(r,s);}
    static void mac(){
        int[][] cases={
            // code,S,MACH,MACL,N,M,expectedMACH,expectedMACL,alias
            {0x012f,1,0xabcd7fff,-1,1,1,0xabcd7fff,-1,0},
            {0x012f,1,0xabcd8000,0,-1,1,0xabcd8000,0,0},
            {0x012f,1,0xabcd0000,2,3,-4,0xabcdffff,-10,0},
            {0x412f,1,0x12345678,Integer.MAX_VALUE,1,1,1,Integer.MAX_VALUE,0},
            {0x412f,1,0x12345678,Integer.MIN_VALUE,-1,1,1,Integer.MIN_VALUE,0},
            {0x412f,1,0x12345678,2,3,-4,0x12345678,-10,0},
            {0x011f,0,0,0,3,-4,-1,-12,1},
            {0x411f,1,0,0,3,-4,0,-12,1},
            {0x012f,0,-1,-1,Integer.MIN_VALUE,Integer.MIN_VALUE,0x3fffffff,-1,0}
        };
        for(int[] c:cases){AbstractCpu s=initial();s.saturation=c[1]!=0;s.mach=c[2];s.macl=c[3];s.r[1]=B;s.r[2]=B+8;int width=c[0]==0x012f||c[0]==0x011f?4:2;
            memory(s,B,width,c[4]);memory(s,c[8]==1?B+width:B+8,width,c[5]);var out=at(one(s,c[0]),A+2);
            require(Objects.equals(out.mach(),c[6])&&Objects.equals(out.macl(),c[7]),"MAC saturation/overflow "+Arrays.toString(c)+" "+out);
            require(out.registers().get(1)==B+width*(c[8]==1?2:1),"MAC alias increment");
        }
    }
    static void memoryAndBanks(){
        for(int size=1;size<=4;size*=2){
            AbstractCpu s=initial();s.r[1]=B;int store=0x2114+(size==1?0:size==2?1:2);var out=at(one(s,store),A+2);
            for(int j=0;j<size;j++)require(out.ram().get(B-size+j)==(byte)(B>>>(8*(size-1-j))),"MOV pre alias original source");
            require(out.registers().get(1)==B-size,"MOV pre alias address");
            s=initial();s.r[1]=B;memory(s,B,size,size==1?0x80:size==2?0x8000:0x80000000);
            out=at(one(s,0x6114+(size==1?0:size==2?1:2)),A+2);
            require(out.registers().get(1)==(size==1?-128:size==2?-32768:Integer.MIN_VALUE),"MOV post alias must suppress increment");
        }
        for(int code:new int[]{0x6121,0x6122,0x2121,0x2122}){
            AbstractCpu s=initial();s.r[1]=B+1;s.r[2]=B+1;var g=one(s,code);
            require(g.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),A+2)),"Misalignment must not retire normally");
            require(g.cpuBoundaries().stream().anyMatch(x->Objects.equals(x.vectorOffset(),0x24)&&Objects.equals(x.dataAddress(),B+1)&&x.resumePc()==null),"Address error interface preserves unknown savedPC");
        }
        AbstractCpu s=initial();s.r[1]=null;memory(s,B,4,99);var g=one(s,0x2122);
        require(g.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),A+2)),"Unknown store cannot claim noalias");
        require(g.cpuBoundaries().stream().anyMatch(x->x.kind().equals("UNKNOWN_STORE_DESTINATION")),"Unknown store dependency explicit");
        s=initial();s.bankOverflow=true;s.nextBank=15;for(int j=0;j<19;j++)memory(s,SP+4*j,4,100+j);
        var out=at(one(s,0x005b),A+2);for(int r=0;r<15;r++)require(out.registers().get(r)==100+r,"RESBANK BO stack R"+r);
        require(out.pr()==115&&out.gbr()==116&&out.mach()==117&&out.macl()==118&&out.registers().get(15)==SP+76,"RESBANK stack layout");
        require(Boolean.TRUE.equals(out.bankOverflow())&&out.nextBank()==15,"RESBANK must retain BO/BN");
        s=initial();s.r[1]=B;for(int j=0;j<2048;j++)memory(s,B+j,1,j);g=one(s,0x2122);out=at(g,A+2);
        require(out.ram().size()==2048,"SRAM known bytes cannot disappear at arbitrary cap");
        for(int value:new int[]{0,0x63f3,-1,0x12345678}){s=initial();s.r[1]=value;out=at(one(s,0x410e),A+2);require(out.sr()==(value&0x63f3),"SR writable mask");}
        // Unknown information is never substituted withzero; independently provable stickyflags survive.
        s=initial();s.r[2]=null;s.t=true;out=at(one(s,0x612a),A+2);require(out.registers().get(1)==null&&Boolean.TRUE.equals(out.t()),"NEGC unknown source/proven borrow");
        s=initial();s.r[1]=null;s.cs=true;out=at(one(s,0x4191),A+2);require(Boolean.TRUE.equals(out.cs()),"CLIP stickyCS");
    }
    static void branches(){
        for(int code:new int[]{0x8d06,0x8f06})for(Boolean t:new Boolean[]{false,true,null}){
            AbstractCpu s=initial();s.t=t;byte[] rom=image();word(rom,A,code);word(rom,A+2,0xc704);word(rom,A+4,0x001b);word(rom,A+16,0x001b);
            var g=graph(rom,s);boolean take=t==null||t==(code==0x8d06);
            if(take)require(at(g,A+16).registers().get(0)==((A+18)&~3)+16,"Taken contextual MOVA");
            if(t==null||!take)require(at(g,A+4).registers().get(0)==((A+6)&~3)+16,"Not-taken ordinary MOVA");
        }
        for(int conditional:new int[]{0x8d06,0x8f06})for(int subsequent:new int[]{0x0100,0x002b,0x4194,0xa002}){
            AbstractCpu s=initial();s.t=conditional!=0x8d06;byte[] rom=image();word(rom,A,conditional);word(rom,A+2,subsequent);word(rom,A+4,0x0009);word(rom,A+6,0x001b);
            if(subsequent==0x0100){word(rom,A+4,3);}
            if(subsequent==0x002b){memory(s,SP,4,0x400);memory(s,SP+4,4,0);word(rom,0x400,0x001b);word(rom,A+4,0x0009);}
            if(subsequent==0xa002){word(rom,A+10,0x001b);}
            var g=graph(rom,s);require(g.report().issues().stream().noneMatch(x->x.reason().contains("SLOT_ILLEGAL")),"Not-taken conditional cannot ban following opcode");
        }
        for(int code:new int[]{0xa006,0xb006,0x422b,0x420b,0x0223,0x0203,0x000b,0x002b}){
            AbstractCpu s=initial();s.pr=A+16;s.r[2]=code==0x0223||code==0x0203?12:A+16;
            byte[] rom=image();word(rom,A,code);word(rom,A+2,0x7201);word(rom,A+16,0x001b);memory(s,SP,4,A+16);memory(s,SP+4,4,0);
            var out=at(graph(rom,s),A+16);require(out.registers().get(2)==s.r[2]+1,"Target snapshotted before register-mutating slot");
        }
        for(int code:new int[]{0xa006,0x8d06}){AbstractCpu s=initial();s.t=true;byte[] rom=image();word(rom,A,code);word(rom,A+2,0x001b);word(rom,A+16,0x001b);var g=graph(rom,s);
            require(g.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),A+16)),"SLEEP slot stops branch retirement until wake");
            require(g.cpuBoundaries().stream().anyMatch(x->x.kind().equals("SLEEP_OR_STANDBY_REQUEST")&&Objects.equals(x.resumePc(),A+16)),"SLEEP slot resume boundary");}
        for(int value:new int[]{0,1,-1,B}){AbstractCpu s=initial();s.r[1]=value;var out=at(one(s,0x0183),A+2);require(out.registers().get(1)==value,"PREF is nonfaulting CPU hint");}
        // Explicit synchronous divide exception entry: no ordinarynext, normative stackPC/SR.
        for(boolean signed:new boolean[]{false,true}){AbstractCpu s=initial();s.r[0]=0;byte[] rom=image();word(rom,A,signed?0x4194:0x4184);word(rom,A+2,0x001b);longword(rom,0x44,0x400);word(rom,0x400,0x001b);var g=graph(rom,s);var out=at(g,0x400);
            require(out.registers().get(15)==SP-8,"DIV0 exception stack");require(out.ram().get(SP-5)==(byte)A,"DIV0 stack faultingPC");require(g.cpuStates().stream().noneMatch(x->Objects.equals(x.pc(),A+2)),"DIV0 no ordinaryretirement");}
    }
    static void divisionAndTraps(){
        // SW3.7.5, 6.3.13-14: known divisor excludes impossible exception paths.
        Integer[][] values={{0,7},{0,null},{-1,Integer.MIN_VALUE},{2,null},{-1,null},
                {null,7},{null,Integer.MIN_VALUE},{null,null}};
        for(boolean signed:new boolean[]{false,true})for(Integer[] inputs:values){
            AbstractCpu st=initial();st.r[0]=inputs[0];st.r[1]=inputs[1];
            byte[] r=image();word(r,A,signed?0x4194:0x4184);word(r,A+2,0x001b);
            longword(r,0x44,0x400);longword(r,0x48,0x420);word(r,0x400,0x001b);word(r,0x420,0x001b);
            var g=graph(r,st);
            boolean zero=inputs[0]==null||inputs[0]==0;
            boolean overflow=signed&&(inputs[0]==null||inputs[0]==-1)
                    &&(inputs[1]==null||inputs[1]==Integer.MIN_VALUE);
            boolean normal=!Integer.valueOf(0).equals(inputs[0])
                    &&!(signed&&Integer.valueOf(-1).equals(inputs[0])&&Integer.valueOf(Integer.MIN_VALUE).equals(inputs[1]));
            require(g.report().instructions().containsKey(0x400)==zero,"DIV0 possible iff divisor may be zero");
            require(g.report().instructions().containsKey(0x420)==overflow,"DIV overflow possible iff MIN/-1");
            require(g.cpuStates().stream().anyMatch(x->x.pc()==A+2)==normal,"DIV normal completion conditions");
        }
        AbstractCpu st=initial();st.r[0]=null;
        byte[] r=image();word(r,A,0x4094);word(r,A+2,0x001b);longword(r,0x44,0x400);longword(r,0x48,0x420);
        word(r,0x400,0x001b);word(r,0x420,0x001b);var g=graph(r,st);
        require(!g.report().instructions().containsKey(0x420),"DIVS R0,R0 cannot overflow");
        st=initial();st.vbr=B;memory(st,B+0x80,4,0x400);r=image();word(r,A,0xc320);word(r,0x400,0x001b);
        var out=at(graph(r,st),0x400);require(out.registers().get(15)==SP-8,"TRAPA SRAM table stack");
        require(out.ram().get(SP-5)==(byte)(A+2),"TRAPA saved PC after instruction");
        st=initial();st.vbr=B+1;memory(st,B+0x81,4,0x400);
        require(!graph(r,st).report().instructions().containsKey(0x400),"TRAPA misaligned VBR blocked");
    }
    static void executableRam(){
        // Hardware5.1/5.4 SRAM; same encoding decoder, architectural PC retained.
        AbstractCpu st=initial();st.r[1]=B;byte[] r=image();word(r,A,0x412b);word(r,A+2,0xe207);
        memory(st,B,2,0x0300);memory(st,B+2,2,0x1234); // MOVI20 #0x1234,R3
        memory(st,B+4,2,0xc704); // MOVA @(16,PC),R0 = (B+8)+16
        memory(st,B+6,2,0x001b);
        var g=graph(r,st);var out=at(g,B+6);
        require(out.registers().get(2)==7&&out.registers().get(3)==0x1234,"SRAM 32bit execution after delay slot");
        require(out.registers().get(0)==B+24,"SRAM PC-relative address");
        st=initial();st.r[1]=B;memory(st,B,2,0xa006);memory(st,B+2,2,0xe309);memory(st,B+16,2,0x001b);
        out=at(graph(r,st),B+16);require(out.registers().get(3)==9,"SRAM branch and slot");
        st=initial();st.r[1]=B;memory(st,B,2,0x0300);g=graph(r,st);
        require(!g.report().instructions().containsKey(B+4),"Missing SRAM continuation cannot become zeros");
        require(g.report().issues().stream().anyMatch(x->x.reason().contains("TRUNCATED_32BIT")),"SRAM truncated diagnostic");
        st=initial();st.r[0]=0;memory(st,B,2,0xe309);memory(st,B+2,2,0x001b);
        r=image();word(r,A,0x4194);longword(r,0x44,B);out=at(graph(r,st),B+2);
        require(out.registers().get(3)==9&&out.registers().get(15)==SP-8,"Division handler in SRAM");
        for(int destination:new int[]{0x1000,0x80100000,0x40000000}){
            st=initial();st.r[1]=destination;g=one(st,0x2122);
            require(g.cpuStates().stream().noneMatch(x->x.pc()==A+2),"Unmodeled write cannot retire");
            require(g.cpuBoundaries().stream().anyMatch(x->x.kind().equals("UNMODELED_MEMORY_WRITE")),"Unmodeled write boundary");
        }
    }
    static void transferAliases(){
        // SW6.4.31, SW6.3.17: source snapshot and update ordering, every GPR incl R0/SP.
        for(int reg=0;reg<16;reg++)for(int size:new int[]{1,2,4}){
            int mode=size==1?0:size==2?1:2;
            AbstractCpu st=initial();st.r[reg]=B;
            var out=at(one(st,0x2004|(reg<<8)|(reg<<4)|mode),A+2);
            for(int j=0;j<size;j++)require(out.ram().get(B-size+j)==(byte)(B>>>(8*(size-1-j))),"pre-store source alias R"+reg);
            require(out.registers().get(reg)==B-size,"pre-store pointer alias R"+reg);
            st=initial();st.r[reg]=B;memory(st,B,size,0x80ff1234);
            out=at(one(st,0x6004|(reg<<8)|(reg<<4)|mode),A+2);
            int expected=size==1?0x34:size==2?0x1234:0x80ff1234;
            require(out.registers().get(reg)==expected,"post-load alias suppresses increment R"+reg);
            st=initial();st.r[reg]=B+size;memory(st,B,size,0x80ff1234);
            out=at(one(st,0x40cb|(reg<<8)|(mode<<4)),A+2);
            require(out.registers().get(0)==expected,"reverse pre-load R"+reg);
            if(reg!=0)require(out.registers().get(reg)==B,"reverse pre-load pointer R"+reg);
            st=initial();st.r[reg]=B;int source=st.r[0];
            out=at(one(st,0x408b|(reg<<8)|(mode<<4)),A+2);
            for(int j=0;j<size;j++)require(out.ram().get(B+j)==(byte)(source>>>(8*(size-1-j))),"reverse store source R"+reg);
            require(out.registers().get(reg)==B+size,"reverse store increment R"+reg);
        }
        AbstractCpu st=initial();st.r[1]=B;st.r[2]=0xe309001b;
        byte[] r=image();word(r,A,0x2122);word(r,A+2,0x412b);word(r,A+4,0x0009);
        var out=at(graph(r,st),B+2);
        require(out.registers().get(3)==9,"guest store then SRAM instruction fetch");
    }
    static void bankBoundaries(){
        AbstractCpu st=initial();byte[] r=image();word(r,A,0x005b);word(r,A+2,0x001b);
        longword(r,0x40,0x400);word(r,0x400,0x001b);var g=graph(r,st);
        require(at(g,0x400).registers().get(15)==SP-8,"BN0 underflow exception entry");
        require(g.cpuStates().stream().noneMatch(x->x.pc()==A+2),"BN0 cannot restore normally");
        st=initial();st.nextBank=null;g=graph(r,st);
        require(g.cpuStates().stream().noneMatch(x->x.pc()==A+2),"Unknown BN cannot guess bank");
        require(g.report().issues().stream().anyMatch(x->x.reason().contains("RESBANK_BANK_NUMBER_UNKNOWN")),"Unknown BN explicit diagnostic");
        for(int code:new int[]{0x41e5,0x41e1})for(Integer address:new Integer[]{null,1,80,0x780,0x10000,-1}){
            st=initial();st.r[1]=address;g=one(st,code);
            require(g.cpuStates().stream().noneMatch(x->x.pc()==A+2),"Invalid bank address cannot fabricate retirement");
            require(g.report().issues().stream().anyMatch(x->x.reason().contains("INVALID_OR_UNKNOWN_BANK_ADDRESS")),"Invalid bank diagnostic");
        }
    }
    public static void main(String[] args)throws Exception{
        arithmetic();mac();memoryAndBanks();branches();divisionAndTraps();executableRam();bankBoundaries();transferAliases();
        Files.writeString(Path.of("build/cpu-boundary-count.txt"),"mathCases="+math.size()+" assertions="+checks+"\n");
        System.out.println("CPU_BOUNDARY_ACCEPTANCE: PASS mathCases="+math.size()+" assertions="+checks);
    }
}
