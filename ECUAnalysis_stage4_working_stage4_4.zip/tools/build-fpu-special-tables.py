#!/usr/bin/env python3
"""Literal special-case tables, REJ09B0051-0300 §§6.5.2/3/6/13/18.
Rows FRn, columns FRm: +2,-2,+0,-0,+inf,-inf,qNaN,sNaN.
V => invalid canonical qNaN; DZ sign => divide-by-zero infinity.
Subnormal rows/columns are aliases of signed zero (DN fixed 1).
"""
from pathlib import Path
add=['4 0 2 2 I i Q V','0 -4 -2 -2 I i Q V','2 -2 0 0 I i Q V','2 -2 0 z I i Q V','I I I I I V Q V','i i i i V i Q V','Q Q Q Q Q Q Q V','V V V V V V V V']
mul=['4 -4 0 z I i Q V','-4 4 z 0 i I Q V','0 z 0 z V V Q V','z 0 z 0 V V Q V','I i V V I i Q V','i I V V i I Q V','Q Q Q Q Q Q Q V','V V V V V V V V']
div=['1 -1 Z+ Z- 0 z Q V','-1 1 Z- Z+ z 0 Q V','0 z V V 0 z Q V','z 0 V V z 0 Q V','I i I i V V Q V','i I i I V V Q V','Q Q Q Q Q Q Q V','V V V V V V V V']
keys=['P','N','0','z','I','i','Q','S','D','d','q','s']
category=[0,1,2,3,4,5,6,7,2,3,6,7]
rows=[]
for dbl in (0,1):
    sign=1<<(63 if dbl else 31)
    bits={'P':0x4000000000000000 if dbl else 0x40000000,'N':0xc000000000000000 if dbl else 0xc0000000,'0':0,'z':sign,
          'I':0x7ff0000000000000 if dbl else 0x7f800000,'i':0xfff0000000000000 if dbl else 0xff800000,
          'Q':0x7ff0000000000001 if dbl else 0x7f800001,'S':0x7ff8000000000001 if dbl else 0x7fc00001,'D':1,'d':sign|1}
    bits['q']=bits['Q']|sign;bits['s']=bits['S']|sign
    out={'4':0x4010000000000000 if dbl else 0x40800000,'2':bits['P'],'1':0x3ff0000000000000 if dbl else 0x3f800000,'0':0,'z':sign,'I':bits['I'],'i':bits['i'],'Q':0x7ff7ffffffffffff if dbl else 0x7fbfffff}
    for token in ('4','2','1'):out['-'+token]=out[token]|sign
    for opcode in (0,1,2,3,4,5):
        for ni,keyA in enumerate(keys):
            for mi,keyB in enumerate(keys):
                n,m=category[ni],category[mi];flags=0;t=0
                if opcode<4:
                    table=add if opcode<2 else mul if opcode==2 else div
                    mapped=m^1 if opcode==1 and m<6 else m
                    token=table[n].split()[mapped]
                    if token=='V':flags=0x10040;token='Q'
                    if token.startswith('Z'):flags=0x8020;token='I' if token=='Z+' else 'i'
                    expected=out[token]
                else:
                    expected=bits[keyA] # comparison does not write FR
                    if n==7 or m==7 or opcode==5 and (n==6 or m==6):flags=0x10040
                    elif n<6 and m<6:
                        rank=[2,-2,0,0,100,-100]
                        t=int(rank[n]==rank[m] if opcode==4 else rank[n]>rank[m])
                normaltrap=0x380 if opcode<4 and n<2 and m<2 else 0
                source_special=int(n in (4,5,6,7) or m in (4,5,6,7))
                rows.append((opcode,dbl,bits[keyA],bits[keyB],expected,flags,t,normaltrap,source_special))
p=Path(__file__).parent/'fixtures/fpu-special-tables.tsv'
p.write_text(''.join('\t'.join(format(v,'x') for v in row)+'\n' for row in rows))
print(f'Wrote {len(rows)} manual-table vectors')
# FMAC: corrected Rev.4 §6.5.11 pp.6-205..208 (revision list physical p.6).
# Twelve categories for each of three independent sources, including +/-subnormals
# and both signs of q/sNaN. All finite arithmetic here is exact small integer math.
bits={'P':0x40000000,'N':0xc0000000,'0':0,'z':0x80000000,'I':0x7f800000,'i':0xff800000,'Q':0x7f800001,'S':0x7fc00001,'D':1,'d':0x80000001,'q':0xff800001,'s':0xffc00001}
outputs={0:0,2:0x40000000,4:0x40800000,6:0x40c00000,-2:0xc0000000,-4:0xc0800000,-6:0xc0c00000}
rows=[]
for na,ka in enumerate(keys):
 for nb,kb in enumerate(keys):
  for nc,kc in enumerate(keys):
   a,b,c=category[na],category[nb],category[nc]
   sa,sb,sc=(bits[k]>>31 for k in (ka,kb,kc));ps=sb^sc
   flags=0;mask=0
   if 7 in (a,b,c):flags=0x10040;expected=0x7fbfffff
   elif b==6 or c==6:expected=0x7fbfffff
   elif (b in (4,5) and c in (2,3)) or (c in (4,5) and b in (2,3)):flags=0x10040;expected=0x7fbfffff
   elif a==6:expected=0x7fbfffff
   elif b in (4,5) or c in (4,5):
    if a in (4,5) and sa!=ps:flags=0x10040;expected=0x7fbfffff
    else:expected=0x7f800000|(ps<<31)
   elif a in (4,5):expected=bits[ka]
   elif b in (2,3) or c in (2,3):
    expected=((ps & sa)<<31) if a in (2,3) else bits[ka]
   else:
    values=[2,-2,0,0]
    exact=values[b]*values[c]+values[a]
    expected=outputs[exact];mask=0x380
   source_special=int(a>=4 or b>=4 or c>=4)
   rows.append((bits[ka],bits[kb],bits[kc],expected,flags,mask,source_special))
p=Path(__file__).parent/'fixtures/fpu-fmac-special.tsv'
p.write_text(''.join('\t'.join(format(v,'x') for v in row)+'\n' for row in rows))
print(f'Wrote {len(rows)} corrected FMAC manual vectors')
