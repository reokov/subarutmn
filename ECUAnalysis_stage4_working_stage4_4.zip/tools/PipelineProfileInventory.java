package ecu.independent;
import java.nio.file.*;
import java.util.*;
/** Inventory, NOT a timing oracle or functional coverage denominator. */
public final class PipelineProfileInventory {
    public static void main(String[] args)throws Exception {
        List<String> rows=new ArrayList<>();rows.add("id\tform\tmode\toperation\timplementation\tcpu_offset\tresult_offset\tlatency\tresources");int present=0,missing=0;
        for(String line:Files.readAllLines(Path.of("tools/fixtures/renesas-isa.tsv")).subList(1,254)) {
            String[] c=line.split("\t");byte[] b=new byte[8];for(int j=0;j<c[2].length();j++)if(c[2].charAt(j)=='1')b[j/8]|=(byte)(1<<(7-j%8));
            int mode=c[3].equals("PR1")?0xc0000:c[3].equals("SZ1")?0x140000:0x40000;
            var i=new Sh2aDecoder().decode(b,0,new Sh2aDecoder.DecodeContext(mode,false,null,false));var p=SystemExceptionModel.pipelineSpec(i,mode);
            if(p==null)missing++;else present++;
            rows.add(String.join("\t",c[0],c[1],c[3],i.operation().name(),p==null?"NOT_IMPLEMENTED":"PROFILE_PRESENT_NOT_FULL_ACCEPTANCE",p==null?"":Integer.toString(p.cpuOffset()),p==null?"":Integer.toString(p.resultOffset()),p==null?"":Integer.toString(p.latency()),p==null?"":p.resources().toString()));
        }
        Path out=Path.of(args.length==0?"build/stage4_4/profile-inventory.tsv":args[0]);Files.createDirectories(out.toAbsolutePath().getParent());Files.write(out,rows);
        System.out.println("PIPELINE_PROFILE_INVENTORY: rows=253 present="+present+" notImplemented="+missing+"; inventory only");
    }
}
