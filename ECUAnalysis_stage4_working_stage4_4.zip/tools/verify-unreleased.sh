#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
BUILD="$ROOT/.verify-classes"
mkdir -p "$BUILD"
javac -Xlint:all -d "$BUILD" "$ROOT"/src/main/java/ecu/independent/*.java "$ROOT"/tools/*.java
for test in SemanticsAcceptance InstructionLengthAcceptance FmovDisplacementAcceptance DecodeSweep PeripheralFailClosedAcceptance; do
  java -cp "$BUILD" "$test"
done
java -cp "$BUILD" ecu.independent.FpuClassificationAcceptance
java -cp "$BUILD" ecu.independent.SoftwareInterruptBoundaryAcceptance
# A blocked release is the expected and only accepted result at this stage.
set +e
java -cp "$BUILD" FullCoverageReleaseGate
status=$?
set -e
if [ "$status" -ne 2 ]; then
  echo 'ERROR: release gate did not block an incomplete implementation'
  exit 1
fi
echo 'VERIFICATION_COMPLETED; RELEASE_BLOCKED'
