#!/usr/bin/env python3
"""Independent exact Fraction oracle. Binary search representable positive numbers;
round by comparing the exact value with the adjacent midpoint (squared for sqrt).
No Java code or FpuBinary implementation is read. DN1 only, fixed by SH-2A.
"""
from fractions import Fraction as F
import random
from pathlib import Path
rng=random.Random(72543)
def value(b,d):
    f,bias=(52,1023) if d else (23,127)
    e=b>>f; mant=(b&((1<<f)-1))+(1<<f if e else 0)
    shift=(e or 1)-bias-f
    return F(mant*(1<<max(shift,0)),1<<max(-shift,0))
def oracle(x,d,rm,sqrt=False):
    sign=0
    if x<0: sign=1<<(63 if d else 31); x=-x
    inf=0x7ff0000000000000 if d else 0x7f800000
    f=52 if d else 23
    lo,hi=0,inf
    while lo+1<hi:
        mid=(lo+hi)//2; y=value(mid,d)
        if (y*y if sqrt else y)<=x: lo=mid
        else: hi=mid
    y=value(lo,d); exact=(y*y==x if sqrt else y==x)
    # Virtual successor of MAX is 2**(emax+1), giving overflow midpoint.
    upper=value(hi,d) if hi<inf else F(1<<(1024 if d else 128))
    middle=(y+upper)/2
    above=x>(middle*middle if sqrt else middle)
    tie=x==(middle*middle if sqrt else middle)
    bits=hi if rm==0 and (above or tie and lo%2) else lo
    overflow=(bits==inf) or (rm==1 and x>=upper and hi==inf)
    flags=0 if exact else 0x1004
    if overflow: flags|=0x5014;bits=inf if rm==0 else inf-1
    if bits<(1<<f):
        if bits or not exact: flags|=0x300c
        bits=0
    return sign|bits,flags
rows=[]
for d in (False,True):
    f,bias=(52,1023) if d else (23,127)
    sign=1<<(63 if d else 31)
    inf=0x7ff0000000000000 if d else 0x7f800000
    vals=[1<<f,(1<<f)+1,inf-1,(bias<<f),(bias<<f)+1,((bias+1)<<f)-1,((bias-1)<<f)]
    vals += [rng.randrange(1<<f,inf) for _ in range(130)]
    for idx,a in enumerate(vals):
        b=vals[(idx*37+5)%len(vals)]
        for sa,sb in ((0,0),(sign,0),(0,sign),(sign,sign)):
            x=value(a,d)*(-1 if sa else 1); y=value(b,d)*(-1 if sb else 1)
            for op,z in ((0,x+y),(1,x-y),(2,x*y),(3,x/y)):
                for rm in (0,1):
                    bits,flags=oracle(z,d,rm)
                    rows.append((op,int(d),rm,a|sa,b|sb,bits,flags))
        for rm in (0,1):
            bits,flags=oracle(value(a,d),d,rm,True)
            rows.append((0x6d,int(d),rm,a,0,bits,flags))
# conversion and fused product vectors, without intermediate binary rounding
for _ in range(800):
    a=rng.randrange(0x10000000000000,0x7ff0000000000000)
    if rng.randrange(2):a|=1<<63
    for rm in (0,1):
        x=value(a&0x7fffffffffffffff,True)*(-1 if a>>63 else 1)
        bits,flags=oracle(x,False,rm)
        rows.append((0xbd,1,rm,a,0,bits,flags))
# FLOAT exact int32 -> binary32/64; FCNVSD exact widening; fused alias FR0=destination.
for d in (False,True):
    for integer in [0,1,-1,2147483647,-2147483648,16777217,-16777217]+[rng.randrange(-2**31,2**31) for _ in range(100)]:
        for rm in (0,1):
            bits,flags=oracle(F(integer),d,rm)
            rows.append((0x2d,int(d),rm,integer&0xffffffff,0,bits,flags))
for _ in range(400):
    a=rng.randrange(0x800000,0x7f800000);b=rng.randrange(0x800000,0x7f800000)
    if rng.randrange(2):a|=1<<31
    if rng.randrange(2):b|=1<<31
    x=value(a&0x7fffffff,False)*(-1 if a>>31 else 1)
    y=value(b&0x7fffffff,False)*(-1 if b>>31 else 1)
    for rm in (0,1):
        bits,flags=oracle(x,True,rm)
        rows.append((0xad,1,rm,a,0,bits,flags))
        bits,flags=oracle(x*y+x,False,rm)
        rows.append((0x2e,0,rm,a,b,bits,flags))
out=Path(__file__).parent/'fixtures/fpu-exact.tsv'
out.write_text(''.join('\t'.join(format(x,'x') for x in row)+'\n' for row in rows))
print(f'Wrote {len(rows)} exact independently generated vectors to {out}')
