import ecu.independent.Sh2aDecoder;
import static ecu.independent.Sh2aDecoder.*;
import java.nio.file.*;
import java.util.*;

/** Oracle: independently cross-checked primary Renesas bitstrings, never decoder masks. */
public final class NormativeDecoderAcceptance {
    record Form(String id,String format,String bits,String mode) {
        int length() { return bits.length()/8; }
        boolean mode(int fpscr) {
            return switch(mode) {
                case "PR0" -> (fpscr&0x80000)==0; case "PR1" -> (fpscr&0x80000)!=0;
                case "SZ0" -> (fpscr&0x100000)==0; case "SZ1" -> (fpscr&0x100000)!=0;
                default -> true;
            };
        }
        boolean matches(int first,int second,boolean prefixOnly) {
            int limit=prefixOnly?16:bits.length();
            for(int j=0;j<limit;j++) {
                char c=bits.charAt(j);
                if(c!='0' && c!='1') continue;
                int word=j<16?first:second, shift=15-j%16;
                if(((word>>>shift)&1)!=c-'0') return false;
            }
            return true;
        }
        int field(char c,int first,int second) {
            int result=0;
            for(int j=0;j<bits.length();j++) if(bits.charAt(j)==c)
                result=(result<<1)|(((j<16?first:second)>>>(15-j%16))&1);
            // Three-bit DR register field encodes the even FR pair base.
            if((c=='n'||c=='m') && bits.chars().filter(v->v==c).count()==3) result*=2;
            return result;
        }
        String name() { return format.split(" ")[0]; }
    }
    static final Sh2aDecoder DECODER=new Sh2aDecoder();
    static final byte[] IMAGE=new byte[12];
    static List<Form> forms;
    static long checks;
    static final Set<String> covered=new HashSet<>();
    static void require(boolean ok,String reason) { if(!ok) throw new AssertionError(reason); }
    static int sx(int x,int bits) { int sign=1<<(bits-1); return (x^sign)-sign; }
    static Instruction decode(int w,int second,int fpscr,boolean slot,Integer destination) {
        IMAGE[4]=(byte)(w>>>8); IMAGE[5]=(byte)w;
        IMAGE[6]=(byte)(second>>>8); IMAGE[7]=(byte)second;
        return DECODER.decode(IMAGE,4,new DecodeContext(fpscr,slot,destination,false));
    }
    static Operation operation(Form f) {
        String s=f.format, name=f.name();
        if(name.equals("PREF")) return Operation.OPAQUE;
        if(name.equals("MOV")) {
            if(s.contains("#")) return Operation.MOV_IMM;
            return Operation.MOV_REG;
        }
        if(name.startsWith("MOV.") || name.startsWith("MOVU.")) {
            if(s.contains("PC")) return Operation.MOV_PC;
            if(s.contains("GBR")) return s.contains(", R0")?Operation.MOV_GBR_LOAD:Operation.MOV_GBR_STORE;
            if(s.contains("@(R0")) return s.contains("Rm, @")?Operation.MOV_INDEX_STORE:Operation.MOV_INDEX_LOAD;
            if(s.contains("@-Rm")) return Operation.MOV_REV_LOAD;
            if(s.contains("@Rn+")) return Operation.MOV_REV_STORE;
            if(name.startsWith("MOVU")) return Operation.MOV_UNSIGNED_LOAD;
            if(s.contains("disp12")) return s.indexOf('@')<s.indexOf(',')?Operation.MOV_DISP12_LOAD:Operation.MOV_DISP12_STORE;
            return s.indexOf('@')<s.indexOf(',')?Operation.MOV_LOAD:Operation.MOV_STORE;
        }
        if(name.startsWith("MOVML")) return s.contains("@-R15")?Operation.MOVML_PUSH:Operation.MOVML_POP;
        if(name.startsWith("MOVMU")) return s.contains("@-R15")?Operation.MOVMU_PUSH:Operation.MOVMU_POP;
        if(name.startsWith("F")) return switch(name) {
            case "FADD","FSUB","FMUL","FDIV" -> Operation.FPU_ARITHMETIC;
            case "FCMP/EQ","FCMP/GT" -> Operation.FPU_COMPARE;
            case "FCNVDS","FCNVSD","FLOAT","FTRC" -> Operation.FPU_CONVERT;
            case "FABS","FNEG" -> Operation.FPU_SIGN;
            case "FLDI0","FLDI1" -> Operation.FPU_IMMEDIATE;
            case "FSQRT" -> Operation.FPU_SQRT;
            case "FSCHG" -> Operation.FPU_MODE;
            case "FMAC" -> Operation.FPU_FMAC;
            case "FLDS","FSTS" -> Operation.FPU_REG_MOVE;
            default -> !s.contains("@")?Operation.FPU_REG_MOVE:
                s.indexOf('@')<s.indexOf(',')?Operation.FPU_MEM_LOAD:Operation.FPU_MEM_STORE;
        };
        if(name.startsWith("B") && !name.equals("BRA") && !name.equals("BRAF") &&
                !name.equals("BSR") && !name.equals("BSRF") && !name.equals("BT") &&
                !name.equals("BF") && !name.equals("BT/S") && !name.equals("BF/S"))
            return name.endsWith(".B")?Operation.BIT_MEMORY:Operation.BIT_REG;
        if(name.startsWith("LDC")||name.startsWith("STC")) return Operation.SYS_REG_TRANSFER;
        if(name.startsWith("LDS")||name.startsWith("STS")) {
            if(s.contains("FPUL")||s.contains("FPSCR")) return Operation.FPU_REGISTER_TRANSFER;
            if(s.contains("PR")) return switch(name) {
                case "LDS" -> Operation.LDS_PR; case "STS" -> Operation.STS_PR;
                case "LDS.L" -> Operation.LDS_L_PR; default -> Operation.STS_L_PR;
            };
            return Operation.MAC_REGISTER_TRANSFER;
        }
        return switch(name) {
            case "ADD" -> s.contains("#")?Operation.ADD_IMM:Operation.ADD_REG;
            case "ADDC" -> Operation.ADDC_REG; case "ADDV" -> Operation.ADDV_REG;
            case "SUB" -> Operation.SUB_REG; case "SUBC" -> Operation.SUBC_REG; case "SUBV" -> Operation.SUBV_REG;
            case "AND" -> s.contains("#")?Operation.AND_IMM:Operation.AND_REG;
            case "OR" -> s.contains("#")?Operation.OR_IMM:Operation.OR_REG;
            case "XOR" -> s.contains("#")?Operation.XOR_IMM:Operation.XOR_REG;
            case "TST" -> s.contains("#")?Operation.TST_IMM:Operation.TST_REG;
            case "AND.B","OR.B","XOR.B","TST.B" -> Operation.GBR_BYTE_LOGIC;
            case "CMP/EQ" -> s.contains("#")?Operation.CMP_EQ_IMM:Operation.CMP_EQ_REG;
            case "CMP/HS" -> Operation.CMP_HS; case "CMP/HI" -> Operation.CMP_HI;
            case "CMP/GE" -> Operation.CMP_GE; case "CMP/GT" -> Operation.CMP_GT;
            case "CMP/PZ" -> Operation.CMP_PZ; case "CMP/PL" -> Operation.CMP_PL; case "CMP/STR" -> Operation.CMP_STR;
            case "NOT" -> Operation.NOT_REG; case "NEG" -> Operation.NEG_REG; case "NEGC" -> Operation.NEGC_REG;
            case "MOVRT" -> Operation.MOVT_INV; case "DT" -> Operation.DT_REG;
            case "MUL.L" -> Operation.MUL_L; case "MULS.W" -> Operation.MULS_W; case "MULU.W" -> Operation.MULU_W;
            case "DMULS.L" -> Operation.DMULS_L; case "DMULU.L" -> Operation.DMULU_L;
            case "MAC.L" -> Operation.MAC_L; case "MAC.W" -> Operation.MAC_W;
            case "TAS.B" -> Operation.TAS_B; case "SWAP.B" -> Operation.SWAP_B; case "SWAP.W" -> Operation.SWAP_W;
            case "EXTS.B" -> Operation.EXTS_B; case "EXTS.W" -> Operation.EXTS_W;
            case "EXTU.B" -> Operation.EXTU_B; case "EXTU.W" -> Operation.EXTU_W;
            case "RTS","RTS/N" -> Operation.RETURN; case "RTV/N" -> Operation.RTV_N;
            case "JSR/N" -> s.contains("TBR")?Operation.TBR_CALL:Operation.BRANCH;
            case "BRA","BRAF","BSR","BSRF","JMP","JSR","BT","BF","BT/S","BF/S" -> Operation.BRANCH;
            default -> Operation.valueOf(name.replace('.','_'));
        };
    }
    static void fields(Form f,Instruction i,int first,int second,int fpscr) {
        String s=f.format.replace("@( R0","@(R0"),name=f.name(),tag=f.id+" "+s+" "+Integer.toHexString(first)+":"+Integer.toHexString(second);
        Operation op=operation(f);
        require(i.operation()==op,tag+" operation="+i.operation()+" expected="+op);
        if(!name.startsWith("MOV") && op!=Operation.GBR_BYTE_LOGIC)
            require(i.mnemonic().equals(name)||i.mnemonic().startsWith(name+" "),tag+" mnemonic="+i.mnemonic());
        if(op==Operation.GBR_BYTE_LOGIC)
            require(i.regM()==switch(name){case "TST.B"->0;case "AND.B"->1;case "XOR.B"->2;default->3;},tag+" GBR action");
        if(op==Operation.BIT_REG)
            require(i.regM()==switch(name){case "BCLR"->0;case "BSET"->1;case "BST"->2;default->3;},tag+" register bit action");
        if(op==Operation.BIT_MEMORY)
            require(i.regM()==switch(name){case "BCLR.B"->0;case "BSET.B"->1;case "BST.B"->2;
                case "BLD.B"->3;case "BAND.B"->4;case "BOR.B"->5;case "BXOR.B"->6;
                case "BLDNOT.B"->11;case "BANDNOT.B"->12;default->13;},tag+" memory bit action");
        if(op==Operation.SYS_REG_TRANSFER) {
            int expected;
            if(name.equals("STC")) expected=s.contains("SR")?8:s.contains("GBR")?1:s.contains("VBR")?2:3;
            else if(name.equals("LDC")) expected=s.contains("SR")?9:s.contains("GBR")?5:s.contains("VBR")?6:7;
            else if(name.equals("LDC.L")) expected=s.contains("SR")?10:s.contains("GBR")?11:12;
            else expected=s.contains("SR")?13:s.contains("GBR")?14:15;
            require(i.regM()==expected,tag+" system transfer selector");
        }
        if(op==Operation.MAC_REGISTER_TRANSFER) {
            int expected=(name.equals("STS")?0:name.equals("LDS")?2:name.equals("STS.L")?4:6)+(s.contains("MACL")?1:0);
            require(i.regM()==expected,tag+" MAC transfer selector");
        }
        if(op==Operation.FPU_REGISTER_TRANSFER) {
            int expected=(name.equals("STS")?0:name.equals("LDS")?2:name.equals("STS.L")?4:6)+(s.contains("FPUL")?1:0);
            require(i.regM()==expected,tag+" FPU transfer selector");
        }

        require(i.width()==f.length(),tag+" length");
        require(i.encoding()==(f.length()==4?(first<<16)|second:first),tag+" packed encoding");
        boolean hasN=f.bits.indexOf('n')>=0, hasM=f.bits.indexOf('m')>=0;
        int n=f.field('n',first,second),m=f.field('m',first,second);
        if(hasN) require(i.regN()==n,tag+" regN="+i.regN()+" expected="+n);
        if(hasM) {
            if(hasN || op==Operation.MOV_REV_LOAD || (op==Operation.MOV_LOAD && s.contains(", R0")))
                require(i.regM()==m,tag+" regM="+i.regM()+" expected="+m);
            else require(i.regN()==m,tag+" source in legacy regN="+i.regN()+" expected="+m);
        }
        Flow flow=Flow.NEXT;
        if(name.equals("BRA")) flow=Flow.BRANCH;
        if(name.equals("BRAF")||name.equals("JMP")) flow=Flow.INDIRECT;
        if(name.startsWith("BSR")||name.startsWith("JSR")) flow=Flow.CALL;
        if(Set.of("BT","BF","BT/S","BF/S").contains(name)) flow=Flow.CONDITIONAL;
        if(name.startsWith("RT")) flow=Flow.RETURN;
        if(name.equals("SLEEP")) flow=Flow.STOP;
        if(name.equals("TRAPA")) flow=Flow.EXCEPTION;
        require(i.flow()==flow,tag+" flow="+i.flow()+" expected="+flow);
        boolean delayed=Set.of("BRA","BRAF","BSR","BSRF","JMP","JSR","RTS","RTE","BT/S","BF/S").contains(name);
        require(i.delaySlot()==delayed,tag+" delay flag");
        int disp=f.field('d',first,second);
        Integer target=null;
        if(Set.of("BRA","BSR","BT","BF","BT/S","BF/S").contains(name))
            target=8+sx(disp,name.equals("BRA")||name.equals("BSR")?12:8)*2;
        require(Objects.equals(i.target(),target),tag+" target");
        int immediate=f.field('i',first,second);
        if(name.equals("MOVI20")||name.equals("MOVI20S")) immediate=sx(immediate,20)*(name.equals("MOVI20S")?256:1);
        else if(op==Operation.MOV_IMM||op==Operation.ADD_IMM||op==Operation.CMP_EQ_IMM) immediate=sx(immediate,8);
        else if(op==Operation.BIT_MEMORY) immediate=(immediate<<12)|disp;
        else if(op==Operation.MOVA) immediate=8+disp*4;
        else if(op==Operation.BRANCH) immediate=Set.of("BT","BT/S","BRAF","BSRF").contains(name)?1:0;
        else if(op==Operation.TBR_CALL) immediate=disp*4;
        else if(f.bits.indexOf('d')>=0 && op!=Operation.MOV_PC) {
            int scale=name.endsWith(".W")?2:name.endsWith(".L")?4:1;
            if(name.startsWith("FMOV")) scale=(fpscr&0x100000)!=0?8:4;
            immediate=disp*scale;
        } else if((op==Operation.FPU_MEM_LOAD||op==Operation.FPU_MEM_STORE)&&s.contains("@(R0")) immediate=-1;
        require(i.imm()==immediate,tag+" imm="+i.imm()+" expected="+immediate);
        Integer reference=null;
        if(op==Operation.MOV_PC) reference=8+disp*(name.equals("MOV.W")?2:4);
        if(op==Operation.MOVA) reference=8+disp*4;
        require(Objects.equals(i.referenceAddress(),reference),tag+" reference");
        boolean post=s.contains("@Rm+")||s.contains("@Rn+")||s.contains("@R15+");
        boolean pre=s.contains("@-Rn")||s.contains("@- Rn")||s.contains("@-Rm")||s.contains("@-R15");
        require(i.postIncrement()==post,tag+" postIncrement");
        require(i.preDecrement()==pre,tag+" preDecrement");
        int bytes=0;
        if(s.contains("@") && !Set.of("PREF","JMP","JSR","JSR/N").contains(name)) {
            bytes=name.endsWith(".B")?1:name.endsWith(".W")?2:4;
        }
        if(op==Operation.FPU_REGISTER_TRANSFER||op==Operation.SYS_REG_TRANSFER) bytes=4;
        if(name.startsWith("FMOV")) bytes=(fpscr&0x100000)!=0?8:4;
        else if(f.mode.startsWith("PR")) bytes=f.mode.equals("PR1")?8:4;
        if(name.equals("FSTS")||name.equals("FLDS")) bytes=4;
        if(name.equals("FSCHG")) bytes=0;
        if(op==Operation.MOVA || op==Operation.TBR_CALL) bytes=4;
        if(op==Operation.MOVI20||op==Operation.MOVI20S) bytes=4;
        // Reverse loads and MAC flags describe the address direction of their memory operands.
        if(op==Operation.MOV_REV_LOAD) { post=false; pre=true; }
        require(i.operandWidth()==bytes,tag+" operandWidth="+i.operandWidth()+" expected="+bytes);
    }
    static void check(int first,int second,int fpscr,List<Form> candidates) {
        Form matched=null;
        for(Form f:candidates) if(f.mode(fpscr)&&f.matches(first,second,false)) {
            require(matched==null,"Conflicting normative forms "+matched+" and "+f);
            matched=f;
        }
        Instruction i=decode(first,second,fpscr,false,null);checks++;
        if(matched==null) {
            require(i.status()==Status.ILLEGAL_ENCODING,"Undefined accepted "+Integer.toHexString(first)+":"+Integer.toHexString(second)+" "+i);
            return;
        }
        require(i.status()==Status.VALID,matched+" status="+i.status());
        covered.add(matched.id); fields(matched,i,first,second,fpscr);
    }
    static int materialize(Form f,Map<Character,Integer> values) {
        int word=0; Map<Character,Integer> positions=new HashMap<>();
        for(int j=f.bits.length()-1;j>=0;j--) {
            char c=f.bits.charAt(j); int bit;
            if(c=='0'||c=='1') bit=c-'0';
            else { int shift=positions.getOrDefault(c,0);bit=(values.getOrDefault(c,0)>>>shift)&1;positions.put(c,shift+1); }
            word|=bit<<(f.bits.length()-1-j);
        }
        return word;
    }
    public static void main(String[] args) throws Exception {
        forms=new ArrayList<>();
        List<String> fixture=Files.readAllLines(Path.of("tools/fixtures/renesas-isa.tsv"));
        require(fixture.size()==254,"Fixture must contain exactly253 forms and one header");
        for(String line:fixture.subList(1,fixture.size())) {
            String[] v=line.split("\t",-1); require(v.length==7,"fixture schema"); forms.add(new Form(v[0],v[1],v[2],v[3]));
        }
        require(forms.size()==253,"Primary inventory count");
        int[] modes={0,0x100000,0x80000,0x180000};
        long prefixes=0;
        for(int first=0;first<65536;first++) {
            List<Form> candidates=new ArrayList<>();
            for(Form f:forms) if(f.matches(first,0,true)) candidates.add(f);
            boolean longer=candidates.stream().anyMatch(f->f.length()==4);
            require(!longer || candidates.stream().allMatch(f->f.length()==4),"16/32 collision");
            if(longer) prefixes++;
            for(int mode:modes) {
                if(longer) for(int type=0;type<16;type++) check(first,type<<12,mode,candidates);
                else check(first,0,mode,candidates);
                byte[] truncated={(byte)(first>>>8),(byte)first};
                Instruction i=DECODER.decode(truncated,0);
                require(i.width()==(longer?4:2),"Length oracle "+first);
                if(longer) require(i.status()==Status.INCOMPLETE_FETCH,"Truncated32 "+first);
            }
        }
        require(prefixes==896,"Independent prefix count");
        // For each32 family: exhaustive Cartesian register/immediate/displacement fields.
        // Each family has <=24 free bits; no enumeration of irrelevant reserved space.
        for(Form f:forms) if(f.length()==4) {
            int free=(int)f.bits.chars().filter(c->c!='0'&&c!='1').count();
            int mode=Arrays.stream(modes).filter(f::mode).findFirst().orElseThrow();
            List<Form> family=List.of(f);
            int[] freePositions=new int[free];int k=0;
            for(int j=0;j<32;j++) if(f.bits.charAt(j)!='0'&&f.bits.charAt(j)!='1') freePositions[k++]=31-j;
            int base=materialize(f,Map.of());
            for(int value=0;value<(1<<free);value++) {
                int encoding=base;
                for(int bit=0;bit<free;bit++) encoding|=((value>>>bit)&1)<<freePositions[bit];
                check(encoding>>>16,encoding&65535,mode,family);
            }
            System.out.println(f.id+" exhaustive32 PASS combinations="+(1<<free));
        }
        require(covered.size()==253,"Forms covered="+covered.size());
        for(int mode:modes) for(int first=0;first<65536;first++) {
            Instruction plain=decode(first,0,mode,false,null),slot=decode(first,0,mode,true,0x102);
            if(plain.status()!=Status.VALID && plain.status()!=Status.UNSUPPORTED_IMPLEMENTATION) continue;
            boolean illegal=plain.width()==4 || Set.of(Flow.BRANCH,Flow.CONDITIONAL,Flow.CALL,Flow.RETURN,Flow.INDIRECT).contains(plain.flow()) ||
                    Set.of(Operation.TRAPA,Operation.RESBANK,Operation.DIVS,Operation.DIVU).contains(plain.operation());
            require(slot.status()==(illegal?Status.ILLEGAL_ENCODING:plain.status()),"slot "+plain);
            if(!illegal && (plain.operation()==Operation.MOV_PC||plain.operation()==Operation.MOVA)) {
                int expected=plain.operandWidth()==2?0x104+(first&255)*2:0x104+(first&255)*4;
                require(Objects.equals(slot.referenceAddress(),expected),"PC-relative slot reference");
                if(plain.operation()==Operation.MOVA) require(slot.imm()==expected,"MOVA slot immediate");
                require(decode(first,0,mode,true,null).referenceAddress()==null,"Unknown slot target fabricated");
            }
        }
        require(DECODER.decode(null,0).status()==Status.INCOMPLETE_FETCH,"null fetch");
        require(DECODER.decode(new byte[1],0).status()==Status.INCOMPLETE_FETCH,"short fetch");
        require(DECODER.decode(new byte[4],1).status()==Status.ADDRESS_ERROR,"odd fetch");
        require(DECODER.decode(new byte[4],-2).status()==Status.INCOMPLETE_FETCH,"negative image address");
        for(int first:new int[]{0xf000,0x406a,0x3001}) {
            IMAGE[4]=(byte)(first>>>8);IMAGE[5]=(byte)first;IMAGE[6]=0x30;IMAGE[7]=0;
            require(DECODER.decode(IMAGE,4,new DecodeContext(0,false,null,true)).status()==Status.ILLEGAL_ENCODING,"standby");
        }
        System.out.println("NORMATIVE_DECODER_ACCEPTANCE: PASS forms="+covered.size()+"/253 firstWords=65536 modes=4 prefixes="+prefixes+" checks="+checks);
    }
}
