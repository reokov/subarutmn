#!/usr/bin/env python3
"""Reproduce the primary-source inventory; never imports or reads decoder code."""
import csv, re, subprocess, pathlib, hashlib, io, sys
root=pathlib.Path(__file__).resolve().parents[1]
pdf=root/'inputs/SH2A-FPU Software Manual.pdf'
s=subprocess.check_output(['pdftotext','-layout',str(pdf),'-']).decode()
a=s.index('5.1.1       Data Transfer Instructions'); b=s.index('Section 6 Instruction Descriptions',a)
rows=[]; table=''
for pg in s[a:b].split('\f'):
    page_match=re.search(r'page (\d+) of 484',pg)
    if not page_match: continue
    page=page_match[1]
    for line in pg.splitlines():
        t=re.search(r'Table (5\.\d+)\s',line)
        if t: table=t[1]
        m=re.search(r'\b([01nmid]{16,17})\b',line)
        if not m: continue
        label=line[:m.start()].strip()
        if label: rows.append([re.sub(r'\s+',' ',label),m[1],page,table])
        else: rows[-1][1]+=m[1]
assert len(rows)==253
# Table5.9 store disp12 splits 17+15 bits. Detailed section6.3.15 p115 is unambiguous.
for row in rows:
    if row[0].startswith('FMOV.S FRm, @(disp12'): row[1]='0011nnnnmmmm00010011dddddddddddd'
    if row[0].startswith('FMOV.D DRm, @(disp12'): row[1]='0011nnnnmmm000010011dddddddddddd'
    if row[0].startswith('MAC.'): row[0]+=' @Rn+'

# Independent device manual: this is a second source, not decoder output.
hwpdf=root/'inputs/SH7254R Group User’s Manual%3A Hardware.pdf'
hw=subprocess.check_output(['pdftotext','-layout',str(hwpdf),'-']).decode()
ha=hw.index('2.5.2         Data Transfer Instructions'); hb=hw.index('2.6         Processing States',ha)
hwrows=[]
for pg in hw[ha:hb].split('\f'):
    pm=re.search(r'Page (\d+) of 1812',pg)
    if not pm: continue
    for line in pg.splitlines():
        match=re.search(r'\b([01nmid]{16})\b',line)
        if not match: continue
        if line[:match.start()].strip() and match[1]!='0011dddddddddddd': hwrows.append([match[1],pm[1]])
        else: hwrows[-1][0]+=match[1]
assert len(hwrows)==253,len(hwrows)
assert sorted(r[1] for r in rows)==sorted(r[0] for r in hwrows),'Software/device encoding mismatch'
hwpages=dict(hwrows)

def mode(label,table):
    if table!='5.9': return 'ANY'
    if label.startswith('FMOV'): return 'SZ1' if 'DR' in label else 'SZ0'
    if label=='FSCHG' or label.startswith(('FLDI','FMAC')): return 'PR0'
    if label.startswith('FCNV'): return 'PR1'
    if label.startswith(('FLDS','FSTS')): return 'ANY'
    return 'PR1' if 'DR' in label else 'PR0'

def masks(code):
    return (int(''.join('1' if c in '01' else '0' for c in code),2),int(''.join(c if c in '01' else '0' for c in code),2))
header=['group','first_mask','first_value','second_mask','second_value','length_bytes','mnemonic','addressing','primary_source','primary_page','context','operand_fields','verification']
out=io.StringIO(newline=''); fixture=io.StringIO(newline='')
w=csv.writer(out);w.writerow(header)
f=csv.writer(fixture,delimiter='\t');f.writerow(['id','format','bits','context','table','page','description_pages'])
for index,(label,code,page,table) in enumerate(rows,1):
    assert len(code) in (16,32),(label,code)
    ps=[]
    for detail in s[b:].split('\f'):
        p=re.search(r'page (\d+) of 484',detail)
        if p and code in re.sub(r'\s+','',detail):ps.append(p[1])
    # SW p312 prints nnnn for FSQRT DR; Table5.9 p67 and HW DR register model constrain even pairs.
    if not ps:
        assert label=='FSQRT DRn';ps=['312:DR_pair_constraint_sec2.2.4']
    fm,fv=masks(code[:16]); sm,sv=masks(code[16:]) if len(code)==32 else (None,None)
    fields=';'.join(c+':'+','.join(str(len(code)-1-i) for i,v in enumerate(code) if v==c) for c in 'nmid' if c in code)
    ctx=mode(label,table); ident=f'ISA{index:03}'
    mnemonic=label.split()[0]
    slot_ban=len(code)==32 or mnemonic in ['JMP','JSR','JSR/N','BRA','BRAF','BSR','BSRF','BT','BF','BT/S','BF/S','RTS','RTS/N','RTV/N','RTE','TRAPA','RESBANK','DIVS','DIVU']
    context=ctx+';slot='+('ILLEGAL' if slot_ban else 'ALLOWED')
    if table in ['5.9','5.10']: context+=';FPU_STANDBY=ILLEGAL'
    if 'DR' in label: fields+=';DR=even_FR_pair_base'
    if 'imm20' in label: fields+=';imm=signed20'+('<<8' if mnemonic=='MOVI20S' else '')
    elif '#imm' in label: fields+=';imm='+('signed8' if mnemonic in ['ADD','MOV','CMP/EQ'] else 'unsigned')
    if 'disp' in label:
        scale='FPSCR.SZ?8:4' if mnemonic.startswith('FMOV') else '2' if mnemonic.endswith('.W') or mnemonic in ['BRA','BSR','BT','BF','BT/S','BF/S'] else '4' if mnemonic.endswith('.L') or mnemonic in ['MOVA','JSR/N'] else '1'
        fields+=';disp_scale='+scale
    fields+=';class='+('FPU' if table=='5.9' else 'FPU_RELATED_CPU' if table=='5.10' else 'SYSTEM_CPU' if table=='5.8' else 'CPU')
    if mnemonic in ['BRA','BSR','BT','BF','BT/S','BF/S']:
        fields+=';disp=signed'+('12' if mnemonic in ['BRA','BSR'] else '8')+';disp_scale=2;PC=address+4'
    if 'PC' in label:
        fields+=';PC=address+4_or_slot_destination+2'
        if mnemonic!='MOV.W': fields+=';PC_align=4'
    pages='SW_table:'+page+';SW_desc:'+','.join(ps)+';HW:'+hwpages[code]
    w.writerow([ident,f'0x{fm:04X}',f'0x{fv:04X}',f'0x{sm:04X}' if sm is not None else '',f'0x{sv:04X}' if sv is not None else '',len(code)//8,label.split()[0],label,'REJ09B0051-0300 Rev3.00 Table'+table+'; sec6; R01UH0480EJ0400 Rev4.00 sec2.5',pages,context,fields,'PRIMARY_TABLE_AND_DESCRIPTION'])
    f.writerow([ident,label,code,ctx,table,page,','.join(ps)])
for path,content in [(root/'docs/requirements/isa-encodings.csv',out.getvalue()),(root/'tools/fixtures/renesas-isa.tsv',fixture.getvalue())]:
    if '--check' in sys.argv:
        assert path.read_bytes()==content.encode(),f'Normative inventory differs: {path}'
    else: path.write_bytes(content.encode())
print('253 primary forms; HW matches=253/253; CSV schema=13; SW source SHA256='+hashlib.sha256(pdf.read_bytes()).hexdigest())
