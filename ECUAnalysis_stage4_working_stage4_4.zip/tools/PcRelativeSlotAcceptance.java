package ecu.independent;

/** Synthetic oracle from REJ09B0051-0300 Rev.3.00, sec.6.4.31 pp.219-220,
 * sec.6.4.34 p.228: destination+2 precedes longword alignment and disp scaling.
 * No firmware input; graph values are tested by mutually exclusive guest branches.
 */
public final class PcRelativeSlotAcceptance {
    private static final int YES=0x700, NO=0x710;
    private PcRelativeSlotAcceptance() {}
    private static void w(byte[] r,int a,int v){r[a]=(byte)(v>>>8);r[a+1]=(byte)v;}
    private static void l(byte[] r,int a,int v){w(r,a,v>>>16);w(r,a+2,v);}
    private static void imm(byte[] r,int a,int n,int v){w(r,a,(n<<8)|((v>>>12)&0xF0));w(r,a+2,v);}
    private static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
    private static byte[] base(){byte[] r=new byte[0x200000];l(r,0,0x100);l(r,4,0xFFF90000);return r;}
    private static void probe(byte[] r,int target,int expected){
        int p=target;
        if(expected==-2){w(r,p,0xE1FE);p+=2;} else {imm(r,p,1,expected);p+=4;}
        w(r,p,0x3010); // CMP/EQ R1,R0
        // Nearby branch destinations jump to out-of-line markers via BRA/NOP.
        w(r,p+2,0x8903);w(r,p+4,0x8B04);w(r,p+6,0x001B);
        w(r,p+12,0xA000|((YES-(p+12)-4)/2&0xFFF));w(r,p+14,0x0009);
        w(r,p+16,0xA000|((NO-(p+16)-4)/2&0xFFF));w(r,p+18,0x0009);
        w(r,YES,0x001B);w(r,NO,0x001B);
    }
    private static void scenario(String branch,int target,int opcode,int address,int width,int expected){
        byte[] r=base();int slot;
        switch(branch){
            case "BRA", "BSR" -> {w(r,0x100,(branch.equals("BRA")?0xA000:0xB000)|((target-0x104)/2&0xFFF));slot=0x102;}
            case "JMP" -> {imm(r,0x100,0,target);w(r,0x104,0x402B);slot=0x106;}
            case "RTS" -> {imm(r,0x100,1,target);w(r,0x104,0x412A);w(r,0x106,0x000B);slot=0x108;}
            case "BT/S" -> {w(r,0x100,0x0018);w(r,0x102,0x8D00|((target-0x106)/2&255));slot=0x104;}
            default -> throw new IllegalArgumentException(branch);
        }
        w(r,slot,opcode);
        if(width==2)w(r,address,0xFFFE);else if(width==4)l(r,address,7);
        probe(r,target,expected);
        var g=new FirmwareGraph().analyze(r,100);
        require(g.instructions().containsKey(YES)&&!g.instructions().containsKey(NO),
                branch+" target="+Integer.toHexString(target)+" op="+Integer.toHexString(opcode)+" value/flow wrong: "+g.issues());
        require(g.dataReferences().stream().anyMatch(x->x.from()==slot&&x.to()==address),"contextual reference missing");
    }
    public static void main(String[] args){
        for(String branch:new String[]{"BRA","BSR","JMP","RTS"})for(int target:new int[]{0x1000,0x1002}){
            scenario(branch,target,0x9040,target+2+128,2,-2);
            scenario(branch,target,0xD040,((target+2)&~3)+256,4,7);
            scenario(branch,target,0xC740,((target+2)&~3)+256,0,((target+2)&~3)+256);
        }
        // A taken conditional supplies the target PC; unknown T is split before the slot.
        scenario("BT/S",0x180,0xD040,0x280,4,7);
        byte[] unknown=base();w(unknown,0x100,0x402B);w(unknown,0x102,0xD040);
        var g=new FirmwareGraph().analyze(unknown,30);
        require(g.issues().stream().anyMatch(x->x.reason().startsWith("PC_RELATIVE_DELAY_SLOT_DESTINATION_UNRESOLVED")),"unknown target not diagnosed");
        require(!g.instructions().containsKey(0x102),"unknown contextual slot was executed");
        for(boolean knownFalse:new boolean[]{false,true}){
            byte[] conditional=base();int branch=0x100;
            if(knownFalse){w(conditional,branch,0x0008);branch+=2;}
            w(conditional,branch,0x8D10);w(conditional,branch+2,0xC740);
            var c=new FirmwareGraph().analyze(conditional,30);
            final int branchPc=branch;
            // SW6.4.6 p166: not-taken is an ordinary instruction, unknown T forks.
            require(c.instructions().containsKey(branch+2),"conditional ordinary/slot path absent");
            require(c.dataReferences().stream().anyMatch(x->x.from()==branchPc+2 &&
                    x.to()==((branchPc+6)&~3)+256),"not-taken ordinary PC-relative reference absent");
            if(!knownFalse) require(c.dataReferences().stream().anyMatch(x->x.from()==branchPc+2 &&
                    x.to()==((branchPc+4+32+2)&~3)+256),"unknown T taken reference absent");
        }
        System.out.println("PC_RELATIVE_SLOT_ACCEPTANCE: PASS (28 synthetic scenarios; not full delayed-branch verification)");
    }
}
