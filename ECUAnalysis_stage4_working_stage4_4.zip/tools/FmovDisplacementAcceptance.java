import ecu.independent.FirmwareGraph;

/**
 * Synthetic disp12 FMOV check (RENESAS SH-2A/SH2A-FPU Software Manual
 * REJ09B0051-0300 Rev.3.00, section 6.3.15: displacement scaled by FPSCR.SZ,
 * x4 single / x8 double).
 *
 * WARNING (2026-11-09): the concrete expected targets below were last executed against
 * the decoder BEFORE the FPSCR.SZ scaling refactor (AbstractCpu.java:640-643 now applies
 * SZ scaling at execution time and the decoder keeps the RAW disp12, see
 * Sh2aOpcodeExtensions.java:28-36). This file therefore needs one operator-approved run
 * before its numbers can be trusted again; until then this acceptance is BLOCKED, not PASS.
 * It never was real ECU validation. See docs/FULL_COVERAGE_RELEASE_GATE_RU.md criterion 1.
 */
public final class FmovDisplacementAcceptance {
    private FmovDisplacementAcceptance() {}
    private static FirmwareGraph.Report run(boolean doubleWidth, boolean store) {
        byte[] rom=new byte[0x200000];
        rom[0]=0;rom[1]=0;rom[2]=1;rom[3]=0;
        rom[4]=(byte)0xFF;rom[5]=(byte)0xF9;rom[6]=0;rom[7]=0;
        int mode=store?0x3003:0x7003;
        int[] halfwords=doubleWidth ? new int[]{0x0200,0x0400,0xF3FD,0x3221,mode,0x001B}
                : new int[]{0x0200,0x0400,0x3221,mode,0x001B};
        for(int i=0;i<halfwords.length;i++){
            rom[0x100+2*i]=(byte)(halfwords[i]>>>8);
            rom[0x101+2*i]=(byte)halfwords[i];
        }
        return new FirmwareGraph().analyze(rom,64);
    }
    public static void main(String[] args) {
        var single=run(false,false);
        boolean a=single.dataReferences().stream().anyMatch(r->r.to()==0x40C && r.width()==4 && r.kind().equals("ROM_LOAD"));
        if(!a)throw new AssertionError("Single FMOV disp12 must be multiplied by 4: "+single.dataReferences());
        var dbl=run(true,false);
        boolean b=dbl.dataReferences().stream().anyMatch(r->r.to()==0x418 && r.width()==4 && r.kind().equals("ROM_LOAD"));
        boolean c=dbl.dataReferences().stream().anyMatch(r->r.to()==0x41C && r.width()==4 && r.kind().equals("ROM_LOAD"));
        if(!b||!c)throw new AssertionError("Double FMOV disp12 must be multiplied by 8: "+dbl.dataReferences()+" "+dbl.issues());
        var singleStore=run(false,true);
        if(singleStore.issues().stream().noneMatch(i->i.reason().equals("ROM_WRITE_ATTEMPT_IN_ABSTRACT_STATE_0x0000040C")))
            throw new AssertionError("Single FMOV store 4-byte displacement: "+singleStore.issues());
        var doubleStore=run(true,true);
        if(doubleStore.issues().stream().noneMatch(i->i.reason().equals("ROM_WRITE_ATTEMPT_IN_ABSTRACT_STATE_0x00000418")))
            throw new AssertionError("Double FMOV store 8-byte displacement: "+doubleStore.issues());
        System.out.println("PASS synthetic FMOV disp12 load/store, 4-byte and 8-byte addressing; NOT real ECU validation");
    }
}
