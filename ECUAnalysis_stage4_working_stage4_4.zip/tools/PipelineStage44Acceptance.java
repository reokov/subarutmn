package ecu.independent;
import java.util.*;
import static ecu.independent.SystemExceptionModel.*;
import static ecu.independent.SystemExceptionsAcceptance.*;
/** SW Rev3 8.2/8.3/8.6/8.9, synthetic only. ED buffering schedules are conditional. */
public final class PipelineStage44Acceptance {
    static int cases,assertions;
    static void check(boolean ok,String reason){assertions++;if(!ok)throw new AssertionError(reason);}
    static long phase(Pipeline p,PipelineStage stage,int pc){return p.steps().stream().filter(s->s.stage()==stage&&s.pc()==pc).mapToLong(PipelineStep::slot).findFirst().orElseThrow();}
    static FirmwareGraph run(AbstractCpu s,int... ops){byte[] r=image(ops[0]);for(int j=0;j<ops.length;j++)w(r,A+2*j,ops[j]);w(r,A+ops.length*2,0x001b);var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,128,s);return g;}
    static void stages(){
        cases++;var p=new Pipeline();var div=ps(0xf423,A,0xc0000);p.issue(div,values(div,1));p.advance(16);var add=ps(0xf860,A+2,0xc0000);
        check(p.ready(add)==16,"SW8.6(2): no future E1 reservation ready16->23");p.issue(add,values(add,2));p.advance(25);
        check(!p.committed().containsKey("FR4"),"no SF25 without actual return");p.advance(27);
        check(phase(p,PipelineStage.E1_RETURN,A)==23&&phase(p,PipelineStage.E2,A)==26&&phase(p,PipelineStage.RESULT_COMMIT,A)==27,"actual E1/E2/SF transitions");
        check(p.uncertainties().contains("UNVERIFIED_ED_E1_HANDOFF_BUFFERING"),"buffer-dependent trace must stay conditional");
        cases++;p=new Pipeline();div=ps(0xf423,A,0x40000);p.issue(div,values(div,1));var second=ps(0xf863,A+2,0x40000);
        check(p.ready(second)==1,"second divide issues before ED-free");p.issue(second,values(second,2));add=ps(0xfca0,A+4,0x40000);
        check(p.ready(add)==2,"independent FADD while WAIT_ED");p.issue(add,values(add,3));p.advance(5);
        check(p.committed().get("FR12")==3&&!p.committed().containsKey("FR8"),"independent completion during ED wait");
        p.advance(19);check(!p.committed().containsKey("FR8"),"early second SF");p.advance(20);
        check(phase(p,PipelineStage.ED,A+2)==10&&phase(p,PipelineStage.RESULT_COMMIT,A+2)==20,"ED exclusivity and full stage sequence");
        for(int[] row:new int[][]{{0xf423,0x40000,12},{0xf46d,0x40000,11},{0xf423,0xc0000,25},{0xf46d,0xc0000,24}}){
            cases++;p=new Pipeline();div=ps(row[0],A,row[1]);p.issue(div,values(div,1));p.advance(row[2]-1);check(!p.committed().containsKey("FR4"),"normal long-op result early");p.advance(row[2]);check(p.committed().get("FR4")==1,"normal long-op final SF");
        }
        cases++;p=new Pipeline(Map.of(2L,8));div=ps(0xf423,A,0x40000);p.issue(div,values(div,1));p.advance(2);
        check(p.systemState()==9&&p.outstanding().getFirst().phase()==2,"ED advances in states within extended slot");p.advance(5);
        check(phase(p,PipelineStage.RESULT_COMMIT,A)==5&&p.systemState()==12,"long slot keeps distinct state/slot counters");
    }
    static void memoryMode(){
        cases++;var s=initial();s.r[2]=B;s.r[1]=0x12345678;s.r[3]=s.r[4]=0;
        var g=run(s,0x2212,0x6322,0x6433,0x0009,0x0009,0x0009);
        check(!at(g,A+2).ram().containsKey(B),"store visible at issue instead of MA");var end=at(g,A+12);
        check(ram(end,B)==0x12345678&&end.registers().get(3)==0x12345678&&end.registers().get(4)==0x12345678,"actual executor RAM/load/bypass commit");
        cases++;var p=new Pipeline();var lds=ps(0x415a,A,0x40000);p.issue(lds,values(lds,1));
        check(p.ready(ps(0x6322,A+2,0x40000))==0,"SWfig8.11 LDS+read allowed");check(p.ready(ps(0x2212,A+2,0x40000))==1,"SWfig8.9 LDS+store conflict");
        cases++;s=initial();s.r[1]=0xc0000;s.fr[2]=s.fr[4]=0x3ff00000;s.fr[3]=s.fr[5]=0;
        g=run(s,0x416a,0xf420,0x036a,0x6033,0x0009);
        check(at(g,A+10).fr().get(4)==0x40000000&&at(g,A+10).fr().get(5)==0,"loaded PR1 used at decode and execution");
        check(g.pipelineStops().getLast().steps().stream().anyMatch(x->x.stage()==PipelineStage.ISSUE&&x.pc()==A+2&&x.slot()==3),"FPSCR write dependency3");
        check((at(g,A+10).registers().get(3)&FpuSemantics.PR)!=0,"FPSCR read after arithmetic");
        cases++;p=new Pipeline();var m=ps(0xf42c,A,0x140000);p.issue(m,values(m,1));check(p.ready(ps(0x0009,A+2,0x140000))==1,"double FMOV multicycle");p.advance(3);check(!p.committed().containsKey("FR4"),"double FMOV early SF");p.advance(4);check(p.committed().containsKey("FR5"),"double move pair");
    }
    static void control(){
        for(boolean rte:new boolean[]{false,true}){
            cases++;var s=initial();s.r[1]=5;if(rte){s.writeRam(SP,4,A+8,A-2);s.writeRam(SP+4,4,0,A-2);}
            byte[] r=image(rte?0x002b:0xa002);w(r,A+2,0x7101);w(r,A+8,0x6313);w(r,A+10,0x6433);w(r,A+12,0x0009);w(r,A+14,0x001b);
            var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,128,s);check(at(g,A+14).registers().get(3)==6&&at(g,A+14).registers().get(4)==6,"delay-slot -> target executor");
            var trace=g.pipelineStops().getLast().steps();check(trace.stream().anyMatch(x->x.stage()==PipelineStage.ISSUE&&x.pc()==A+2&&x.slot()==(rte?6:2)),"branch/RTE slot fence");
            if(rte)check(at(g,A+14).registers().get(15)==SP+8&&at(g,A+14).sr()==0,"RTE SP/SR commit");
        }
        cases++;var s=initial();s.t=null;byte[] r=image(0x8b02);w(r,A+2,0x001b);w(r,A+8,0x0009);w(r,A+10,0x001b);
        var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,128,s);
        check(g.pipelineStops().stream().filter(x->x.pc()==A+10).flatMap(x->x.steps().stream()).anyMatch(x->x.stage()==PipelineStage.ISSUE&&x.pc()==A+8&&x.slot()==3),"unknown T taken fence");
        check(g.pipelineStates().stream().anyMatch(x->x.pc()==A+2&&x.slot()==0),"not-taken path penalty");
        for(boolean partial:new boolean[]{false,true}){
            cases++;s=initial();if(partial)s.q=null;s.pipeline=new Pipeline();s.pipeline.initialize(s);s.writeSr(0xf0);s.r[15]=SP+8;
            var spec=ps(0x002b,A,0x40000);Map<String,Integer> delta=new LinkedHashMap<>();for(String name:spec.writes())delta.put(name,Pipeline.read(s,name));s.pipeline.issue(spec,delta);s.pipeline.restoreCommitted(s);
            check(s.interruptMask==0&&s.r[15]==SP,"first RTE premature SR/SP");if(partial)check(s.q==null&&Boolean.FALSE.equals(s.bankOverflow),"partial SR known bits lost");s.pipeline.advance(6);s.pipeline.restoreCommitted(s);check(s.interruptMask==15&&s.r[15]==SP+8,"RTE delayed commit");
        }
        cases++;s=initial();r=image(0xb002);w(r,A+2,9);w(r,A+4,0x001b);w(r,A+8,0x000b);w(r,A+10,9);g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,128,s);check(at(g,A+4).pr()==A+4&&g.pipelineStates().stream().anyMatch(x->x.pc()==A+4&&x.slot()==6),"BSR/RTS PR and slots");
    }
    static void exceptionsAndCopy(){
        cases++;var s=initial();s.r[2]=B+2;byte[] r=image(0x6322);w(r,H,0x002b);w(r,H+2,9);var g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,128,s);
        check(g.systemEvents().stream().anyMatch(x->x.stage()==Stage.ACCEPTANCE&&x.event().kind()==Kind.CPU_ADDRESS),"potential H24 entry");check(at(g,A+2).registers().get(15)==SP,"accepted frame shadow survives RTE");
        cases++;s=initial();s.systemPending.add(new Event(1,Kind.IRQ,A,null,0x100,3,"explicit",Availability.AFTER_ISSUE,null,A));r=image(0xa002);w(r,A+2,9);w(r,A+8,9);g=new FirmwareGraph().withNoWaitPipeline();g.analyzeCpu(r,128,s);check(ram(at(g,H),SP-8)==A+8,"reported IRQ after slot saved PC");
        cases++;s=initial();s.fpscr=0x40800;s.fr[6]=s.fr[8]=0;g=run(s,0xf423,0xf863);
        check(g.pipelineStops().stream().anyMatch(x->x.outstanding().size()==2&&x.outstanding().stream().anyMatch(f->f.result().isEmpty())),"H34 preserves normal and exceptional jobs");check(g.systemEvents().stream().noneMatch(x->x.stage()==Stage.ACCEPTANCE&&x.event().kind()==Kind.FPU),"no guessed physical H34 report");
        cases++;s=initial();s.pipeline=new Pipeline();s.pipeline.initialize(s);var div=ps(0xf423,A,0x40000);s.pipeline.issue(div,values(div,1));s.pipeline.advance(4);var copy=s.copy();copy.pipeline.advance(12);
        check(s.pipeline.committed().get("FR4")==0x3f800000,"copy shares stage state");s.restoreFaultState(copy);check(s.pipeline.committed().get("FR4")==1,"rollback state");
    }
    static void cpuWaw(){
        for(int[] ops:new int[][]{{0xf424,0x0018},{0x015a,0xe101}}){
            cases++;var p=new Pipeline();var producer=ps(ops[0],A,0x40000);p.issue(producer,values(producer,1));
            check(p.ready(ps(ops[1],A+2,0x40000))==2,"FPU instruction writing CPU register/T must use CPU WAW latency, SW8.3.3 not FR reduction");
        }
    }
    static void addressMemory(){
        // Independent table 8.1 / 8.9.1(4,7) oracle: load EX/MA/WB, store EX/MA.
        for(int op:new int[]{0x6326,0x2236,0x42eb,0x42ab,0x032e,0x0236,0xc600,0xc200,0xf429,0xf24b}){
            cases++;check(ps(op,A,0x40000)!=null,"missing address/index/GBR profile "+Integer.toHexString(op));
        }
        cases++;var s=initial();s.r[2]=B;s.r[3]=0;s.writeRam(B,4,0x12345678,A-2);
        var g=run(s,0x6326,0x6423,0x6533,9,9,9);var end=at(g,A+12);
        check(end.registers().get(2)==B+4&&end.registers().get(3)==0x12345678&&end.registers().get(4)==B+4&&end.registers().get(5)==0x12345678,"postinc address/data dependencies");
        cases++;s=initial();s.r[2]=B;g=run(s,0x2226,9,9,9,9);end=at(g,A+10);
        check(end.registers().get(2)==B-4&&ram(end,B-4)==B,"predec alias stores old source");
        cases++;s=initial();s.r[2]=B;s.writeRam(B,4,7,A-2);g=run(s,0x6226,0x6323,9,9,9);end=at(g,A+10);
        check(end.registers().get(2)==7&&end.registers().get(3)==7,"postinc m=n suppress update");
        cases++;s=initial();s.r[2]=B+4;s.writeRam(B,4,11,A-2);g=run(s,0x42eb,0x6323,0x6403,9,9,9);end=at(g,A+12);
        check(end.registers().get(2)==B&&end.registers().get(0)==11&&end.registers().get(4)==11,"reverse load address/data");
        cases++;s=initial();s.r[0]=4;s.r[2]=B;s.r[3]=77;g=run(s,0x0236,0x042e,0x6543,9,9,9);end=at(g,A+12);
        check(ram(end,B+4)==77&&end.registers().get(4)==77,"indexed R0 address + pending memory");
        cases++;s=initial();s.gbr=B;s.r[0]=91;g=run(s,0xc200,0xe000,0xc600,0x6303,9,9);end=at(g,A+12);
        check(ram(end,B)==91&&end.registers().get(0)==91,"GBR preserved by committed shadow");
        cases++;s=initial();s.r[2]=B;s.writeRam(B,4,0x40800000,A-2);g=run(s,0xf429,0x6323,0xf54c,9,9,9,9,9,9,9);end=at(g,A+20);
        check(end.registers().get(3)==B+4&&end.fr().get(5)==0x40800000,"FMOV postinc CPU address and FPU data");
    }
    static void memoryHazards(){
        cases++;var s=initial();s.r[2]=B;s.pipeline=new Pipeline();s.pipeline.initialize(s);var load=ps(0xf429,A,0x40000);
        Map<String,Integer> delta=new HashMap<>();delta.put("R2",B+4);delta.put("FR4",0x40800000);s.pipeline.issue(load,delta);
        check(s.pipeline.ready(ps(0x6323,A+2,0x40000))==1,"FMOV CPU address forwarding1");
        check(s.pipeline.ready(ps(0xf54c,A+2,0x40000))==2,"FMOV FR data forwarding2");
        s.pipeline.advance(1);s.pipeline.restoreCommitted(s);check(s.r[2]==B&&s.fr[4]==0x3f800000,"forwardable values do not become architectural commit");
        var fork=s.copy();fork.pipeline.operands(fork);check(fork.r[2]==B+4&&fork.fr[4]==0x40800000,"operand overlay");fork.pipeline.reset();
        check(s.pipeline.outstanding().size()==1&&s.pipeline.key().equals(s.copy().pipeline.key()),"reset/copy isolation with per-register timing");
        cases++;var p=new Pipeline();var store=ps(0x2236,A,0x40000);p.issue(store,values(store,1));
        check(p.ready(ps(0x6323,A+2,0x40000))==1,"store address latency1");
        check(p.ready(ps(0x2232,A+2,0x40000))==1,"two memory operations cannot pair");
        check(p.ready(ps(0xe301,A+2,0x40000))==0,"store captured source WAR permits parallel write");
        for(int width=0;width<3;width++)for(boolean alias:new boolean[]{false,true}){
            int bytes=1<<width;cases++;s=initial();s.r[2]=B+16;s.r[3]=0x76543210;int reg=alias?2:3;
            var g=run(s,0x2204+(reg<<4)+width,9,9,9,9,9);var end=at(g,A+12);
            int expected=alias?B+16:0x76543210;int address=B+16-bytes;
            for(int j=0;j<bytes;j++)check(Objects.equals(end.ram().get(address+j),(byte)(expected>>>(8*(bytes-1-j)))),"predec width/source snapshot");
            check(end.registers().get(2)==address,"predec address commit");
        }
        cases++;s=initial();s.r[2]=B+2;s.writeRam(B,4,1,A-2);var g=run(s,0xf429,9,9,9,9);
        check(g.systemEvents().stream().anyMatch(x->x.event().kind()==Kind.CPU_ADDRESS),"FMOV update misalignment generates H24");
        check(g.pipelineStops().stream().noneMatch(x->x.outstanding().stream().anyMatch(f->f.spec().pc()==A)),"faulting address update is not issued as normal result");
    }
    static void shiftResource(){
        for(int opcode:new int[]{0x632c,0x632d,0x632e,0x632f}){
            cases++;var p=new Pipeline();var first=ps(opcode,A,0x40000);p.issue(first,values(first,1));
            check(p.ready(ps(0x4408,A+2,0x40000))==1,"SW8.9.2(1) EXT uses shifter");
        }
        for(int opcode:new int[]{0x6218,0x6219,0x221d}){
            cases++;var p=new Pipeline();var first=ps(opcode,A,0x40000);p.issue(first,values(first,1));
            check(p.ready(ps(0x4408,A+2,0x40000))==1,"SW8.9.1(3) SWAP/XTRCT share SHIFT");
        }
    }
    static void actualPhaseReadiness(){
        cases++;var p=new Pipeline();var load=ps(0xf428,A,0x140000);p.issue(load,values(load,1));
        var store=ps(0x2356,A+2,0x140000);check(p.ready(store)==1,"independent CPU store ID1");p.issue(store,values(store,2));
        check(p.ready(ps(0x6633,A+4,0x140000))==2,"EX2 address ready despite MA3 hold and MA4 completion");
        p.advance(4);check(p.steps().stream().anyMatch(x->x.pc()==A+2&&x.stage()==PipelineStage.WAIT_RESOURCE&&x.slot()==3),"actual MA wait3");
        check(phase(p,PipelineStage.RESULT_COMMIT,A+2)==4,"store commit only after MA4");
        cases++;var s=initial();s.fpscr=0x140000;s.r[2]=B;s.r[3]=B+16;s.r[5]=123;
        s.writeRam(B,4,0x3ff00000,A-2);s.writeRam(B+4,4,0,A-2);
        var g=run(s,0xf428,0x2356,0x6633,9,9,9,9,9,9,9);var end=at(g,A+20);
        check(end.registers().get(6)==B+12&&ram(end,B+12)==123,"MA hold actual executor forwards computed address");
        check(g.pipelineStops().getLast().steps().stream().anyMatch(x->x.pc()==A+4&&x.stage()==PipelineStage.ISSUE&&x.slot()==2),"decode-to-observable address bypass at ID2");
    }
    static void doubleMemory(){
        cases++;var load=ps(0xf428,A,0x140000);check(load!=null,"missing FMOV.D load profile");
        var p=new Pipeline();p.issue(load,values(load,1));
        check(p.ready(ps(0xf64c,A+2,0x40000))==2,"table8.1 even FR latency2");
        check(p.ready(ps(0xf65c,A+2,0x40000))==3,"table8.1 odd FR latency3");
        check(p.ready(ps(0xf64c,A+2,0x140000))==4,"table8.1 DR latency4");
        check(p.ready(ps(0xf540,A+2,0x140000))==3,"two independent single operands FR4/FR5 are not DR4");
        cases++;p=new Pipeline();load=ps(0xf429,A,0x140000);p.issue(load,values(load,1));
        check(p.ready(ps(0x6323,A+2,0x140000))==1,"CPU address latency1 independent of DR4");
        check(p.ready(ps(0xf86c,A+2,0x140000))==2,"FP_LS held for both EX slots");
        check(p.ready(ps(0xf860,A+2,0x140000))==1,"independent arithmetic enters next slot");
        p.advance(3);check(!p.committed().containsKey("FR4"),"double load no architectural SF before4");p.advance(4);check(p.committed().containsKey("FR5"),"double load both halves commit SF4");
        cases++;var s=initial();s.fpscr=0x140000;s.r[2]=B;s.r[3]=B+16;s.writeRam(B,4,0x3ff00000,A-2);s.writeRam(B+4,4,0,A-2);
        var g=run(s,0xf429,0xf34b,0x6423,9,9,9,9,9,9,9);var end=at(g,A+20);
        check(end.fr().get(4)==0x3ff00000&&end.fr().get(5)==0&&end.registers().get(2)==B+8,"double postinc executor");
        check(end.registers().get(3)==B+8&&ram(end,B+8)==0x3ff00000&&ram(end,B+12)==0,"double predec store words");
    }
    static void fpSystemMemory(){
        for(int op:new int[]{0x4252,0x4262,0x4256,0x4266,0xf3fd}){
            cases++;check(ps(op,A,0x40001)!=null,"missing FP control-memory/FSCHG profile "+Integer.toHexString(op));
        }
        for(int base:new int[]{0x4052,0x4062,0x4056,0x4066})for(int reg:new int[]{0,2,15})for(int mode:new int[]{0x40001,0xc0001,0x140001,0x1c0001}){
            cases++;boolean load=(base&15)==6;var s=initial();s.fpscr=mode;s.fpul=0x12345678;s.r[reg]=load?B:B+4;
            int value=base==0x4066?0x40001:0x3f800000;s.writeRam(B,4,value,A-2);
            int op=base|(reg<<8);var g=run(s,op,9,9,9,9,9);var end=at(g,A+12);
            check(end.registers().get(reg)==(load?B+4:B),"FP control address commit");
            if(load){if(base==0x4066)check(end.fpscr()==value,"LDS.L FPSCR result/mask");else check(end.fpul()==value,"LDS.L FPUL result");}
            else check(ram(end,B)==(base==0x4062?mode:0x12345678),"STS.L raw data/SRAM commit");
            check(g.pipelineStops().getLast().steps().stream().anyMatch(x->x.pc()==A&&x.stage()==PipelineStage.RESULT_COMMIT),"FP control production commit absent");
        }
        cases++;var p=new Pipeline();var producer=ps(0xf43d,A,0x40001);p.issue(producer,values(producer,1));
        check(p.ready(ps(0x4252,A+2,0x40001))==2,"FPUL to memory forwarding is minus1, not minus3");
        check(p.ready(ps(0x025a,A+2,0x40001))==1,"FPUL to GPR forwarding minus2");
        cases++;var s=initial();s.r[2]=B;s.writeRam(B,4,0x40000000,A-2);s.writeRam(B+4,4,0,A-2);
        var g=run(s,0xf3fd,0xf428,9,9,9,9,9,9,9,9);var end=at(g,A+20);
        check((end.fpscr()&FpuSemantics.SZ)!=0&&end.fr().get(4)==0x40000000&&end.fr().get(5)==0,"FSCHG size forwarding to double load");
        cases++;p=new Pipeline();producer=ps(0xf423,A,0x40001);p.issue(producer,values(producer,1));p.advance(1);
        check(p.ready(ps(0xf3fd,A+2,0x40001))==1,"FSCHG SZ-only must not wait for FDIV FPSCR flags");
        cases++;s=initial();p=new Pipeline();p.initialize(s);producer=ps(0xf423,A,s.fpscr);p.issue(producer,values(producer,1));p.advance(1);
        var toggle=ps(0xf3fd,A+2,s.fpscr);p.issue(toggle,Map.of("SZ",1));p.numericalFpscr(s.fpscr|FpuSemantics.SZ);
        var copy=p.copy();copy.advance(4);copy.restoreCommitted(s);
        check((s.fpscr&FpuSemantics.SZ)!=0,"committed FSCHG SZ lost while divide outstanding");
        check(copy.uncertainties().contains("UNVERIFIED_FSCHG_PIPELINE_RESOURCE"),"conflicting FSCHG resource references must be observable");
        check(p.slot()==1&&!p.committed().get("SZ").equals(1),"FSCHG copy aliases source");
        copy.reset();check(copy.outstanding().isEmpty(),"FSCHG pending reset");
        cases++;s=initial();s.r[2]=B+2;g=run(s,0x4266,9,9,9);
        check(g.systemEvents().stream().anyMatch(x->x.event().kind()==Kind.CPU_ADDRESS),"control memory misalignment H24 generation");
        check(g.pipelineStops().stream().noneMatch(x->x.outstanding().stream().anyMatch(f->f.spec().pc()==A)),"faulting control transfer issued as normal");
    }
    static void prTransfers(){
        for(int op:new int[]{0xc700,0x422a,0x022a,0x4226,0x4222}){cases++;check(ps(op,A,0x40000)!=null,"PR/MOVA profile absent");}
        for(int reg:new int[]{0,2,15})for(boolean load:new boolean[]{true,false}){
            cases++;var s=initial();s.pr=0x12345678;s.r[reg]=load?B:B+4;s.writeRam(B,4,0x87654321,A-2);
            var g=run(s,(load?0x4026:0x4022)|(reg<<8),9,9,9,9,9);var end=at(g,A+12);
            check(end.registers().get(reg)==(load?B+4:B),"PR memory address update");
            check(load?end.pr()==0x87654321:ram(end,B)==0x12345678,"PR raw memory result");
            var trace=g.pipelineStops().getLast().steps();check(trace.stream().anyMatch(x->x.pc()==A&&x.stage()==PipelineStage.RESULT_COMMIT),"PR memory executor commit");
        }
        cases++;var s=initial();s.r[2]=0x12345678;var g=run(s,0x422a,0x032a,9,9);check(at(g,A+8).pr()==0x12345678&&at(g,A+8).registers().get(3)==0x12345678,"LDS PR -> STS PR forwarding");
        cases++;g=run(initial(),0xc701,0x6303,9,9);check(at(g,A+8).registers().get(3)==A+8,"MOVA aligned PC plus scaled displacement");
        cases++;var p=new Pipeline();var load=ps(0x4226,A,0x40000);p.issue(load,values(load,1));
        check(p.ready(ps(0x032a,A+2,0x40000))==2,"LDS.L PR latency2");
        check(p.ready(ps(0x6543,A+2,0x40000))==0,"independent CPU may overlap PR load");
        p.advance(2);check(!p.committed().containsKey("PR"),"PR cannot commit at MA");p.advance(3);check(p.committed().get("PR")==1,"PR load commit at WB");
        cases++;p=new Pipeline();var store=ps(0x4222,A,0x40000);p.issue(store,values(store,1));
        check(p.ready(ps(0x6323,A+2,0x40000))==1,"PR predecrement address latency1");
        check(p.ready(ps(0x6542,A+2,0x40000))==1,"PR store MA contention");
        cases++;s=initial();s.r[2]=B+2;g=run(s,0x4226,9,9,9);
        check(g.systemEvents().stream().anyMatch(x->x.event().kind()==Kind.CPU_ADDRESS),"PR misaligned load H24");
        check(g.pipelineStops().stream().noneMatch(x->x.outstanding().stream().anyMatch(f->f.spec().pc()==A)),"faulting PR load normal issue");
    }
    static void nonSrControl(){
        for(int op:new int[]{0x0312,0x0322,0x034a,0x431e,0x432e,0x434a,0x4317,0x4327,0x4313,0x4323}){cases++;check(ps(op,A,0x40000)!=null,"non-SR control profile absent");}
        for(int base:new int[]{0x0012,0x0022,0x004a,0x401e,0x402e,0x404a})for(int reg:new int[]{0,3,15}){
            cases++;var s=initial();s.gbr=0x12345678;s.vbr=0x23456780;s.tbr=0x34567800;s.r[reg]=0x76543210;
            var g=run(s,base|(reg<<8),9,9,9,9);var end=at(g,A+10);
            if(base==0x401e)check(end.gbr()==0x76543210,"LDC GBR commit");
            else if(base==0x402e)check(end.vbr()==0x76543210,"LDC VBR commit");
            else if(base==0x404a)check(end.tbr()==0x76543210,"LDC TBR commit");
            else check(end.registers().get(reg)==(base==0x0012?0x12345678:base==0x0022?0x23456780:0x34567800),"STC raw register value");
        }
        for(int base:new int[]{0x4017,0x4027,0x4013,0x4023})for(int reg:new int[]{0,3,15}){
            cases++;boolean load=(base&15)==7;var s=initial();s.gbr=0x12345678;s.vbr=0x23456780;s.r[reg]=load?B:B+4;s.writeRam(B,4,0x87654320,A-2);
            var g=run(s,base|(reg<<8),9,9,9,9,9);var end=at(g,A+12);
            check(end.registers().get(reg)==(load?B+4:B),"control memory address update");
            check(load?(base==0x4017?end.gbr():end.vbr())==0x87654320:ram(end,B)==(base==0x4013?0x12345678:0x23456780),"control memory bits/commit");
        }
        cases++;var s=initial();s.r[2]=B;s.gbr=B+32;s.writeRam(B,4,0x12345678,A-2);
        var g=run(s,0x421e,0xc600,9,9,9,9,9,9);
        check(at(g,A+12).registers().get(0)==0x10,"GBR load cannot commit before actual WB");
        check(at(g,A+16).registers().get(0)==0x12345678,"LDC GBR -> effective memory address forwarding");
        cases++;s=initial();s.gbr=null;g=run(s,0x0312,9,9);check(at(g,A+6).registers().get(3)==null,"unknown GBR must remain unknown");
        cases++;var p=new Pipeline();s=initial();p.initialize(s);var spec=ps(0x432e,A,s.fpscr);p.issue(spec,Map.of("VBR",0x200));var cp=p.copy();cp.advance(1);cp.restoreCommitted(s);
        check(s.vbr==0x200&&!Objects.equals(p.committed().get("VBR"),0x200),"VBR copy/committed separation");cp.reset();check(cp.committed().isEmpty(),"control reset shadow");
        cases++;s=initial();s.r[3]=B+2;g=run(s,0x4317,9,9,9);check(g.systemEvents().stream().anyMatch(x->x.event().kind()==Kind.CPU_ADDRESS),"LDC.L misalignment H24");
        cases++;g=run(initial(),0xf3fd,9,9,9);
        check(g.report().issues().stream().anyMatch(x->x.reason().contains("UNVERIFIED_FSCHG_PIPELINE_RESOURCE")),"FSCHG actual uncertainty absent");
        check(g.report().issues().stream().noneMatch(x->x.reason().contains("ED_E1_HANDOFF_BUFFERING")),"FSCHG-only false ED uncertainty");
    }
    static void flagRegisters(){
        for(int op:new int[]{0x4291,0x4295,0x4281,0x4285,0x3214,0x2217,0x0019,0x8620,0x8628,0x8728,0x8720}){cases++;check(ps(op,A,0x40000)!=null,"flag/register profile absent");}
        for(int[] c:new int[][]{{0x4291,-129,-128},{0x4291,127,127},{0x4295,-32769,-32768},{0x4295,32767,32767},{0x4281,-1,255},{0x4281,255,255},{0x4285,65536,65535},{0x4285,65535,65535}})for(boolean sticky:new boolean[]{false,true}){
            cases++;var s=initial();s.r[2]=c[1];s.cs=sticky;var g=run(s,c[0],9,9,9);var end=at(g,A+8);
            check(end.registers().get(2)==c[2]&&end.cs()==(sticky||c[1]!=c[2]),"CLIP literal bound/sticky CS");
        }
        cases++;var s=initial();s.r[2]=128;s.r[3]=1;var g=run(s,0x4291,0x4391,9,9);var end=at(g,A+8);
        check(end.registers().get(2)==127&&end.registers().get(3)==1&&Boolean.TRUE.equals(end.cs()),"parallel CLIP sticky accumulation");
        var trace=g.pipelineStops().getLast().steps();check(trace.stream().filter(x->x.stage()==PipelineStage.ISSUE&&(x.pc()==A||x.pc()==A+2)).allMatch(x->x.slot()==0),"CLIP CS rewrite must not stall issue-pair");
        for(int reg:new int[]{0,2,15}){
            cases++;s=initial();s.r[reg]=-1;g=run(s,0x2007|(reg<<8)|(reg<<4),9,9,9);end=at(g,A+8);
            check(Boolean.TRUE.equals(end.q())&&Boolean.TRUE.equals(end.m())&&Boolean.FALSE.equals(end.t()),"DIV0S alias signs/Q/M/T");
        }
        for(int[] c:new int[][]{{0,0,0,0,1,-1,1,0},{0,0,1,0,1,0,0,1},{0,1,0,0,1,1,1,1},{1,0,0,0,1,1,0,1},{1,1,0,0,1,-1,0,0}}){
            cases++;s=initial();s.q=c[0]!=0;s.m=c[1]!=0;s.t=c[2]!=0;s.r[2]=c[3];s.r[1]=c[4];g=run(s,0x3214,9,9,9);end=at(g,A+8);
            check(end.registers().get(2)==c[5]&&end.q()==(c[6]!=0)&&end.t()==(c[7]!=0)&&end.m()==(c[1]!=0),"DIV1 normative Q/M table vector "+Arrays.toString(c)+" got "+end.registers().get(2)+"/"+end.q()+"/"+end.t()+"/"+end.m());
        }
        cases++;s=initial();s.q=s.m=s.t=true;g=run(s,0x0019,0x3214,9,9,9);end=at(g,A+10);
        check(Boolean.FALSE.equals(end.m()),"DIV0U M commit/forward to DIV1");
        for(int bit=0;bit<8;bit++)for(boolean t:new boolean[]{false,true}){
            cases++;s=initial();s.r[2]=0xa5;s.t=t;g=run(s,0x8620|bit,0x8628|bit,0x8720|bit,0x8728|bit,9,9);end=at(g,A+12);
            check(end.registers().get(2)==((0xa5&~(1<<bit))|(t?1<<bit:0))&&end.t()==t,"BCLR/BSET/BST/BLD all bits with T forwarding");
        }
        cases++;s=initial();s.q=s.m=s.cs=null;var p=new Pipeline();p.initialize(s);var spec=ps(0x0019,A,s.fpscr);p.issue(spec,Map.of("Q",0,"M",0,"T",0));var cp=p.copy();cp.advance(1);cp.restoreCommitted(s);
        check(Boolean.FALSE.equals(s.q)&&Boolean.FALSE.equals(s.m)&&p.committed().get("Q")==null,"flag shadow UNKNOWN/copy isolation");
        cases++;s=initial();s.writeRam(SP,4,A+8,A-2);s.writeRam(SP+4,4,0x2301,A-2);g=run(s,0x002b,9,9,9,9,9,9,9);end=at(g,A+16);
        check(Boolean.TRUE.equals(end.q())&&Boolean.TRUE.equals(end.m())&&Boolean.TRUE.equals(end.cs())&&Boolean.TRUE.equals(end.t()),"RTE restores flags over initial shadow");
    }
    static void srTransfers(){
        cases++;var stalled=new Pipeline();var older=ps(0xf428,A,0x140000);stalled.issue(older,values(older,1));var loadedSr=ps(0x4307,A+2,0x140000);stalled.issue(loadedSr,values(loadedSr,1));
        check(stalled.ready(ps(9,A+4,0x140000))==6,"MA-stalled LDC.L last execution slot follows actual phase progress");
        stalled.advance(6);stalled.issue(ps(9,A+4,0x140000),Map.of());check(stalled.ready(ps(9,A+6,0x140000))==7,"actual final execution slot reserves one issue lane");stalled.advance(7);
        check(phase(stalled,PipelineStage.RESULT_COMMIT,A+2)==7,"MA-stalled SR commit actual7");
        cases++;var state=initial();state.fpscr=0x140000;state.r[2]=B;state.r[3]=B+16;state.writeRam(B,4,0x3ff00000,A-2);state.writeRam(B+4,4,0,A-2);state.writeRam(B+16,4,0,A-2);
        var graph=run(state,0xf428,0x4307,9,9,9,9,9,9,9,9);var steps=graph.pipelineStops().getLast().steps();
        check(steps.stream().anyMatch(x->x.pc()==A+4&&x.stage()==PipelineStage.ISSUE&&x.slot()==6),"production route MA-stalled SR next ID6");
        check(steps.stream().anyMatch(x->x.pc()==A+2&&x.stage()==PipelineStage.RESULT_COMMIT&&x.slot()==7),"production route MA-stalled SR commit7");
        // Explicit synthetic MA ownership interval, not a claimed instruction latency.
        var holder=new PipelineSpec(A-2,2,Set.of(),Set.of(),List.of(new ResourceUse("MA",2,5)),5,6,false,false,false,false,false,false,6,1,0);
        cases++;stalled=new Pipeline();stalled.issue(holder,Map.of());var storedSr=ps(0x4703,A,0x40000);stalled.issue(storedSr,values(storedSr,1));
        check(stalled.ready(ps(9,A+2,0x40000))==2,"STC.L final MA wait does not move completed EX issue boundary");stalled.advance(7);
        check(phase(stalled,PipelineStage.RESULT_COMMIT,A)==7,"STC.L synthetic MA hold commit7");
        cases++;stalled=new Pipeline();stalled.issue(holder,Map.of());var rte=ps(0x002b,A,0x40000);stalled.issue(rte,values(rte,1));
        check(stalled.ready(ps(9,A+2,0x40000))==11,"RTE delay-slot fence follows actual completed sequence after MA wait");
        cases++;stalled=new Pipeline();var compare=ps(0xf424,A,0xc0000);stalled.issue(compare,values(compare,1));
        check(stalled.ready(ps(9,A+2,0xc0000))==1,"partial two-slot E1 execution boundary must not round up to E1 end");
        for(int mode:new int[]{0x40000,0x140000})for(int suffix:new int[]{0x7000,0x3000}){
            cases++;var r=image(0x3421);w(r,A+2,suffix);var spec=pipelineSpec(new Sh2aDecoder().decode(r,A),mode);var p=new Pipeline();p.issue(spec,values(spec,1));
            check(p.ready(ps(9,A+4,mode))==((mode&FpuSemantics.SZ)==0?1:2),"32-bit multicycle cannot pair final slot with following CPU");
        }
        for(int op:new int[]{0x420e,0x4207,0x0202,0x4203}){cases++;check(ps(op,A,0x40000)!=null,"SR control profile absent");}
        cases++;var loaded=new Pipeline();var loadedSpec=ps(0x4207,A,0x40000);loaded.issue(loadedSpec,values(loadedSpec,1));
        check(loaded.ready(ps(0x0329,A+2,0x40000))==5,"memory-loaded SR flag read additional slot");
        check(loaded.ready(ps(0x4307,A+2,0x40000))==4,"SR WAW must not inherit flag-read additional slot");
        for(int value:new int[]{0,0xf0,0x2301,0x63f3})for(int reg:new int[]{0,2,15}){
            cases++;var s=initial();s.writeSr(0xf0);s.r[reg]=value;var g=run(s,0x400e|(reg<<8),9,9,9,9,9,9);var end=at(g,A+14);
            check(end.sr()==value,"LDC SR whole flags/mask commit");
            cases++;s=initial();s.writeSr(value);g=run(s,0x0002|(reg<<8),9,9,9,9);check(at(g,A+10).registers().get(reg)==value,"STC SR bits");
            cases++;s=initial();s.writeSr(0xf0);s.r[reg]=B;s.writeRam(B,4,value,A-2);g=run(s,0x4007|(reg<<8),9,9,9,9,9,9);end=at(g,A+14);
            check(end.sr()==value&&end.registers().get(reg)==B+4,"LDC.L SR memory/flags/address");
            cases++;s=initial();s.writeSr(value);s.r[reg]=B+4;g=run(s,0x4003|(reg<<8),9,9,9,9,9);end=at(g,A+12);
            check(ram(end,B)==value&&end.registers().get(reg)==B,"STC.L SR memory/address");
        }
        for(int[] c:new int[][]{{0x420e,2,3},{0x0202,1,2},{0x4207,4,5},{0x4203,1,3}}){
            cases++;var p=new Pipeline();var spec=ps(c[0],A,0x40000);p.issue(spec,values(spec,1));
            check(p.ready(ps(9,A+2,0x40000))==c[1],"SW8.9.6 SR next-ID diagram "+Integer.toHexString(c[0]));
            p.advance(c[1]);p.issue(ps(9,A+2,0x40000),Map.of());
            check(p.ready(ps(9,A+4,0x40000))==c[1]+1,"multicycle final step occupies one issue lane");
            p.advance(c[2]);check(phase(p,PipelineStage.RESULT_COMMIT,A)==c[2],"SR final phase commit");
        }
        cases++;var s=initial();s.writeSr(0xf0);var p=new Pipeline();p.initialize(s);var spec=ps(0x420e,A,0x40000);
        p.issue(spec,Map.of("SR",0,"T",0,"Q",0,"M",0,"CS",0));p.advance(2);p.restoreCommitted(s);
        check(s.interruptMask==15&&s.irqMaskChangeWindow==0,"SR load must not publish mask/window before completion");
        p.advance(3);p.restoreCommitted(s);check(s.interruptMask==0&&s.irqMaskChangeWindow==5,"SR mask completion arms existing abstract window");
        check(p.uncertainties().contains("UNVERIFIED_INTC_MASK_CHANGE_REPORT_SYNC"),"abstract mask window is not physical report timing");
        spec=ps(9,A+2,0x40000);p.issue(spec,Map.of());p.advance(4);p.restoreCommitted(s);check(s.irqMaskChangeWindow==4,"abstract window advances on CPU completion");
        cases++;s=initial();s.r[2]=B+2;var g=run(s,0x4207,9,9,9);check(g.systemEvents().stream().anyMatch(x->x.event().kind()==Kind.CPU_ADDRESS),"LDC.L SR H24");
        for(int bit=0;bit<8;bit++)for(boolean t:new boolean[]{false,true})for(int operation=0;operation<4;operation++){
            cases++;s=initial();s.r[2]=0xa5;s.t=t;int op=(operation==0?0x8620:operation==1?0x8628:operation==2?0x8720:0x8728)|bit;
            g=run(s,op,9,9,9);var end=at(g,A+8);int expected=operation==0?0xa5&~(1<<bit):operation==1?0xa5|(1<<bit):operation==2?(0xa5&~(1<<bit))|(t?1<<bit:0):0xa5;
            check(end.registers().get(2)==expected&&end.t()==(operation==3?((0xa5>>>bit)&1)!=0:t),"isolated BIT_REG literal oracle");
        }
    }
    public static void main(String[] args){stages();memoryMode();control();exceptionsAndCopy();cpuWaw();addressMemory();memoryHazards();doubleMemory();actualPhaseReadiness();shiftResource();fpSystemMemory();prTransfers();nonSrControl();flagRegisters();srTransfers();System.out.println("PIPELINE_STAGE44_ACCEPTANCE: PASS scenarios="+cases+" assertions="+assertions+"; buffering-dependent schedules conditional");}
}
