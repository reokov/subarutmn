package ecu.independent;

import java.util.List;

/** Synthetic control-flow check; not a Renesas simulator oracle. */
public final class SoftwareInterruptBoundaryAcceptance {
    private static void word(byte[] rom,int offset,int value) {
        rom[offset]=(byte)(value>>>8);
        rom[offset+1]=(byte)value;
    }
    private static void dword(byte[] rom,int offset,int value) {
        word(rom,offset,value>>>16);word(rom,offset+2,value);
    }
    private static void require(boolean value,String message) {
        if(!value)throw new AssertionError(message);
    }
    public static void main(String[] args) {
        var scheduler=new Sh7254rSoftwareInterruptScheduler();
        var cpu=new AbstractCpu(0xFFF9FFF0);
        cpu.softwareInterrupts[14]=1;
        require(scheduler.select(cpu,0x100).status()==
                Sh7254rSoftwareInterruptScheduler.Status.MASKED,"reset mask");
        cpu.writeSr(0);
        var decision=scheduler.select(cpu,0x100);
        require(decision.status()==Sh7254rSoftwareInterruptScheduler.Status.READY &&
                decision.event().priority()==15 &&
                decision.event().vectorOffset()==93*4,"SINT15 priority/vector");
        cpu.softwareInterrupts[14]=null;
        cpu.softwareInterrupts[0]=1;
        require(scheduler.select(cpu,0x100).status()==
                Sh7254rSoftwareInterruptScheduler.Status.INDETERMINATE_PENDING,
                "unknown high-priority source");

        // Reset -> LDC R2,SR -> BRA with SINTR1 write in delay slot ->
        // SINT1 handler clears request -> RTE to BRA destination.
        byte[] rom=new byte[0x200000];
        dword(rom,0,0x100);dword(rom,4,0xFFF9FFF0);
        word(rom,0x100,0xE200); // MOV #0,R2
        word(rom,0x102,0x420E); // LDC R2,SR
        word(rom,0x104,0xD10E); // MOV.L PC literal @0x140 -> R1
        word(rom,0x106,0xE001); // MOV #1,R0
        word(rom,0x108,0xA002); // BRA 0x110
        word(rom,0x10A,0x2100); // MOV.B R0,@R1 in delay slot
        word(rom,0x110,0x0009); // NOP
        word(rom,0x112,0x001B); // SLEEP (no hardware model)
        dword(rom,0x140,0xFFFE0810); // SINTR1
        dword(rom,107*4,0x200); // vector SINT1
        word(rom,0x200,0xE000); // MOV #0,R0
        word(rom,0x202,0x2100); // clear SINT1
        word(rom,0x204,0x002B); // RTE
        word(rom,0x206,0x0009); // delayed NOP
        var report=new FirmwareGraph().analyze(rom,100,List.of());
        require(report.edges().stream().anyMatch(e->e.from()==0x10A &&
                e.to()==0x200 &&
                e.kind().equals("SINT1_ACCEPTED_AFTER_INSTRUCTION")),
                "SINT must be dispatched after delay slot");
        require(report.edges().stream().anyMatch(e->e.to()==0x110 &&
                e.kind().equals("RTE_RESTORED_PC_SR")),
                "RTE must return to pending branch destination");
        require(report.edges().stream().noneMatch(e->e.from()==0x108 &&
                e.to()==0x200),"no interrupt before delay slot");
        var bankCpu = new AbstractCpu(0xFFF9FFF0);
        bankCpu.writeSr(0);
        bankCpu.bankEnable=1;
        bankCpu.nextBank=0;
        bankCpu.r[0]=0x12345678;
        bankCpu.softwareInterrupts[0]=1;
        var bankEvent=scheduler.select(bankCpu,0x110);
        require(bankEvent.status()==Sh7254rSoftwareInterruptScheduler.Status.READY,
                "bank-enabled SINT request");
        var bus=new Sh7254rMemoryMap(rom);
        var bankEntry=new Sh7254rInterruptController().enter(bankCpu,bankEvent.event(),bus);
        require(bankEntry.disposition()==Sh7254rInterruptController.Disposition.ENTERED,
                "banked entry valid");
        require(bankCpu.nextBank==1 && bankCpu.readBank(0)==0x12345678,
                "bank must preserve R0");
        bankCpu.r[0]=999;
        require(bankCpu.restoreBank() && bankCpu.r[0]==0x12345678 &&
                bankCpu.nextBank==0,"RESBANK must restore saved R0");
        System.out.println("SOFTWARE_IRQ_BOUNDARY_ACCEPTANCE: PASS (synthetic, not cycle exact)");
    }
}
