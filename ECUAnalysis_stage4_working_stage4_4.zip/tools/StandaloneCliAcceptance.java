import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Actual packaged CLI subprocess on generated data, never on files in firmware/. */
public final class StandaloneCliAcceptance {
    private StandaloneCliAcceptance() {}
    private static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception{
        Path root=Path.of("build/cli-acceptance");Files.createDirectories(root);
        Path work=Files.createTempDirectory(root,"synthetic-");
        byte[] rom=new byte[0x200000];
        // Reset PC 0x1000, SP 0xFFF90000; MOV #7,R0; SLEEP (no timing claim).
        rom[2]=0x10;rom[4]=(byte)0xFF;rom[5]=(byte)0xF9;
        rom[0x1000]=(byte)0xE0;rom[0x1001]=7;rom[0x1003]=0x1B;
        Path input=work.resolve("generated-synthetic.bin"),out=work.resolve("reports");
        Files.write(input,rom);
        String hash=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(rom));
        for(int run=0;run<2;run++){
            Path log=work.resolve("cli-"+run+".txt");
            var p=new ProcessBuilder(Path.of(System.getProperty("java.home"),"bin/java").toString(),
                    "-jar","build/ecu-analysis-cli-unreleased.jar",input.toString(),out.toString(),"--limit","16")
                    .redirectErrorStream(true).redirectOutput(log.toFile()).start();
            if(!p.waitFor(30,TimeUnit.SECONDS)){p.destroyForcibly();throw new AssertionError("CLI timeout");}
            require(p.exitValue()==0,"CLI failed: "+Files.readString(log));
        }
        List<Path> reports;
        try(var stream=Files.list(out)){reports=stream.filter(Files::isDirectory).toList();}
        require(reports.size()==2,"CLI must preserve the previous report");
        for(Path report:reports){
            String metadata=Files.readString(report.resolve("metadata.txt"),StandardCharsets.UTF_8);
            require(metadata.contains("sha256="+hash+"\n"),"wrong input provenance");
            require(metadata.contains("instruction_count=2\n")&&metadata.contains("truncated=false\n"),"incomplete synthetic CLI traversal");
            String instructions=Files.readString(report.resolve("instructions.csv"));
            require(instructions.contains("0x00001000,2,0x0000E007,MOV #imm,R0")&&
                    instructions.contains("0x00001002,2,0x0000001B,SLEEP"),"decoded output missing");
            require(!instructions.contains("CONFIRMED_CODE"),"synthetic analysis became observed execution");
        }
        require(Arrays.equals(rom,Files.readAllBytes(input)),"CLI changed input");
        System.out.println("STANDALONE_CLI_ACCEPTANCE: PASS (packaged jar, synthetic input, two preserved reports)");
        System.out.println("synthetic_input="+input+" output="+out);
    }
}
