package ecu.ghidra;

import docking.ActionContext;
import docking.action.DockingAction;
import docking.action.MenuData;
import ecu.independent.FirmwareGraph;
import ecu.independent.ReportWriter;
import ghidra.app.plugin.PluginCategoryNames;
import ghidra.app.plugin.ProgramPlugin;
import ghidra.framework.plugintool.PluginInfo;
import ghidra.framework.plugintool.PluginTool;
import ghidra.framework.plugintool.util.PluginStatus;
import ghidra.program.model.address.Address;
import ghidra.program.model.mem.Memory;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import java.nio.file.Path;

/**
 * Ghidra is only a ROM container and GUI host. Neither its language provider,
 * SLEIGH instructions, auto-analyzer, listing, nor decompiler is consulted.
 * The Program is never modified by this extension.
 */
@PluginInfo(status=PluginStatus.UNSTABLE,packageName="ECUAnalysis",
    category=PluginCategoryNames.ANALYSIS,
    shortDescription="ECUAnalysis 0.6.0 independent SH7254R research",
    description="Independent partial SH-2A decoder, conservative abstract CFG and ROM-read provenance")
public final class IndependentEcuPlugin extends ProgramPlugin {
    public IndependentEcuPlugin(PluginTool tool) {
        super(tool);
        DockingAction action = new DockingAction("Analyze opened SH7254R ROM independently",getName()) {
            @Override public void actionPerformed(ActionContext context) { analyze(); }
        };
        action.setMenuBarData(new MenuData(new String[]{"Tools","ECU Analysis",
                "Analyze SH7254R (independent)"}));
        tool.addAction(action);
    }
    private void analyze() {
        if (currentProgram==null) {message("No program opened.");return;}
        try {
            Memory memory=currentProgram.getMemory();
            Address base=currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(0);
            boolean large=memory.contains(base.add(0x27FFFFL));
            int size=large?0x280000:0x200000;
            if (!memory.contains(base.add(size-1L)))
                throw new IllegalArgumentException("Full 2 MiB / 2.5 MiB user MAT not mapped from address 0");
            byte[] rom=new byte[size];
            // Read in bounded chunks: do not require the user ROM to be one Ghidra block.
            for (int off=0;off<size;off+=65536) {
                int count=Math.min(65536,size-off);
                byte[] chunk=new byte[count];
                int read=memory.getBytes(base.add(off),chunk);
                if (read!=count)
                    throw new IllegalArgumentException("Unmapped ROM byte(s) at offset 0x"+Integer.toHexString(off));
                System.arraycopy(chunk,0,rom,off,count);
            }
            JFileChooser chooser=new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.setDialogTitle("Independent SH7254R analysis output directory");
            if (chooser.showSaveDialog(null)!=JFileChooser.APPROVE_OPTION) return;
            Path destination=chooser.getSelectedFile().toPath();
            new SwingWorker<Path,Void>() {
                private FirmwareGraph.Report result;
                @Override protected Path doInBackground() throws Exception {
                    result=new FirmwareGraph().analyze(rom,250_000);
                    return ReportWriter.write(result,rom,destination);
                }
                @Override protected void done() {
                    try {
                        Path folder=get();
                        message("Report: "+folder+"\nReachable instruction candidates: "+
                            result.instructions().size()+"\nIssues: "+result.issues().size()+
                            "\nTruncated: "+result.truncated()+
                            "\nThis is NOT a complete SH-2A disassembly or emulation.");
                    } catch(Exception ex) {
                        message("Independent analysis aborted: "+ex.getMessage());
                    }
                }
            }.execute();
        } catch(Exception ex) {message("Unable to read ROM: "+ex.getMessage());}
    }
    private static void message(String text) {
        SwingUtilities.invokeLater(()->JOptionPane.showMessageDialog(null,text,
                "ECUAnalysis 0.6.0",JOptionPane.INFORMATION_MESSAGE));
    }
}
