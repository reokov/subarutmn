package ecu.independent;

/**
 * Explicit-source interrupt-entry primitive, not a peripheral scheduler.
 * Renesas R01UH0480EJ0400 Rev.4.00 sec. 8.6 and REJ09B0051-0300
 * Rev.3.00 sec. 3.1.3/3.6. The handler pointer is read from VBR+offset,
 * not taken to be the vector-table offset itself.
 *
 * No state mutation occurs when any prerequisite is unknown or invalid.
 */
final class Sh7254rInterruptController {
    enum Disposition {
        ENTERED, MASKED, UNKNOWN_SR, UNKNOWN_VBR, INVALID_STACK,
        UNKNOWN_BANK_CONFIGURATION, INVALID_BANK_MODE,
        BANK_OVERFLOW_NOT_EMULATED, BANK_OVERFLOW_EXCEPTION_NOT_ROUTED,
        INVALID_PRIORITY, INVALID_VECTOR, HANDLER_UNAVAILABLE,
        UNKNOWN_SP, VBR_NOT_ALIGNED
    }
    record Event(int interruptedPc, int vectorOffset, int priority,
                 boolean nmi, boolean bankEligible) {}
    record Entry(Disposition disposition,int vectorOffset,Integer handler,Integer initialVector,Integer initialHandler,Integer stackingFaultAddress) {
        Entry(Disposition disposition,int vectorOffset,Integer handler){this(disposition,vectorOffset,handler,null,null,null);}
    }

    Entry enter(AbstractCpu state,Event event,Sh7254rMemoryMap memory) {
        int priority=event.priority();
        if(event.nmi() ? priority!=16 : priority<0 || priority>15)
            return failed(Disposition.INVALID_PRIORITY,event);
        if(event.vectorOffset()==0x30 && priority!=15)return failed(Disposition.INVALID_PRIORITY,event);
        if(!SystemExceptionModel.assignedInterruptVector(event.vectorOffset()))return failed(Disposition.INVALID_VECTOR,event);
        int vector=event.vectorOffset()/4;
        if((vector==79||vector==82)&&priority!=15 || vector>=93&&vector<=107&&priority!=108-vector)return failed(Disposition.INVALID_PRIORITY,event);
        if((event.vectorOffset()&3)!=0 || event.vectorOffset()<0 ||
                event.vectorOffset()>0x7FC ||
                (event.nmi() && event.vectorOffset()!=0x2C))
            return failed(Disposition.INVALID_VECTOR,event);
        Integer sr=state.readSr(),sp=state.r[15];
        if(!event.nmi() && state.interruptMask==null)
            return failed(Disposition.UNKNOWN_SR,event);
        if(!event.nmi() && priority<=state.interruptMask)
            return failed(Disposition.MASKED,event);
        // Bounds verified against REJ09B0051-0300 Rev.3.00 sec.3.10.1 p.32 (SP must be a
        // multiple of 4) and the pre-decrement-before-write stacking order: SP equal to
        // SRAM_END_EXCLUSIVE (reset SP 0xFFFA0000 in all four reviewed BINs) is legal
        // because SP-4 = 0xFFF9FFFC and SP-8 = 0xFFF9FFF8 are inside SRAM, while the
        // reserved gap 0xFFFA0000-0xFFFBFFFF (R01UH0480EJ0400 Rev.4.00 sec.5) is never
        // written; SP < SRAM_START+8 or a misaligned SP would fault such a write.
        if(sp==null ||
                Integer.toUnsignedLong(sp)<Sh7254rMemoryMap.SRAM_START+((sp&3)!=0?16:8) ||
                Integer.toUnsignedLong(sp)>Sh7254rMemoryMap.SRAM_END_EXCLUSIVE)
            return failed(Disposition.INVALID_STACK,event);
        if(state.vbr==null)return failed(Disposition.UNKNOWN_VBR,event);
        if((state.vbr&3)!=0)return failed(Disposition.VBR_NOT_ALIGNED,event);
        if((sp&3)!=0&&stackingHandler(state,memory)==null)return failed(Disposition.HANDLER_UNAVAILABLE,event);
        boolean useBank=false;
        if(event.bankEligible() && !event.nmi() && event.vectorOffset()!=0x30) {
            // HW8.3.6: BE00 ignores IBCR; BE01 does not consult its priority mask.
            // BOVE matters only when the selected bank actually overflows.
            if(state.bankEnable==null || state.bankEnable==3&&state.bankPriorityMask==null)
                return failed(Disposition.UNKNOWN_BANK_CONFIGURATION,event);
            if(state.bankEnable==2)
                return failed(Disposition.INVALID_BANK_MODE,event);
            useBank=state.bankEnable==1 ||
                    (state.bankEnable==3 && (state.bankPriorityMask&(1<<priority))!=0);
        }
        boolean overflowStack=false;
        if(useBank) {
            if(state.nextBank==null||state.nextBank<0||state.nextBank>15)return failed(Disposition.UNKNOWN_BANK_CONFIGURATION,event);
            if(state.nextBank==15) {
                if(Boolean.TRUE.equals(state.bankOverflowException)) {
                    var entry=raiseInstructionException(state,0x3c,event.interruptedPc(),memory);
                    if(entry.disposition()==Disposition.ENTERED){state.interruptMask=priority;state.sr=null;}
                    return entry;
                }
                if(state.bankOverflowException==null)return failed(Disposition.UNKNOWN_BANK_CONFIGURATION,event);
                if(Integer.toUnsignedLong(sp)<Sh7254rMemoryMap.SRAM_START+((sp&3)!=0?92:84))return failed(Disposition.INVALID_STACK,event);
                overflowStack=true;
            }
        }

        long vectorAddress=Integer.toUnsignedLong(state.vbr)+event.vectorOffset();
        if(vectorAddress>0xFFFF_FFFFL)
            return failed(Disposition.INVALID_VECTOR,event);
        Integer handler=null;
        if(memory.romRange(vectorAddress,4))handler=memory.readRom(vectorAddress,4);
        else if(vectorAddress>=Sh7254rMemoryMap.SRAM_START &&
                vectorAddress+4<=Sh7254rMemoryMap.SRAM_END_EXCLUSIVE)
            handler=state.readRam((int)vectorAddress,4);
        if(handler==null || !availableHandler(state,memory,handler))
            return failed(Disposition.HANDLER_UNAVAILABLE,event);

        // All fallible prerequisites have been verified: commit atomically.
        if(useBank&&!overflowStack)state.saveBank(event.vectorOffset());
        pushFrame(state,sr,event.interruptedPc(),event.interruptedPc());
        // REJ09B0051-0300 Rev.3.00 sec.3.6.3 p.26 (txt 2784-2786): the priority level of the
        // accepted interrupt is written to SR.I3-I0; for NMI, although its level is 16, H'F
        // (level 15) is written. Leaving SR.I unchanged would let lower-priority interrupts be
        // accepted inside an NMI handler, which hardware forbids.
        if(overflowStack) {
            // SW7.3.3 p329 /HW8.8.3 p172: stack banked state after SR/PC.
            Integer[] values=new Integer[19];values[0]=state.macl;values[1]=state.mach;
            values[2]=state.gbr;values[3]=state.pr;
            for(int i=0;i<15;i++)values[i+4]=state.r[14-i];
            int pointer=sp-8;
            for(Integer value:values){pointer-=4;state.writeRam(pointer,4,(sp&3)!=0?null:value,event.interruptedPc());}
            state.r[15]=pointer;
        }
        int maskBits=event.nmi()?0xF:priority;
        state.interruptMask=maskBits;state.sr=null;
        if(overflowStack)state.bankOverflow=true;
        if((sp&3)!=0)return chainStackingError(state,event.vectorOffset(),handler,sp-4,event.interruptedPc(),memory);
        return new Entry(Disposition.ENTERED,event.vectorOffset(),handler);
    }
    /**
     * Instruction (synchronous) exception entry: REJ09B0051-0300 Rev.3.00 sec.3.1.2(2)
     * p.18 — register bank saving is NOT performed for instruction exceptions and SR.I
     * bits are NOT modified; SR is stacked first, then PC (sec.3.7.2 p.27 TRAPA,
     * sec.3.7.3 p.28 slot illegal, sec.3.7.5 p.28 integer division: stacked PC = start
     * address of the dividing instruction itself). The vector is fetched from VBR+offset
     * (sec.3.1.3 p.18 table 3.3); VBR must be a multiple of 4 (sec.3.10.2 p.32) and SP
     * must be a multiple of 4 (sec.3.10.1 p.32). The jump is not a delayed branch.
     * No state mutation occurs when any prerequisite is unknown; the caller then stops
     * the path instead of fabricating a continuation.
     */
    private static boolean availableHandler(AbstractCpu state,Sh7254rMemoryMap memory,int handler) {
        if(memory.cpuFetchAddressError(handler))return true; // Entry completes before handler fetch faults.
        long address=Integer.toUnsignedLong(handler);
        return (handler&1)==0 && (memory.romRange(address,2) ||
                address>=Sh7254rMemoryMap.SRAM_START && address+2<=Sh7254rMemoryMap.SRAM_END_EXCLUSIVE
                && state.readRam(handler,2)!=null);
    }
    Entry raiseInstructionException(AbstractCpu state,int vectorOffset,int stackedPc,
                                    Sh7254rMemoryMap memory) {
        if(vectorOffset<0 || vectorOffset>0x7FC || (vectorOffset&3)!=0)
            return new Entry(Disposition.INVALID_VECTOR,vectorOffset,null);
        Integer sr=state.readSr(),sp=state.r[15];
        if(sp==null)return new Entry(Disposition.UNKNOWN_SP,vectorOffset,null);
        if(state.vbr==null)return new Entry(Disposition.UNKNOWN_VBR,vectorOffset,null);
        if((state.vbr&3)!=0)return new Entry(Disposition.VBR_NOT_ALIGNED,vectorOffset,null);
        long unsignedSp=Integer.toUnsignedLong(sp);
        if(unsignedSp<Sh7254rMemoryMap.SRAM_START+((sp&3)!=0&&vectorOffset!=0x24?16:8))return new Entry(Disposition.INVALID_STACK,vectorOffset,null);
        if(unsignedSp>Sh7254rMemoryMap.SRAM_END_EXCLUSIVE)return new Entry(Disposition.INVALID_STACK,vectorOffset,null);
        long vectorAddress=Integer.toUnsignedLong(state.vbr)+vectorOffset;
        if(vectorAddress>0xFFFF_FFFFL)return new Entry(Disposition.INVALID_VECTOR,vectorOffset,null);
        Integer handler=null;
        if(memory.romRange(vectorAddress,4))handler=memory.readRom(vectorAddress,4);
        else if(vectorAddress>=Sh7254rMemoryMap.SRAM_START &&
                vectorAddress+4<=Sh7254rMemoryMap.SRAM_END_EXCLUSIVE)
            handler=state.readRam((int)vectorAddress,4);
        if(handler==null || !availableHandler(state,memory,handler))
            return new Entry(Disposition.HANDLER_UNAVAILABLE,vectorOffset,null);
        if((sp&3)!=0&&vectorOffset!=0x24&&stackingHandler(state,memory)==null)
            return new Entry(Disposition.HANDLER_UNAVAILABLE,vectorOffset,null);
        pushFrame(state,sr,stackedPc,stackedPc);
        if((sp&3)!=0)return chainStackingError(state,vectorOffset,handler,sp-4,stackedPc,memory);
        return new Entry(Disposition.ENTERED,vectorOffset,handler);
    }
    private static void pushFrame(AbstractCpu state,Integer sr,int pc,int writer) {
        int sp=state.r[15];boolean unaligned=(sp&3)!=0;
        state.r[15]=sp-4;state.writeRam(sp-4,4,unaligned?null:sr,writer);
        state.r[15]=sp-8;state.writeRam(sp-8,4,unaligned?null:Integer.valueOf(pc),writer);
    }
    private static Integer stackingHandler(AbstractCpu state,Sh7254rMemoryMap memory) {
        long address=Integer.toUnsignedLong(state.vbr)+0x24;
        Integer h=memory.romRange(address,4)?memory.readRom(address,4):
                address>=Sh7254rMemoryMap.SRAM_START&&address+4<=Sh7254rMemoryMap.SRAM_END_EXCLUSIVE?state.readRam((int)address,4):null;
        return h!=null&&availableHandler(state,memory,h)?h:null;
    }
    private static Entry chainStackingError(AbstractCpu state,int vector,int handler,int fault,int writer,Sh7254rMemoryMap memory) {
        // HW7.9.3: writes occur with undefined data; a second H24 stacking fault is suppressed.
        if(vector==0x24)return new Entry(Disposition.ENTERED,vector,handler,null,null,fault);
        Integer target=stackingHandler(state,memory);
        if(target==null)throw new IllegalStateException("H24 preflight missing");
        pushFrame(state,state.readSr(),handler,writer);
        return new Entry(Disposition.ENTERED,0x24,target,vector,handler,fault);
    }
    private static Entry failed(Disposition why,Event event) {
        return new Entry(why,event.vectorOffset(),null);
    }
}
