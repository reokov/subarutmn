package ecu.independent;

import java.math.BigInteger;

/** Exact rational arithmetic and integer-only binary32/64 rounding.
 * No host floating point arithmetic participates in results or exception decisions. */
final class FpuBinary {
    private FpuBinary() {}
    record Rational(BigInteger num, BigInteger den) {
        Rational {
            if (den.signum() <= 0) throw new IllegalArgumentException("denominator");
        }
        Rational add(Rational b) { return new Rational(num.multiply(b.den).add(b.num.multiply(den)),den.multiply(b.den)); }
        Rational negate() { return new Rational(num.negate(),den); }
        Rational multiply(Rational b) { return new Rational(num.multiply(b.num),den.multiply(b.den)); }
        Rational divide(Rational b) { return new Rational(num.multiply(b.den).multiply(BigInteger.valueOf(b.num.signum())),den.multiply(b.num.abs())); }
    }
    record Rounded(long bits, boolean inexact, boolean overflow, boolean tiny) {}
    static long sign(boolean dbl) { return dbl?Long.MIN_VALUE:0x80000000L; }
    static long infinity(boolean dbl) { return dbl?0x7ff0000000000000L:0x7f800000L; }
    static long qnan(boolean dbl) { return dbl?0x7ff7ffffffffffffL:0x7fbfffffL; }
    static long fractionMask(boolean dbl) { return dbl?0xfffffffffffffL:0x7fffffL; }
    static boolean nan(long b,boolean dbl) { return (b&~sign(dbl))>infinity(dbl); }
    // SH-2A uses the inverse of the usual host IEEE quiet/signaling bit convention.
    static boolean signaling(long b,boolean dbl) { return nan(b,dbl)&&(b&(dbl?0x8000000000000L:0x400000L))!=0; }
    static boolean inf(long b,boolean dbl) { return (b&~sign(dbl))==infinity(dbl); }
    static boolean zero(long b,boolean dbl) { return (b&~sign(dbl))==0; }
    static long flush(long b,boolean dbl) {
        return (b&infinity(dbl))==0?b&sign(dbl):b;
    }
    static Rational value(long b,boolean dbl) {
        int f=dbl?52:23,bias=dbl?1023:127;
        int e=(int)((b&infinity(dbl))>>>f);
        BigInteger n=BigInteger.valueOf(b&fractionMask(dbl));
        if(e!=0)n=n.setBit(f);
        int shift=(e==0?1:e)-bias-f;
        if((b&sign(dbl))!=0)n=n.negate();
        return shift>=0?new Rational(n.shiftLeft(shift),BigInteger.ONE):new Rational(n,BigInteger.ONE.shiftLeft(-shift));
    }
    private static int exponent(BigInteger n,BigInteger d) {
        int e=n.bitLength()-d.bitLength();
        if((e>=0?n.compareTo(d.shiftLeft(e)):n.shiftLeft(-e).compareTo(d))<0)e--;
        return e;
    }
    static Rounded round(Rational x,boolean dbl,int rm,boolean negativeZero,boolean sqrt) {
        int f=dbl?52:23,bias=dbl?1023:127,emin=1-bias,emax=bias;
        boolean negative=x.num.signum()<0 || (x.num.signum()==0&&negativeZero);
        long sign=negative?sign(dbl):0;
        BigInteger n=x.num.abs(),d=x.den;
        if(n.signum()==0)return new Rounded(sign,false,false,true);
        int e=exponent(n,d);
        if(sqrt)e=Math.floorDiv(e,2);
        int scale=f-Math.max(e,emin);
        int shift=sqrt?2*scale:scale;
        BigInteger a=shift>=0?n.shiftLeft(shift):n;
        BigInteger b=shift>=0?d:d.shiftLeft(-shift);
        BigInteger q=sqrt?a.divide(b).sqrt():a.divide(b);
        boolean inexact=!a.equals((sqrt?q.multiply(q):q).multiply(b));
        if(rm==0&&inexact) {
            int cmp=sqrt?a.shiftLeft(2).compareTo(q.shiftLeft(1).add(BigInteger.ONE).pow(2).multiply(b)):
                    a.subtract(q.multiply(b)).shiftLeft(1).compareTo(b);
            if(cmp>0||(cmp==0&&q.testBit(0)))q=q.add(BigInteger.ONE);
        }
        if(q.bitLength()>f+1){q=q.shiftRight(1);e++;}
        if(e>emax) return new Rounded(sign|(rm==0?infinity(dbl):infinity(dbl)-1),true,true,false);
        boolean tiny=q.bitLength()<=f && e<emin;
        long bits=tiny?q.longValue():((long)(Math.max(e,emin)+bias)<<f)|(q.longValue()&fractionMask(dbl));
        return new Rounded(sign|bits,inexact,false,tiny);
    }
}
