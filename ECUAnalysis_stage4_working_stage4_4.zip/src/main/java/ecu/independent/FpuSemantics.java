package ecu.independent;

import java.math.BigInteger;

/** SH-2A FPU execution. REJ09B0051-0300 §§2.2.5, 3.7.6, 6.2 helpers,
 * 6.5. Exception generation is separate from FirmwareGraph's potential acceptance.
 * DN is fixed to one on SH72543R/44R; RM 2/3 are reserved. */
final class FpuSemantics {
    static final int PR=0x80000,SZ=0x100000,QIS=0x400000,DN=0x40000,CAUSE=0x3f000;
    static final int V=0x10040,Z=0x8020,O=0x4010,U=0x2008,I=0x1004;
    private FpuSemantics() {}
    private static Long read(AbstractCpu s,int n,boolean dbl) {
        if(n<0||n>=16||s.fr[n]==null)return null;
        if(!dbl)return Integer.toUnsignedLong(s.fr[n]);
        if((n&1)!=0||n==15||s.fr[n+1]==null)return null;
        return Integer.toUnsignedLong(s.fr[n])<<32|Integer.toUnsignedLong(s.fr[n+1]);
    }
    private static void write(AbstractCpu s,int n,boolean dbl,long b,boolean fpul) {
        if(fpul)s.fpul=(int)b;
        else if(dbl){s.fr[n]=(int)(b>>>32);s.fr[n+1]=(int)b;}
        else s.fr[n]=(int)b;
    }
    private static int enabled(int mode) {
        return ((mode&0xf80)<<5)|((mode&0xf80)>>>5);
    }
    private static String commit(AbstractCpu s,int mode,int flags,int trapMask,int n,boolean dbl,long bits,boolean fpul) {
        if((mode&trapMask)!=0||(flags&enabled(mode)&CAUSE)!=0)return exceptionGenerated(s,mode,flags);
        s.fpscr=(mode&~CAUSE)|flags;
        write(s,n,dbl,bits,fpul);
        return null;
    }
    private static String invalid(AbstractCpu s,int mode,int n,boolean dbl,boolean fpul) {
        return commit(s,mode,V,0,n,dbl,FpuBinary.qnan(dbl),fpul);
    }
    private static String rounded(AbstractCpu s,int mode,int n,boolean dbl,boolean fpul,FpuBinary.Rational exact,
                                  boolean negativeZero,int trapMask,boolean sqrt) {
        var r=FpuBinary.round(exact,dbl,mode&3,negativeZero,sqrt);
        int flags=r.inexact()?I:0;
        long bits=r.bits();
        if(r.overflow())flags|=O|I;
        // §6.2 check_*_exception: a nonzero subnormal output is flushed, even
        // when exact. Underflow is set if the tiny result is inexact after flush.
        if(r.tiny()&&!FpuBinary.zero(bits,dbl)){bits&=FpuBinary.sign(dbl);flags|=I;}
        if(r.tiny()&&(flags&I)!=0)flags|=U;
        return commit(s,mode,flags,trapMask,n,dbl,bits,fpul);
    }
    interface Memory {
        boolean aligned(Integer address,int width);
        Integer load(Integer address);
        void store(Integer address,Integer value);
    }
    static String apply(AbstractCpu s,Sh2aDecoder.Instruction inst) { return apply(s,inst,null); }
    static String apply(AbstractCpu s,Sh2aDecoder.Instruction inst,Memory memory) {
        return switch(inst.operation()) {
            case FPU_ARITHMETIC,FPU_COMPARE,FPU_CONVERT,FPU_SQRT,FPU_FMAC -> numeric(s,inst);
            default -> transfer(s,inst,memory);
        };
    }
    private static Integer binary(Integer a,Integer b,java.util.function.IntBinaryOperator operation) {
        return a==null||b==null?null:operation.applyAsInt(a,b);
    }
    private static String transfer(AbstractCpu s,Sh2aDecoder.Instruction i,Memory memory) {
        int n=i.regN(),m=i.regM(),d=i.imm();
        if(memory==null && (i.operation()==Sh2aDecoder.Operation.FPU_MEM_LOAD ||
                i.operation()==Sh2aDecoder.Operation.FPU_MEM_STORE ||
                i.operation()==Sh2aDecoder.Operation.FPU_REGISTER_TRANSFER && m>=4))return "FPU_MEMORY_CONTEXT_REQUIRED";
        switch(i.operation()) {
            case FPU_REGISTER_TRANSFER -> {
                switch(m) {
                    case 0 -> s.r[n]=s.fpscr;
                    case 1 -> s.r[n]=s.fpul;
                    case 2 -> s.writeFpscr(s.r[n]);
                    case 3 -> s.fpul=s.r[n];
                    case 4,5 -> {
                        Integer addr=binary(s.r[n],-4,(a,b)->a+b);
                        if(!memory.aligned(addr,4))return "FPU_DATA_ADDRESS_ERROR";
                        s.r[n]=addr;
                        memory.store(addr,m==4?s.fpscr:s.fpul);
                    }
                    case 6,7 -> {
                        if(!memory.aligned(s.r[n],4))return "FPU_DATA_ADDRESS_ERROR";
                        Integer value=memory.load(s.r[n]);
                        if(m==6)s.writeFpscr(value);else s.fpul=value;
                        s.r[n]=binary(s.r[n],4,(a,b)->a+b);
                    }
                    default -> throw new IllegalStateException("Unsupported FPU control transfer");
                }
            }
            case FPU_MODE -> s.fpscr=s.fpscr==null?null:s.fpscr^0x00100000; // FSCHG
            case FPU_IMMEDIATE -> s.fr[n]=i.mnemonic().startsWith("FLDI0")?0:0x3F800000;
            case FPU_SIGN -> {
                Integer bits=s.fr[n];
                if(bits!=null) s.fr[n]=i.mnemonic().startsWith("FABS")?
                        bits&0x7FFFFFFF:bits^0x80000000;
            }
            case FPU_REG_MOVE -> {
                if(i.mnemonic().startsWith("FSTS"))s.fr[n]=s.fpul;
                else if(i.mnemonic().startsWith("FLDS"))s.fpul=s.fr[n];
                else if(s.fpscr!=null && (s.fpscr&FpuSemantics.SZ)!=0) {
                    if((n&1)!=0 || (m&1)!=0) {return "FMOV_ODD_DOUBLE_REGISTER";}
                    s.fr[n]=s.fr[m];s.fr[n+1]=s.fr[m+1];
                } else s.fr[n]=s.fr[m];
            }
            case FPU_MEM_LOAD -> {
                int width=s.fpscr!=null && (s.fpscr&FpuSemantics.SZ)!=0?8:4;
                int byteOffset=i.width()==4 && i.operandWidth()==0 ? d*width : d;
                Integer addr=d==-1 && i.width()==2?binary(s.r[m],s.r[0],(a,b)->a+b):
                        binary(s.r[m],byteOffset,(a,b)->a+b);
                if(width==8 && (n&1)!=0) {return "FMOV_DOUBLE_ODD_REGISTER";}
                if(!memory.aligned(addr,width))return "FPU_DATA_ADDRESS_ERROR";
                s.fr[n]=memory.load(addr);
                if(width==8)s.fr[n+1]=memory.load(addr==null?null:addr+4);
                if(i.postIncrement())s.r[m]=binary(s.r[m],width,(a,b)->a+b);
            }
            case FPU_MEM_STORE -> {
                int width=s.fpscr!=null && (s.fpscr&FpuSemantics.SZ)!=0?8:4;
                int byteOffset=i.width()==4 && i.operandWidth()==0 ? d*width : d;
                Integer addr=d==-1 && i.width()==2?binary(s.r[n],s.r[0],(a,b)->a+b):
                        binary(s.r[n],byteOffset,(a,b)->a+b);
                if(width==8 && (m&1)!=0) {return "FMOV_DOUBLE_ODD_REGISTER";}
                if(i.preDecrement()) {
                    addr=binary(s.r[n],-width,(a,b)->a+b);
                }
                if(!memory.aligned(addr,width))return "FPU_DATA_ADDRESS_ERROR";
                if(i.preDecrement())s.r[n]=addr;
                memory.store(addr,s.fr[m]);
                if(width==8)memory.store(addr==null?null:addr+4,s.fr[m+1]);
            }
            default -> { return "FPU_OPERATION_NOT_HANDLED"; }
        }
        return null;
    }
    private static String numeric(AbstractCpu s,Sh2aDecoder.Instruction inst) {
        if(s.fpscr==null)return "FPSCR_UNKNOWN";
        int mode=s.fpscr,n=inst.regN(),m=inst.regM();
        if((mode&3)>1)return "FPSCR_ROUNDING_RESERVED";
        if((mode&DN)==0)return "FPSCR_DN0_RESERVED";
        boolean dbl=(mode&PR)!=0;
        var op=inst.operation();
        String name=inst.mnemonic().split(" ")[0];
        if(dbl&&(n&1)!=0)return "ODD_DOUBLE_DESTINATION_RESERVED";
        if(dbl&&(op==Sh2aDecoder.Operation.FPU_ARITHMETIC||op==Sh2aDecoder.Operation.FPU_COMPARE)&&(m&1)!=0)
            return "ODD_DOUBLE_SOURCE_RESERVED";
        if(op==Sh2aDecoder.Operation.FPU_CONVERT&&name.equals("FLOAT")) {
            if(s.fpul==null)return "FPUL_INPUT_UNKNOWN";
            return rounded(s,mode,n,dbl,false,new FpuBinary.Rational(BigInteger.valueOf(s.fpul),BigInteger.ONE),false,dbl?0:0x80,false);
        }
        if(op==Sh2aDecoder.Operation.FPU_FMAC&&dbl)return "FMAC_DOUBLE_UNDEFINED_BY_RENESAS";
        if((name.equals("FCNVSD")||name.equals("FCNVDS"))&&!dbl)return name+"_REQUIRES_PR1";
        boolean srcDouble=dbl&&!name.equals("FCNVSD");
        Long raw=name.equals("FCNVSD")?(s.fpul==null?null:Integer.toUnsignedLong(s.fpul)):read(s,n,srcDouble);
        boolean binary=op==Sh2aDecoder.Operation.FPU_ARITHMETIC||op==Sh2aDecoder.Operation.FPU_COMPARE||op==Sh2aDecoder.Operation.FPU_FMAC;
        Long rawB=binary?read(s,m,dbl):Long.valueOf(0L);
        Long rawC=op==Sh2aDecoder.Operation.FPU_FMAC?read(s,0,false):Long.valueOf(0L);
        if(raw==null||rawB==null||rawC==null)return "FPU_INPUT_UNKNOWN";
        long a=FpuBinary.flush(raw,srcDouble),b=FpuBinary.flush(rawB,dbl),c=FpuBinary.flush(rawC,false);
        // QIS explicitly adds qNaN/infinity source traps; it does not affect moves/signs.
        if((mode&(QIS|0x800))==(QIS|0x800)&&
                (special(a,srcDouble)||(binary&&special(b,dbl))||(op==Sh2aDecoder.Operation.FPU_FMAC&&special(c,false))))
            return exceptionGenerated(s,mode,V);
        boolean an=FpuBinary.nan(a,srcDouble),bn=binary&&FpuBinary.nan(b,dbl),cn=op==Sh2aDecoder.Operation.FPU_FMAC&&FpuBinary.nan(c,false);
        boolean sn=FpuBinary.signaling(a,srcDouble)||(binary&&FpuBinary.signaling(b,dbl))||(op==Sh2aDecoder.Operation.FPU_FMAC&&FpuBinary.signaling(c,false));
        boolean ai=FpuBinary.inf(a,srcDouble),bi=binary&&FpuBinary.inf(b,dbl),ci=op==Sh2aDecoder.Operation.FPU_FMAC&&FpuBinary.inf(c,false);
        boolean az=FpuBinary.zero(a,srcDouble),bz=FpuBinary.zero(b,dbl),cz=FpuBinary.zero(c,false);
        boolean as=(a&FpuBinary.sign(srcDouble))!=0,bs=(b&FpuBinary.sign(dbl))!=0,cs=(c&0x80000000L)!=0;
        if(op==Sh2aDecoder.Operation.FPU_COMPARE) {
            boolean invalid=sn||(name.equals("FCMP/GT")&&(an||bn));
            if(invalid&&(mode&0x800)!=0)return exceptionGenerated(s,mode,V);
            s.fpscr=(mode&~CAUSE)|(invalid?V:0);
            s.t=!(an||bn)&&(name.equals("FCMP/EQ")?compare(a,b,dbl)==0:compare(a,b,dbl)>0);
            return null;
        }
        if(name.equals("FTRC")) {
            // §6.5.19: NaNs of either sign saturate to MIN; truncation permits
            // negative values > -2147483649, including -2147483648.5 in binary64.
            BigInteger truncated=an||ai?null:FpuBinary.value(a,dbl).num().divide(FpuBinary.value(a,dbl).den());
            boolean bad=truncated==null||truncated.compareTo(BigInteger.valueOf(Integer.MIN_VALUE))<0||truncated.compareTo(BigInteger.valueOf(Integer.MAX_VALUE))>0;
            int result=bad?(an||as?Integer.MIN_VALUE:Integer.MAX_VALUE):truncated.intValue();
            return commit(s,mode,bad?V:0,0,n,false,Integer.toUnsignedLong(result),true);
        }
        boolean fpul=name.equals("FCNVDS");
        boolean dstDouble=name.equals("FCNVSD")||(!fpul&&dbl);
        if(sn)return invalid(s,mode,n,dstDouble,fpul);
        // FMAC gives invalid 0*infinity priority over a qNaN accumulator.
        if(op==Sh2aDecoder.Operation.FPU_FMAC&&!bn&&!cn&&((bi&&cz)||(ci&&bz)))return invalid(s,mode,n,false,false);
        if(an||bn||cn)return commit(s,mode,0,0,n,dstDouble,FpuBinary.qnan(dstDouble),fpul);
        if(op==Sh2aDecoder.Operation.FPU_CONVERT) {
            if(ai)return commit(s,mode,0,0,n,dstDouble,(as?FpuBinary.sign(dstDouble):0)|FpuBinary.infinity(dstDouble),fpul);
            return rounded(s,mode,n,dstDouble,fpul,FpuBinary.value(a,srcDouble),as,fpul?0x380:0,false);
        }
        if(op==Sh2aDecoder.Operation.FPU_SQRT) {
            if(az||ai&&!as)return commit(s,mode,0,0,n,dbl,a,false);
            if(as)return invalid(s,mode,n,dbl,false);
            return rounded(s,mode,n,dbl,false,FpuBinary.value(a,dbl),false,0x80,true);
        }
        if(op==Sh2aDecoder.Operation.FPU_FMAC) {
            // R01US0031JJ0400 Rev.4 revision list (PDF p.7) and §6.5.11
            // pp.6-205..207 explicitly correct Rev.3 infinite/zero-product rules.
            boolean ps=bs^cs;
            if(bi||ci) {
                if(ai&&as!=ps)return invalid(s,mode,n,false,false);
                return commit(s,mode,0,0,n,false,(ps?0x80000000L:0)|FpuBinary.infinity(false),false);
            }
            if(ai)return commit(s,mode,0,0,n,false,a,false);
            if(bz||cz) {
                long result=az?((ps&&as)?0x80000000L:0):a;
                return commit(s,mode,0,0,n,false,result,false);
            }
            var exact=FpuBinary.value(b,false).multiply(FpuBinary.value(c,false)).add(FpuBinary.value(a,false));
            return rounded(s,mode,n,false,false,exact,false,0x380,false);
        }
        boolean sub=name.equals("FSUB"),mul=name.equals("FMUL"),div=name.equals("FDIV");
        boolean sign=as^bs;
        if(mul||div) {
            if((mul&&((ai&&bz)||(bi&&az)))||(div&&((ai&&bi)||(az&&bz))))return invalid(s,mode,n,dbl,false);
            if(div&&bz&&!ai)return commit(s,mode,Z,0,n,dbl,(sign?FpuBinary.sign(dbl):0)|FpuBinary.infinity(dbl),false);
            if(ai||mul&&bi)return commit(s,mode,0,0,n,dbl,(sign?FpuBinary.sign(dbl):0)|FpuBinary.infinity(dbl),false);
            if(az||mul&&bz||div&&bi)return commit(s,mode,0,0,n,dbl,sign?FpuBinary.sign(dbl):0,false);
        } else {
            boolean effectiveB=bs^sub;
            if(ai&&bi&&as!=effectiveB)return invalid(s,mode,n,dbl,false);
            if(ai||bi)return commit(s,mode,0,0,n,dbl,ai?a:((effectiveB?FpuBinary.sign(dbl):0)|FpuBinary.infinity(dbl)),false);
            if(az||bz) {
                long result=az&&bz?((as&&effectiveB)?FpuBinary.sign(dbl):0):az?(b^(sub?FpuBinary.sign(dbl):0)):a;
                return commit(s,mode,0,0,n,dbl,result,false);
            }
        }
        var x=FpuBinary.value(a,dbl);var y=FpuBinary.value(b,dbl);
        var exact=mul?x.multiply(y):div?x.divide(y):x.add(sub?y.negate():y);
        return rounded(s,mode,n,dbl,false,exact,(mul||div)&&sign,0x380,false);
    }
    private static boolean special(long bits,boolean dbl) {return FpuBinary.nan(bits,dbl)||FpuBinary.inf(bits,dbl);}
    private static int compare(long a,long b,boolean dbl) {
        if(FpuBinary.zero(a,dbl)&&FpuBinary.zero(b,dbl))return 0;
        long sign=FpuBinary.sign(dbl);
        boolean an=(a&sign)!=0,bn=(b&sign)!=0;
        if(an!=bn)return an?-1:1;
        int cmp=Long.compare(a&~sign,b&~sign);
        return an?-cmp:cmp;
    }
    static String exceptionGenerated(AbstractCpu s,int mode,int causes) {
        s.fpscr=(mode&~CAUSE)|causes;
        s.fpuExceptionPending=AbstractCpu.FPU_PENDING;
        StringBuilder label=new StringBuilder();
        if((causes&V)!=0)label.append('V');if((causes&Z)!=0)label.append('Z');
        if((causes&O)!=0)label.append('O');if((causes&U)!=0)label.append('U');if((causes&I)!=0)label.append('I');
        return "FPU_EXCEPTION_GENERATED_"+(label.isEmpty()?"ENABLED_WITHOUT_CAUSE":label);
    }
    static boolean frozenCompare(AbstractCpu s,Sh2aDecoder.Instruction inst) {
        if(s.fpscr==null)return false;
        boolean dbl=(s.fpscr&PR)!=0;
        Long a=read(s,inst.regN(),dbl),b=read(s,inst.regM(),dbl);
        if(a==null||b==null)return false;
        a=FpuBinary.flush(a,dbl);b=FpuBinary.flush(b,dbl);
        s.t=!FpuBinary.nan(a,dbl)&&!FpuBinary.nan(b,dbl)&&(inst.mnemonic().equals("FCMP/EQ")?compare(a,b,dbl)==0:compare(a,b,dbl)>0);
        return true;
    }
}
