package ecu.independent;

/**
 * SH72543R / SH72544R user-MAT on-chip-ROM-enabled address profile.
 * Renesas R01UH0480EJ0400 rev 4.00, section 5, tables 5.1/5.4.
 * The actual execution mode/boot MAT cannot be inferred solely from a BIN.
 */
public final class Sh7254rMemoryMap {
    public enum Region { USER_ROM, SRAM, EEPROM_READ, MMIO_WINDOW, EXTERNAL_OR_RESERVED }
    public static final long SRAM_START = 0xFFF80000L;
    public static final long SRAM_END_EXCLUSIVE = 0xFFFA0000L;
    public static final long MMIO_START = 0xFFFC0000L;
    public static final long MMIO_END_EXCLUSIVE = 0x100000000L;
    /** Power-down standby control register (§29.3.1 @H'FFFE0400; MSTP1 halts the FPU clock). */
    public static final int STBCR = 0xFFFE0400;
    public static final long EEPROM_START = 0x80100000L;
    public static final long EEPROM_END_EXCLUSIVE = 0x80120000L;
    private final byte[] userRom;
    private final String cpu;
    public Sh7254rMemoryMap(byte[] userRom) {
        if (userRom == null) throw new IllegalArgumentException("ROM is null");
        if (userRom.length != 0x200000 && userRom.length != 0x280000)
            throw new IllegalArgumentException("Require 2 MiB SH72543R or 2.5 MiB SH72544R full user MAT dump");
        this.userRom = userRom.clone();
        this.cpu = userRom.length == 0x200000 ? "SH72543R" : "SH72544R";
    }
    public String cpu() { return cpu; }
    public int romLength() { return userRom.length; }
    /** Hardware7.3.1 table7.6; mode-dependent external fetches remain unknown. */
    boolean cpuFetchAddressError(int address) {
        long a=Integer.toUnsignedLong(address);
        return (address&1)!=0||region(a)==Region.MMIO_WINDOW||
                a>=SRAM_END_EXCLUSIVE-10&&a<SRAM_END_EXCLUSIVE;
    }
    public boolean romRange(long a, int size) { return size > 0 && a >= 0 && a + size <= userRom.length; }
    public Region region(long a) {
        long u = a & 0xFFFFFFFFL;
        if (u < userRom.length) return Region.USER_ROM;
        if (u >= SRAM_START && u < SRAM_END_EXCLUSIVE) return Region.SRAM;
        if (u >= EEPROM_START && u < EEPROM_END_EXCLUSIVE) return Region.EEPROM_READ;
        if (u >= MMIO_START && u < MMIO_END_EXCLUSIVE) return Region.MMIO_WINDOW;
        return Region.EXTERNAL_OR_RESERVED;
    }
    /** Valid ROM data read: undefined outside ROM (never substitute zero). */
    public Integer readRom(long address, int size) {
        if (!romRange(address, size) || size > 4 || (size == 2 && (address & 1) != 0)
                || (size == 4 && (address & 3) != 0)) return null;
        int result = 0;
        for (int j = 0; j < size; j++) result = result << 8 | (userRom[(int) address+j] & 255);
        return result;
    }
    /** Distinguish a MMIO WINDOW from a KNOWN registered peripheral address. */
    public boolean knownMmioRegister(long address) {
        return Sh7254rIntcMmio.belongs((int)address);
    }
}
