package ecu.independent;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

/** Independent, read-only research reports. Existing analyses are never overwritten. */
public final class ReportWriter {
    private ReportWriter() {}
    public static Path write(FirmwareGraph.Report report, byte[] rom, Path output) throws Exception {
        Files.createDirectories(output);
        String hash=hash(rom);
        String romid=romId(rom);
        String prefix=romid+"_"+hash.substring(0,16)+"_";
        Path dir=output.resolve(prefix+"independent_analysis");
        int index=1;
        while(Files.exists(dir)) dir=output.resolve(prefix+"independent_analysis_"+(index++));
        Files.createDirectory(dir);
        StringBuilder inst=new StringBuilder("address,width,encoding,mnemonic,flow,target,delay_slot,status\n");
        Map<Integer,String> bytes=report.byteOwnership();
        report.instructions().values().stream().sorted(Comparator.comparingInt(Sh2aDecoder.Instruction::address))
            .forEach(i-> inst.append(String.format(Locale.ROOT,"0x%08X,%d,0x%08X,%s,%s,%s,%b,%s%n",
                i.address(),i.width(),i.encoding(),i.mnemonic(),i.flow(),
                i.target()==null?"":hex(i.target()),i.delaySlot(),
                bytes.getOrDefault(i.address(),CodeDataClassifier.Status.UNKNOWN.name()))));
        write(dir.resolve("instructions.csv"),inst);
        StringBuilder edges=new StringBuilder("from,to,kind\n");
        report.edges().forEach(e->edges.append(hex(e.from())).append(',').append(hex(e.to()))
                .append(',').append(e.kind()).append('\n'));
        write(dir.resolve("edges.csv"),edges);
        StringBuilder references=new StringBuilder("instruction,address,width,kind\n");
        report.dataReferences().forEach(r-> references.append(hex(r.from())).append(',')
                .append(hex(r.to())).append(',').append(r.width()).append(',').append(r.kind()).append('\n'));
        write(dir.resolve("memory_references.csv"),references);
        StringBuilder ramFlow=new StringBuilder("writer_instruction,reader_instruction,ram_address,width,status\n");
        report.ramDependencies().forEach(e->ramFlow.append(hex(e.writer())).append(',')
                .append(hex(e.reader())).append(',').append(hex(e.address())).append(',')
                .append(e.width()).append(',').append(e.evidence()).append('\n'));
        write(dir.resolve("ram_dependencies.csv"),ramFlow);
        StringBuilder issues=new StringBuilder("address,reason\n");
        report.issues().forEach(e->issues.append(hex(e.address())).append(',').append(e.reason()).append('\n'));
        write(dir.resolve("issues.csv"),issues);
        StringBuilder vectors=new StringBuilder("vector_index,raw_table_offset,target,status\n");
        report.vectorCandidates().forEach(v->vectors.append(v.index()).append(',')
                .append(hex(v.index()*4)).append(',').append(hex(v.address())).append(',')
                .append(v.assessment()).append('\n'));
        write(dir.resolve("vector_candidates.csv"),vectors);
        StringBuilder preemptions=new StringBuilder(
                "resume_pc,handler,vector_offset,accepted_after_instruction,source\n");
        report.interruptPreemptions().forEach(p->preemptions.append(hex(p.resumePc())).append(',')
                .append(hex(p.handler())).append(',').append(hex(p.vectorOffset())).append(',')
                .append(hex(p.acceptedAfter())).append(',').append(csv(p.source())).append('\n'));
        write(dir.resolve("interrupt_preemptions.csv"),preemptions);
        StringBuilder interruptSources=new StringBuilder(
                "name,vector,vector_offset,priority_fixed,priority_register,ipr_nibble,status\n");
        for(var source:Sh7254rInterruptSources.known()) {
            interruptSources.append(source.name()).append(',').append(source.vector()).append(',')
                    .append(hex(source.vector()*4)).append(',')
                    .append(source.fixedPriority()<0?"":Integer.toString(source.fixedPriority())).append(',')
                    .append(source.priorityRegister()==0?"":hex(source.priorityRegister())).append(',')
                    .append(source.priorityNibble()<0?"":Integer.toString(source.priorityNibble())).append(',')
                    .append("HARDWARE_SOURCE_CATALOG_NOT_OBSERVED_EXECUTION\n");
        }
        write(dir.resolve("interrupt_source_catalog.csv"),interruptSources);
        StringBuilder regions=new StringBuilder("start,end_exclusive,size,status\n");
        int previous=-2,first=-1;
        String state=null;
        for(var e:bytes.entrySet()) {
            if (first!=-1 && (e.getKey()!=previous+1 || !e.getValue().equals(state))) {
                region(regions,first,previous+1,state);first=-1;
            }
            if(first==-1) {first=e.getKey();state=e.getValue();}
            previous=e.getKey();
        }
        if(first!=-1) region(regions,first,previous+1,state);
        write(dir.resolve("observed_regions.csv"),regions);
        StringBuilder provenance=new StringBuilder(
                "address,status,access_type,evidence_source,condition,limitation\n");
        report.classificationEvidence().forEach(e->provenance.append(hex(e.address())).append(',')
                .append(csv(e.status())).append(',').append(csv(e.accessType())).append(',')
                .append(csv(e.source())).append(',').append(csv(e.condition())).append(',')
                .append(csv(e.limitation())).append('\n'));
        write(dir.resolve("classification_evidence.csv"),provenance);
        StringBuilder counts=new StringBuilder("status,byte_count\n");
        for(CodeDataClassifier.Status s:CodeDataClassifier.Status.values())
            if(s!=CodeDataClassifier.Status.UNKNOWN)
                counts.append(s.name()).append(',').append(count(bytes,s.name())).append('\n');
        counts.append("UNKNOWN,").append("NOT_LISTED_ROM_BYTES_ARE_UNKNOWN\n");
        write(dir.resolve("classification_counts.csv"),counts);
        String metadata="engine=independent-sh2a-abstract-v0.6.0\n"+
                "status=PARTIAL_ISA_PARTIAL_ABSTRACT_EXECUTION_NOT_FULL_ECU_EMULATION\n"+
                "sha256="+hash+"\nromid_candidate="+romid+"\n"+
                "mcu="+report.cpu()+"\n"+
                "reset_pc="+hex(report.resetPc())+"\nreset_sp="+hex(report.resetSp())+"\n"+
                "execution_mode=ASSUMED_USER_MAT_ON_CHIP_ROM_ENABLED\n"+
                "assumption=raw full user MAT, big endian, ROM base 0, reset vectors at 0 and 4\n"+
                "classification=EVIDENCE_GRADED_CONFIRMED_CODE_REQUIRES_OBSERVED_TRACE_WITNESS\n"+
                "classification_scale=CONFIRMED_CODE,REACHABLE_CODE,POSSIBLE_CODE,CONFIRMED_DATA,POSSIBLE_DATA,CONFLICT,UNKNOWN\n"+
                "classification_source=inputs/Renesas_SH2A_SH7254R_Hardware_Reference_RU.md sec.10 (secondary digest)\n"+
                "confirmed_code_bytes="+count(bytes,CodeDataClassifier.Status.CONFIRMED_CODE.name())+
                " (no trace was supplied unless above zero)\n"+
                "unobserved_bytes=UNKNOWN_NOT_CALIBRATION_NOT_LISTED\n"+
                "interrupt_vectors=UNVERIFIED_CANDIDATES_ONLY_VBR_UNKNOWN\n"+
                "intc=PARTIAL_SH7254R_INTEGRATED_SOFTWARE_IRQ_NO_TIMED_HARDWARE_IRQ\n"+
                "known_mmio=INTC_DOCUMENTED_SUBSET_AND_STBCR\n"+
                "instruction_count="+report.instructions().size()+"\n"+
                "processed_states="+report.processedStates()+"\n"+
                "edge_count="+report.edges().size()+"\n"+
                "memory_reference_count="+report.dataReferences().size()+"\n"+
                "ram_dependency_count="+report.ramDependencies().size()+"\n"+
                "issue_count="+report.issues().size()+"\n"+
                "truncated="+report.truncated()+"\n"+
                "tests=NOT_RUN_BY_THIS_ANALYSIS_INVOCATION\n";
        Files.writeString(dir.resolve("metadata.txt"),metadata,StandardCharsets.UTF_8);
        return dir;
    }
    private static void region(StringBuilder dst,int first,int end,String state) {
        dst.append(hex(first)).append(',').append(hex(end)).append(',').append(end-first)
            .append(',').append(state).append('\n');
    }
    private static long count(Map<Integer,String> bytes,String status) {
        long n=0; for(String s:bytes.values()) if(s.equals(status)) n++; return n;
    }
    /** CSV field quoting so that provenance sentences containing commas stay parseable. */
    private static String csv(String value) {
        if(value==null) return "";
        if(value.indexOf(',')<0 && value.indexOf('"')<0 && value.indexOf('\n')<0) return value;
        return '"'+value.replace("\"","\"\"")+'"';
    }
    private static String hex(int addr) {return String.format(Locale.ROOT,"0x%08X",addr);}
    private static void write(Path path,StringBuilder text) throws IOException {
        Files.writeString(path,text.toString(),StandardCharsets.UTF_8);
    }
    static String hash(byte[] data) throws Exception {
        byte[] hash=MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder out=new StringBuilder();
        for(byte b:hash) out.append(String.format(Locale.ROOT,"%02x",b&255));
        return out.toString();
    }
    /** Conservative ROMID heuristic; no hard-coded firmware-dependent offset. */
    static String romId(byte[] data) {
        Pattern p=Pattern.compile("LF[A-Z0-9]{6}");
        Set<String> ids=new LinkedHashSet<>();
        for(int i=0;i<=data.length-8;i++) {
            if(data[i]!='L' || data[i+1]!='F') continue;
            String s=new String(data,i,8,StandardCharsets.US_ASCII);
            if (p.matcher(s).matches()) ids.add(s);
            if(ids.size()>1) return "ROMID_UNVERIFIED";
        }
        return ids.size()==1?ids.iterator().next():"ROMID_UNKNOWN";
    }
}
