package ecu.independent;

/**
 * Fail-closed software interrupt arbitration at an architectural instruction
 * retirement boundary. This is NOT a cycle-accurate INTC, external interrupt
 * controller or time-driven peripheral scheduler.
 *
 * SH7254R Group Hardware Manual R01UH0480EJ0400 Rev.4.00:
 * section 7, table 7.8; section 8.3.7; section 8.4 vector table.
 * SINTn has fixed priority n (1..15), vector number 108-n.
 * Request remains asserted until the guest writes zero to SINTRn.
 */
final class Sh7254rSoftwareInterruptScheduler {
    enum Status {
        NO_REQUEST, MASKED, READY, INDETERMINATE_PENDING,
        INDETERMINATE_MASK
    }
    record Decision(Status status, Sh7254rInterruptController.Event event,
                    int sourceNumber) {}

    Decision select(AbstractCpu cpu, int resumePc) {
        int highest = 0;
        int highestUnknown = 0;
        for (int i = 0; i < cpu.softwareInterrupts.length; i++) {
            Integer requested = cpu.softwareInterrupts[i];
            int n = i + 1;
            if (requested == null) highestUnknown = Math.max(highestUnknown,n);
            else if ((requested & 1) != 0) highest = n;
        }
        if (highest == 0 && highestUnknown == 0)
            return new Decision(Status.NO_REQUEST,null,0);
        if (cpu.interruptMask == null)
            return new Decision(Status.INDETERMINATE_MASK,null,0);
        int mask = cpu.interruptMask;
        if (highest <= mask && highestUnknown <= mask)
            return new Decision(Status.MASKED,null,highest);
        if (highestUnknown > Math.max(highest,mask))
            return new Decision(Status.INDETERMINATE_PENDING,null,0);
        if (highest <= mask)
            return new Decision(Status.MASKED,null,highest);
        int vector = 108-highest;
        return new Decision(Status.READY,
                new Sh7254rInterruptController.Event(resumePc,vector*4,
                        highest,false,true),highest);
    }
}
