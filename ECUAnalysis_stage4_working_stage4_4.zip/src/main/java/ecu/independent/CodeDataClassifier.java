package ecu.independent;

import java.util.*;

/**
 * Evidence-graded CODE/DATA classification required by
 * inputs/Renesas_SH2A_SH7254R_Hardware_Reference_RU.md section 10.
 *
 * Rules enforced here (the reference is a secondary digest, the normative source stays
 * the Renesas SH-2A/SH2A-FPU Software Manual REJ09B0051-0300 and the SH7254R Hardware
 * Manual R01UH0480EJ0400; this class only models evidence, not hardware semantics):
 * <ul>
 *   <li>A decodable encoding alone is never {@link Status#CONFIRMED_CODE}. Static
 *       reachability inside this abstract model yields {@link Status#REACHABLE_CODE}
 *       together with the prerequisites that were assumed on that path.</li>
 *   <li>{@link Status#CONFIRMED_CODE} and {@link Status#CONFIRMED_DATA} are created only
 *       from an explicit observed-execution witness supplied by the operator
 *       ({@code FirmwareGraph.applyObservedTrace}), never by decoding alone.</li>
 *   <li>Incompatible readings of one byte produce {@link Status#CONFLICT}; ambiguity is
 *       never silently resolved into code or data.</li>
 *   <li>The 2 MiB / 2.5 MiB ROM is never enumerated. An address absent from this map is
 *       {@link Status#UNKNOWN}, which is reported explicitly by {@link #statusAt(int)}.</li>
 * </ul>
 */
public final class CodeDataClassifier {
    public enum Status { CONFIRMED_CODE, REACHABLE_CODE, POSSIBLE_CODE,
                        CONFIRMED_DATA, POSSIBLE_DATA, CONFLICT, UNKNOWN }

    /** One classification conclusion with its full provenance. */
    public record Evidence(int address, String status, String accessType, String source,
                          String condition, String limitation) {}

    /** Result of a claim: the joined status and, when set, the conflict reason. */
    public record Claim(Status status, String reason) {}

    private static final Map<String, Status> BY_NAME = new HashMap<>();
    static { for (Status s : Status.values()) BY_NAME.put(s.name(), s); }

    /** Keeps the number of retained provenance rows bounded on huge ROMs. */
    private static final int EVIDENCE_CAP = 400_000;

    private final Map<Integer, String> bytes = new TreeMap<>();
    private final Map<Integer, Integer> fetchOwner = new HashMap<>();
    private final LinkedHashSet<Evidence> evidence = new LinkedHashSet<>();
    private boolean evidenceOverflow;

    void clear() {
        bytes.clear(); fetchOwner.clear(); evidence.clear(); evidenceOverflow = false;
    }

    public static boolean isCode(Status s) {
        return s == Status.CONFIRMED_CODE || s == Status.REACHABLE_CODE || s == Status.POSSIBLE_CODE;
    }

    /** CONFIRMED > REACHABLE > POSSIBLE inside one kind; code + data on one byte = CONFLICT. */
    public static Status join(Status a, Status b) {
        if (a == null || a == Status.UNKNOWN) return b == null ? Status.UNKNOWN : b;
        if (b == null || b == Status.UNKNOWN) return a;
        if (a == Status.CONFLICT || b == Status.CONFLICT) return Status.CONFLICT;
        if (isCode(a) != isCode(b)) return Status.CONFLICT;
        return rank(a) >= rank(b) ? a : b;
    }

    private static int rank(Status s) {
        return switch (s) {
            case CONFIRMED_CODE, CONFIRMED_DATA -> 3;
            case REACHABLE_CODE -> 2;
            case POSSIBLE_CODE, POSSIBLE_DATA -> 1;
            default -> 0;
        };
    }

    public Status statusAt(int address) {
        String raw = bytes.get(address);
        Status s = raw == null ? null : BY_NAME.get(raw);
        return s == null ? Status.UNKNOWN : s;
    }

    /**
     * Claims one byte with a provenance row. {@code ownerAddress} is the instruction that
     * fetches the byte, or -1 for data claims. Two different fetching instructions covering
     * the same byte are incompatible instruction streams, not a mergeable pair.
     */
    public Claim claim(int address, Status status, String accessType, String source,
                       String condition, String limitation, int ownerAddress) {
        Status current = statusAt(address);
        Status next = join(current, status);
        String reason = null;
        if (isCode(next) && ownerAddress >= 0) {
            Integer previous = fetchOwner.put(address, ownerAddress);
            if (previous != null && previous.intValue() != ownerAddress) {
                next = Status.CONFLICT;
                reason = "OVERLAPPING_INSTRUCTION_STREAMS";
            }
        }
        if (next == Status.CONFLICT && reason == null)
            reason = "CODE_DATA_OVERLAP";
        bytes.put(address, next.name());
        if (evidence.size() < EVIDENCE_CAP)
            evidence.add(new Evidence(address, next.name(), accessType, source, condition, limitation));
        else evidenceOverflow = true;
        return new Claim(next, reason);
    }

    /** Upgrades a decoded instruction start byte from a witnessed PC in an observed trace. */
    Claim confirmFetched(int address, String source, String condition) {
        return claim(address, Status.CONFIRMED_CODE, "FETCH_OBSERVED", source, condition,
                "trace witness; instruction bytes themselves are not re-verified", address);
    }

    public Map<Integer, String> snapshot() { return Collections.unmodifiableMap(new TreeMap<>(bytes)); }

    public List<Evidence> evidence() {
        List<Evidence> out = new ArrayList<>(evidence);
        out.sort(Comparator.comparingInt(Evidence::address));
        return List.copyOf(out);
    }

    public boolean evidenceOverflow() { return evidenceOverflow; }

    public EnumMap<Status, Integer> counts() {
        EnumMap<Status, Integer> counts = new EnumMap<>(Status.class);
        for (String raw : bytes.values()) {
            Status s = BY_NAME.get(raw);
            if (s != null) counts.merge(s, 1, Integer::sum);
        }
        return counts;
    }
}
