package ecu.independent;

/**
 * Independent decoder for the SH72543R/SH72544R SH-2A instruction encodings.
 * This class does not call Ghidra, SLEIGH, P-code or an external disassembler.
 *
 * Encoding references: Renesas REJ09B0051-0300, sections 5 and 6, and
 * REJ06J0014-0100 (compiler use guide). Unsupported opcodes remain opaque.
 */
public final class Sh2aDecoder {
    public enum Flow { NEXT, BRANCH, CONDITIONAL, CALL, RETURN, INDIRECT, EXCEPTION, STOP, UNKNOWN }
    /**
     * Decoding outcome. This is the ONLY classification axis for a decoded word;
     * it replaces the previous boolean "supported", which conflated hardware-illegal
     * encodings with valid-but-unimplemented ones (review of fixes #5-#10).
     * Normative basis REJ09B0051-0300 Rev.3.00:
     *  - ILLEGAL_ENCODING      : undefined code, general illegal outside a delay slot
     *                            (sec.3.7.4 p.28 txt 2938-2948; sec.3.7.3 p.28 txt 2906-2928),
     *                            complete device inventory in Hardware Tables2.12-2.20.
     *  - UNSUPPORTED_IMPLEMENTATION : a defined SH-2A/SH-2A-FPU opcode whose semantics this
     *                            analyzer has not implemented; NOT an exception, NOT executed.
     *  - UNVERIFIED_ENCODING   : legality of the encoding is not yet established from the
     *                            manual; NOT promoted to executable, NOT promoted to illegal.
     *  - INCOMPLETE_FETCH      : bytes/address not available to decode a whole instruction;
     *                            an image/memory-availability issue, NOT a hardware exception.
     *  - ADDRESS_ERROR         : an architectural access-alignment violation (odd fetch
     *                            address, sec.3.5 table 3.5 txt 2495-2497); a CPU address
     *                            error (vector number 9 -> H'24), NOT illegal encoding and
     *                            NOT availability; stacked PC imprecise/delayed (sec.3.3
     *                            txt 2579-2588), so the graph fabricates no edge.
     */
    public enum Status { VALID, ILLEGAL_ENCODING, UNSUPPORTED_IMPLEMENTATION,
                         UNVERIFIED_ENCODING, INCOMPLETE_FETCH, ADDRESS_ERROR }
    public enum Operation {
        UNKNOWN, TRAPA, RTE, RESBANK, LDBANK, STBANK, FPU_ARITHMETIC, FPU_COMPARE, FPU_CONVERT, FPU_SQRT, FPU_FMAC, NOP, MOV_IMM, MOVI20, MOVI20S, MOV_REG, ADD_IMM, ADD_REG, SUB_REG,
        AND_REG, OR_REG, XOR_REG, TST_REG, CMP_EQ_REG, CMP_EQ_IMM, CMP_HS,
        CMP_GE, CMP_HI, CMP_GT, CMP_PL, CMP_PZ, CLRT, SETT, MOVT,
        SHLL, SHLR, SHAL, SHAR, SHLL2, SHLR2, SHLL8, SHLR8,
        SHLL16, SHLR16, MOV_LOAD, MOV_STORE, MOV_PC, MOVA,
        MOV_UNSIGNED_LOAD, MOV_GBR_LOAD, MOV_GBR_STORE, MOV_INDEX_LOAD, MOV_INDEX_STORE,
        MOV_REV_LOAD, MOV_REV_STORE, MOVT_INV, NOTT, NOT_REG, NEG_REG, NEGC_REG, BIT_REG, BIT_MEMORY,
        EXTS_B, EXTS_W, EXTU_B, EXTU_W, SWAP_B, SWAP_W, XTRCT,
        ADDC_REG, ADDV_REG, SUBC_REG, SUBV_REG, DT_REG, CMP_STR,
        ROTL, ROTR, ROTCL, ROTCR, SHAD, SHLD,
        AND_IMM, OR_IMM, XOR_IMM, TST_IMM, GBR_BYTE_LOGIC, TAS_B,
        MOVML_PUSH, MOVML_POP, MOVMU_PUSH, MOVMU_POP,
        TBR_CALL, RTV_N, MOV_DISP12_LOAD, MOV_DISP12_STORE,
        SYS_REG_TRANSFER, DIV0U, DIV0S, DIV1, DIVS, DIVU, MULR,
        MUL_L, MULS_W, MULU_W, DMULS_L, DMULU_L, MAC_L, MAC_W, CLRMAC,
        MAC_REGISTER_TRANSFER, FPU_REGISTER_TRANSFER, FPU_SIGN, FPU_IMMEDIATE,
        FPU_REG_MOVE, FPU_MEM_LOAD, FPU_MEM_STORE, FPU_MODE, FPU, CLIPS_B, CLIPS_W, CLIPU_B, CLIPU_W,
        MUL, MAC, OPAQUE,
        STS_PR, LDS_PR, STS_L_PR, LDS_L_PR, BRANCH, RETURN, SLEEP
    }
    /** regN is usually destination/base; regM is source/base; imm is signed or unsigned by operation. */
    public record Instruction(int address, int width, int encoding, String mnemonic,
                              Flow flow, Integer target, boolean delaySlot, Status status,
                              Operation operation, int regN, int regM, int imm,
                              int operandWidth, Integer referenceAddress, boolean postIncrement,
                              boolean preDecrement) {
        public int endExclusive() { return address + width; }
        /** Backward-compatible accessor: an instruction is executable only when VALID. */
        public boolean supported() { return status == Status.VALID; }
    }
    private static int sx(int value, int bits) { return (value << (32 - bits)) >> (32 - bits); }
    static Instruction make(int a, int word, int width, String mnemonic, Flow flow,
                                    Integer target, boolean delay, Operation op,
                                    int n, int m, int imm, int bytes, Integer reference,
                                    boolean post, boolean pre) {
        return new Instruction(a, width, word, mnemonic, flow, target, delay, Status.VALID,
                op, n, m, imm, bytes, reference, post, pre);
    }
    static Instruction simple(int a, int w, String text, Flow flow, Integer target,
                                      boolean delay, Operation op, int n, int m, int imm) {
        return make(a, w, 2, text, flow, target, delay, op, n, m, imm, 0, null, false, false);
    }
    /**
     * Contextual PC for MOV.W/MOV.L/MOVA in an executed delay slot. REJ09B0051-0300
     * Rev.3.00 sec.6.4.31 pp.219-220 and sec.6.4.34 p.228: PC = branch destination
     * + 2, then clear bits 1:0 for longword/MOVA before adding the scaled disp8.
     * Caller must prove the destination and that the delayed transfer is taken.
     */
    static Instruction pcRelativeSlot(Instruction i, int destination) {
        if (i.operation()!=Operation.MOV_PC && i.operation()!=Operation.MOVA)
            throw new IllegalArgumentException("Not a PC-relative instruction");
        int pc=destination+2;
        int reference=i.operandWidth()==2 ? pc+(i.encoding()&255)*2
                : (pc&~3)+(i.encoding()&255)*4;
        return new Instruction(i.address(),i.width(),i.encoding(),i.mnemonic(),i.flow(),
                i.target(),i.delaySlot(),i.status(),i.operation(),i.regN(),i.regM(),
                i.operation()==Operation.MOVA ? reference : i.imm(),i.operandWidth(),reference,i.postIncrement(),i.preDecrement());
    }
    /**
     * Re-classify an already-decoded VALID FPU instruction as undefined code because the FPU
     * module is in standby (STBCR.MSTP1=1, R01UH0480EJ0400 §29.3.1 txt 64960-64969). §7.6.1
     * (txt 6759-6778) and §7.6.4 (txt 6844-6850) define an FPU instruction / FPU-related CPU
     * instruction executed in FPU module standby as undefined code: general illegal outside a
     * delay slot (stacked PC = start address of the undefined code) and slot illegal in a slot.
     * Only opcodes whose standing AS AN FPU INSTRUCTION is established are upgraded: VALID and
     * UNSUPPORTED_IMPLEMENTATION (a defined opcode whose semantics the analyzer has not implemented
     * is still a proven FPU instruction, and standby makes the exception mandatory either way).
     * UNVERIFIED_ENCODING is not upgraded, because its status as an instruction at all is not
     * established - decoder incompleteness must not manufacture a hardware exception.
     */
    static Instruction illegalFpuStandby(Instruction i) {
        return new Instruction(i.address(), i.width(), i.encoding(),
                i.mnemonic()+"_IN_FPU_STANDBY_UNDEFINED_CODE",
                Flow.EXCEPTION, null, i.delaySlot(), Status.ILLEGAL_ENCODING,
                i.operation(), i.regN(), i.regM(), i.imm(), i.operandWidth(),
                i.referenceAddress(), i.postIncrement(), i.preDecrement());
    }
    static Instruction unknown(int a, int w, int length, String reason) {
        return new Instruction(a, length, w, reason,
                statusFor(reason)==Status.ILLEGAL_ENCODING ? Flow.EXCEPTION : Flow.UNKNOWN, null, false,
                statusFor(reason), Operation.UNKNOWN, -1, -1, 0, 0, null, false, false);
    }
    /** Undefined codes are the complement of the complete device inventory:
     * Hardware Tables2.11-2.20, Software Tables5.3-5.11 and sec6 descriptions.
     * Classification evidence and the two-source comparison are recorded in
     * docs/DECODER_CONTRACT_RU.md; missing bytes remain a fetch failure.
     */
    static Status statusFor(String reason) {
        if (reason == null) return Status.UNVERIFIED_ENCODING;
        switch (reason) {
            case "CPU_ADDRESS_ERROR_INSTRUCTION_FETCH_ODD":     // odd fetch address, sec.3.5
                return Status.ADDRESS_ERROR;
            case "TRUNCATED_32BIT_INSTRUCTION":                 // second word beyond image
            case "TRUNCATED_INSTRUCTION":
            case "INSTRUCTION_FETCH_OUTSIDE_IMAGE":             // no memory/bytes available
            case "INVALID_INSTRUCTION_ADDRESS":                 // legacy availability fallback
                return Status.INCOMPLETE_FETCH;
            case "RESERVED_32BIT_DISP12_MODE":
            case "RESERVED_SH2A_MEMORY_BIT_OP":
            case "UNSUPPORTED_OR_INVALID_16BIT":
            case "SH4_ONLY_OR_RESERVED_FPU":
            case "SH2A_FPU_NOT_LISTED_IN_TABLE_5_9":
                // Closed device inventory: HW Table2.11 total253, Tables2.12-2.20;
                // SW Tables5.3-5.11 AND sec6 descriptions, sec6.1 exclusions.
                // Undefined-code consequence: SW sec3.7.3-3.7.4 pp28-29.
                return Status.ILLEGAL_ENCODING;
            default: return Status.UNVERIFIED_ENCODING;
        }
    }
    static Instruction mem(int a, int w, String name, Operation op, int n, int m,
                                   int bytes, int displacement, boolean post, boolean pre) {
        return make(a, w, 2, name, Flow.NEXT, null, false, op,
                n, m, displacement, bytes, null, post, pre);
    }
    /**
     * Mode-neutral decode, retained for existing abstract-analysis consumers. FPU
     * PR/SZ legality and dynamic addresses are unresolved here; FMOV operandWidth=0
     * means mode-dependent, and a 32-bit FMOV imm is the unscaled disp12.
     * Use the contextual overload when FPSCR / slot context is known.
     */
    public Instruction decode(byte[] rom, int a) {
        return memoryMetadata(decodeEncoding(rom,a));
    }
    /** Decode bytes fetched at an architectural address (e.g. SRAM), using the same
     * encoding path as the image API. The byte buffer begins at that address. */
    Instruction decodeFetched(byte[] bytes,int address) {
        if((address&1)!=0) return unknown(address,-1,0,"CPU_ADDRESS_ERROR_INSTRUCTION_FETCH_ODD");
        if(bytes==null || bytes.length<2)
            return unknown(address,-1,0,"INSTRUCTION_FETCH_OUTSIDE_IMAGE");
        int first=((bytes[0]&255)<<8)|(bytes[1]&255);
        Integer second=bytes.length<4?null:((bytes[2]&255)<<8)|(bytes[3]&255);
        return memoryMetadata(decodeWords(address,first,second));
    }
    private static Instruction memoryMetadata(Instruction i) {
        int bytes=i.operandWidth(); boolean post=i.postIncrement(), pre=i.preDecrement();
        switch(i.operation()) {
            case MAC_L -> { bytes=4; post=true; }
            case MAC_W -> { bytes=2; post=true; }
            case MOVML_PUSH, MOVMU_PUSH, STS_L_PR -> { bytes=4; pre=true; }
            case MOVML_POP, MOVMU_POP, LDS_L_PR -> { bytes=4; post=true; }
            case MAC_REGISTER_TRANSFER -> {
                if(i.regM()>=4) { bytes=4; pre=i.regM()<6; post=!pre; }
            }
            case FPU_REGISTER_TRANSFER -> {
                bytes=4;
                if(i.regM()>=4) { pre=i.regM()<6; post=!pre; }
            }
            case SYS_REG_TRANSFER -> {
                bytes=4;
                if(i.regM()>=10 && i.regM()<=15) { post=i.regM()<=12; pre=!post; }
            }
            case TAS_B, GBR_BYTE_LOGIC -> bytes=1;
            case LDBANK, STBANK, TBR_CALL -> bytes=4;
            case FPU_MEM_LOAD, FPU_MEM_STORE -> bytes=0;
            default -> { }
        }
        return new Instruction(i.address(),i.width(),i.encoding(),i.mnemonic(),i.flow(),i.target(),
                i.delaySlot(),i.status(),i.operation(),i.regN(),i.regM(),i.imm(),bytes,
                i.referenceAddress(),post,pre);
    }
    /** Caller supplies an architectural snapshot, not computed execution results.
     * branchDestination is the proven destination of the preceding taken delayed
     * branch; null preserves an unresolved PC-relative reference in a slot.
     */
    public record DecodeContext(int fpscr, boolean inDelaySlot,
                                Integer branchDestination, boolean fpuStandby) { }
    public Instruction decode(byte[] rom,int a,DecodeContext context) {
        if(context==null) throw new IllegalArgumentException("Decode context is required");
        Instruction i=decode(rom,a);
        if(i.status()!=Status.VALID && i.status()!=Status.UNSUPPORTED_IMPLEMENTATION) return i;
        boolean fpu=(i.width()==2 && (i.encoding()&0xF000)==0xF000) ||
                i.operation()==Operation.FPU_MEM_LOAD || i.operation()==Operation.FPU_MEM_STORE ||
                i.operation()==Operation.FPU_REGISTER_TRANSFER;
        if(fpu && context.fpuStandby()) return illegalContext(i,"FPU_STANDBY_UNDEFINED_CODE");
        if(context.inDelaySlot() && (i.width()==4 || i.flow()==Flow.BRANCH ||
                i.flow()==Flow.CALL || i.flow()==Flow.CONDITIONAL || i.flow()==Flow.RETURN ||
                i.flow()==Flow.INDIRECT || i.operation()==Operation.TRAPA ||
                i.operation()==Operation.RESBANK || i.operation()==Operation.DIVS || i.operation()==Operation.DIVU))
            return illegalContext(i,"SLOT_ILLEGAL");
        if(context.inDelaySlot() && (i.operation()==Operation.MOV_PC || i.operation()==Operation.MOVA)) {
            if(context.branchDestination()!=null) i=pcRelativeSlot(i,context.branchDestination());
            else i=new Instruction(i.address(),i.width(),i.encoding(),i.mnemonic(),i.flow(),i.target(),
                    i.delaySlot(),i.status(),i.operation(),i.regN(),i.regM(),0,i.operandWidth(),null,
                    i.postIncrement(),i.preDecrement());
        }
        if(!fpu || i.operation()==Operation.FPU_REGISTER_TRANSFER) return i;
        return fpuContext(i,context.fpscr());
    }
    /** Shared mode validation for ROM and SRAM execution; no second ISA table. */
    static Instruction fpuContext(Instruction i,int fpscr) {
        if(i.status()!=Status.VALID)return i;
        boolean pr=(fpscr&0x80000)!=0, sz=(fpscr&0x100000)!=0;
        int bytes=4, immediate=i.imm(); String name=i.mnemonic();
        boolean invalid=false;
        switch(i.operation()) {
            case FPU_MEM_LOAD, FPU_MEM_STORE -> {
                int fp=i.operation()==Operation.FPU_MEM_LOAD ? i.regN() : i.regM();
                invalid=sz && (fp&1)!=0; bytes=sz?8:4;
                if(i.width()==4) immediate*=bytes;
                if(sz) name=name.replace("FMOV.S","FMOV.D").replace("FR","DR");
            }
            case FPU_REG_MOVE -> {
                if(name.startsWith("FMOV")) {
                    invalid=sz && ((i.regN()|i.regM())&1)!=0; bytes=sz?8:4;
                    if(sz) name=name.replace("FR","DR");
                }
            }
            case FPU_ARITHMETIC, FPU_COMPARE -> {
                invalid=pr && ((i.regN()|i.regM())&1)!=0; bytes=pr?8:4;
            }
            case FPU_SIGN, FPU_SQRT -> { invalid=pr && (i.regN()&1)!=0; bytes=pr?8:4; }
            case FPU_CONVERT -> {
                boolean pairOnly=name.startsWith("FCNV");
                invalid=(pairOnly && !pr) || ((pr || pairOnly) && (i.regN()&1)!=0);
                bytes=pr || pairOnly ? 8 : 4;
            }
            case FPU_FMAC, FPU_IMMEDIATE -> invalid=pr;
            case FPU_MODE -> { invalid=pr; bytes=0; }
            default -> { }
        }
        if(invalid) return illegalContext(i,"FPSCR_OR_DR_ENCODING_ILLEGAL");
        return new Instruction(i.address(),i.width(),i.encoding(),name,i.flow(),i.target(),
                i.delaySlot(),i.status(),i.operation(),i.regN(),i.regM(),immediate,bytes,
                i.referenceAddress(),i.postIncrement(),i.preDecrement());
    }
    private static Instruction illegalContext(Instruction i,String reason) {
        return new Instruction(i.address(),i.width(),i.encoding(),reason+":"+i.mnemonic(),
                Flow.EXCEPTION,null,i.delaySlot(),Status.ILLEGAL_ENCODING,i.operation(),i.regN(),
                i.regM(),i.imm(),i.operandWidth(),i.referenceAddress(),i.postIncrement(),i.preDecrement());
    }
    private Instruction decodeEncoding(byte[] rom, int a) {
        // Address cases are separated by required CPU behaviour (fix #11 revision):
        // an odd fetch address is a CPU address error (sec.3.5 table 3.5 txt 2495-2497);
        // a missing/unmapped byte is an image-availability shortage (INCOMPLETE_FETCH),
        // not an alignment exception.
        if (a >= 0 && (a & 1) != 0)
            return unknown(a, -1, 0, "CPU_ADDRESS_ERROR_INSTRUCTION_FETCH_ODD");
        if (rom == null || a < 0 || a > rom.length - 2)
            return unknown(a, -1, 0, "INSTRUCTION_FETCH_OUTSIDE_IMAGE");
        final int w = ((rom[a] & 255) << 8) | (rom[a + 1] & 255);
        Integer continuation=a>rom.length-4?null:((rom[a+2]&255)<<8)|(rom[a+3]&255);
        return decodeWords(a,w,continuation);
    }
    private Instruction decodeWords(int a,int w,Integer continuation) {
        final int n = (w >>> 8) & 15, m = (w >>> 4) & 15, low = w & 15;
        // SH-2A instruction-length detection precedes ALL 16-bit decoding.
        // The first-half patterns are also documented in Linux arch/sh SH2A
        // opcode_helper.c. An unknown 32-bit operation consumes BOTH words.
        // Renesas table 5.3: 32-bit MOVI20 and MOVI20S use prefix 0000nnnniiii0000/1.
        // Table 5.3/5.9: 32-bit displacement families use 0011nnnnmmmm0001.
        // 0011nnnnmmmm0010 is 16-bit CMP/HS, NEVER a 32-bit prefix.
        boolean longImmediate = (w & 0xF00E) == 0x0000;
        boolean extended = (w & 0xF00F) == 0x3001;
        // Additional extended bit operation families have a distinct 0011 prefix.
        boolean otherExtended = (w & 0xF08F) == 0x3009;
        if (longImmediate || extended || otherExtended) {
            if (continuation==null) return unknown(a, w, 4, "TRUNCATED_32BIT_INSTRUCTION");
            int second = continuation;
            if (longImmediate) {
                int immediate = sx((((w >>> 4) & 15) << 16) | second, 20);
                boolean shifted = (w & 1) != 0;
                int value = shifted ? immediate << 8 : immediate;
                return make(a, (w << 16) | second, 4, shifted ? "MOVI20S" : "MOVI20",
                        Flow.NEXT, null, false, shifted ? Operation.MOVI20S : Operation.MOVI20,
                        n, -1, value, 4, null, false, false);
            }
            Instruction extra32 = Sh2aOpcodeExtensions.decode32(a,w,second,n,m);
            return extra32 != null ? extra32 : unknown(a,(w<<16)|second,4,"UNSUPPORTED_SH2A_32BIT");
        }
        Instruction extra16 = Sh2aOpcodeExtensions.decode16(a,w,n,m);
        if (extra16 != null) return extra16;
        if (w == 0x0009) return simple(a, w, "NOP", Flow.NEXT, null, false, Operation.NOP,-1,-1,0);
        if (w == 0x000B) return simple(a, w, "RTS", Flow.RETURN, null, true, Operation.RETURN,-1,-1,0);
        if (w == 0x006B) return simple(a, w, "RTS/N", Flow.RETURN, null, false, Operation.RETURN,-1,-1,0);
        if (w == 0x002B) return simple(a,w,"RTE",Flow.RETURN,null,true,Operation.RTE,-1,-1,0);
        if (w == 0x001B) return simple(a, w, "SLEEP", Flow.STOP, null, false, Operation.SLEEP,-1,-1,0);
        if (w == 0x0008) return simple(a, w, "CLRT", Flow.NEXT, null, false, Operation.CLRT,-1,-1,0);
        if (w == 0x0018) return simple(a, w, "SETT", Flow.NEXT, null, false, Operation.SETT,-1,-1,0);
        if ((w & 0xF0FF) == 0x0029) return simple(a, w, "MOVT R"+n, Flow.NEXT,null,false,Operation.MOVT,n,-1,0);
        if ((w & 0xF0FF) == 0x002A) return simple(a, w, "STS PR,R"+n, Flow.NEXT,null,false,Operation.STS_PR,n,-1,0);
        if ((w & 0xF0FF) == 0x402A) return simple(a, w, "LDS R"+n+",PR", Flow.NEXT,null,false,Operation.LDS_PR,n,-1,0);
        if ((w & 0xF0FF) == 0x4022) return simple(a, w, "STS.L PR,@-R"+n, Flow.NEXT,null,false,Operation.STS_L_PR,n,-1,0);
        if ((w & 0xF0FF) == 0x4026) return simple(a, w, "LDS.L @R"+n+"+,PR", Flow.NEXT,null,false,Operation.LDS_L_PR,n,-1,0);
        if ((w & 0xF000) == 0xA000) return simple(a, w, "BRA", Flow.BRANCH,a+4+sx(w&4095,12)*2,true,Operation.BRANCH,-1,-1,0);
        if ((w & 0xF000) == 0xB000) return simple(a, w, "BSR", Flow.CALL,a+4+sx(w&4095,12)*2,true,Operation.BRANCH,-1,-1,0);
        if ((w & 0xFF00) == 0x8900) return simple(a,w,"BT",Flow.CONDITIONAL,a+4+sx(w&255,8)*2,false,Operation.BRANCH,-1,-1,1);
        if ((w & 0xFF00) == 0x8B00) return simple(a,w,"BF",Flow.CONDITIONAL,a+4+sx(w&255,8)*2,false,Operation.BRANCH,-1,-1,0);
        if ((w & 0xFF00) == 0x8D00) return simple(a,w,"BT/S",Flow.CONDITIONAL,a+4+sx(w&255,8)*2,true,Operation.BRANCH,-1,-1,1);
        if ((w & 0xFF00) == 0x8F00) return simple(a,w,"BF/S",Flow.CONDITIONAL,a+4+sx(w&255,8)*2,true,Operation.BRANCH,-1,-1,0);
        if ((w & 0xF0FF) == 0x400B) return simple(a,w,"JSR @R"+n,Flow.CALL,null,true,Operation.BRANCH,n,-1,0);
        if ((w & 0xF0FF) == 0x404B) return simple(a,w,"JSR/N @R"+n,Flow.CALL,null,false,Operation.BRANCH,n,-1,0);
        if ((w & 0xF0FF) == 0x402B) return simple(a,w,"JMP @R"+n,Flow.INDIRECT,null,true,Operation.BRANCH,n,-1,0);
        if ((w & 0xF0FF) == 0x0023) return simple(a,w,"BRAF R"+n,Flow.INDIRECT,null,true,Operation.BRANCH,n,-1,1);
        if ((w & 0xF0FF) == 0x0003) return simple(a,w,"BSRF R"+n,Flow.CALL,null,true,Operation.BRANCH,n,-1,1);
        if ((w & 0xF000) == 0xE000) return simple(a,w,"MOV #imm,R"+n,Flow.NEXT,null,false,Operation.MOV_IMM,n,-1,sx(w&255,8));
        if ((w & 0xF000) == 0x7000) return simple(a,w,"ADD #imm,R"+n,Flow.NEXT,null,false,Operation.ADD_IMM,n,-1,sx(w&255,8));
        if ((w & 0xFF00) == 0x8800) return simple(a,w,"CMP/EQ #imm,R0",Flow.NEXT,null,false,Operation.CMP_EQ_IMM,0,-1,sx(w&255,8));
        if ((w & 0xF00F) == 0x6003) return simple(a,w,"MOV R"+m+",R"+n,Flow.NEXT,null,false,Operation.MOV_REG,n,m,0);
        if ((w & 0xF00F) == 0x300C) return simple(a,w,"ADD R"+m+",R"+n,Flow.NEXT,null,false,Operation.ADD_REG,n,m,0);
        if ((w & 0xF00F) == 0x3008) return simple(a,w,"SUB R"+m+",R"+n,Flow.NEXT,null,false,Operation.SUB_REG,n,m,0);
        if ((w & 0xF00F) == 0x2009) return simple(a,w,"AND R"+m+",R"+n,Flow.NEXT,null,false,Operation.AND_REG,n,m,0);
        if ((w & 0xF00F) == 0x200B) return simple(a,w,"OR R"+m+",R"+n,Flow.NEXT,null,false,Operation.OR_REG,n,m,0);
        if ((w & 0xF00F) == 0x200A) return simple(a,w,"XOR R"+m+",R"+n,Flow.NEXT,null,false,Operation.XOR_REG,n,m,0);
        if ((w & 0xF00F) == 0x2008) return simple(a,w,"TST R"+m+",R"+n,Flow.NEXT,null,false,Operation.TST_REG,n,m,0);
        if ((w & 0xF00F) == 0x3000) return simple(a,w,"CMP/EQ R"+m+",R"+n,Flow.NEXT,null,false,Operation.CMP_EQ_REG,n,m,0);
        if ((w & 0xF00F) == 0x3002) return simple(a,w,"CMP/HS R"+m+",R"+n,Flow.NEXT,null,false,Operation.CMP_HS,n,m,0);
        if ((w & 0xF00F) == 0x3003) return simple(a,w,"CMP/GE R"+m+",R"+n,Flow.NEXT,null,false,Operation.CMP_GE,n,m,0);
        if ((w & 0xF00F) == 0x3006) return simple(a,w,"CMP/HI R"+m+",R"+n,Flow.NEXT,null,false,Operation.CMP_HI,n,m,0);
        if ((w & 0xF00F) == 0x3007) return simple(a,w,"CMP/GT R"+m+",R"+n,Flow.NEXT,null,false,Operation.CMP_GT,n,m,0);
        if ((w & 0xF0FF) == 0x4015) return simple(a,w,"CMP/PL R"+n,Flow.NEXT,null,false,Operation.CMP_PL,n,-1,0);
        if ((w & 0xF0FF) == 0x4011) return simple(a,w,"CMP/PZ R"+n,Flow.NEXT,null,false,Operation.CMP_PZ,n,-1,0);
        if ((w & 0xF0FF) == 0x4000) return simple(a,w,"SHLL R"+n,Flow.NEXT,null,false,Operation.SHLL,n,-1,0);
        if ((w & 0xF0FF) == 0x4001) return simple(a,w,"SHLR R"+n,Flow.NEXT,null,false,Operation.SHLR,n,-1,0);
        if ((w & 0xF0FF) == 0x4020) return simple(a,w,"SHAL R"+n,Flow.NEXT,null,false,Operation.SHAL,n,-1,0);
        if ((w & 0xF0FF) == 0x4021) return simple(a,w,"SHAR R"+n,Flow.NEXT,null,false,Operation.SHAR,n,-1,0);
        if ((w & 0xF0FF) == 0x4008) return simple(a,w,"SHLL2 R"+n,Flow.NEXT,null,false,Operation.SHLL2,n,-1,0);
        if ((w & 0xF0FF) == 0x4009) return simple(a,w,"SHLR2 R"+n,Flow.NEXT,null,false,Operation.SHLR2,n,-1,0);
        if ((w & 0xF0FF) == 0x4018) return simple(a,w,"SHLL8 R"+n,Flow.NEXT,null,false,Operation.SHLL8,n,-1,0);
        if ((w & 0xF0FF) == 0x4019) return simple(a,w,"SHLR8 R"+n,Flow.NEXT,null,false,Operation.SHLR8,n,-1,0);
        if ((w & 0xF0FF) == 0x4028) return simple(a,w,"SHLL16 R"+n,Flow.NEXT,null,false,Operation.SHLL16,n,-1,0);
        if ((w & 0xF0FF) == 0x4029) return simple(a,w,"SHLR16 R"+n,Flow.NEXT,null,false,Operation.SHLR16,n,-1,0);
        if ((w & 0xF000) == 0x9000) {
            int reference = a + 4 + (w & 255)*2;
            return make(a,w,2,"MOV.W @(disp,PC),R"+n,Flow.NEXT,null,false,
                    Operation.MOV_PC,n,-1,0,2,reference,false,false);
        }
        if ((w & 0xF000) == 0xD000) {
            int reference = ((a+4) & ~3) + (w & 255)*4;
            return make(a,w,2,"MOV.L @(disp,PC),R"+n,Flow.NEXT,null,false,
                    Operation.MOV_PC,n,-1,0,4,reference,false,false);
        }
        if ((w & 0xFF00) == 0xC700) {
            int reference = ((a+4) & ~3) + (w & 255)*4;
            return make(a,w,2,"MOVA @(disp,PC),R0",Flow.NEXT,null,false,
                    Operation.MOVA,0,-1,reference,4,reference,false,false);
        }
        if ((w & 0xF000) == 0x5000) return mem(a,w,"MOV.L @(disp,R"+m+"),R"+n,Operation.MOV_LOAD,n,m,4,low*4,false,false);
        if ((w & 0xF000) == 0x1000) return mem(a,w,"MOV.L R"+m+",@(disp,R"+n+")",Operation.MOV_STORE,n,m,4,low*4,false,false);
        if ((w & 0xF00F) == 0x6000) return mem(a,w,"MOV.B @R"+m+",R"+n,Operation.MOV_LOAD,n,m,1,0,false,false);
        if ((w & 0xF00F) == 0x6001) return mem(a,w,"MOV.W @R"+m+",R"+n,Operation.MOV_LOAD,n,m,2,0,false,false);
        if ((w & 0xF00F) == 0x6002) return mem(a,w,"MOV.L @R"+m+",R"+n,Operation.MOV_LOAD,n,m,4,0,false,false);
        if ((w & 0xF00F) == 0x6004) return mem(a,w,"MOV.B @R"+m+"+,R"+n,Operation.MOV_LOAD,n,m,1,0,true,false);
        if ((w & 0xF00F) == 0x6005) return mem(a,w,"MOV.W @R"+m+"+,R"+n,Operation.MOV_LOAD,n,m,2,0,true,false);
        if ((w & 0xF00F) == 0x6006) return mem(a,w,"MOV.L @R"+m+"+,R"+n,Operation.MOV_LOAD,n,m,4,0,true,false);
        if ((w & 0xF00F) == 0x2000) return mem(a,w,"MOV.B R"+m+",@R"+n,Operation.MOV_STORE,n,m,1,0,false,false);
        if ((w & 0xF00F) == 0x2001) return mem(a,w,"MOV.W R"+m+",@R"+n,Operation.MOV_STORE,n,m,2,0,false,false);
        if ((w & 0xF00F) == 0x2002) return mem(a,w,"MOV.L R"+m+",@R"+n,Operation.MOV_STORE,n,m,4,0,false,false);
        if ((w & 0xF00F) == 0x2004) return mem(a,w,"MOV.B R"+m+",@-R"+n,Operation.MOV_STORE,n,m,1,0,false,true);
        if ((w & 0xF00F) == 0x2005) return mem(a,w,"MOV.W R"+m+",@-R"+n,Operation.MOV_STORE,n,m,2,0,false,true);
        if ((w & 0xF00F) == 0x2006) return mem(a,w,"MOV.L R"+m+",@-R"+n,Operation.MOV_STORE,n,m,4,0,false,true);
        return unknown(a,w,2,"UNSUPPORTED_OR_INVALID_16BIT");
    }
}
