package ecu.independent;

import java.util.*;

/**
 * Independent SH-2A abstract execution and conservative graph recovery.
 * A recognized opcode is NOT necessarily code. A reachable candidate is NOT
 * a confirmed hardware trace. No call to Ghidra, P-code or SLEIGH is made.
 *
 * Byte-level conclusions use the seven-level evidence scale of
 * inputs/Renesas_SH2A_SH7254R_Hardware_Reference_RU.md section 10
 * ({@link CodeDataClassifier.Status}): CONFIRMED_CODE is produced only by an operator
 * supplied execution witness ({@link #applyObservedTrace}), never by decoding.
 */
public final class FirmwareGraph {
    private boolean noWaitPipeline;
    private Map<Long,Integer> pipelineSlotStates=Map.of();
    /** All instruction fetches completed, one-state slots, no bus waits (SW8.2).
     * Unsupported instruction timing stops the path; no physical H24/H34 report is inferred. */
    public FirmwareGraph withNoWaitPipeline() {noWaitPipeline=true;pipelineSlotStates=Map.of();return this;}
    public FirmwareGraph withPipelineSlotStates(Map<Long,Integer> durations) {
        new SystemExceptionModel.Pipeline(durations);pipelineSlotStates=Map.copyOf(durations);noWaitPipeline=true;return this;
    }
    public record PipelineSnapshot(int pc,long slot,List<SystemExceptionModel.Flight> outstanding,
                                   List<SystemExceptionModel.PipelineStep> steps,String blocked,Set<String> uncertainties) {}
    public List<PipelineSnapshot> pipelineStates() {
        List<PipelineSnapshot> result=new ArrayList<>();
        for(var e:seen.entrySet())if(e.getValue().pipeline!=null) {
            var p=e.getValue().pipeline;
            result.add(new PipelineSnapshot(e.getKey().address(),p.slot(),p.outstanding(),p.steps(),p.blocked(),p.uncertainties()));
        }
        return List.copyOf(result);
    }
    private final List<PipelineSnapshot> pipelineStops=new ArrayList<>();
    public List<PipelineSnapshot> pipelineStops(){return List.copyOf(pipelineStops);}
    private void blockPipeline(AbstractCpu s,int pc,String reason) {
        s.pipeline.block(reason);
        pipelineStops.add(new PipelineSnapshot(pc,s.pipeline.slot(),s.pipeline.outstanding(),s.pipeline.steps(),reason,s.pipeline.uncertainties()));
    }
    public record Edge(int from, int to, String kind) {}
    /** Immutable architectural entry state, observed through the actual worklist route. */
    public record CpuSnapshot(Integer pc,List<Integer> registers,Integer pr,Integer gbr,Integer vbr,
                              Integer tbr,Integer sr,Integer mach,Integer macl,Boolean t,Boolean q,
                              Boolean m,Boolean saturation,Boolean cs,Boolean bankOverflow,
                              Integer nextBank,Map<Integer,Integer> bankCells,Map<Integer,Byte> ram,
                              List<Integer> fr,Integer fpul,Integer fpscr,Integer fpuPending,
                              List<SystemExceptionModel.Event> systemPending,Integer lastRetiredPc,Integer lastResumePc,int irqMaskChangeWindow,
                              SystemExceptionModel.FpuResult deferredFpuResult) { }
    /** Generated event; not evidence of pipeline acceptance or an architectural saved PC. */
    public record FpuExceptionEvent(int instructionPc,int cause,int flags,int enable,int fpscr) { }
    private final List<FpuExceptionEvent> fpuEvents=new ArrayList<>();
    private final List<SystemExceptionModel.Observation> systemEvents=new ArrayList<>();
    public List<SystemExceptionModel.Observation> systemEvents(){return List.copyOf(systemEvents);}
    public enum ExecutionStage { ISSUE, COMPLETE, CANCELLED, FPU_RESULT }
    public record ExecutionStep(ExecutionStage stage,int instructionPc) {}
    private final List<ExecutionStep> executionSteps=new ArrayList<>();
    public List<ExecutionStep> executionSteps(){return List.copyOf(executionSteps);}
    public List<FpuExceptionEvent> fpuEvents() { return List.copyOf(fpuEvents); }
    public record CpuBoundary(int instructionPc,String kind,Integer dataAddress,Integer resumePc,
                              Integer vectorOffset) { }
    private final List<CpuBoundary> cpuBoundaries=new ArrayList<>();
    public List<CpuBoundary> cpuBoundaries() { return List.copyOf(cpuBoundaries); }
    public List<CpuSnapshot> cpuStates() {
        List<CpuSnapshot> result=new ArrayList<>();
        for(var e:seen.entrySet()) {
            AbstractCpu s=e.getValue();
            result.add(new CpuSnapshot(e.getKey().address(),
                    Collections.unmodifiableList(Arrays.asList(s.r.clone())),s.pr,s.gbr,s.vbr,
                    s.tbr,s.readSr(),s.mach,s.macl,s.t,s.q,s.m,s.saturation,s.cs,s.bankOverflow,
                    s.nextBank,Map.copyOf(s.bankCells),Map.copyOf(s.ram),
                    Collections.unmodifiableList(Arrays.asList(s.fr.clone())),s.fpul,s.deferredFpuResult==null&&(s.pipeline==null||s.pipeline.outstanding().stream().noneMatch(f->f.spec().arithmetic()||f.spec().writes().contains("FPSCR")))?s.fpscr:null,s.fpuExceptionPending,List.copyOf(s.systemPending),s.lastRetiredPc,s.lastResumePc,s.irqMaskChangeWindow,s.deferredFpuResult));
        }
        return List.copyOf(result);
    }

    public record Issue(int address, String reason) {}
    public record DataReference(int from, int to, int width, String kind) {}
    public record RamDependency(int writer, int reader, int address, int width, String evidence) {}
    public record VectorCandidate(int index, int address, String assessment) {}
    /**
     * An accepted interrupt: the PC hardware will resume through RTE, the handler entered and
     * the instruction boundary that allowed acceptance. Kept separate from {@link Edge} so no
     * consumer mistakes a pending resume point for a control-flow edge of the branch.
     */
    public record Preemption(int resumePc, int handler, int vectorOffset, int acceptedAfter,
                             String source) {}
    public record Report(String cpu, int resetPc, int resetSp,
                         Map<Integer, Sh2aDecoder.Instruction> instructions,
                         List<Edge> edges, List<Issue> issues,
                         List<DataReference> dataReferences, List<RamDependency> ramDependencies,
                         List<VectorCandidate> vectorCandidates,
                         List<Preemption> interruptPreemptions,
                         Map<Integer, String> byteOwnership,
                         List<CodeDataClassifier.Evidence> classificationEvidence,
                         int processedStates, boolean truncated) {}
    /**
     * A frontier item plus the reason it exists. {@code assumed} marks paths that rest on a
     * user-supplied entry hypothesis, so their bytes stay POSSIBLE_CODE instead of
     * REACHABLE_CODE.
     */
    private record WorkItem(int address, AbstractCpu cpu, String origin, boolean assumed) {}
    private record WorkKey(int address,Integer pr,Integer fpuPending,List<SystemExceptionModel.Event> pending,int maskWindow,SystemExceptionModel.FpuResult fpResult,List<Object> pipeline) {}
    /** Prerequisite text reused for every statically derived conclusion. */
    private static final String LIMIT_ABSTRACT =
            "abstract model; no hardware or simulator trace was observed";
    private static final String COND_RESET_ROOT =
            "assumed operating mode = user MAT with on-chip ROM, reset PC/SP read from 0x00000000/0x00000004;"
            + " MD pins, boot MAT and external bus NOT verified (HW sec.3/5)";
    private static final String COND_MANUAL_ENTRY =
            "user-supplied entry; origin is an assertion, not derived from ROM content";
    /** Exception vector offsets, REJ09B0051-0300 Rev.3.00 table 3.3 p.19:
     * general illegal instruction number 4 -> H'00000010 (sec.3.7.4 p.28, txt 2238-2242,
     * clean upper table region); slot illegal instruction number 6 -> H'00000018
     * (sec.3.7.3 p.28); integer division number 17 -> H'00000044 (division by zero) and
     * number 18 -> H'00000048 (overflow) (sec.3.7.5 p.28); register bank underflow
     * number 16 -> H'00000040 (same table, txt 2311-2315: the label sits in the pattern
     * slot before number 16, as div0/divovf/NMI/slot-illegal/FPU do; the lower table
     * region is verified against code anchors div0=17/H'44 and divovf=18/H'48); FPU
     * exception number 13 -> H'00000034 (sec.3.7.6 p.29, txt 2985/2990, table 3.3
     * txt 2290-2292 - the vector is UNIQUE for every FPU exception cause).
     * Bank OVERFLOW (number 15 -> H'3C) is not routed: it requires INTC bank-state
     * ("all banks saved" + configuration) that the model cannot prove. */
    private static final int VECTOR_GENERAL_ILLEGAL=0x10, VECTOR_DIV_BY_ZERO=0x44,
            VECTOR_DIV_OVERFLOW=0x48, VECTOR_SLOT_ILLEGAL=0x18,
            VECTOR_BANK_UNDERFLOW=0x40, VECTOR_FPU_EXCEPTION=0x34;
    private final Sh2aDecoder decoder = new Sh2aDecoder();
    private final Sh7254rSoftwareInterruptScheduler softwareIrq =
            new Sh7254rSoftwareInterruptScheduler();
    private final Sh7254rInterruptController interruptEntry =
            new Sh7254rInterruptController();
    private final CodeDataClassifier classifier = new CodeDataClassifier();
    private Sh7254rMemoryMap bus;
    private byte[] busRom;
    private final Map<Integer, Sh2aDecoder.Instruction> code = new TreeMap<>();
    private final LinkedHashSet<Edge> edges = new LinkedHashSet<>();
    private final LinkedHashSet<Issue> issues = new LinkedHashSet<>();
    private final LinkedHashSet<DataReference> data = new LinkedHashSet<>();
    private final LinkedHashSet<RamDependency> ramFlows = new LinkedHashSet<>();
    private final LinkedHashSet<Preemption> preemptions = new LinkedHashSet<>();
    private final Deque<WorkItem> work = new ArrayDeque<>();
    private final Map<WorkKey, AbstractCpu> seen = new HashMap<>();
    private int processed;
    private int resetPc, resetSp;
    private boolean truncated;
    private boolean frontierLimited;
    private List<VectorCandidate> lastVectors = List.of();

    public Report analyze(byte[] rom, int maximumInstructions) {
        return analyze(rom, maximumInstructions, List.of());
    }
    /** Extra entries are user-supplied hypotheses, not discovered interrupt roots. */
    public Report analyze(byte[] rom, int maximumInstructions, List<Integer> extraEntries) {
        return analyzeCore(rom,maximumInstructions,extraEntries,null);
    }
    /** Explicit initial state for synthetic acceptance/debugging; shares the production route. */
    Report analyzeCpu(byte[] rom,int maximumInstructions,AbstractCpu initial) {
        return analyzeCore(rom,maximumInstructions,List.of(),Objects.requireNonNull(initial));
    }
    private Report analyzeCore(byte[] rom,int maximumInstructions,List<Integer> extraEntries,AbstractCpu initial) {
        this.bus = new Sh7254rMemoryMap(rom);
        this.busRom=rom.clone();
        cpuBoundaries.clear();fpuEvents.clear();systemEvents.clear();executionSteps.clear();
        pipelineStops.clear();
        code.clear(); classifier.clear(); edges.clear();issues.clear();data.clear();ramFlows.clear();
        preemptions.clear();
        work.clear();seen.clear();processed=0;frontierLimited=false;
        if (maximumInstructions < 1 || maximumInstructions > 2_000_000)
            throw new IllegalArgumentException("Instruction limit outside [1,2000000]");
        int pc = Objects.requireNonNull(bus.readRom(0,4));
        int sp = Objects.requireNonNull(bus.readRom(4,4));
        boolean resetValid = (validInstructionAddress(pc)||bus.cpuFetchAddressError(pc)) && (sp&3)==0 &&
                (Integer.toUnsignedLong(sp)>=Sh7254rMemoryMap.SRAM_START) &&
                (Integer.toUnsignedLong(sp)<=Sh7254rMemoryMap.SRAM_END_EXCLUSIVE);
        if (resetValid) {
            AbstractCpu root=initial==null?new AbstractCpu(sp):initial.copy();
            if(noWaitPipeline&&root.pipeline==null)root.pipeline=new SystemExceptionModel.Pipeline(pipelineSlotStates);
            if(initial==null) {
                var reset=root.queueSystem(SystemExceptionModel.Kind.POWER_ON_RESET,null,null,0,0,"RESET_INPUT",SystemExceptionModel.Availability.REPORTED_ID);
                observeGenerated(root,reset);root.systemPending.remove(reset);
                systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.ACCEPTANCE,reset,null,null,pc,"POWER_ON_RESET_NO_STACK"));
                systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.TRANSITION,reset,null,null,pc,"target reset vector/state"));
            }
            work.add(new WorkItem(pc,root,"RESET_VECTOR_WORD_AT_0x00000000",false));
            // The two boot words are read as data by the reset sequence itself.
            for (int i=0;i<8;i++)
                classifier.claim(i,CodeDataClassifier.Status.POSSIBLE_DATA,"RESET_VECTOR_READ",
                        "RESET_AT_0x00000000/0x00000004",COND_RESET_ROOT,LIMIT_ABSTRACT,-1);
        }
        else issues.add(new Issue(0,"INVALID_RESET_VECTOR_OR_BOOT_MODE; PC/SP not verified for user MAT"));
        if (extraEntries != null) for (Integer entry : extraEntries) {
            if (entry != null && validInstructionAddress(entry)) {
                // Fresh state: no pending FPU exception is asserted at a manually supplied
                // entry (fpuExceptionPending=null) - the entry itself is an unverified
                // assumption (issue below), unlike the reset entry where POR clears the latch.
                work.add(new WorkItem(entry,new AbstractCpu(),
                        "MANUAL_ENTRY_ARGUMENT", true));
                issues.add(new Issue(entry,"MANUALLY_SUPPLIED_ENTRY; origin and CPU state unverified"));
            } else issues.add(new Issue(entry==null?-1:entry,"INVALID_MANUAL_ENTRY"));
        }
        int maxProcessed = Math.min(4_000_000, maximumInstructions*8);
        while (!work.isEmpty() && code.size()<maximumInstructions && processed<maxProcessed) {
            WorkItem item=work.removeFirst();
            int a=item.address();
            completeFpuAt(a,item.cpu());
            if(item.cpu().pipeline!=null){item.cpu().pipeline.decodeBoundary();item.cpu().pipeline.restoreCommitted(item.cpu());}
            item.cpu().pc=a;
            if(bus.cpuFetchAddressError(a)) {
                addressFault(item.cpu(),a,a,"CPU_FETCH_ADDRESS_ERROR");routeAddressFault(a,item.cpu(),a);continue;
            }
            if (!validInstructionAddress(a)) {issue(a,fetchAddressReason(a));continue;}
            item.cpu().pc=a;
            WorkKey key=new WorkKey(a,item.cpu().pr,item.cpu().fpuExceptionPending,List.copyOf(item.cpu().systemPending),item.cpu().irqMaskChangeWindow,item.cpu().deferredFpuResult,item.cpu().pipeline==null?null:item.cpu().pipeline.key());
            AbstractCpu previous=seen.get(key);
            AbstractCpu state;
            if (previous == null) {
                state=item.cpu().copy();
                seen.put(key,state.copy());
            } else {
                if (!previous.joinFrom(item.cpu())) continue;
                state=previous.copy();
            }
            processed++;
            Sh2aDecoder.Instruction inst=fetchInstruction(state,a);
            if(state.pipeline!=null&&isFpuOperation(inst.operation()))state.fpscr=state.pipeline.decodeFpscr(state.fpscr);
            if(state.fpscr!=null && isFpuOperation(inst.operation()))inst=Sh2aDecoder.fpuContext(inst,state.fpscr);
            if(acceptReportedAtId(a,state,item.assumed()))continue;
            // Classification-driven dispatch (fix #11). The old boolean conflated
            // hardware-illegal words with valid-but-unimplemented ones and routed BOTH to
            // the mandatory VBR+H'10 vector. Only a proven ILLEGAL_ENCODING may do so
            // (REJ09B0051-0300 Rev.3.00 sec.3.7.4 p.28 txt 2938-2948; stacked PC = start
            // address of the undefined code txt 2947-2948; vector H'10 = table 3.3 number 4,
            // confirmed from the primary PDF clean layout p.19 txt 153). The word is never
            // executed: no sequential edge is emitted by any branch below.
            // FPU module standby (STBCR.MSTP1=1, §29.3.1): any decoded FPU / FPU-related CPU
            // instruction is undefined code (§7.6.1 txt 6759-6778, §7.6.4 txt 6844-6850).
            // Fix #15 (priority 1, ordering): ONE standby classification, placed BEFORE the status
            // switch, so neither an unresolved FPSCR mode (validFpuMode below) nor an unimplemented
            // semantic can hide the standby outcome - while the FPU clock is halted the encoding is
            // discarded at decode and never reaches the datapath, so SZ/PR is irrelevant here.
            //  MSTP1 = TRUE   -> upgrade to ILLEGAL_ENCODING (VALID and UNSUPPORTED_IMPLEMENTATION
            //                     alike: a defined opcode is still a proven FPU instruction, and
            //                     decoder incompleteness must not swallow a mandatory exception); the
            //                     existing general-illegal route then applies with its EXACT stacked
            //                     PC (= start address of the undefined code); no new exception
            //                     plumbing and no imprecise PC is fabricated.
            //  MSTP1 = UNKNOWN-> BOTH categories stay: a POTENTIAL H'10 edge raised against a COPY
            //                     (a possibility mutates no tracked state) plus the ordinary handling
            //                     of the opcode as the running-FPU hypothesis. This follows the
            //                     in-repo rule already used for DIV with unknown operands and for
            //                     RESBANK underflow: an exception that cannot be excluded is never
            //                     dropped, and neither category is promoted to guaranteed.
            //  MSTP1 = FALSE  -> ordinary semantics, untouched.
            // UNVERIFIED_ENCODING is never upgraded: its standing as an instruction at all is not
            // established, so no vector may be claimed for it (fix #11/#12 boundary).
            if (isFpuOperation(inst.operation())
                    && (inst.status()==Sh2aDecoder.Status.VALID
                        || inst.status()==Sh2aDecoder.Status.UNSUPPORTED_IMPLEMENTATION)) {
                if (Boolean.TRUE.equals(state.fpuStandby)) {
                    inst=Sh2aDecoder.illegalFpuStandby(inst);
                } else if (state.fpuStandby==null) {
                    issue(a,"FPU_STANDBY_UNKNOWN_VBR+"+hex(VECTOR_GENERAL_ILLEGAL)+
                            "_POSSIBLE_ILLEGAL_AND_"+
                            (inst.status()==Sh2aDecoder.Status.VALID
                                    ?"NORMAL_COMPLETION_KEPT":"UNSUPPORTED_HALT_KEPT"));
                    // Fix #15 (priority 3): the two admissible outcomes refine the SAME unknown in
                    // OPPOSITE directions, each on its own path. This exception edge exists ONLY
                    // because the FPU clock was halted - that is the very cause of the illegal
                    // instruction (§7.6.1 txt 6774-6778) - so the state travelling to VBR+H'10
                    // carries MSTP1=TRUE and keeps it there: no software write inside the handler
                    // may clear the bit (§29.3.1 txt 64960-64967), hence every later FPU
                    // instruction on that route stays routed to H'10 with its own exact stacked PC.
                    // If the edge cannot be built (unknown SP/VBR, unavailable handler) the copy is
                    // discarded but raiseSyncException records <reason>_VECTOR_NOT_ROUTED_<cause>,
                    // so the evidence of the possible exception survives without a fabricated edge.
                    AbstractCpu standbyPath=state.copy();
                    standbyPath.fpuStandby=Boolean.TRUE;
                    raiseSyncException(a,standbyPath,VECTOR_GENERAL_ILLEGAL,a,item.assumed(),
                            "FPU_STANDBY_UNKNOWN_POSSIBLE_ILLEGAL");
                    // Fix #15 (priority 3) refinement: the sequential continuation of a retired FPU /
                    // FPU-related instruction exists ONLY if the FPU was clocked, because in standby
                    // the very same encoding is discarded at decode into H'10 (§7.6.1 txt 6774-6778,
                    // §7.6.4 txt 6845-6850). Following that continuation therefore refines
                    // MSTP1 to FALSE on this path - an honest narrowing, not an assumption: the
                    // alternative standby outcome has already been kept as the edge above, and any
                    // later STBCR write can still set TRUE again. Without this refinement every
                    // following FPU instruction would re-emit a possible H'10 and the unknown would
                    // never resolve. Applied only when the opcode is VALID and therefore actually
                    // retired here: an UNSUPPORTED_IMPLEMENTATION halts the path instead of
                    // retiring, so it carries no evidence about the clock state.
                    if (inst.status()==Sh2aDecoder.Status.VALID)
                        state.fpuStandby=Boolean.FALSE;
                }
            }
            switch (inst.status()) {
                case ILLEGAL_ENCODING -> {
                    issue(a,"GENERAL_ILLEGAL_INSTRUCTION_VECTOR_H10_"+hex(a)+"; "+
                            inst.mnemonic()+"; undefined code decoded outside a delay slot");
                    raiseSyncException(a,state,VECTOR_GENERAL_ILLEGAL,a,item.assumed(),
                            "GENERAL_ILLEGAL");
                    continue;
                }
                // Defined SH-2A-FPU opcode, semantics not implemented: halt at the issue,
                // no fabricated exception, no sequential edge (acceptance criterion 1).
                case UNSUPPORTED_IMPLEMENTATION -> {
                    issue(a,"UNSUPPORTED_IMPLEMENTATION_"+inst.mnemonic()+
                            "; valid encoding, semantics not implemented; no exception raised");
                    continue;
                }
                // Legality not established from the manual: neither executable nor illegal.
                case UNVERIFIED_ENCODING -> {
                    issue(a,"UNVERIFIED_ENCODING_"+inst.mnemonic()+
                            "; legality unverified; no execution and no exception");
                    continue;
                }
                // Bytes/address unavailable: image-availability issue, not a hardware vector.
                case INCOMPLETE_FETCH -> {
                    issue(a,inst.mnemonic()+
                            "; incomplete fetch/image availability; no exception, halted");
                    continue;
                }
                // Odd fetch address is a CPU address error (REJ09B0051-0300 sec.3.5 table 3.5
                // txt 2495-2497; vector number 9 -> H'24, table 3.3), architecturally distinct
                // from illegal encoding and from an availability shortage. Its stacked PC is
                // "start address of the instruction following the last instruction executed"
                // (sec.3.3 txt 2585-2586) and the error is accepted imprecisely/delayed, so
                // without a pipeline model NO edge is fabricated here; the frontier pre-validates
                // alignment, so this branch is a defensive classifier, not an executable route.
                case ADDRESS_ERROR -> {
                    issue(a,"CPU_ADDRESS_ERROR_VECTOR_H24_"+hex(a)+
                            "; odd fetch address; stacked PC needs pipeline model; no edge");
                    continue;
                }
                case VALID -> { }
            }
            // A numerical generation does not locate its physical CPU-ID report.
            // Reported events use the common arbiter above. Legacy/unverified FPU
            // reports keep explicit potential alternatives, not a cycle-accurate claim.
            if (state.fpuExceptionPending != null && state.systemPending.stream().noneMatch(e->
                    e.kind()==SystemExceptionModel.Kind.FPU&&e.availability()==SystemExceptionModel.Availability.AFTER_ISSUE)) {
                if (state.fpuExceptionPending == AbstractCpu.FPU_PENDING_AFTER_SLOT) {
                    // HW table7.10 bars the delay-slot ID, not the first target ID.
                    state.fpuExceptionPending=AbstractCpu.FPU_PENDING;
                    issue(a,"FPU_PENDING_SLOT_BAR_ENDED_AT_TARGET_ID_"+hex(a));
                }
                {
                    AbstractCpu accepting=state.copy();
                    accepting.fpuExceptionPending=null;
                    accepting.systemPending.replaceAll(e->e.kind()==SystemExceptionModel.Kind.FPU?e.reported():e);
                    issue(a,"FPU_EXCEPTION_PENDING_ACCEPTED_POTENTIAL_"+hex(a)+
                            "; stacked PC = this instruction address; exact acceptance point "
                            +"UNVERIFIED (pipeline latency)");
                    raiseSyncException(a,accepting,VECTOR_FPU_EXCEPTION,a,item.assumed(),
                            "FPU_EXCEPTION_PENDING_ACCEPTED");
                }
            }
            // The same 0xFxxx encoding changes meaning with FPSCR.PR/SZ.
            // A mode not proved on this path is not a license to guess.
            // Fix #15 (priority 1, ordering): the standby classification above runs BEFORE this
            // gate on purpose. While STBCR.MSTP1=1 the FPU clock is halted, so the instruction is
            // discarded at decode and FPSCR.SZ/PR is never consulted - an unresolved or unsupported
            // mode must not mask the mandatory H'10.
            if (!validFpuMode(state,inst)) {issue(a,"FPU_MODE_UNRESOLVED_OR_UNSUPPORTED_"+inst.mnemonic());continue;}
            own(inst,item.origin(),item.assumed());
            if(inst.flow()!=Sh2aDecoder.Flow.NEXT&&inst.operation()!=Sh2aDecoder.Operation.RTV_N
                    &&!beginInstruction(state,inst,false,item.assumed()))continue;
            // Resolve all targets / branch condition BEFORE the delay slot mutates registers.
            Integer direct=inst.target();
            Integer indirect=null;
            if (inst.flow()==Sh2aDecoder.Flow.INDIRECT ||
                    (inst.flow()==Sh2aDecoder.Flow.CALL && direct==null)) {
                if(inst.regN()>=0) {
                    Integer register=state.r[inst.regN()];
                    if (register!=null)
                        indirect=inst.imm()==1 ? a+4+register : register;
                }
            }
            Integer target=direct!=null?direct:indirect;
            // RTS snapshots PR before its slot (sec.6.4.49 pp.246-247); the same
            // destination supplies the contextual PC and a slot-illegal stacked PC.
            if (inst.operation()==Sh2aDecoder.Operation.RETURN) target=state.pr;
            if (inst.operation()==Sh2aDecoder.Operation.RTE) {
                Integer top=state.r[15];
                Integer savedPc=loadState(state,a,top,4);
                Integer savedSr=loadState(state,a,top==null?null:top+4,4);
                if (savedPc==null || state.cpuFault!=null) {
                    if(state.cpuFault!=null)issue(a,"H24_SAVED_PC_UNVERIFIED_RTE_FRAME; generation recorded; no guessed return target");
                    issue(a,"RTE_REQUIRES_KNOWN_STACK_PC_AND_COMPLETED_READ");
                    continue;
                }
                target=savedPc;
                state.r[15]=top+8;
                // RTE restores SR before executing its delayed-slot instruction.
                Sh7254rIntcMmio.reconcileBeforeRte(state);
                state.writeSr(savedSr);
            }
            if(inst.operation()==Sh2aDecoder.Operation.TBR_CALL) {
                Integer pointer=state.tbr==null?null:state.tbr+inst.imm();
                if(pointer!=null) {
                    Integer loaded=loadState(state,a,pointer,4);
                    if(loaded!=null && (validInstructionAddress(loaded)||bus.cpuFetchAddressError(loaded))) target=loaded;
                }
                if(state.cpuFault!=null){issue(a,"H24_SAVED_PC_UNVERIFIED_TBR_TARGET");continue;}
            }
            // SW6.4.6 p166 /6.4.12 p178: no delay slot when BT/S or BF/S is NOT taken.
            // Refine each alternative before executing its instructions, including PC-relative loads.
            if(inst.flow()==Sh2aDecoder.Flow.CONDITIONAL&&(inst.delaySlot()||state.pipeline!=null)) {
                boolean takenValue=inst.imm()==1;
                if(state.t==null) {
                    AbstractCpu notTaken=state.copy(); notTaken.t=!takenValue;
                    if(notTaken.pipeline!=null)notTaken.pipeline.assumeT(!takenValue);
                    retire(notTaken,a,false);
                    next(a,a+inst.width(),notTaken,item.assumed(),"CONDITIONAL_NOT_TAKEN");
                    state.t=takenValue;
                    if(state.pipeline!=null)state.pipeline.assumeT(takenValue);
                } else if(state.t!=takenValue) {
                    retire(state,a,false);
                    next(a,a+inst.width(),state,item.assumed(),"CONDITIONAL_NOT_TAKEN");
                    continue;
                }
            }
            if(!inst.delaySlot()&&inst.flow()!=Sh2aDecoder.Flow.NEXT&&inst.operation()!=Sh2aDecoder.Operation.RTV_N
                    &&inst.operation()!=Sh2aDecoder.Operation.TRAPA)retire(state,a,false);
            Boolean preSlotT=state.t;
            Integer preSlotPr=state.pr;
            int after=a+inst.width();
            int end=after;
            boolean call=inst.flow()==Sh2aDecoder.Flow.CALL;
            if (call) state.pr=a+inst.width()+(inst.delaySlot()?2:0);
            if (inst.delaySlot()) {
                if (!validInstructionAddress(after)) {issue(a,"DELAY_SLOT_BYTES_UNAVAILABLE");continue;}
                retire(state,a,false);
                state.pc=after;
                completeFpuAt(after,state);
                if(bus.cpuFetchAddressError(after)) {
                    addressFault(state,after,after,"CPU_FETCH_ADDRESS_ERROR");routeAddressFault(after,state,target);continue;
                }
                Sh2aDecoder.Instruction slot=fetchInstruction(state,after);
                if(state.pipeline!=null&&isFpuOperation(slot.operation()))state.fpscr=state.pipeline.decodeFpscr(state.fpscr);
                if(state.fpscr!=null && isFpuOperation(slot.operation()))slot=Sh2aDecoder.fpuContext(slot,state.fpscr);
                // FPU instruction in FPU module standby (§29.3.1 MSTP1, §7.6.1 txt 6759-6766,
                // §7.6.3 txt 6816-6829) is undefined code -> slot illegal, raised AT DECODE with
                // the stacked PC = jump destination of the delayed branch.
                // Fix #15 (priority 1, ordering): unified standby classification for the delay slot,
                // placed BEFORE the slot-illegal test and before the conservative halt below, so
                // neither an unresolved FPSCR mode nor an unimplemented semantic can hide the
                // standby outcome.
                //  MSTP1 = TRUE   -> upgrade to ILLEGAL_ENCODING (VALID and UNSUPPORTED_IMPLEMENTATION
                //                     alike: a defined opcode is still a proven FPU instruction), and the
                //                     existing slot-illegal route raises H'18;
                //  MSTP1 = UNKNOWN-> BOTH categories stay: a POTENTIAL H'18 against a COPY plus the
                //                     ordinary handling of the slot as the running-FPU hypothesis;
                //  MSTP1 = FALSE  -> ordinary semantics, untouched.
                // UNVERIFIED_ENCODING is never upgraded: its standing as an FPU instruction is not
                // established, so no vector may be claimed for it. Only a KNOWN destination is
                // stacked, never a recomputed guess (sec.3.7.3 step 3 analogue).
                if (isFpuOperation(slot.operation())
                        && (slot.status()==Sh2aDecoder.Status.VALID
                            || slot.status()==Sh2aDecoder.Status.UNSUPPORTED_IMPLEMENTATION)) {
                    if (Boolean.TRUE.equals(state.fpuStandby)) {
                        slot=Sh2aDecoder.illegalFpuStandby(slot);
                    } else if (state.fpuStandby==null) {
                        issue(a,"FPU_STANDBY_UNKNOWN_IN_DELAY_SLOT_"+hex(after)+"_POSSIBLE_H18_AND_"+
                                (slot.status()==Sh2aDecoder.Status.VALID
                                        ?"NORMAL_SLOT_KEPT":"UNSUPPORTED_HALT_KEPT"));
                        // Fix #15 (priority 3): per-path refinement, mirror of the main loop. The
                        // H'18 edge is taken ONLY while the FPU clock is halted (§7.6.3 txt
                        // 6816-6829), so the state entering the handler carries MSTP1=TRUE and
                        // keeps it (the bit cannot be cleared by software, §29.3.1 txt 64960-64967).
                        if(target!=null && validInstructionAddress(target)) {
                            AbstractCpu standbyPath=state.copy();
                            standbyPath.fpuStandby=Boolean.TRUE;
                            raiseSyncException(a,standbyPath,VECTOR_SLOT_ILLEGAL,target,
                                    item.assumed(),"FPU_STANDBY_UNKNOWN_POSSIBLE_SLOT_ILLEGAL");
                        }
                        else issue(a,"FPU_STANDBY_UNKNOWN_SLOT_ILLEGAL_DESTINATION_UNKNOWN");
                        // Fix #15 (priority 3) refinement, same reasoning as above: a slot that executes
                        // normally proves the FPU was clocked (§7.6.1 txt 6759-6766), so the
                        // continuation of this branch carries MSTP1=FALSE. VALID slots only.
                        if (slot.status()==Sh2aDecoder.Status.VALID)
                            state.fpuStandby=Boolean.FALSE;
                    }
                }
                // Slot illegal instruction exception (REJ09B0051-0300 Rev.3.00 sec.3.7.3
                // p.28 txt 2906-2928 + PC-modifier/32-bit list table 3.1 note 3, clean
                // layout p.16 txt 2058-2063). A delay slot raises slot illegal H'18 AT
                // DECODE only for: a proven ILLEGAL_ENCODING (undefined code), a 32-bit
                // instruction (width!=2), an instruction that modifies the PC (BRANCH/
                // CONDITIONAL/CALL/RETURN/INDIRECT or TRAPA), RESBANK, DIVS or DIVU.
                // A valid-but-unimplemented opcode (UNSUPPORTED_IMPLEMENTATION) is NOT
                // slot-illegal unless its prohibition is proved separately. FPU/FPU-related
                // undefined-in-slot applies while the FPU is in module standby (handled above by
                // the STBCR.MSTP1 re-classification); on a product WITHOUT an FPU the whole FPU
                // space is undefined, but SH7254R has an FPU, so only the standby case applies.
                boolean slotPcMod = slot.flow()==Sh2aDecoder.Flow.BRANCH
                        || slot.flow()==Sh2aDecoder.Flow.CONDITIONAL
                        || slot.flow()==Sh2aDecoder.Flow.CALL
                        || slot.flow()==Sh2aDecoder.Flow.RETURN
                        || slot.flow()==Sh2aDecoder.Flow.INDIRECT
                        || slot.operation()==Sh2aDecoder.Operation.TRAPA;
                boolean slotIllegal = slot.status()==Sh2aDecoder.Status.ILLEGAL_ENCODING
                        || slot.width()!=2
                        || slotPcMod
                        || slot.operation()==Sh2aDecoder.Operation.RESBANK
                        || slot.operation()==Sh2aDecoder.Operation.DIVS
                        || slot.operation()==Sh2aDecoder.Operation.DIVU;
                if(slotIllegal) {
                    issue(a,"SLOT_ILLEGAL_IN_DELAY_SLOT_VECTOR_H18_"+hex(after));
                    // Only a known destination can be stacked honestly (sec.3.7.3 step 3):
                    // the PC saved is the jump destination of the delayed branch, never a
                    // recomputed guess.
                    if(target!=null && validInstructionAddress(target))
                        raiseSyncException(a,state,VECTOR_SLOT_ILLEGAL,target,item.assumed(),
                                "SLOT_ILLEGAL");
                    else issue(a,"SLOT_ILLEGAL_DESTINATION_UNKNOWN; exception not routed");
                    continue;
                }
                // Valid-but-unimplemented slot (opaque FPU/CPU) or unresolved FPSCR mode:
                // halted conservatively, NOT
                // promoted to slot-illegal (no proven prohibition), no sequential edge.
                if(slot.status()!=Sh2aDecoder.Status.VALID || !validFpuMode(state,slot)) {
                    issue(a,"UNSUPPORTED_OR_UNVERIFIED_DELAY_SLOT_"+hex(after)+
                            "; not promoted to slot-illegal");
                    continue;
                }
                if (slot.operation()==Sh2aDecoder.Operation.MOV_PC ||
                        slot.operation()==Sh2aDecoder.Operation.MOVA) {
                    // A not-taken BF/S or BT/S uses the next instruction normally
                    // (sec.6.4.6 p.166 / sec.6.4.12 p.178), unlike a taken slot.
                    // Until path-specific slot processing exists, do not guess a
                    // common PC when T is unknown or the branch is not taken.
                    if (target==null || (inst.flow()==Sh2aDecoder.Flow.CONDITIONAL &&
                            (preSlotT==null || preSlotT!=(inst.imm()==1)))) {
                        issue(a,"PC_RELATIVE_DELAY_SLOT_DESTINATION_UNRESOLVED_"+hex(after));
                        continue;
                    }
                    slot=Sh2aDecoder.pcRelativeSlot(slot,target);
                }
                // Fix #15: the STBCR.MSTP1 classification for this slot already ran above, before
                // the slot-illegal test and before this conservative halt, so no standby outcome can
                // be lost here; reaching this point means standby is proven FALSE or the slot is not
                // an FPU operation.
                own(slot,"DELAY_SLOT_OF_"+hex(a),item.assumed());
                addEdge(a,after,"DELAY_SLOT");
                Integer slotPendingBefore=state.fpuExceptionPending;
                if(!execute(state,slot,true,item.assumed())){routeAddressFault(after,state,target);continue;}
                if(slotPendingBefore==null && state.fpuExceptionPending!=null) {
                    // HW7.7/table7.10 bars this slot, not the first target ID.
                    state.fpuExceptionPending=AbstractCpu.FPU_PENDING_AFTER_SLOT;
                    issue(a,"FPU_EXCEPTION_GENERATED_IN_DELAY_SLOT_"+hex(after)+
                            "; not accepted immediately after a delayed branch (table 3.9); "
                            +"slot ID barred; next target ID eligible subject to report availability");
                }
                end=after+slot.width();
            } else if (inst.operation()==Sh2aDecoder.Operation.DIVS ||
                    inst.operation()==Sh2aDecoder.Operation.DIVU) {
                // DIVS/DIVU outside a delay slot: architecturally possible outcomes
                // (sec.3.7.5 p.28, table 3.3 p.19, sec.6.3.13-14 pp.113-114; T bit column =
                // "-", i.e. not modified): normal completion, division by zero (VBR+H'44)
                // and, for DIVS only, signed MIN/-1 overflow (VBR+H'48). A DIV in a delay
                // slot is slot-illegal (handled above) and never reaches the arithmetic.
                int vector=divideExceptionVector(state,inst);
                if(vector!=0) {
                    // Proven exception: the instruction does NOT retire, so the sequential
                    // continuation is impossible and must not be emitted.
                    issue(a,"INTEGER_DIVISION_EXCEPTION_PROVEN_VECTOR_"+hex(vector)+
                            "; sequential edge not emitted by design");
                    raiseSyncException(a,state,vector,a,item.assumed(),
                            "INTEGER_DIVISION_EXCEPTION");
                    continue;
                } else if(state.r[0]==null || state.r[inst.regN()]==null) {
                    // Unknown operands: the exception CANNOT be excluded. Possible outcomes
                    // must all be kept: the potential vectors are emitted against COPIES of
                    // the pre-instruction state (the not-yet-executed arithmetic changes
                    // nothing), and normal completion keeps the sequential path with the
                    // quotient UNKNOWN. Possible is never promoted to guaranteed, and an
                    // UNKNOWN operand never discards a possible exception (bounded: at most
                    // two extra exception edges from one instruction).
                    boolean zeroPossible=state.r[0]==null;
                    boolean overflowPossible=inst.regN()!=0 && inst.operation()==Sh2aDecoder.Operation.DIVS
                            && (state.r[0]==null || state.r[0]==-1)
                            && (state.r[inst.regN()]==null || state.r[inst.regN()]==Integer.MIN_VALUE);
                    issue(a,"DIV_OPERANDS_UNKNOWN; normal completion possible; zeroPossible="+
                            zeroPossible+" overflowPossible="+overflowPossible);
                    boolean routed=false;
                    if(zeroPossible) routed=raiseSyncException(a,state.copy(),VECTOR_DIV_BY_ZERO,a,
                            item.assumed(),"DIV0_EXCEPTION_POTENTIAL");
                    if(overflowPossible) routed|=raiseSyncException(a,state.copy(),VECTOR_DIV_OVERFLOW,a,
                            item.assumed(),"DIV_OVERFLOW_EXCEPTION_POTENTIAL");
                    if((zeroPossible || overflowPossible) && !routed)
                        issue(a,"DIV_EXCEPTION_POTENTIAL_NOT_ROUTED; VBR/SP/vector "
                                +"prerequisites unknown; potential recorded in issues");
                    if(!execute(state,inst,false,item.assumed())){routeAddressFault(a,state,after);continue;}
                } else {
                    if(!execute(state,inst,false,item.assumed())){routeAddressFault(a,state,after);continue;}
                }
                next(a,after,state,item.assumed(),"NEXT");
                continue;
            } else if (inst.operation()==Sh2aDecoder.Operation.RESBANK &&
                    Integer.valueOf(0).equals(state.nextBank) && Boolean.FALSE.equals(state.bankOverflow)) {
                // SW3.5.1(2),7.5.1(2): known BO=0, BN=0 proves underflow.
                // No bank or ordinary continuation is restored; saved PC is RESBANK itself.
                issue(a,"RESBANK_BN_ZERO_BO_CLEAR; bank underflow vector "+hex(VECTOR_BANK_UNDERFLOW));
                raiseSyncException(a,state.copy(),VECTOR_BANK_UNDERFLOW,a,item.assumed(),
                        "BANK_UNDERFLOW_EXCEPTION");
                continue;
            } else if (inst.flow()==Sh2aDecoder.Flow.NEXT ||
                    inst.operation()==Sh2aDecoder.Operation.RTV_N) {
                if (!execute(state,inst,false,item.assumed())){routeAddressFault(a,state,after);continue;}
            }
            int source=inst.delaySlot()?after:a;
            switch(inst.flow()) {
                case NEXT -> next(a,after,state,item.assumed(),"NEXT");
                case BRANCH -> next(source,target,state,item.assumed(),"DIRECT_BRANCH");
                case CONDITIONAL -> {
                    boolean take=preSlotT==null || preSlotT==(inst.imm()==1);
                    boolean skip=preSlotT==null || preSlotT!=(inst.imm()==1);
                    if(take) next(source,target,state,item.assumed(),"CONDITIONAL_TAKEN");
                    if(skip) next(source,end,state,item.assumed(),"CONDITIONAL_NOT_TAKEN");
                }
                case CALL -> {
                    if (target!=null) next(source,target,state,item.assumed(),"CALL");
                    else {
                        issue(a,"UNRESOLVED_INDIRECT_CALL; no fabricated target");
                        // The callee body is unknown: it may never return and may clobber any
                        // register, FP/bank state and RAM before an eventual RTS. The return to
                        // end is therefore a CONDITIONAL path, kept at POSSIBLE_CODE level
                        // (assumed=true), never promoted to model-derived REACHABLE_CODE, and it
                        // carries NO caller values (opaqueAfterUnknownCall).
                        if(state.pipeline!=null)issue(a,"PIPELINE_NOT_IMPLEMENTED_OPAQUE_CALLEE_STATE");
                        else if(validInstructionAddress(end))
                            next(a,end,state.opaqueAfterUnknownCall(),true,
                                    "POSSIBLE_RETURN_THROUGH_UNKNOWN_TARGET");
                    }
                }
                case INDIRECT -> {
                    if(target!=null) next(source,target,state,item.assumed(),"INDIRECT_TARGET_PROPAGATED");
                    else issue(a,"UNRESOLVED_INDIRECT_BRANCH");
                }
                case RETURN -> {
                    if (inst.operation()==Sh2aDecoder.Operation.RTE) next(source,target,state,item.assumed(),"RTE_RESTORED_PC_SR");
                    else if(preSlotPr!=null) next(source,preSlotPr,state,item.assumed(),"RETURN_USING_PR");
                    else issue(a,"RETURN_PR_UNKNOWN");
                }
                case EXCEPTION -> {
                    if(inst.operation()!=Sh2aDecoder.Operation.TRAPA) {
                        issue(a,"EXCEPTION_KIND_NOT_MODELED");break;
                    }
                    // SW6.4.65 p269: same exception-entry primitive, resume after TRAPA.
                    raiseSyncException(a,state,inst.imm()*4,a+inst.width(),item.assumed(),
                            "SYNCHRONOUS_TRAPA_VECTOR");
                }
                case STOP -> {
                    cpuBoundaries.add(new CpuBoundary(a,"SLEEP_OR_STANDBY_REQUEST",null,a+inst.width(),null));
                    issue(a,"SLEEP_OR_STOP_REQUIRES_INTERRUPT_MODEL");
                }
                case UNKNOWN -> issue(a,"UNEXPECTED_UNKNOWN_FLOW");
            }
        }
        this.resetPc=pc; this.resetSp=sp;
        truncated=!work.isEmpty() || frontierLimited;
        if (truncated) issue(-1,"ANALYSIS_BOUND_REACHED; coverage incomplete");
        if (classifier.evidenceOverflow())
            issue(-1,"CLASSIFICATION_EVIDENCE_CAP_REACHED; provenance rows truncated");
        lastVectors=candidateVectors(rom);
        return report();
    }
    /**
     * Applies an operator-supplied execution witness (observed PC sequence). Only addresses
     * that this analysis already decoded become CONFIRMED_CODE, and only ROM bytes that those
     * confirmed instructions read become CONFIRMED_DATA. Addresses that were not decoded are
     * reported instead of being invented, so the witness cannot smuggle new code into the map.
     */
    public void applyObservedTrace(List<Integer> observedPc,String source) {
        if (observedPc == null || source == null || source.isBlank())
            throw new IllegalArgumentException("Observed trace and its source are required");
        for (Integer pcValue : observedPc) {
            if (pcValue == null || !bus.romRange(Integer.toUnsignedLong(pcValue),2)
                    || (pcValue & 1) != 0) {
                issue(pcValue==null?-1:pcValue,"OBSERVED_PC_OUTSIDE_ROM_OR_MISALIGNED");
                continue;
            }
            int pc=pcValue;
            if (!code.containsKey(pc)) { issue(pc,"CONFIRMED_PC_NOT_DECODED; trace kept, code not invented"); continue; }
            String condition="observed execution trace from "+source;
            for (int i=0;i<code.get(pc).width();i++)
                classifier.confirmFetched(pc+i,"TRACE:"+source,condition);
            for (DataReference r : data)
                if (r.from()==pc && r.kind().equals("ROM_LOAD"))
                    for (int i=0;i<r.width();i++)
                        classifier.claim(r.to()+i,CodeDataClassifier.Status.CONFIRMED_DATA,
                                "ROM_DATA_READ_OBSERVED","TRACE:"+source,condition,
                                "witnessed reader instruction", -1);
        }
    }
    /**
     * Rebuilds the report from the current state so an applied trace witness is reflected in the
     * classification columns. Vector candidates are not re-derived: that would add duplicate
     * provenance rows for addresses that are already recorded.
     */
    public Report report() {
        if (bus==null) throw new IllegalStateException("analyze() must run before report()");
        return new Report(bus.cpu(),resetPc,resetSp,Map.copyOf(code),List.copyOf(edges),
                List.copyOf(issues),List.copyOf(data),List.copyOf(ramFlows),lastVectors,
                List.copyOf(preemptions),classifier.snapshot(),classifier.evidence(),
                processed,truncated);
    }
    private boolean validInstructionAddress(int a) {
        long u=Integer.toUnsignedLong(a);
        return (a&1)==0 && (bus.romRange(u,2) ||
                u>=Sh7254rMemoryMap.SRAM_START && u+2<=Sh7254rMemoryMap.SRAM_END_EXCLUSIVE);
    }
    private Sh2aDecoder.Instruction fetchInstruction(AbstractCpu state,int address) {
        long u=Integer.toUnsignedLong(address);
        if(bus.romRange(u,2)) return decoder.decode(busRom,address);
        byte[] bytes=new byte[4];int count=0;
        while(count<4 && u+count<Sh7254rMemoryMap.SRAM_END_EXCLUSIVE) {
            Byte value=state.ram.get(address+count);
            if(value==null) break;
            bytes[count++]=value;
        }
        return decoder.decodeFetched(Arrays.copyOf(bytes,count),address);
    }
    /** Image availability is distinct from the hardware fetch errors in table7.6.
     * Known odd/I/O/SRAM-prefetch faults are routed before this diagnostic. */
    private String fetchAddressReason(int a) {
        if ((a & 1) != 0)
            return "CPU_ADDRESS_ERROR_ODD_FETCH_VECTOR_H24_" + hex(a) + "; sec.3.5 table 3.5 txt 2495-2497";
        return switch (bus.region(Integer.toUnsignedLong(a))) {
            case MMIO_WINDOW -> "CPU_FETCH_ADDRESS_ERROR_VECTOR_H24_" + hex(a) + "; Hardware7.3.1 table7.6";
            case EXTERNAL_OR_RESERVED -> "FETCH_BYTES_ABSSENT_IN_BIN_" + hex(a)
                    + "; byte availability only, memory presence/mode unverified";
            case EEPROM_READ -> "FETCH_EEPROM_REGION_BYTES_ABSENT_IN_BIN_" + hex(a);
            default -> "FETCH_BYTES_ABSSENT_IN_BIN_" + hex(a) + "; region may be executable at runtime";
        };
    }
    private void issue(int address,String text) { issues.add(new Issue(address,text)); }
    private void own(Sh2aDecoder.Instruction inst,String origin,boolean assumed) {
        Sh2aDecoder.Instruction previous=code.putIfAbsent(inst.address(),inst);
        if (previous!=null && !previous.equals(inst)) issue(inst.address(),"CONFLICT_INSTRUCTION_DECODING");
        // Decodability never grants CONFIRMED_CODE: a path from a user-supplied entry stays
        // POSSIBLE_CODE, a path derived from the model's own successors is REACHABLE_CODE.
        CodeDataClassifier.Status status=assumed?CodeDataClassifier.Status.POSSIBLE_CODE
                :CodeDataClassifier.Status.REACHABLE_CODE;
        String condition=assumed?COND_MANUAL_ENTRY
                :"reached through "+origin+"; unresolved inputs on that path stay UNKNOWN";
        for (int i=0;i<inst.width();i++) {
            int byteAddress=inst.address()+i;
            var claim=classifier.claim(byteAddress,status,"FETCH",origin,condition,
                    LIMIT_ABSTRACT,inst.address());
            if("OVERLAPPING_INSTRUCTION_STREAMS".equals(claim.reason()))
                issue(inst.address(),"OVERLAPPING_INSTRUCTION_STREAMS_AT_"+hex(byteAddress));
            else if(claim.status()==CodeDataClassifier.Status.CONFLICT)
                issue(inst.address(),"CODE_DATA_OVERLAP");
        }
    }
    private void next(int from,Integer to,AbstractCpu state,boolean assumed,String type) {
        next(from,to,state,assumed,type,true);
    }
    private void next(int from,Integer to,AbstractCpu state,boolean assumed,String type,boolean arbitrate) {
        if(state.cpuFault!=null || state.unmodeledPeripheralWrite) return;
        if(state.sleepRequested) {
            cpuBoundaries.add(new CpuBoundary(from,"SLEEP_OR_STANDBY_REQUEST",null,to,null));
            issue(from,"SLEEP_OR_STOP_REQUIRES_INTERRUPT_MODEL");return;
        }
        if (to==null) {issue(from,"UNRESOLVED_TARGET_"+type);return;}
        if(bus.cpuFetchAddressError(to)) {
            var fault=state.copy();addressFault(fault,to,to,"CPU_FETCH_ADDRESS_ERROR");
            routeAddressFault(from,fault,to);return;
        }
        if (!validInstructionAddress(to)) {issue(from,"INVALID_TARGET_"+hex(to)+"_"+type);return;}
        // Each successor must own its CPU state: alternative conditional paths
        // cannot share the bank/stack mutations produced by interrupt entry.
        AbstractCpu outgoing=state.copy();
        // The boundary is reached only after a delayed instruction is executed.
        // In particular, no SINT event may preempt the pending delay slot.
        outgoing.lastResumePc=to;
        var request=softwareIrq.select(outgoing,to);
        if(arbitrate && request.status()==Sh7254rSoftwareInterruptScheduler.Status.READY) {
            if(outgoing.irqMaskChangeWindow>0) {
                issue(from,"SINT_MASK_CHANGE_DELIVERY_UNVERIFIED_WINDOW_"+outgoing.irqMaskChangeWindow);
                AbstractCpu deferred=outgoing.copy();deferred.pc=to;
                addEdge(from,to,"POTENTIAL_SINT_MASK_SYNC_DEFERRED");
                if(work.size()<10_000)work.addLast(new WorkItem(to,deferred,"MASK_SYNC_DEFERRED",true));
                else{frontierLimited=true;issue(from,"WORKLIST_CAP_REACHED");}
            }
            var delivery=new SystemExceptionModel.Event(-request.sourceNumber(),SystemExceptionModel.Kind.SOFTWARE,
                    null,null,request.event().vectorOffset(),request.event().priority(),"SINTR"+request.sourceNumber(),SystemExceptionModel.Availability.PIPELINE_UNVERIFIED);
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.PENDING,delivery,to,null,null,"INTC delivery latency not clocked"));
            // SINTR supplies an abstract report; delivery latency remains an explicit assumption.
            var reported=delivery.reported();
            if(outgoing.systemPending.stream().noneMatch(e->e.kind()==SystemExceptionModel.Kind.SOFTWARE&&e.vectorOffset()==reported.vectorOffset()))
                outgoing.systemPending.add(reported);
            var result=arbitrateId(from,to,outgoing,assumed,"SYSTEM_ACCEPTED_AFTER_INSTRUCTION",
                    List.copyOf(outgoing.systemPending),null,false,"ASSUMED_INTC_DELIVERY_AT_BOUNDARY");
            if(result.stopsInstruction())return;
        } else if (arbitrate && (request.status()==Sh7254rSoftwareInterruptScheduler.Status.INDETERMINATE_MASK ||
                request.status()==Sh7254rSoftwareInterruptScheduler.Status.INDETERMINATE_PENDING)) {
            issue(from,"POSSIBLE_SOFTWARE_INTERRUPT_UNRESOLVED_"+request.status());
            // An ordinary path remains a hypothesis, not a proven CPU trace.
        }
        addEdge(from,to,type);
        // More than one path to the same PC joins unknown values instead of assuming equality.
        if (work.size() >= 10_000) {
            if (!frontierLimited) issue(from,"WORKLIST_CAP_REACHED; other paths may be missing");
            frontierLimited=true;
            return;
        }
        outgoing.pc=to;
        work.addLast(new WorkItem(to,outgoing,"EDGE_"+type+"_FROM_"+hex(from),assumed));
    }
    private void addEdge(int from,int to,String type) {edges.add(new Edge(from,to,type));}
    /**
     * Routes a CONCRETE synchronous exception through the instruction-exception primitive:
     * REJ09B0051-0300 Rev.3.00 sec.3.7.5 p.28 (integer division: SR stacked first, then PC
     * = start address of the dividing instruction itself, jump to VBR+H'44/H'48 is not a
     * delayed branch), sec.3.7.3 p.28 (slot illegal: DIVS/DIVU/RESBANK/32-bit in a delay
     * slot raise the exception at decode; PC = jump destination of the delayed branch),
     * sec.3.1.2(2) p.18 (instruction exceptions: no bank saving, SR.I unchanged),
     * sec.3.10.1-3.10.2 p.32 (SP and VBR must be multiples of 4). If any prerequisite is
     * unknown, nothing is fabricated: no state changes and the caller stops the path.
     */
    private boolean raiseSyncException(int site,AbstractCpu state,int vectorOffset,int stackedPc,
                                        boolean assumed,String reason) {
        SystemExceptionModel.Kind kind=reason.contains("TRAPA")?SystemExceptionModel.Kind.TRAPA:SystemExceptionModel.synchronous(vectorOffset);
        SystemExceptionModel.Event event=state.systemPending.stream().filter(e->e.kind()==kind).findFirst().orElse(null);
        if(event==null) {
            event=state.queueSystem(kind,kind==SystemExceptionModel.Kind.FPU?null:state.pc==null?site:state.pc,null,vectorOffset,0,reason,SystemExceptionModel.Availability.REPORTED_ID);
            if(kind==SystemExceptionModel.Kind.FPU)systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.PENDING,event,site,null,null,"adopted legacy latch; generator provenance UNKNOWN"));
            else observeGenerated(state,event);
        }
        if(kind!=SystemExceptionModel.Kind.FPU) {
            var contextual=event.withSavedPc(stackedPc);
            state.systemPending.remove(event);state.systemPending.add(contextual);event=contextual;
        }
        return arbitrateId(site,state.pc==null?site:state.pc,state,assumed,reason,List.copyOf(state.systemPending),event,
                kind==SystemExceptionModel.Kind.SLOT_ILLEGAL,
                reason.contains("FPU_EXCEPTION_PENDING_ACCEPTED")?"POTENTIAL_ID_REPORT":"REPORTED_ID_ARCHITECTURAL").routed();
    }
    private void addressFault(AbstractCpu state,int generator,Integer address,String source) {
        if(state.cpuFault!=null)return;
        state.cpuFault=source;state.faultAddress=address;
        var event=state.queueSystem(SystemExceptionModel.Kind.CPU_ADDRESS,generator,address,0x24,0,
                source,SystemExceptionModel.Availability.PIPELINE_UNVERIFIED);
        observeGenerated(state,event);
        cpuBoundaries.add(new CpuBoundary(generator,source,address,null,0x24));
    }
    private void routeAddressFault(int site,AbstractCpu state,Integer resumePc) {
        if(state.cpuFault==null)return;
        if(resumePc==null){issue(site,"H24_SAVED_PC_UNVERIFIED_CONTROL_TARGET");return;}
        // This is a possible first ID after completion, not evidence of the physical
        // last retired instruction in an overlapping 2-ILP pipeline.
        var copy=state.copy();copy.cpuFault=null;copy.faultAddress=null;
        copy.systemPending.replaceAll(e->e.kind()==SystemExceptionModel.Kind.CPU_ADDRESS?e.reported():e);
        if(!"CPU_FETCH_ADDRESS_ERROR".equals(state.cpuFault))copy.lastRetiredPc=site;
        copy.inFlightPc=null;copy.inFlightDivision=false;
        issue(site,"H24_POTENTIAL_COMPLETION_ID_"+hex(resumePc)+"; overlapping issue/bus report timing UNVERIFIED");
        arbitrateId(site,resumePc,copy,true,"H24_POTENTIAL_COMPLETION_ID",List.copyOf(copy.systemPending),null,false,
                "POTENTIAL_COMPLETION_ID; physical last-retired/latency UNVERIFIED");
    }
    private void observeGenerated(AbstractCpu state,SystemExceptionModel.Event event) {
        systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.GENERATION,event,state.pc,null,null,"event generated; acceptance separate"));
        systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.PENDING,event,state.pc,null,null,event.availability().name()));
    }
    private record IdResult(boolean stopsInstruction,boolean routed) {}
    private boolean acceptReportedAtId(int pc,AbstractCpu state,boolean assumed) {
        return arbitrateId(pc,pc,state,assumed,"SYSTEM_REPORTED_ID",List.copyOf(state.systemPending),null,false,"REPORTED_ID_ARCHITECTURAL").stopsInstruction();
    }
    private IdResult arbitrateId(int site,int decodePc,AbstractCpu state,boolean assumed,String reason,
                                List<SystemExceptionModel.Event> candidates,SystemExceptionModel.Event decodedEvent,
                                boolean slot,String evidence) {
        // TRAPA completes by its own exception sequence. Reports arriving after its
        // issue wait for that sequence; SW8.9.6(16)/8.9.7(1), not DIV cancellation.
        boolean completingTrap=decodedEvent!=null&&decodedEvent.kind()==SystemExceptionModel.Kind.TRAPA
                &&Objects.equals(state.inFlightPc,decodedEvent.generatorPc());
        if(completingTrap)candidates=List.of(decodedEvent);
        var boundary=new SystemExceptionModel.Boundary(decodePc,slot,state.inFlightPc==null||completingTrap,state.inFlightDivision);
        var decision=SystemExceptionModel.select(candidates,state.interruptMask,boundary);
        for(var event:decision.candidates())systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.ARBITRATION,event,decodePc,null,null,decision.status().name()));
        if(decision.status()==SystemExceptionModel.Status.WAIT_COMPLETION||decision.status()==SystemExceptionModel.Status.DEFERRED_SLOT)
            for(var event:candidates)if(event.availability()==SystemExceptionModel.Availability.REPORTED_ID)
                systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.PENDING,event,decodePc,null,null,decision.status().name()));
        if(decision.status()==SystemExceptionModel.Status.ACCEPT) {
            var winner=decision.winner();
            if(decodedEvent!=null&&!winner.equals(decodedEvent))state.systemPending.remove(decodedEvent);
            Integer saved=SystemExceptionModel.savedPc(winner,decodePc);
            if(saved==null&&winner.kind()!=SystemExceptionModel.Kind.POWER_ON_RESET){issue(site,"SAVED_PC_CONTEXT_UNVERIFIED_"+winner.kind());return new IdResult(true,false);}
            String acceptedReason=reason.equals("SYSTEM_ACCEPTED_AFTER_INSTRUCTION")?
                    (winner.kind()==SystemExceptionModel.Kind.SOFTWARE?"SINT"+winner.level():winner.kind().name())+"_ACCEPTED_AFTER_INSTRUCTION":reason;
            return new IdResult(true,enterSystem(site,decodePc,state,winner,saved==null?0:saved,assumed,acceptedReason,evidence));
        }
        if(decision.status()==SystemExceptionModel.Status.UNVERIFIED_TIMING) {
            var known=SystemExceptionModel.select(candidates.stream().filter(e->e.availability()==SystemExceptionModel.Availability.REPORTED_ID).toList(),state.interruptMask,boundary);
            if(known.status()==SystemExceptionModel.Status.ACCEPT) {
                boolean routed=false;
                for(var candidate:decision.candidates()) {
                    var copy=state.copy();copy.systemPending.replaceAll(e->e.equals(candidate)?e.reported():e);
                    var selected=candidate.reported();
                    if(decodedEvent!=null&&!candidate.equals(decodedEvent))copy.systemPending.remove(decodedEvent);
                    Integer saved=SystemExceptionModel.savedPc(selected,decodePc);
                    if(saved==null&&selected.kind()!=SystemExceptionModel.Kind.POWER_ON_RESET)issue(site,"SAVED_PC_CONTEXT_UNVERIFIED_"+selected.kind());
                    else routed|=enterSystem(site,decodePc,copy,selected,saved==null?0:saved,assumed,reason+"_POTENTIAL_"+selected.kind(),"POTENTIAL_ID_REPORT_ORDER");
                    if(candidate.equals(known.winner()))break;
                }
                return new IdResult(true,routed);
            }
        }
        return new IdResult(false,false);
    }
    private boolean enterSystem(int site,int decodePc,AbstractCpu state,SystemExceptionModel.Event event,int savedPc,boolean assumed,String reason,String evidence) {
        if(state.pipeline!=null&&!state.pipeline.outstanding().isEmpty()&&event.kind()!=SystemExceptionModel.Kind.POWER_ON_RESET) {
            blockPipeline(state,decodePc,"UNVERIFIED_EXCEPTION_PHASE_"+event.kind());
            issue(site,"PIPELINE_EXCEPTION_PHASE_UNVERIFIED_"+event.kind()+"; in-flight preserved, no guessed saved PC");
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.BLOCKED,event,decodePc,null,null,"outstanding pipeline; acceptance phase input required"));
            return false;
        }
        if(state.deferredFpuResult!=null&&event.kind()==SystemExceptionModel.Kind.FPU) {
            issue(site,"FPU_COMPLETION_PROFILE_EXCEPTION_TIMING_UNVERIFIED; normal-only completion input cannot order this report");
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.BLOCKED,event,decodePc,null,null,"normal completion/report ordering UNVERIFIED"));
            return false;
        }
        if(event.kind()==SystemExceptionModel.Kind.POWER_ON_RESET) {
            Integer pc=bus.readRom(0,4),sp=bus.readRom(4,4);
            if(pc==null||sp==null||!(validInstructionAddress(pc)||bus.cpuFetchAddressError(pc))||(sp&3)!=0||Integer.toUnsignedLong(sp)<Sh7254rMemoryMap.SRAM_START||Integer.toUnsignedLong(sp)>Sh7254rMemoryMap.SRAM_END_EXCLUSIVE) {
                issue(site,"POWER_ON_RESET_VECTOR_UNAVAILABLE");return false;
            }
            var resetPipeline=state.pipeline;
            if(resetPipeline!=null)resetPipeline.reset();
            cancelInFlight(state);state.restoreFaultState(new AbstractCpu(sp));state.pc=pc;
            state.pipeline=resetPipeline;
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.ACCEPTANCE,event,decodePc,null,pc,"RESET_NO_STACK"));
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.TRANSITION,event,decodePc,null,pc,"VBR0;I15;BO/CS/BN0;FPSCR40001;undefined registers remain unknown"));
            next(site,pc,state,assumed,"POWER_ON_RESET",false);return true;
        }
        SystemExceptionModel.Event bankFault=null;
        boolean bankRequested=SystemExceptionModel.interrupt(event.kind())&&event.kind()!=SystemExceptionModel.Kind.NMI&&event.kind()!=SystemExceptionModel.Kind.USER_BREAK
                &&(Integer.valueOf(1).equals(state.bankEnable)||Integer.valueOf(3).equals(state.bankEnable)&&state.bankPriorityMask!=null&&(state.bankPriorityMask&(1<<event.level()))!=0);
        if(bankRequested&&Integer.valueOf(15).equals(state.nextBank)&&Boolean.TRUE.equals(state.bankOverflowException)) {
            bankFault=state.queueSystem(SystemExceptionModel.Kind.BANK_OVERFLOW,event.generatorPc(),null,0x3c,event.level(),
                    "BANK_OVERFLOW_FROM_"+event.source(),SystemExceptionModel.Availability.REPORTED_ID);
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.GENERATION,bankFault,decodePc,null,null,"all banks saved; BOVE1; interrupt selected"));
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.PENDING,bankFault,decodePc,null,null,"before vector/stack entry"));
        }
        var entry=SystemExceptionModel.interrupt(event.kind())?
                interruptEntry.enter(state,new Sh7254rInterruptController.Event(savedPc,event.vectorOffset(),event.level(),
                        event.kind()==SystemExceptionModel.Kind.NMI,event.kind()!=SystemExceptionModel.Kind.USER_BREAK),bus):
                interruptEntry.raiseInstructionException(state,event.vectorOffset(),savedPc,bus);
        if(entry.disposition()!=Sh7254rInterruptController.Disposition.ENTERED) {
            if(entry.disposition()==Sh7254rInterruptController.Disposition.INVALID_STACK&&state.r[15]!=null&&(state.r[15]&3)!=0) {
                addressFault(state,decodePc,state.r[15]-4,"STACKING_ADDRESS_ERROR");
                issue(site,"STACKING_WRITES_UNDEFINED_H24_NESTING_UNVERIFIED; no fabricated frame");
            }
            if(entry.disposition()==Sh7254rInterruptController.Disposition.VBR_NOT_ALIGNED)
                addressFault(state,decodePc,state.vbr+event.vectorOffset(),"VECTOR_FETCH_ADDRESS_ERROR");
            issue(site,reason+"_VECTOR_NOT_ROUTED_"+entry.disposition());
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.BLOCKED,event,decodePc,savedPc,null,entry.disposition().name()));return false;
        }
        if(event.kind()==SystemExceptionModel.Kind.TRAPA&&Objects.equals(state.inFlightPc,event.generatorPc()))
            retire(state,state.inFlightPc,false);
        else cancelInFlight(state);
        if(event.kind()==SystemExceptionModel.Kind.BANK_OVERFLOW){state.interruptMask=event.level();state.sr=null;}
        boolean interruptSource=SystemExceptionModel.interrupt(event.kind());
        Integer observedSavedPc=savedPc;
        if(entry.initialVector()!=null) {
            var first=entry.initialVector()==0x3c&&bankFault!=null?bankFault:event;
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.ACCEPTANCE,first,decodePc,null,entry.initialHandler(),"stack write data UNDEFINED, HW7.9.3"));
            state.systemPending.remove(first);
            if(first.kind()==SystemExceptionModel.Kind.FPU)state.fpuExceptionPending=null;
            event=state.queueSystem(SystemExceptionModel.Kind.CPU_ADDRESS,decodePc,entry.stackingFaultAddress(),0x24,0,"EXCEPTION_STACKING",SystemExceptionModel.Availability.REPORTED_ID);
            observeGenerated(state,event);
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.TRANSITION,first,decodePc,null,entry.initialHandler(),"first exception sequence completed; H24 precedes handler instruction"));
            observedSavedPc=null;reason+="_STACKING_H24";
        } else if(entry.stackingFaultAddress()!=null) {
            var suppressed=state.queueSystem(SystemExceptionModel.Kind.CPU_ADDRESS,decodePc,entry.stackingFaultAddress(),0x24,0,"H24_STACKING_SUPPRESSED",SystemExceptionModel.Availability.REPORTED_ID);
            systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.GENERATION,suppressed,decodePc,null,null,"not accepted during H24 stacking, HW7.9.3"));
            state.systemPending.remove(suppressed);observedSavedPc=null;
        } else if(entry.vectorOffset()!=event.vectorOffset()) {
            if(bankFault==null)throw new IllegalStateException("unclassified exception redirection");
            event=bankFault;
        }
        if(interruptSource&&entry.stackingFaultAddress()==null)preemptions.add(new Preemption(savedPc,entry.handler(),entry.vectorOffset(),site,event.source()+"_"+evidence));
        state.systemPending.remove(event);
        if(event.kind()==SystemExceptionModel.Kind.FPU)state.fpuExceptionPending=null;
        systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.ACCEPTANCE,event,decodePc,observedSavedPc,entry.handler(),evidence));
        systemEvents.add(new SystemExceptionModel.Observation(SystemExceptionModel.Stage.TRANSITION,event,decodePc,observedSavedPc,entry.handler(),"SR then PC stacked; non-delayed handler transfer"));
        addEdge(site,entry.handler(),reason+"_VBR_PLUS_"+hex(entry.vectorOffset()));
        if(state.pipeline!=null)state.pipeline.rebase(state);
        next(site,entry.handler(),state,assumed,reason,false);
        return true;
    }
    private void ref(int from,int target,int width,String kind) {
        data.add(new DataReference(from,target,width,kind));
        if (!bus.romRange(Integer.toUnsignedLong(target),width)) return;
        if (!kind.equals("ROM_LOAD")) return;
        // CONFIRMED_DATA would need an observed witness; a model-derived load is evidence of
        // data usage only under the stated prerequisites, so POSSIBLE_DATA is the ceiling here.
        CodeDataClassifier.Status reader=classifier.statusAt(from);
        CodeDataClassifier.Status status=reader==CodeDataClassifier.Status.CONFIRMED_CODE
                ?CodeDataClassifier.Status.CONFIRMED_DATA:CodeDataClassifier.Status.POSSIBLE_DATA;
        String condition="read as data by "+hex(from)+"; reader status "+reader;
        for (int i=0;i<width;i++) {
            int a=target+i;
            var claim=classifier.claim(a,status,"ROM_DATA_READ",hex(from),condition,
                    LIMIT_ABSTRACT,-1);
            if(claim.status()==CodeDataClassifier.Status.CONFLICT)
                issue(from,"CODE_DATA_OVERLAP_AT_"+hex(a));
        }
    }
    private static Integer binary(Integer a,Integer b,java.util.function.IntBinaryOperator op) {
        return a==null||b==null?null:op.applyAsInt(a,b);
    }
    private static boolean validFpuMode(AbstractCpu state,Sh2aDecoder.Instruction i) {
        Integer mode=state.fpscr;
        return switch(i.operation()) {
            case FPU_ARITHMETIC,FPU_COMPARE,FPU_SQRT,FPU_FMAC,FPU_CONVERT ->
                    mode!=null && (mode&3)<=1;
            case FPU_MODE -> mode!=null && (mode&FpuSemantics.PR)==0;
            case FPU_IMMEDIATE -> mode!=null && (mode&FpuSemantics.PR)==0;
            case FPU_SIGN -> mode!=null && ((mode&FpuSemantics.PR)==0 || (i.regN()&1)==0);
            case FPU_MEM_LOAD -> mode!=null &&
                    ((mode&FpuSemantics.SZ)==0 || (i.regN()&1)==0);
            case FPU_MEM_STORE -> mode!=null &&
                    ((mode&FpuSemantics.SZ)==0 || (i.regM()&1)==0);
            case FPU_REG_MOVE -> !i.mnemonic().startsWith("FMOV") || mode!=null;
            default -> true;
        };
    }
    private static int extend(int value,int bytes) {
        return switch(bytes) {case 1 -> (byte)value;case 2 -> (short)value; default -> value;};
    }
    /**
     * Concrete DIVS/DIVU exception condition, REJ09B0051-0300 Rev.3.00 sec.6.3.13-14
     * pp.113-114 (direction: Rn is the dividend, R0 the divisor) and sec.3.7.5 p.28:
     * division by zero -> H'44 for both; signed MIN/-1 -> H'48 for DIVS only.
     * Returns 0 when no exception is proved (including unknown operands, where the
     * exception cannot be excluded and no vector may be claimed).
     */
    private static int divideExceptionVector(AbstractCpu s,Sh2aDecoder.Instruction i) {
        Integer divisor=s.r[0], dividend=s.r[i.regN()];
        if(Integer.valueOf(0).equals(divisor)) return VECTOR_DIV_BY_ZERO;
        if(divisor==null||dividend==null) return 0;
        if(i.operation()==Sh2aDecoder.Operation.DIVS &&
                dividend==Integer.MIN_VALUE && divisor==-1) return VECTOR_DIV_OVERFLOW;
        return 0;
    }
    private Integer load(int from,Integer address,int width) {
        if(address==null) {issue(from,"LOAD_ADDRESS_UNKNOWN");return null;}
        if ((address & (width-1)) != 0) {
            issue(from,"MISALIGNED_LOAD_"+hex(address));return null;
        }
        long a=Integer.toUnsignedLong(address);
        Sh7254rMemoryMap.Region region=bus.region(a);
        if(region==Sh7254rMemoryMap.Region.USER_ROM) {
            ref(from,address,width,"ROM_LOAD");
            return bus.readRom(a,width);
        }
        if(region==Sh7254rMemoryMap.Region.SRAM) return null; // handled in loadState
        if(region==Sh7254rMemoryMap.Region.MMIO_WINDOW) {
            ref(from,address,width,"MMIO_READ_UNKNOWN");
            issue(from,"UNMODELED_PERIPHERAL_READ_"+hex(address)+"_WIDTH_"+width);
            return null;
        }
        issue(from,"UNMAPPED_OR_UNINITIALIZED_LOAD_"+hex(address));
        return null;
    }
    private Integer loadState(AbstractCpu s,int from,Integer address,int width) {
        if(s.cpuFault!=null) return null;
        if(address!=null && (address & (width-1)) != 0) {
            issue(from,"MISALIGNED_LOAD_"+hex(address));
            addressFault(s,from,address,"CPU_ADDRESS_ERROR_READ");return null;
        }
        if(address!=null && bus.region(Integer.toUnsignedLong(address))==Sh7254rMemoryMap.Region.SRAM) {
            Integer writer=s.writerOf(address,width);
            if(writer!=null) ramFlows.add(new RamDependency(writer,from,address,width,
                    "POSSIBLE_SAME_PATH_RAM_WRITE_THEN_READ"));
            return s.readRam(address,width);
        }
        if(address!=null && bus.region(Integer.toUnsignedLong(address))==Sh7254rMemoryMap.Region.MMIO_WINDOW) {
            // Fix #17: STBCR is a READABLE register at sizes 8 and 16 (§29.3.1 txt 64868,
            // txt 64882-64883; §29.3.2 txt 64998-64999), so an access lying wholly inside
            // H'FFFE0400..H'FFFE0401 must not be answered as UNMODELED_PERIPHERAL_READ.
            // loadStbcr was never reachable from here before this wiring (dead code).
            // Only these two shapes are claimed: a wider access also covers the neighbouring
            // register, whose behaviour is not STBCR's, so it stays fail-closed in load().
            int stbcrOffset=address.intValue()-Sh7254rMemoryMap.STBCR;
            if ((stbcrOffset==0 && (width==1||width==2)) || (stbcrOffset==1 && width==1)) {
                return loadStbcr(s,from,address.intValue(),width);
            }
            var access=Sh7254rIntcMmio.read(s,address,width);
            if(access.handled()) {
                ref(from,address,width,"MMIO_INTC_READ");
                if(!access.validWidth())issue(from,"INTC_READ_WIDTH_UNSUPPORTED_"+hex(address));
                return access.value();
            }
        }
        return load(from,address,width);
    }
    private void store(AbstractCpu s,int from,Integer address,int width,Integer value) {
        if(s.cpuFault!=null) return;
        if(address==null) {
            issue(from,"STORE_ADDRESS_UNKNOWN; RAM_INVALIDATED; MMIO_EFFECT_UNRESOLVED");
            s.ram.clear();s.ramWriters.clear();s.unmodeledPeripheralWrite=true;
            cpuBoundaries.add(new CpuBoundary(from,"UNKNOWN_STORE_DESTINATION",null,null,null));return;
        }
        if((address & (width-1)) != 0) {
            issue(from,"MISALIGNED_STORE_"+hex(address));
            addressFault(s,from,address,"CPU_ADDRESS_ERROR_WRITE");return;
        }
        var region=bus.region(Integer.toUnsignedLong(address));
        switch(region) {
            case SRAM -> s.writeRam(address,width,value,from);
            case MMIO_WINDOW -> {
                // Fix #17: the whole STBCR register is covered, not only its low byte address.
                // A byte transfer to EITHER byte of STBCR is an ignored write by §29.3.1
                // txt 64878-64880 / §29.3.2 txt 64994-64996 ("data is written in byte units,
                // the operation is ignored"), so the byte at H'FFFE0401 must not be reported as
                // an unmodelled write that poisons the path - its outcome IS proven (no change).
                int stbcrOffset=address.intValue()-Sh7254rMemoryMap.STBCR;
                if (stbcrOffset==0 || (stbcrOffset==1 && width==1)) {
                    storeStbcr(s,from,address.intValue(),width,value);
                } else {
                var access=Sh7254rIntcMmio.write(s,address,width,value);
                if(!access.handled()) {
                    ref(from,address,width,"MMIO_WRITE_UNMODELED");
                    issue(from,"UNMODELED_PERIPHERAL_WRITE_"+hex(address)+"_WIDTH_"+width);
                    s.unmodeledPeripheralWrite=true;
                }
                else {
                    ref(from,address,width,"MMIO_INTC_WRITE");
                    if(access.reason()!=null) {
                        issue(from,access.reason()+"_"+hex(address));
                        s.unmodeledPeripheralWrite=true;
                    }
                    if(access.pendingSoftwareVector()!=null) {
                        int vector=access.pendingSoftwareVector();
                        issue(from,"SINT"+(108-vector)+"_REQUESTED_VECTOR_"+vector+
                                "_PENDING_UNTIL_INSTRUCTION_RETIREMENT");
                    }
                }
                }
            }
            case USER_ROM, EEPROM_READ, EXTERNAL_OR_RESERVED -> {
                issue(from,region==Sh7254rMemoryMap.Region.USER_ROM
                        ? "ROM_WRITE_ATTEMPT_IN_ABSTRACT_STATE_"+hex(address)
                        : "UNMODELED_STORE_"+hex(address));
                s.unmodeledPeripheralWrite=true;
                cpuBoundaries.add(new CpuBoundary(from,"UNMODELED_MEMORY_WRITE",address,null,null));
            }
        }
    }
    /**
     * STBCR write semantics (R01UH0480EJ0400 Rev.4.00 §29.3.1 txt 64874-64880, §29.3.2
     * txt 64994-64996): STBCR must be written by a WORD transfer whose upper byte is the key
     * code H'3C; a byte transfer writes nothing and any other key leaves the MSTP bits
     * unchanged, while a transfer wider than a word is not a defined STBCR access at all
     * (table 29.4 txt 64868 allows sizes 8 and 16) and poisons the path. MSTP1 (bit 1) halts
     * the FPU clock and is IRREVERSIBLE except by power-on
     * reset (txt 64960-64967): once standby it never returns to running under software control.
     * Stopping a NON-FPU module (MSTP0 UBC / MSTP2 AUD-II / MSTP3 DMAC / MSTP4 JTAG) is a
     * side effect this abstract model does not track, so those writes still poison the path;
     * an FPU-only stop is modelled precisely because its sole architectural consequence is that
     * later FPU instructions become undefined code (§7.6.1), not corruption of tracked state.
     */
    private void storeStbcr(AbstractCpu s,int from,int address,int width,Integer value) {
        ref(from,address,width,"MMIO_STBCR_WRITE");
        // Fix #14 (priority 2): "the operation is ignored" is proven for BYTE transfers only
        // (§29.3.1 txt 64878-64880, §29.3.2 txt 64994-64996) and table 29.4 txt 64868 lists
        // the allowed access sizes as 8 and 16. A transfer WIDER than a word is therefore not
        // a defined STBCR access: its outcome is unknown and must not be asserted as an ignored
        // byte write, so the path is poisoned instead of silently keeping stale MSTP bits.
        if (width==1) {issue(from,"STBCR_BYTE_WRITE_IGNORED_STATE_UNCHANGED");return;}
        if (width!=2) {
            // The path is poisoned AND the tracked MSTP bits become UNKNOWN: an access of a size
            // this register does not define (table 29.4 txt 64868 lists 8 and 16) has no stated
            // outcome, so a later read must not present the pre-access pattern as current.
            issue(from,"STBCR_ACCESS_WIDTH_UNDEFINED_"+width+"_PATH_POISONED");
            s.stbcrOtherMstp=null;s.unmodeledPeripheralWrite=true;return;
        }
        if (value==null) {
            // Fix #16: an unknown data value hides the key, so the write may have been accepted
            // (§29.3.1 txt 64878-64883) and the non-FPU MSTP bits may hold anything the opaque
            // data carried. They become UNKNOWN instead of keeping a stale concrete pattern that a
            // later read would report as current. MSTP1 stays sticky: hardware refuses a clear.
            issue(from,"STBCR_VALUE_UNKNOWN_NON_FPU_MSTP_BITS_UNKNOWN");
            s.stbcrOtherMstp=null;s.unmodeledPeripheralWrite=true;return;
        }
        if (((value>>>8)&0xFF)!=0x3C) {issue(from,"STBCR_KEY_NOT_H3C_MODIFY_IGNORED");return;}
        int mstp=value&0x1F;
        // Fix #16: a key-correct word transfer with a KNOWN value establishes MSTP4:0 exactly
        // (txt 64878-64880); bits 4/3/2/0 are recorded here so that a subsequent READ can report
        // which bits are proven (txt 64917-64975) rather than answering H'0000 unconditionally.
        // Fix #17: the mask of MSTP4/3/2/0 is 0x1D (bit 4 JTAG | bit 3 DMAC | bit 2 AUD-II |
        // bit 0 UBC). The previous 0x15 dropped bit 3, so after a proven MSTP3=1 write the read
        // would have reported DMAC running while the register holds 1 - an invented bit value.
        s.stbcrOtherMstp=value&0x1D;
        boolean fpuStop=(mstp&0x02)!=0;
        boolean otherStop=(mstp&~0x02)!=0;
        if (fpuStop) s.fpuStandby=Boolean.TRUE; // sticky; software cannot clear MSTP1 (§29.3.1)
        if (otherStop) {
            issue(from,"STBCR_NON_FPU_MODULE_STOP_UNMODELED_MSTP_H"+Integer.toHexString(mstp));
            s.unmodeledPeripheralWrite=true;
        }
        if (!fpuStop && !otherStop) {
            // Fix #15 (priority 2): a key-correct write with MSTP1=0 does NOT restart the FPU -
            // clearing MSTP1 is impossible except by a power-on reset (§29.3.1 txt 64960-64967).
            // So the claim "all tracked modules run" would be false on a path already in standby;
            // the proven state is retained and the ignored clear is reported separately.
            if (Boolean.TRUE.equals(s.fpuStandby))
                issue(from,"STBCR_CLEAR_OF_MSTP1_IGNORED_IRREVERSIBLE_FPU_STANDBY_RETAINED");
            else issue(from,"STBCR_WRITE_ALL_TRACKED_MODULES_RUNNING");
        }
        else if (fpuStop)
            issue(from,"FPU_MODULE_STANDBY_ENTERED_STBCR_MSTP1_IRREVERSIBLE_UNTIL_POR");
    }
    /**
     * STBCR READ semantics (R01UH0480EJ0400 Rev.4.00 §29.3.1). The register is 16-bit readable
     * with access sizes 8 and 16 (table 29.4 txt 64868, "Both word and byte accesses are available
     * to read STBCR" txt 64882-64883). Bit layout txt 64895-64916: bits 15:8 STBCRKEY "always
     * read as H'00 because the values written to these bits are not retained"; bits 7:5 reserved
     * "always read as 0"; bits 4:0 MSTP4..MSTP0 (txt 64917-64975). SH-2A is big-endian, so the
     * byte at H'FFFE0400 is the key byte and the byte at H'FFFE0401 is the MSTP byte.
     * A 32-bit access is not a defined STBCR size and yields UNKNOWN.
     * Fix #16: the value is assembled ONLY from proven bits and null (=UNKNOWN) is returned
     * whenever any bit it covers is unestablished - an H'0000 is never fabricated for a register
     * whose module-stop state is unknown.
     */
    private Integer loadStbcr(AbstractCpu s,int from,int address,int width) {
        if (width!=1 && width!=2) {
            issue(from,"STBCR_READ_WIDTH_UNDEFINED_"+width+"_VALUE_UNKNOWN");
            return null;
        }
        // Key byte (bits 15:8) reads H'00 by hardware rule, independently of any modelled state.
        if (width==1 && address==Sh7254rMemoryMap.STBCR) {
            ref(from,address,width,"MMIO_STBCR_READ_KEY");
            issue(from,"STBCR_KEY_READS_H00_NOT_RETAINED");
            return 0;
        }
        Integer mstp=stbcrMstpByte(s);
        if (mstp==null) {
            issue(from,"STBCR_READ_"+width+"_VALUE_UNKNOWN_MSTP1_"+
                    (s.fpuStandby==null?"UNKNOWN":"PROVEN")+
                    (s.stbcrOtherMstp==null?"_MSTP4_3_2_0_UNKNOWN":"_MSTP4_3_2_0_PROVEN"));
            return null;
        }
        ref(from,address,width,"MMIO_STBCR_READ");
        // Fix #17: the shapes reaching here are a word at H'FFFE0400 and a byte at H'FFFE0401,
        // and both are described by the same proven low byte: bits 15:8 read H'00 (txt 64882-64883)
        // and bits 7:5 read 0 (txt 64914-64916). The old ternary ended in an unconditional 0 for a
        // third, unreachable case, which could only ever invent a value - removed.
        int value=mstp&0xFF;
        issue(from,"STBCR_READ_"+width+"_MSTP_BITS_PROVEN_VALUE_"+hex(value));
        return value;
    }
    /**
     * Assembles bits 7:0 of STBCR: bits 7:5 are reserved and read 0 (txt 64914-64916), bit 1 is
     * the tracked MSTP1 and bits 4/3/2/0 are the tracked non-FPU module stops (mask 0x1D, fix #17:
     * 0x15 omitted MSTP3/DMAC). Returns null when either is UNKNOWN, so the caller never sees a
     * partially invented byte.
     */
    private Integer stbcrMstpByte(AbstractCpu s) {
        if (s.fpuStandby==null || s.stbcrOtherMstp==null) return null;
        int mstp=s.stbcrOtherMstp&0x1D;
        if (Boolean.TRUE.equals(s.fpuStandby)) mstp|=0x02; // sticky until power-on reset
        return mstp;
    }
    /** True for operations that require the FPU datapath or FPU registers (§5.9/§5.10 tables). */
    private static boolean isFpuOperation(Sh2aDecoder.Operation op) {
        return switch (op) {
            case FPU_ARITHMETIC, FPU_COMPARE, FPU_CONVERT, FPU_SQRT, FPU_FMAC,
                 FPU_REGISTER_TRANSFER, FPU_SIGN, FPU_IMMEDIATE, FPU_REG_MOVE,
                 FPU_MEM_LOAD, FPU_MEM_STORE, FPU_MODE, FPU -> true;
            default -> false;
        };
    }
    private void cancelInFlight(AbstractCpu state) {
        if(state.inFlightPc!=null)executionSteps.add(new ExecutionStep(ExecutionStage.CANCELLED,state.inFlightPc));
        state.inFlightPc=null;state.inFlightDivision=false;
    }
    private void retire(AbstractCpu state,int pc,boolean enabledByLdc) {
        if(state.pipeline!=null) {
            var inst=code.get(pc);var spec=SystemExceptionModel.pipelineSpec(inst,state.pipeline.decodeFpscr(state.fpscr));
            if(spec==null)throw new IllegalStateException("control profile missing");
            Map<String,Integer> delta=new LinkedHashMap<>();
            for(String r:spec.writes())delta.put(r,r.equals("PR")&&inst.flow()==Sh2aDecoder.Flow.CALL?pc+inst.width()+(inst.delaySlot()?2:0):SystemExceptionModel.Pipeline.read(state,r));
            state.pipeline.issue(spec,delta);
            boolean taken=inst.flow()!=Sh2aDecoder.Flow.CONDITIONAL||state.t!=null&&state.t==(inst.imm()==1);
            if(taken)state.pipeline.fence(state.pipeline.slot()+(inst.operation()==Sh2aDecoder.Operation.RTE?6:inst.delaySlot()?2:3));
            state.pipeline.restoreCommitted(state);state.inFlightPc=null;state.inFlightDivision=false;return;
        }
        executionSteps.add(new ExecutionStep(ExecutionStage.COMPLETE,pc));
        state.inFlightPc=null;state.inFlightDivision=false;
        state.lastRetiredPc=pc;
        if(state.irqMaskChangeWindow>0&&!enabledByLdc)state.irqMaskChangeWindow--;
    }
    private boolean beginInstruction(AbstractCpu s,Sh2aDecoder.Instruction i,boolean slot,boolean assumed) {
        if(s.pipeline!=null) {
            if(!s.fpuCompletionBeforePc.isEmpty()) {
                issue(i.address(),"PIPELINE_PROFILE_CONFLICT_EXPLICIT_COMPLETION");return false;
            }
            var spec=SystemExceptionModel.pipelineSpec(i,s.fpscr);
            if(spec==null) {
                blockPipeline(s,i.address(),"NOT_IMPLEMENTED_PROFILE_"+i.mnemonic());
                issue(i.address(),"PIPELINE_NOT_IMPLEMENTED_PROFILE_"+i.mnemonic()+"; no guessed instruction duration");return false;
            }
            s.pipeline.initialize(s);
            try {s.pipeline.advance(s.pipeline.ready(spec));}
            catch(IllegalStateException unknown) {
                blockPipeline(s,i.address(),unknown.getMessage());issue(i.address(),"PIPELINE_"+unknown.getMessage());return false;
            }
            s.pipeline.restoreCommitted(s);
        }
        if(s.deferredFpuResult!=null&&isFpuOperation(i.operation())) {
            issue(i.address(),"FPU_COMPLETION_PROFILE_DEPENDENCY_UNVERIFIED; explicit boundary not reached; no forced SF or forwarding");
            return false;
        }
        if(s.fpuCompletionBeforePc.containsKey(i.address())&&!normalFpuProducer(i)) {
            issue(i.address(),"FPU_COMPLETION_PROFILE_UNSUPPORTED_PRODUCER");return false;
        }
        s.inFlightPc=i.address();
        s.inFlightDivision=i.operation()==Sh2aDecoder.Operation.DIVS||i.operation()==Sh2aDecoder.Operation.DIVU;
        executionSteps.add(new ExecutionStep(ExecutionStage.ISSUE,i.address()));
        s.systemPending.replaceAll(e->e.availability()==SystemExceptionModel.Availability.AFTER_ISSUE&&Objects.equals(e.reportAfterIssuePc(),i.address())?e.reported():e);
        boolean stopped=arbitrateId(i.address(),i.address(),s,assumed,"REPORTED_DURING_EXECUTION",List.copyOf(s.systemPending),null,slot,"EXPLICIT_RELATIVE_REPORT").stopsInstruction();
        if(!stopped&&s.pipeline!=null&&i.flow()!=Sh2aDecoder.Flow.NEXT)s.pipeline.operands(s);
        return !stopped;
    }
    private boolean pipelineMemoryAllowed(AbstractCpu s,Sh2aDecoder.Instruction i) {
        Integer address=null;int d=i.imm();
        switch(i.operation()) {
            case SYS_REG_TRANSFER -> {
                if(i.regM()<10)return true;
                address=binary(s.r[i.regN()],i.regM()>=13?-4:0,(a,b)->a+b);
            }
            case LDS_L_PR -> address=s.r[i.regN()];
            case STS_L_PR -> address=binary(s.r[i.regN()],-4,(a,b)->a+b);
            case FPU_REGISTER_TRANSFER -> {
                int transfer=i.regM();if(transfer<4)return true;
                address=binary(s.r[i.regN()],transfer==4||transfer==5?-4:0,(a,b)->a+b);
            }
            case MOV_PC -> address=i.referenceAddress();
            case MOV_LOAD,MOV_UNSIGNED_LOAD,MOV_DISP12_LOAD -> address=binary(s.r[i.regM()],d,(a,b)->a+b);
            case MOV_STORE,MOV_DISP12_STORE -> address=binary(s.r[i.regN()],i.preDecrement()?-i.operandWidth():d,(a,b)->a+b);
            case MOV_GBR_LOAD,MOV_GBR_STORE -> address=binary(s.gbr,d,(a,b)->a+b);
            case MOV_INDEX_LOAD -> address=binary(s.r[i.regM()],s.r[0],(a,b)->a+b);
            case MOV_INDEX_STORE -> address=binary(s.r[i.regN()],s.r[0],(a,b)->a+b);
            case MOV_REV_LOAD -> address=binary(s.r[i.regM()],-i.operandWidth(),(a,b)->a+b);
            case MOV_REV_STORE -> address=s.r[i.regN()];
            case FPU_MEM_LOAD,FPU_MEM_STORE -> {
                int base=i.operation()==Sh2aDecoder.Operation.FPU_MEM_LOAD?i.regM():i.regN();
                int bytes=(s.fpscr&FpuSemantics.SZ)!=0?8:4;
                Integer offset=d==-1&&i.width()==2?s.r[0]:i.width()==4&&i.operandWidth()==0?d*bytes:d;
                address=binary(s.r[base],i.preDecrement()?-bytes:offset,(a,b)->a+b);
            }
            default -> {return true;}
        }
        if(address==null)return false;var region=bus.region(Integer.toUnsignedLong(address));
        return region==Sh7254rMemoryMap.Region.SRAM||region==Sh7254rMemoryMap.Region.USER_ROM;
    }
    private boolean execute(AbstractCpu s,Sh2aDecoder.Instruction i,boolean slot,boolean assumed) {
        if(!Objects.equals(s.inFlightPc,i.address())&&!beginInstruction(s,i,slot,assumed))return false;
        AbstractCpu before=s.copy();
        if(s.pipeline!=null)s.pipeline.operands(s);
        if(s.pipeline!=null&&!pipelineMemoryAllowed(s,i)) {
            blockPipeline(s,i.address(),"NOT_IMPLEMENTED_MEMORY_BUS_PROFILE");issue(i.address(),"PIPELINE_NOT_IMPLEMENTED_MEMORY_BUS_PROFILE");s.pipeline.restoreCommitted(s);return false;
        }
        AbstractCpu operandBefore=s.pipeline==null?before:s.copy();
        boolean completed=executeInstruction(s,i);
        if(s.pipeline!=null&&completed&&s.cpuFault==null) {
            var spec=SystemExceptionModel.pipelineSpec(i,operandBefore.fpscr);
            s.pipeline.numericalFpscr(s.fpscr);
            // A numerical exceptional result cannot be assigned a report phase from SF/ED.
            if(s.fpuExceptionPending!=null) {
                s.pipeline.issueFault(spec);
                blockPipeline(s,i.address(),"UNVERIFIED_H34_CONDITION_TO_REPORT");
                issue(i.address(),"PIPELINE_H34_REPORT_UNVERIFIED; outstanding state retained; no timed continuation");
                s.pipeline.restoreCommitted(s);return false;
            }
            Map<String,Integer> delta=new LinkedHashMap<>();
            for(String register:spec.writes())delta.put(register,SystemExceptionModel.Pipeline.read(s,register));
            s.pipeline.issue(spec,delta,SystemExceptionModel.MemoryDelta.between(operandBefore,s));
            if(slot)s.pipeline.fence(s.pipeline.slot()+1);
            for(String uncertainty:s.pipeline.uncertainties())issue(i.address(),"PIPELINE_"+uncertainty+"; conditional stage schedule");
            s.pipeline.restoreCommitted(s);
            // CPU completion/retirement is observed from the scheduler, not from Java evaluation.
            s.inFlightPc=null;s.inFlightDivision=false;
            return true;
        }
        if(s.cpuFault!=null) {
            String fault=s.cpuFault;Integer address=s.faultAddress;
            List<SystemExceptionModel.Event> generated=s.systemPending.stream().filter(e->!before.systemPending.contains(e)).toList();
            long nextId=s.nextSystemEventId;
            s.restoreFaultState(before);
            s.cpuFault=fault;s.faultAddress=address;s.nextSystemEventId=nextId;s.systemPending.addAll(generated);
            return false;
        }
        if(completed) {
            Integer completion=s.fpuCompletionBeforePc.get(i.address());
            if(completion!=null&&normalFpuProducer(i)&&s.fpuExceptionPending==null) {
                boolean writesFpul=i.mnemonic().startsWith("FTRC")||i.mnemonic().startsWith("FCNVDS");
                boolean pair=i.mnemonic().startsWith("FCNVSD")||(s.fpscr&FpuSemantics.PR)!=0;
                int mask=writesFpul?0:(pair?3:1)<<i.regN();
                s.deferredFpuResult=new SystemExceptionModel.FpuResult(i.address(),completion,mask,Arrays.asList(s.fr.clone()),writesFpul,s.fpul);
                System.arraycopy(before.fr,0,s.fr,0,16);if(writesFpul)s.fpul=before.fpul;
            }
            boolean enabledByLdc=i.operation()==Sh2aDecoder.Operation.SYS_REG_TRANSFER&&(i.regM()==9||i.regM()==10)
                    &&s.interruptMask!=null&&(before.interruptMask==null||s.interruptMask<before.interruptMask);
            retire(s,i.address(),enabledByLdc);
        }
        return completed;
    }
    private static boolean normalFpuProducer(Sh2aDecoder.Instruction i) {
        return switch(i.operation()){case FPU_ARITHMETIC,FPU_SQRT,FPU_FMAC,FPU_CONVERT->true;default->false;};
    }
    private void completeFpuAt(int pc,AbstractCpu s) {
        var result=s.deferredFpuResult;
        if(result==null||result.beforePc()!=pc)return;
        if(s.fpuExceptionPending!=null||!Boolean.FALSE.equals(s.fpuStandby)) {
            issue(pc,"FPU_COMPLETION_PROFILE_EXCEPTION_TIMING_UNVERIFIED; normal write-back not committed");return;
        }
        for(int j=0;j<16;j++)if((result.frMask()&(1<<j))!=0)s.fr[j]=result.fr().get(j);
        if(result.writesFpul())s.fpul=result.fpul();
        s.deferredFpuResult=null;
        executionSteps.add(new ExecutionStep(ExecutionStage.FPU_RESULT,result.generatorPc()));
    }
    // Existing numerical acceptance tools exercise this execution entry directly.
    private boolean execute(AbstractCpu s,Sh2aDecoder.Instruction i) {
        return execute(s,i,false,false);
    }
    private boolean executeInstruction(AbstractCpu s,Sh2aDecoder.Instruction i) {
        int n=i.regN(),m=i.regM(),d=i.imm();
        // Fix #19: FPU operation inside a pending FPU exception interval (§8.9.7(4)
        // txt 37011-37017): the FPU is halted - FPU instructions (excluding FCMP) and the
        // FPU part of FPU-related CPU instructions are NOP, FPU registers are NOT updated,
        // while CPU side effects (register increments, memory transfers, reading the
        // current FPSCR/FPUL value) still occur.
        if (s.fpuExceptionPending!=null && isFpuOperation(i.operation()))
            return fpuFrozenExecute(s,i);
        if(isFpuOperation(i.operation())) {
            String error=FpuSemantics.apply(s,i,new FpuSemantics.Memory() {
                public boolean aligned(Integer address,int width) { return fpuAligned(s,i.address(),address,width); }
                public Integer load(Integer address) { return loadState(s,i.address(),address,4); }
                public void store(Integer address,Integer value) { FirmwareGraph.this.store(s,i.address(),address,4,value); }
            });
            if(error!=null) {
                // Fix #19: FPU_EXCEPTION_GENERATED_<cause> is a SUCCESS, not an error:
                // FPSCR is already updated by the fill rule, the FPU operation is halted
                // (result register NOT written, §3.7.6 txt 2982-2983), the pending flag is
                // raised, and the instruction retires normally from the CPU viewpoint.
                // Acceptance (table 3.9 / §8.9.7(4)) is decided by the main loop at a
                // later instruction; the issue line records the generation site.
                boolean generated=error.startsWith("FPU_EXCEPTION_GENERATED_");
                if(generated)fpuEvents.add(new FpuExceptionEvent(i.address(),s.fpscr&FpuSemantics.CAUSE,
                        s.fpscr&0x7c,s.fpscr&0xf80,s.fpscr));
                if(generated)observeGenerated(s,s.queueSystem(SystemExceptionModel.Kind.FPU,i.address(),null,
                        0x34,0,"FPU",SystemExceptionModel.Availability.PIPELINE_UNVERIFIED));
                issue(i.address(),error);
                if(!generated)return false;
            }
            return true;
        }
        switch(i.operation()) {
            case NOP, BRANCH -> { }
            case SLEEP -> s.sleepRequested=true;
            case MOV_IMM, MOVI20, MOVI20S -> s.r[n]=d;
            case MULR -> s.r[n]=binary(s.r[n],s.r[0],(a,b)->a*b);
            case CLRMAC -> {s.mach=0;s.macl=0;}
            case MUL_L -> s.macl=binary(s.r[n],s.r[m],(a,b)->a*b);
            case MULS_W -> s.macl=binary(s.r[n],s.r[m],(a,b)->(short)a*(short)b);
            case MULU_W -> s.macl=binary(s.r[n],s.r[m],(a,b)->(a&65535)*(b&65535));
            case DMULS_L, DMULU_L -> {
                Integer lhs=s.r[n],rhs=s.r[m];
                if (lhs==null || rhs==null) {s.mach=null;s.macl=null;}
                else {
                    long x=i.operation()==Sh2aDecoder.Operation.DMULS_L?(long)lhs:Integer.toUnsignedLong(lhs);
                    long y=i.operation()==Sh2aDecoder.Operation.DMULS_L?(long)rhs:Integer.toUnsignedLong(rhs);
                    long out=x*y;
                    s.mach=(int)(out>>>32);s.macl=(int)out;
                }
            }
            case MAC_L, MAC_W -> {
                int width=i.operation()==Sh2aDecoder.Operation.MAC_L?4:2;
                // The manual reads @Rn+, then @Rm+. With n==m the second
                // read therefore uses the already incremented address.
                Integer srcN=loadState(s,i.address(),s.r[n],width);
                s.r[n]=binary(s.r[n],width,(a,b)->a+b);
                Integer srcM=loadState(s,i.address(),s.r[m],width);
                s.r[m]=binary(s.r[m],width,(a,b)->a+b);
                if(srcN==null || srcM==null || s.macl==null || s.saturation==null) {
                    s.mach=null;s.macl=null;
                } else {
                    long product=(width==2?(short)(int)srcN:(long)srcN)*
                            (width==2?(short)(int)srcM:(long)srcM);
                    if(Boolean.TRUE.equals(s.saturation) && width==2) {
                        long value=(long)s.macl+product;
                        if(value<Integer.MIN_VALUE || value>Integer.MAX_VALUE) s.mach=1;
                        s.macl=(int)Math.max(Integer.MIN_VALUE,Math.min(Integer.MAX_VALUE,value));
                    } else if(s.mach==null) { s.mach=null;s.macl=null; }
                    else if(Boolean.TRUE.equals(s.saturation)) {
                        long accumulator=((long)(short)(int)s.mach<<32)|Integer.toUnsignedLong(s.macl);
                        long value=Math.max(-(1L<<47),Math.min((1L<<47)-1,accumulator+product));
                        s.mach=(s.mach&0xFFFF0000)|((int)(value>>>32)&0xFFFF);s.macl=(int)value;
                    } else {
                        long value=(((long)s.mach<<32)|Integer.toUnsignedLong(s.macl))+product;
                        s.mach=(int)(value>>>32);s.macl=(int)value;
                    }
                }
            }
            case MAC_REGISTER_TRANSFER -> {
                switch(m) {
                    case 0 -> s.r[n]=s.mach;
                    case 1 -> s.r[n]=s.macl;
                    case 2 -> s.mach=s.r[n];
                    case 3 -> s.macl=s.r[n];
                    case 4,5 -> {
                        Integer addr=binary(s.r[n],-4,(a,b)->a+b);
                        s.r[n]=addr;
                        store(s,i.address(),addr,4,m==4?s.mach:s.macl);
                    }
                    case 6,7 -> {
                        Integer value=loadState(s,i.address(),s.r[n],4);
                        if(m==6)s.mach=value;else s.macl=value;
                        s.r[n]=binary(s.r[n],4,(a,b)->a+b);
                    }
                    default -> throw new IllegalStateException("Unsupported MAC transfer");
                }
            }
            case DIVS, DIVU -> {
                // Proven exception cases (div0, MIN/-1) are routed by the main loop BEFORE
                // this point (sec.3.7.5 p.28), so the division here cannot throw; unknown
                // operands yield an UNKNOWN quotient and keep the sequential path alive.
                Integer divisor=s.r[0], dividend=s.r[n];
                if(divisor==null || dividend==null) {
                    issue(i.address(),"DIVISION_INPUT_UNKNOWN; exception cannot be excluded");
                    s.r[n]=null;
                } else if(i.operation()==Sh2aDecoder.Operation.DIVU)
                    s.r[n]=Integer.divideUnsigned(dividend,divisor);
                else s.r[n]=dividend/divisor;
            }
            case CLIPS_B, CLIPS_W, CLIPU_B, CLIPU_W -> {
                Integer v=s.r[n];
                if(v!=null) {
                    boolean signed=i.operation()==Sh2aDecoder.Operation.CLIPS_B ||
                            i.operation()==Sh2aDecoder.Operation.CLIPS_W;
                    int bits=i.operation()==Sh2aDecoder.Operation.CLIPS_B ||
                            i.operation()==Sh2aDecoder.Operation.CLIPU_B?8:16;
                    int max=(1<<(bits-(signed?1:0)))-1;
                    int min=signed?-(1<<(bits-1)):0;
                    int clipped= signed?Math.max(min,Math.min(max,v)):
                            Integer.compareUnsigned(v,max)>0?max:v;
                    if(v!=clipped) s.cs=true;
                    s.r[n]=clipped;
                } else if(!Boolean.TRUE.equals(s.cs)) s.cs=null;
            }

            case BIT_REG -> {
                int bit=1<<d;
                if(m==0) s.r[n]=s.r[n]==null?null:s.r[n]&~bit;
                else if(m==1)s.r[n]=s.r[n]==null?null:s.r[n]|bit;
                else if(m==2) s.r[n]=s.r[n]==null||s.t==null?null:
                        (s.r[n]&~bit)|(s.t?bit:0);
                else if(m==3) s.t=s.r[n]==null?null:(s.r[n]&bit)!=0;
            }
            case BIT_MEMORY -> {
                int bit=(d>>>12)&7, displacement=d&0xFFF;
                Integer addr=binary(s.r[n],displacement,(a,b)->a+b);
                Integer value=loadState(s,i.address(),addr,1);
                Boolean bitValue=value==null?null:((value>>>bit)&1)!=0;
                int operation=m;
                if(operation==0 || operation==1 || operation==2) {
                    Integer next=value;
                    if(value!=null && operation==0) next=value&~(1<<bit);
                    if(value!=null && operation==1) next=value|(1<<bit);
                    if(operation==2) next=value==null||s.t==null?null:
                            (value&~(1<<bit))|(s.t?1<<bit:0);
                    store(s,i.address(),addr,1,next);
                } else if(operation==3 || operation==11) {
                    s.t=bitValue==null?null:(operation==3?bitValue:!bitValue);
                } else {
                    Boolean operand=bitValue==null?null:
                            (operation==12 || operation==13?!bitValue:bitValue);
                    Boolean old=s.t;
                    if(operation==4 || operation==12)
                        s.t=Boolean.FALSE.equals(old)||Boolean.FALSE.equals(operand)?false:
                                Boolean.TRUE.equals(old)&&Boolean.TRUE.equals(operand)?true:null;
                    else if(operation==5 || operation==13)
                        s.t=Boolean.TRUE.equals(old)||Boolean.TRUE.equals(operand)?true:
                                Boolean.FALSE.equals(old)&&Boolean.FALSE.equals(operand)?false:null;
                    else if(operation==6)
                        s.t=old==null||operand==null?null:old^operand;
                }
            }
            // MOVRT Rn: REJ09B0051-0300 Rev.3.00 sec.6.3.25 p.139, verified in extracted
            // text build/sh2a-fpu.txt (~lines 13388-13410): encoding 0000nnnn00111001,
            // Operation: T==1 ? R[n]=0 : R[n]=1, i.e. Rn=~T; T itself unchanged. Matches.
            case MOVT_INV -> s.r[n]=s.t==null?null:(s.t?0:1);
            case NOTT -> s.t=s.t==null?null:!s.t;
            case NOT_REG -> s.r[n]=s.r[m]==null?null:~s.r[m];
            case NEG_REG -> s.r[n]=s.r[m]==null?null:-s.r[m];
            case NEGC_REG -> {
                Integer src=s.r[m];Boolean t=s.t;
                s.r[n]=src==null||t==null?null:-src-(t?1:0);
                s.t=Boolean.TRUE.equals(t) || (src!=null && src!=0) ? true:
                        src==null||t==null?null:false;
            }
            case EXTS_B -> s.r[n]=s.r[m]==null?null:(int)(byte)(int)s.r[m];
            case EXTS_W -> s.r[n]=s.r[m]==null?null:(int)(short)(int)s.r[m];
            case EXTU_B -> s.r[n]=s.r[m]==null?null:s.r[m]&0xFF;
            case EXTU_W -> s.r[n]=s.r[m]==null?null:s.r[m]&0xFFFF;
            case SWAP_B -> s.r[n]=s.r[m]==null?null:(s.r[m]&0xFFFF0000) |
                    ((s.r[m]&0xFF)<<8)|((s.r[m]>>>8)&0xFF);
            case SWAP_W -> s.r[n]=s.r[m]==null?null:(s.r[m]<<16)|(s.r[m]>>>16);
            case XTRCT -> s.r[n]=s.r[n]==null||s.r[m]==null?null:
                    (s.r[n]>>>16)|(s.r[m]<<16);
            case DT_REG -> {s.r[n]=s.r[n]==null?null:s.r[n]-1;
                s.t=s.r[n]==null?null:s.r[n]==0;}
            case CMP_STR -> {
                if(s.r[n]==null||s.r[m]==null) s.t=null;
                else {
                    int xor=s.r[n]^s.r[m];
                    s.t=(xor&0xFF)==0 || (xor&0xFF00)==0 ||
                            (xor&0xFF0000)==0 || (xor&0xFF000000)==0;
                }
            }
            case ADDC_REG, SUBC_REG, ADDV_REG, SUBV_REG -> {
                Integer lhs=s.r[n],rhs=s.r[m];Boolean t=s.t;
                boolean subtraction=i.operation()==Sh2aDecoder.Operation.SUBC_REG ||
                        i.operation()==Sh2aDecoder.Operation.SUBV_REG;
                boolean carry=i.operation()==Sh2aDecoder.Operation.ADDC_REG ||
                        i.operation()==Sh2aDecoder.Operation.SUBC_REG;
                if(lhs==null||rhs==null||(carry && t==null)) {s.r[n]=null;s.t=null;}
                else {
                    long a=Integer.toUnsignedLong(lhs),b=Integer.toUnsignedLong(rhs);
                    long c=carry && t ? 1 : 0;
                    long result=subtraction ? (a-b-c) : (a+b+c);
                    int out=(int)result;
                    boolean flag=carry ? (subtraction?a<b+c:result>0xFFFFFFFFL) :
                            (subtraction?(((lhs^rhs)&(lhs^out))<0):
                                    (((~(lhs^rhs))&(lhs^out))<0));
                    s.r[n]=out;s.t=flag;
                }
            }
            case ROTL, ROTR, ROTCL, ROTCR -> {
                Integer v=s.r[n];Boolean oldT=s.t;
                boolean left=i.operation()==Sh2aDecoder.Operation.ROTL ||
                        i.operation()==Sh2aDecoder.Operation.ROTCL;
                boolean throughT=i.operation()==Sh2aDecoder.Operation.ROTCL ||
                        i.operation()==Sh2aDecoder.Operation.ROTCR;
                s.t=v==null?null:left?v<0:(v&1)!=0;
                s.r[n]=v==null||(throughT && oldT==null)?null:(left?
                        (v<<1)|(throughT?(oldT?1:0):(v>>>31)):
                        (v>>>1)|(throughT?(oldT?0x80000000:0):((v&1)<<31)));
            }
            case SHAD, SHLD -> {
                Integer v=s.r[n],count=s.r[m];
                if(v==null||count==null) s.r[n]=null;
                else if(count>=0) s.r[n]=v<<(count&31);
                else {
                    int sh=count&31;
                    int width=sh==0?32:32-sh;
                    s.r[n]=i.operation()==Sh2aDecoder.Operation.SHAD?
                            (width==32?(v<0?-1:0):v>>width):
                            (width==32?0:v>>>width);
                }
            }
            case TST_IMM -> s.t=s.r[0]==null?null:(s.r[0]&d)==0;
            case AND_IMM -> s.r[0]=s.r[0]==null?null:s.r[0]&d;
            case OR_IMM -> s.r[0]=s.r[0]==null?null:s.r[0]|d;
            case XOR_IMM -> s.r[0]=s.r[0]==null?null:s.r[0]^d;
            case GBR_BYTE_LOGIC -> {
                Integer address=binary(s.r[0],s.gbr,(a,b)->a+b);
                Integer value=loadState(s,i.address(),address,1);
                if(m==0) s.t=value==null?null:(value&d)==0; // TST.B
                else {
                    Integer result=value==null?null:switch(m) {
                        case 1 -> value&d; // AND.B
                        case 2 -> value^d; // XOR.B
                        case 3 -> value|d; // OR.B
                        default -> throw new IllegalStateException("GBR byte operation");
                    };
                    store(s,i.address(),address,1,result);
                }
            }
            case TAS_B -> {
                Integer address=s.r[n];
                Integer value=loadState(s,i.address(),address,1);
                s.t=value==null?null:value==0;
                // The hardware locks its bus for this read-modify-write;
                // timing/concurrent peripheral accesses are not modeled.
                store(s,i.address(),address,1,value==null?null:value|0x80);
            }
            case SYS_REG_TRANSFER -> {
                switch(m) {
                    case 1 -> s.r[n]=s.gbr;
                    case 2 -> s.r[n]=s.vbr;
                    case 3 -> s.r[n]=s.tbr;
                    case 5 -> s.gbr=s.r[n];
                    case 6 -> s.vbr=s.r[n];
                    case 7 -> s.tbr=s.r[n];
                    case 8 -> s.r[n]=s.readSr();
                    case 9 -> {
                        Integer mask=s.interruptMask;s.writeSr(s.r[n]);
                        if(s.interruptMask!=null&&(mask==null||s.interruptMask<mask))s.irqMaskChangeWindow=5;
                    }
                    case 10,11,12 -> {
                        Integer v=loadState(s,i.address(),s.r[n],4);
                        if(m==10){Integer mask=s.interruptMask;s.writeSr(v);
                            if(s.interruptMask!=null&&(mask==null||s.interruptMask<mask))s.irqMaskChangeWindow=5;}
                        if(m==11)s.gbr=v;
                        if(m==12)s.vbr=v;
                        s.r[n]=binary(s.r[n],4,(a,b)->a+b);
                    }
                    case 13,14,15 -> {
                        Integer addr=binary(s.r[n],-4,(a,b)->a+b);
                        Integer v=m==13?s.readSr():m==14?s.gbr:s.vbr;
                        s.r[n]=addr;
                        store(s,i.address(),addr,4,v);
                    }
                    default -> throw new IllegalStateException("Unexpected SYS transfer");
                }
            }
            case RTV_N -> s.r[0]=s.r[n];
            case LDBANK -> {
                Integer addr=s.r[n];
                if(addr==null || (addr&0xFFFF0003)!=0 || ((addr>>>7)&0x1FF)>=15 ||
                        ((addr>>>2)&31)>=20) {
                    issue(i.address(),"LDBANK_INVALID_OR_UNKNOWN_BANK_ADDRESS");return false;
                }
                s.r[0]=s.readBank(addr);
            }
            case STBANK -> {
                if(!s.writeBank(s.r[n],s.r[0])) {
                    issue(i.address(),"STBANK_INVALID_OR_UNKNOWN_BANK_ADDRESS");return false;
                }
            }
            case RESBANK -> {
                // Underflow is intercepted by the main loop. BO=1 restores the stack;
                // BO=0 restores architectural bank BN-1, independently of analysis history.
                if(Boolean.TRUE.equals(s.bankOverflow)) {
                    // SW6.3.30 pp145-146 /HW8.8.3 p172: BO stays set until SR restoration.
                    for(int r=0;r<15;r++) {
                        s.r[r]=loadState(s,i.address(),s.r[15],4);
                        s.r[15]=binary(s.r[15],4,(a,b)->a+b);
                    }
                    s.pr=loadState(s,i.address(),s.r[15],4);s.r[15]=binary(s.r[15],4,(a,b)->a+b);
                    s.gbr=loadState(s,i.address(),s.r[15],4);s.r[15]=binary(s.r[15],4,(a,b)->a+b);
                    s.mach=loadState(s,i.address(),s.r[15],4);s.r[15]=binary(s.r[15],4,(a,b)->a+b);
                    s.macl=loadState(s,i.address(),s.r[15],4);s.r[15]=binary(s.r[15],4,(a,b)->a+b);
                    break;
                }
                if(s.bankOverflow==null || !s.restoreBank()) {
                    issue(i.address(),"RESBANK_BANK_NUMBER_UNKNOWN_RESTORE_NOT_PROVEN");return false;
                }
            }
            case DIV0U -> {s.q=false;s.m=false;s.t=false;}
            case DIV0S -> {
                s.q=s.r[n]==null?null:s.r[n]<0;
                s.m=s.r[m]==null?null:s.r[m]<0;
                s.t=s.q==null||s.m==null?null:s.q^s.m;
            }
            case DIV1 -> {
                // Renesas REJ09B0051-0300 section 6.4.18, unsigned comparisons.
                Boolean oldQ=s.q, sign=s.r[n]==null?null:s.r[n]<0;
                Integer lhs=s.r[n],rhs=s.r[m];Boolean oldT=s.t;
                if(oldQ==null||s.m==null||sign==null||lhs==null||rhs==null||oldT==null) {
                    s.r[n]=null;s.q=null;s.t=null;
                } else {
                    int before=(lhs<<1)|(oldT?1:0);
                    boolean subtract=oldQ==s.m;
                    int after=subtract?before-rhs:before+rhs;
                    boolean carry=subtract?Integer.compareUnsigned(after,before)>0:
                            Integer.compareUnsigned(after,before)<0;
                    // Four cases (oldQ,M,sign) from the Renesas reference algorithm.
                    boolean newQ;
                    // oldQ=0,M=0: Q=(sign? !borrow:borrow)
                    // oldQ=0,M=1: Q=(sign? carry:!carry)
                    // oldQ=1,M=0: Q=(sign? !carry:carry)
                    // oldQ=1,M=1: Q=(sign? borrow:!borrow)
                    if(!oldQ && !s.m) newQ=sign?!carry:carry;
                    else if(!oldQ) newQ=sign?carry:!carry;
                    else if(!s.m) newQ=sign?!carry:carry;
                    else newQ=sign?carry:!carry;
                    s.r[n]=after;s.q=newQ;s.t=(newQ==s.m);
                }
            }
            case MOVML_PUSH -> {
                for(int r=n;r>=0;r--) {
                    Integer addr=s.r[15]==null?null:s.r[15]-4;
                    Integer v=r==15?s.pr:s.r[r];
                    s.r[15]=addr;
                    store(s,i.address(),addr,4,v);
                }
            }
            case MOVML_POP -> {
                for(int r=0;r<=n;r++) {
                    Integer addr=s.r[15];
                    Integer v=loadState(s,i.address(),addr,4);
                    if(r==15)s.pr=v;else s.r[r]=v;
                    s.r[15]=addr==null?null:addr+4;
                }
            }
            case MOVMU_PUSH -> {
                for(int r=15;r>=n;r--) {
                    Integer addr=s.r[15]==null?null:s.r[15]-4;
                    Integer v=r==15?s.pr:s.r[r];
                    s.r[15]=addr;
                    store(s,i.address(),addr,4,v);
                }
            }
            case MOVMU_POP -> {
                for(int r=n;r<=15;r++) {
                    Integer addr=s.r[15];
                    Integer v=loadState(s,i.address(),addr,4);
                    if(r==15)s.pr=v;else s.r[r]=v;
                    s.r[15]=addr==null?null:addr+4;
                }
            }

            case MOV_REG -> s.r[n]=s.r[m];
            case MOVT -> s.r[n]=s.t==null?null:(s.t?1:0);
            case ADD_IMM -> s.r[n]=binary(s.r[n],d,(a,b)->a+b);
            case ADD_REG -> s.r[n]=binary(s.r[n],s.r[m],(a,b)->a+b);
            case SUB_REG -> s.r[n]=binary(s.r[n],s.r[m],(a,b)->a-b);
            case AND_REG -> s.r[n]=binary(s.r[n],s.r[m],(a,b)->a&b);
            case OR_REG -> s.r[n]=binary(s.r[n],s.r[m],(a,b)->a|b);
            case XOR_REG -> s.r[n]=binary(s.r[n],s.r[m],(a,b)->a^b);
            case TST_REG -> s.t=s.r[n]==null||s.r[m]==null?null:(s.r[n]&s.r[m])==0;
            case CMP_EQ_REG -> s.t=compare(s.r[n],s.r[m],"EQ");
            case CMP_EQ_IMM -> s.t=compare(s.r[0],d,"EQ");
            case CMP_HS -> s.t=compare(s.r[n],s.r[m],"HS");
            case CMP_HI -> s.t=compare(s.r[n],s.r[m],"HI");
            case CMP_GE -> s.t=compare(s.r[n],s.r[m],"GE");
            case CMP_GT -> s.t=compare(s.r[n],s.r[m],"GT");
            case CMP_PL -> s.t=compare(s.r[n],0,"GT");
            case CMP_PZ -> s.t=compare(s.r[n],0,"GE");
            case CLRT -> s.t=false;
            case SETT -> s.t=true;
            case SHLL, SHAL, SHLR, SHAR -> {
                Integer v=s.r[n];s.t=v==null?null:(i.operation()==Sh2aDecoder.Operation.SHLL || i.operation()==Sh2aDecoder.Operation.SHAL)
                    ? (v<0):(v&1)!=0;
                s.r[n]=v==null?null:switch(i.operation()) {
                    case SHLL,SHAL -> v<<1;case SHLR -> v>>>1;default -> v>>1;};
            }
            case SHLL2,SHLL8,SHLL16,SHLR2,SHLR8,SHLR16 -> {
                int shift=switch(i.operation()) {case SHLL2,SHLR2 -> 2;case SHLL8,SHLR8 -> 8;default ->16;};
                Integer v=s.r[n];
                s.r[n]=v==null?null:(i.operation().name().startsWith("SHLL")?v<<shift:v>>>shift);
            }
            case MOV_PC -> {
                Integer value=loadState(s,i.address(),i.referenceAddress(),i.operandWidth());
                s.r[n]=value==null?null:extend(value,i.operandWidth());
            }
            case MOVA -> {s.r[0]=i.referenceAddress();ref(i.address(),i.referenceAddress(),4,"ADDRESS_TAKEN_NOT_READ");}
            case MOV_UNSIGNED_LOAD, MOV_DISP12_LOAD -> {
                Integer addr=binary(s.r[m],d,(a,b)->a+b);
                Integer value=loadState(s,i.address(),addr,i.operandWidth());
                s.r[n]=value==null?null:(i.operation()==Sh2aDecoder.Operation.MOV_UNSIGNED_LOAD?
                        value:extend(value,i.operandWidth()));
            }
            case MOV_DISP12_STORE -> {
                Integer addr=binary(s.r[n],d,(a,b)->a+b);
                store(s,i.address(),addr,i.operandWidth(),s.r[m]);
            }
            case MOV_GBR_LOAD -> {
                Integer addr=binary(s.gbr,d,(a,b)->a+b);
                Integer value=loadState(s,i.address(),addr,i.operandWidth());
                s.r[0]=value==null?null:extend(value,i.operandWidth());
            }
            case MOV_GBR_STORE -> {
                Integer addr=binary(s.gbr,d,(a,b)->a+b);
                store(s,i.address(),addr,i.operandWidth(),s.r[0]);
            }
            case MOV_INDEX_LOAD -> {
                Integer addr=binary(s.r[m],s.r[0],(a,b)->a+b);
                Integer value=loadState(s,i.address(),addr,i.operandWidth());
                s.r[n]=value==null?null:extend(value,i.operandWidth());
            }
            case MOV_INDEX_STORE -> {
                Integer addr=binary(s.r[n],s.r[0],(a,b)->a+b);
                store(s,i.address(),addr,i.operandWidth(),s.r[m]);
            }
            case MOV_REV_LOAD -> {
                Integer addr=binary(s.r[m],-i.operandWidth(),(a,b)->a+b);
                s.r[m]=addr;
                Integer value=loadState(s,i.address(),addr,i.operandWidth());
                s.r[0]=value==null?null:extend(value,i.operandWidth());
            }
            case MOV_REV_STORE -> {
                Integer addr=s.r[n];
                store(s,i.address(),addr,i.operandWidth(),s.r[0]);
                s.r[n]=binary(s.r[n],i.operandWidth(),(a,b)->a+b);
            }
            case MOV_LOAD -> {
                Integer addr=binary(s.r[m],d,(a,b)->a+b);
                Integer value=loadState(s,i.address(),addr,i.operandWidth());
                s.r[n]=value==null?null:extend(value,i.operandWidth());
                if (i.postIncrement() && m!=n) s.r[m]=binary(s.r[m],i.operandWidth(),(a,b)->a+b);
            }
            case MOV_STORE -> {
                Integer source=s.r[m]; // Snapshot before decrement, also when m==n (SW p216).
                Integer addr=binary(s.r[n],d,(a,b)->a+b);
                if(i.preDecrement()) {
                    addr=binary(s.r[n],-i.operandWidth(),(a,b)->a+b);
                    s.r[n]=addr;
                }
                store(s,i.address(),addr,i.operandWidth(),source);
            }
            case STS_PR -> s.r[n]=s.pr;
            case LDS_PR -> s.pr=s.r[n];
            case STS_L_PR -> {
                Integer addr=binary(s.r[n],-4,(a,b)->a+b);
                s.r[n]=addr;store(s,i.address(),addr,4,s.pr);
            }
            case LDS_L_PR -> {
                s.pr=loadState(s,i.address(),s.r[n],4);
                s.r[n]=binary(s.r[n],4,(a,b)->a+b);
            }
            case TRAPA,RTE,FPU_ARITHMETIC,FPU_COMPARE,FPU_CONVERT,FPU_SQRT,FPU_FMAC ->
                    {issue(i.address(),"UNEXPECTED_SYSTEM_FLOW_OR_FPU_DISPATCH");return false;}
            case OPAQUE -> {
                if(!i.mnemonic().startsWith("PREF @R")) {
                    issue(i.address(),"INSTRUCTION_SEMANTICS_UNSUPPORTED");return false;
                }
                // SW6.3.29 p144: architecturally non-faulting hint; no CPU register/memory change.
            }
            case UNKNOWN, RETURN, TBR_CALL, MUL, MAC, FPU -> {
                issue(i.address(),"INSTRUCTION_SEMANTICS_UNSUPPORTED");return false;
            }
        }
        // MMIO can schedule DMA, reset, or interrupt without CPU control flow.
        // A guessed continuation after an unknown register side effect is unsound.
        return !s.unmodeledPeripheralWrite && s.cpuFault==null;
    }
    /**
     * FPU operation during a pending FPU exception interval (fix #19). REJ09B0051-0300
     * §8.9.7(4) txt 37011-37017: the FPU makes the generating instruction an NOP and makes
     * FPU instructions (excluding FCMP) from occurrence to the accepting instruction NOPs -
     * FPU registers are NOT updated during the interval; FPU-related CPU instructions do not
     * update FPU registers (NOP operation is performed) but CPU registers are updated; CPU
     * instructions are not made NOP and operate as usual (they are NOT isFpuOperation and
     * keep the normal dispatch). FCMP is the only FPU instruction not made NOP: it still
     * sets the T bit (FpuSemantics.frozenCompare, UNKNOWN when operand bits/width are unavailable).
     * The interval ends with the accepting instruction, which never executes (main-loop
     * acceptance test). No new exception can be generated in the interval: the FPU is halted
     * (§3.7.6 txt 2982-2983).
     */
    private boolean fpuAligned(AbstractCpu s,int pc,Integer address,int width) {
        if(address==null || (address&(width-1))==0)return true;
        addressFault(s,pc,address,"CPU_DATA_ADDRESS_ERROR");
        return false;
    }
    private boolean fpuFrozenExecute(AbstractCpu s,Sh2aDecoder.Instruction i) {
        int n=i.regN(),m=i.regM(),d=i.imm();
        switch(i.operation()) {
            case FPU_COMPARE -> {
                // The non-frozen apply() halts on a reserved operand encoding (odd register
                // number in PR1 mode); the frozen interval must not be more permissive.
                if(s.fpscr!=null && (s.fpscr&FpuSemantics.PR)!=0 &&
                        ((n&1)!=0||(m&1)!=0)) {
                    issue(i.address(),"FPU_FROZEN_ODD_DOUBLE_REGISTER");
                    return false;
                }
                if(!FpuSemantics.frozenCompare(s,i)) {
                    // FCMP still sets the T bit in the interval (txt 37011-37012), but the
                    // model cannot compute it (unknown operand/width): the hardware T value
                    // is unknown, so the old tracked value is discarded (the non-frozen path
                    // would halt here with FPU_INPUT_UNKNOWN; T is the only architectural
                    // effect of a frozen FCMP - no FR write, no new exception: the FPU is
                    // already halted).
                    s.t=null;
                    issue(i.address(),"FPU_FROZEN_FCMP_T_UNVERIFIED");
                }
                return true;
            }
            case FPU_ARITHMETIC, FPU_CONVERT, FPU_SQRT, FPU_FMAC -> {
                    return true; // NOP: result register not written (txt 37011-37014)
            }
            case FPU_REGISTER_TRANSFER -> {
                switch(m) {
                    // Read the CURRENT value: CPU side effect; the FPSCR content already
                    // reflects the generated exception (fill rule, §2.2.5 txt 1688-1692).
                    case 0 -> s.r[n]=s.fpscr;
                    case 1 -> s.r[n]=s.fpul;
                    // STS Rn->FPSCR/FPUL: FPU register update discarded in the interval.
                    case 2,3 -> { }
                    case 4,5 -> {
                        // STS FPSCR/FPUL,@Rn-: memory write + Rn decrement are CPU side
                        // effects; the stored value is the current (frozen) FPU content.
                        Integer addr=binary(s.r[n],-4,(a,b)->a+b);
                        if(!fpuAligned(s,i.address(),addr,4))return false;
                        s.r[n]=addr;
                        store(s,i.address(),addr,4,m==4?s.fpscr:s.fpul);
                    }
                    case 6,7 -> {
                        // LDS @Rn+,FPSCR/FPUL: memory read + Rn increment happen (CPU
                        // domain); the FPU register write is discarded.
                        if(!fpuAligned(s,i.address(),s.r[n],4))return false;
                        loadState(s,i.address(),s.r[n],4);
                        s.r[n]=binary(s.r[n],4,(a,b)->a+b);
                    }
                    default -> throw new IllegalStateException("Unsupported FPU control transfer");
                }
                // STS @Rn- performs a real store: if it reaches an unmodelled peripheral the
                // side effect is unknown and the continuation stops, exactly as in the
                // non-frozen execute() tail (return !s.unmodeledPeripheralWrite).
                return !s.unmodeledPeripheralWrite && s.cpuFault==null;
            }
            case FPU_MODE, FPU_IMMEDIATE, FPU_SIGN, FPU_REG_MOVE -> {
                    return true; // pure FPU-register transfers: discarded in the interval
            }
            case FPU_MEM_LOAD -> {
                int width=s.fpscr!=null && (s.fpscr&FpuSemantics.SZ)!=0?8:4;
                int byteOffset=i.width()==4 && i.operandWidth()==0 ? d*width : d;
                Integer addr=d==-1 && i.width()==2?binary(s.r[m],s.r[0],(a,b)->a+b):
                        binary(s.r[m],byteOffset,(a,b)->a+b);
                if(width==8 && (n&1)!=0) {issue(i.address(),"FMOV_DOUBLE_ODD_REGISTER");return false;}
                if(!fpuAligned(s,i.address(),addr,width))return false;
                loadState(s,i.address(),addr,4);
                if(width==8)loadState(s,i.address(),addr==null?null:addr+4,4);
                // FR write discarded; post-increment is a CPU side effect.
                if(i.postIncrement())s.r[m]=binary(s.r[m],width,(a,b)->a+b);
                // Symmetric with the non-frozen execute() tail; loadState never poisons,
                // so this is behaviour-identical and keeps the invariant uniform.
                return !s.unmodeledPeripheralWrite && s.cpuFault==null;
            }
            case FPU_MEM_STORE -> {
                int width=s.fpscr!=null && (s.fpscr&FpuSemantics.SZ)!=0?8:4;
                int byteOffset=i.width()==4 && i.operandWidth()==0 ? d*width : d;
                Integer addr=d==-1 && i.width()==2?binary(s.r[n],s.r[0],(a,b)->a+b):
                        binary(s.r[n],byteOffset,(a,b)->a+b);
                if(width==8 && (m&1)!=0) {issue(i.address(),"FMOV_DOUBLE_ODD_REGISTER");return false;}
                if(i.preDecrement()) {
                    addr=binary(s.r[n],-width,(a,b)->a+b);
                }
                if(!fpuAligned(s,i.address(),addr,width))return false;
                if(i.preDecrement())s.r[n]=addr;
                // Memory store of the current (frozen) FR value + pre-decrement are CPU
                // side effects.
                store(s,i.address(),addr,4,s.fr[m]);
                if(width==8)store(s,i.address(),addr==null?null:addr+4,4,s.fr[m+1]);
                // The store is real: unmodelled peripheral targets poison the continuation
                // (same invariant as the non-frozen execute() tail).
                return !s.unmodeledPeripheralWrite && s.cpuFault==null;
            }
            default -> {
                issue(i.address(),"FPU_FROZEN_OPERATION_UNSUPPORTED_"+i.mnemonic());
                return false;
            }
        }
    }
    private static Boolean compare(Integer a,Integer b,String kind) {
        if (a==null||b==null) return null;
        return switch(kind) {
            case "EQ" -> a.intValue()==b.intValue();
            case "HS" -> Integer.compareUnsigned(a,b)>=0;
            case "HI" -> Integer.compareUnsigned(a,b)>0;
            case "GE" -> a>=b;
            case "GT" -> a>b;
            default -> null;
        };
    }
    private static String hex(int a) {return String.format("0x%08X",a);}
    private List<VectorCandidate> candidateVectors(byte[] rom) {
        List<VectorCandidate> v=new ArrayList<>();
        // Table 7.3: vectors 0..511 are physical data words, but interrupt vectors
        // 64..511 are VBR-relative and VBR can be changed by startup code.
        for(int index=64; index<512 && index*4+4<=rom.length;index++) {
            long offset=index*4L;
            Integer a=bus.readRom(offset,4);
            if(a==null) continue;
            int word=(int)offset;
            for(int j=0;j<4;j++) {
                var claim=classifier.claim(word+j,CodeDataClassifier.Status.POSSIBLE_DATA,
                        "VECTOR_TABLE_WORD","VECTOR_INDEX_"+index+"_AT_"+hex(word),
                        "vector table word read as a handler pointer; VBR-relative target not executed",
                        LIMIT_ABSTRACT,-1);
                if(claim.status()==CodeDataClassifier.Status.CONFLICT)
                    issue(word,"VECTOR_TABLE_WORD_OVERLAPS_CODE_AT_"+hex(word+j));
            }
            if (validInstructionAddress(a))
                v.add(new VectorCandidate(index,a,"UNVERIFIED_VBR_RELATIVE_CANDIDATE; NOT_AUTOMATIC_ENTRY"));
        }
        return List.copyOf(v);
    }
}
