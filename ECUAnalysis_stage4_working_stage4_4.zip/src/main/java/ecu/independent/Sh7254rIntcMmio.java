package ecu.independent;

import java.util.Map;

/**
 * Restricted SH7254R INTC register shadow for abstract execution.
 * Source: Renesas R01UH0480EJ0400, Rev.4.00, sections 8.3 and 8.4.
 *
 * Only documented 8-bit SINTR and 16-bit IBCR/IBNR/IPR accesses are interpreted.
 * A programmed interrupt source is NOT an accepted CPU interrupt; no IRQ is
 * scheduled from this class. Unmapped, unsupported-width and unknown writes
 * remain explicit instead of acquiring artificial zero values.
 */
final class Sh7254rIntcMmio {
    static final int IBCR = 0xFFFE080C;
    static final int IBNR = 0xFFFE080E;
    private static final int IPR01 = 0xFFFE0818;
    private static final int IPR02 = 0xFFFE081A;
    private static final int IPR03 = 0xFFFE0C00;
    private static final int IPR29 = 0xFFFE0C34;
    record Read(boolean handled, boolean validWidth, Integer value) {}
    record Write(boolean handled, String reason, Integer pendingSoftwareVector) {}
    private Sh7254rIntcMmio() {}

    static int sintrNumber(int address) {
        if (address>=0xFFFE0810 && address<=0xFFFE0817)
            return address-0xFFFE0810+1;
        if (address>=0xFFFE0828 && address<=0xFFFE082E)
            return address-0xFFFE0828+9;
        return 0;
    }
    static boolean priorityAddress(int address) {
        return address==IPR01 || address==IPR02 ||
                (address>=IPR03 && address<=IPR29 && (address&1)==0);
    }
    static boolean belongs(int address) {
        return address==IBCR || address==IBNR || priorityAddress(address) || sintrNumber(address)!=0;
    }
    static Read read(AbstractCpu cpu,int address,int width) {
        int sintr=sintrNumber(address);
        if (sintr!=0) {
            int bit=1<<(sintr-1);
            if(width==1&&(cpu.softwareClearRequested&bit)!=0&&Integer.valueOf(0).equals(cpu.softwareInterrupts[sintr-1]))
                cpu.softwareClearRead|=bit;
            return new Read(true,width==1,width==1?cpu.softwareInterrupts[sintr-1]:null);
        }
        if (!belongs(address)) return new Read(false,false,null);
        if (width!=2) return new Read(true,false,null);
        if (address==IBCR) return new Read(true,true,cpu.bankPriorityMask);
        if (address==IBNR) {
            Integer enable=cpu.bankEnable,number=cpu.nextBank;
            Boolean overflow=cpu.bankOverflowException;
            if(enable==null || number==null || overflow==null) return new Read(true,true,null);
            return new Read(true,true,(enable<<14)|(overflow?0x2000:0)|number);
        }
        return new Read(true,true,cpu.intcPriorities.get(address));
    }
    static Write write(AbstractCpu cpu,int address,int width,Integer value) {
        int sintr=sintrNumber(address);
        if (sintr!=0) {
            if(width!=1) return new Write(true,"INTC_UNSUPPORTED_SINTR_WIDTH",null);
            Integer old=cpu.softwareInterrupts[sintr-1];
            if(value!=null && (value&~1)!=0)
                return new Write(true,"SINTR_RESERVED_BITS_WRITTEN",null);
            if(value!=null && value==1 && old!=null && old==1)
                return new Write(true,"SINTR_REPEAT_WRITE_ONE_PROHIBITED",null);
            cpu.softwareInterrupts[sintr-1]=value;
            int bit=1<<(sintr-1);
            cpu.softwareClearRead&=~bit;
            if(Integer.valueOf(0).equals(value))cpu.softwareClearRequested|=bit;
            else cpu.softwareClearRequested&=~bit;
            // SH7254R table 8.4: SINT15=93 ... SINT1=107.
            return new Write(true,value==null?"SINTR_VALUE_UNKNOWN":null,
                    value!=null && value==1?108-sintr:null);
        }
        if(!belongs(address)) return new Write(false,null,null);
        if(width!=2) return new Write(true,"INTC_UNSUPPORTED_REGISTER_WIDTH",null);
        if(address==IBCR) {
            if(value!=null && (value&1)!=0)
                return new Write(true,"IBCR_RESERVED_BIT_ZERO_REQUIRED",null);
            cpu.bankPriorityMask=value;
            return new Write(true,value==null?"IBCR_UNKNOWN_WRITE":null,null);
        }
        if(address==IBNR) {
            if(value!=null && ((value&0x1FF0)!=0 || ((value>>>14)&3)==2))
                return new Write(true,"IBNR_RESERVED_MODE_OR_BITS",null);
            // BN[3:0] is read-only; only BE/BOVE are software writable.
            cpu.bankEnable=value==null?null:(value>>>14)&3;
            cpu.bankOverflowException=value==null?null:(value&0x2000)!=0;
            return new Write(true,value==null?"IBNR_UNKNOWN_WRITE":null,null);
        }
        if(value==null) cpu.intcPriorities.remove(address);
        else cpu.intcPriorities.put(address,value&0xFFFF);
        return new Write(true,value==null?"IPR_UNKNOWN_WRITE":null,null);
    }
    /** HW8.6.1 note/Table8.5: a completed dummy read before RTE proves the
     * source-negation protocol. A zero write alone does not retract a CPU report. */
    static void reconcileBeforeRte(AbstractCpu cpu) {
        cpu.systemPending.removeIf(e->e.kind()==SystemExceptionModel.Kind.SOFTWARE
                &&(cpu.softwareClearRead&(1<<(e.level()-1)))!=0
                &&Integer.valueOf(0).equals(cpu.softwareInterrupts[e.level()-1]));
    }
    static void initializeReset(AbstractCpu cpu) {
        for(int i=0;i<15;i++)cpu.softwareInterrupts[i]=0;
        cpu.intcPriorities.put(IPR01,0);
        cpu.intcPriorities.put(IPR02,0);
        for(int addr=IPR03;addr<=IPR29;addr+=2)cpu.intcPriorities.put(addr,0);
    }
    /** Project only proven values during abstract-state joins. */
    static boolean join(AbstractCpu self,AbstractCpu other) {
        boolean changed=false;
        int requested=self.softwareClearRequested&other.softwareClearRequested;
        int read=self.softwareClearRead&other.softwareClearRead;
        if(requested!=self.softwareClearRequested||read!=self.softwareClearRead)changed=true;
        self.softwareClearRequested=requested;self.softwareClearRead=read;
        for(int i=0;i<15;i++) {
            if(!java.util.Objects.equals(self.softwareInterrupts[i],other.softwareInterrupts[i]) &&
                    self.softwareInterrupts[i]!=null) {
                self.softwareInterrupts[i]=null;changed=true;
            }
        }
        for(var it=self.intcPriorities.entrySet().iterator();it.hasNext();) {
            Map.Entry<Integer,Integer> e=it.next();
            if(!java.util.Objects.equals(e.getValue(),other.intcPriorities.get(e.getKey()))) {
                it.remove();changed=true;
            }
        }
        return changed;
    }
}
