package ecu.independent;

import java.util.*;

/**
 * Address-independent candidate anchors only; exact instruction-operation
 * windows are NOT proof of homologous code or calibration semantics.
 */
public final class StructuralMatcher {
    public record Candidate(int source, int target, int instructionCount,
                            String fingerprint, String status) {}
    private record Window(int address,String fingerprint) {}
    public List<Candidate> uniqueWindows(FirmwareGraph.Report source,
                                         FirmwareGraph.Report target, int size) {
        if(size<4 || size>32) throw new IllegalArgumentException("Window size must be 4..32");
        Map<String,List<Integer>> s=windows(source,size),t=windows(target,size);
        List<Candidate> found=new ArrayList<>();
        for(var entry:s.entrySet()) {
            List<Integer> other=t.get(entry.getKey());
            if(entry.getValue().size()!=1 || other==null || other.size()!=1) continue;
            found.add(new Candidate(entry.getValue().get(0),other.get(0),size,
                    entry.getKey(),"UNVERIFIED_UNIQUE_OPCODE_WINDOW"));
        }
        found.sort(Comparator.comparingInt(Candidate::source));
        return List.copyOf(found);
    }
    private Map<String,List<Integer>> windows(FirmwareGraph.Report r,int size) {
        Map<String,List<Integer>> results=new HashMap<>();
        Map<Integer,Sh2aDecoder.Instruction> instructions=r.instructions();
        for(int start:instructions.keySet()) {
            List<String> signature=new ArrayList<>();
            int address=start;
            for(int i=0;i<size;i++) {
                Sh2aDecoder.Instruction inst=instructions.get(address);
                if(inst==null || inst.flow()!=Sh2aDecoder.Flow.NEXT) break;
                // Ignore branch target, register numbering, addresses, immediates.
                // Still distinguish different memory operand widths and addressing modes.
                signature.add(inst.operation().name()+"/"+inst.operandWidth()+"/"+
                        inst.postIncrement()+"/"+inst.preDecrement());
                address=inst.endExclusive();
            }
            if(signature.size()==size) {
                String key=String.join(";",signature);
                results.computeIfAbsent(key,x->new ArrayList<>()).add(start);
            }
        }
        return results;
    }
}
