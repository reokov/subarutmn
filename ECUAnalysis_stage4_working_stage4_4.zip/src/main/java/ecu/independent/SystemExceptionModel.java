package ecu.independent;

import java.util.*;

/** SH7254R event ordering, R01UH0480EJ0400 tables7.1/7.3/8.4;
 * REJ09B0051 §8.9.7. This is an ID-boundary partial-order model, NOT a cycle clock.
 * A numerical result does not prove when its exception report reaches CPU ID. */
public final class SystemExceptionModel {
    private SystemExceptionModel() {}
    // Assigned module vectors, target Hardware Rev4 Table8.4 pp143–160; holes are reserved.
    private static final Set<Integer> MODULE_VECTORS=Set.of(
            108, 109, 112, 113, 116, 117, 120, 121, 124, 125, 128, 129, 132, 133, 136, 137,
            140, 144, 148, 152, 153, 156, 157, 160, 161, 164, 168, 169, 172, 173, 176, 177,
            178, 179, 180, 184, 185, 186, 187, 188, 192, 193, 194, 195, 196, 200, 201, 202,
            203, 204, 208, 209, 210, 211, 212, 216, 217, 218, 219, 220, 221, 224, 225, 226,
            227, 228, 229, 230, 231, 232, 233, 236, 237, 238, 239, 240, 241, 242, 243, 244,
            245, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 260, 261, 262, 263, 288,
            289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304,
            305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320,
            321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 340, 341, 342, 343, 344,
            345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 368,
            369, 370, 371, 372, 373, 376, 380, 381, 384, 385, 388, 389, 392, 396, 400, 401,
            402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417,
            418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433,
            434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 448, 449, 450,
            452, 453, 454, 456, 457, 458, 459, 460, 461, 464, 465, 466, 467, 468, 469, 472,
            473, 474, 475, 476, 477, 488);
    static boolean assignedInterruptVector(int offset) {
        if((offset&3)!=0)return false;
        int n=offset/4;
        return n==11||n==12||n>=64&&n<=71||n==79||n==82||n>=93&&n<=107||MODULE_VECTORS.contains(n);
    }
    public enum Kind {
        POWER_ON_RESET, CPU_ADDRESS, DMAC_ADDRESS, FPU, DIV_ZERO, DIV_OVERFLOW,
        BANK_UNDERFLOW, BANK_OVERFLOW, NMI, USER_BREAK, IRQ, MEMORY_ERROR,
        SOFTWARE, PERIPHERAL, TRAPA, GENERAL_ILLEGAL, SLOT_ILLEGAL
    }
    public enum Availability { REPORTED_ID, PIPELINE_UNVERIFIED, AFTER_ISSUE }
    public enum Stage { GENERATION, PENDING, ARBITRATION, ACCEPTANCE, TRANSITION, BLOCKED }
    public enum Status { NONE, ACCEPT, DEFERRED_SLOT, UNKNOWN_MASK, UNVERIFIED_TIMING, WAIT_COMPLETION }
    public record Event(long id,Kind kind,Integer generatorPc,Integer dataAddress,
                        int vectorOffset,int level,String source,Availability availability,Integer savedPcContext,Integer reportAfterIssuePc) {
        public Event(long id,Kind kind,Integer generatorPc,Integer dataAddress,int vectorOffset,int level,String source,Availability availability) {
            this(id,kind,generatorPc,dataAddress,vectorOffset,level,source,availability,null,null);
        }
        public Event(long id,Kind kind,Integer generatorPc,Integer dataAddress,int vectorOffset,int level,String source,Availability availability,Integer savedPcContext) {
            this(id,kind,generatorPc,dataAddress,vectorOffset,level,source,availability,savedPcContext,null);
        }
        public Event {
            Objects.requireNonNull(kind);Objects.requireNonNull(source);Objects.requireNonNull(availability);
            if(availability==Availability.AFTER_ISSUE&&(reportAfterIssuePc==null||
                    !(interrupt(kind)||kind==Kind.CPU_ADDRESS||kind==Kind.DMAC_ADDRESS||kind==Kind.FPU||kind==Kind.POWER_ON_RESET)))
                throw new IllegalArgumentException("relative report requires an asynchronous source and issue PC");
            if((vectorOffset&3)!=0||vectorOffset<0||vectorOffset>0x7fc)throw new IllegalArgumentException("vector");
            int fixed=switch(kind){case POWER_ON_RESET->0;case CPU_ADDRESS->0x24;case DMAC_ADDRESS->0x28;
                case FPU->0x34;case DIV_ZERO->0x44;case DIV_OVERFLOW->0x48;case BANK_UNDERFLOW->0x40;
                case BANK_OVERFLOW->0x3c;case NMI->0x2c;case USER_BREAK->0x30;case GENERAL_ILLEGAL->0x10;
                case SLOT_ILLEGAL->0x18;default->-1;};
            if(fixed>=0&&vectorOffset!=fixed)throw new IllegalArgumentException("kind/vector mismatch");
            if(kind==Kind.PERIPHERAL&&!MODULE_VECTORS.contains(vectorOffset/4))throw new IllegalArgumentException("reserved/non-module vector");
            if(kind==Kind.IRQ&&(vectorOffset<0x100||vectorOffset>0x11c))throw new IllegalArgumentException("IRQ vector");
            if(kind==Kind.MEMORY_ERROR&&vectorOffset!=79*4&&vectorOffset!=82*4)throw new IllegalArgumentException("memory error vector");
            if(kind==Kind.SOFTWARE&&(level<1||level>15||vectorOffset!=(108-level)*4))throw new IllegalArgumentException("SINT vector/level");
            if(kind==Kind.TRAPA&&vectorOffset>0x3fc)throw new IllegalArgumentException("TRAPA imm8");
            if(kind==Kind.BANK_OVERFLOW&&(level<1||level>15))throw new IllegalArgumentException("missing bank-overflow origin priority");
            if(interrupt(kind)&&(level<0||level>16||kind==Kind.NMI&&level!=16||kind!=Kind.NMI&&level>15))throw new IllegalArgumentException("interrupt level");
            if((kind==Kind.USER_BREAK||kind==Kind.MEMORY_ERROR)&&level!=15)throw new IllegalArgumentException("fixed priority15");
        }
        Event withSavedPc(int pc){return new Event(id,kind,generatorPc,dataAddress,vectorOffset,level,source,availability,pc,reportAfterIssuePc);}
        Event reported() {return new Event(id,kind,generatorPc,dataAddress,vectorOffset,level,source,Availability.REPORTED_ID,savedPcContext,reportAfterIssuePc);}
        /** Explicit scenario input, never inferred from a numerical FPU result or cycle count. */
        Event afterIssue(int pc){return new Event(id,kind,generatorPc,dataAddress,vectorOffset,level,source,Availability.AFTER_ISSUE,savedPcContext,pc);}
    }
    public record Boundary(int decodePc,boolean delaySlot,boolean instructionCompleted,boolean cancellableDivision) {
        public Boundary(int pc,boolean slot,boolean complete){this(pc,slot,complete,false);}
    }
    public record Decision(Status status,Event winner,List<Event> candidates) {
        public Decision { candidates=List.copyOf(candidates); }
    }
    public record Observation(Stage stage,Event event,Integer decodePc,Integer savedPc,Integer handler,
                              String evidence) {}
    /** One normal FP write-back with an explicitly supplied completion boundary.
     * No exception-report timing is inferred from this boundary. */
    public record FpuResult(int generatorPc,int beforePc,int frMask,List<Integer> fr,boolean writesFpul,Integer fpul) {
        public FpuResult {fr=Collections.unmodifiableList(new ArrayList<>(fr));}
    }
    /** No-wait, completed-fetch scenario input (SW8.2). Not a clock/bus model.
     * ED state counts equal slot counts ONLY in this explicitly one-state-slot profile. */
    public enum PipelineStage { ISSUE, EXECUTE, CPU_COMPLETION, RETIREMENT, RESULT_COMMIT, CANCELLED, E1_INITIAL, ED, E1_RETURN, E2, SF, FP_EX, NA, CPU_EX, MA, WB, WAIT_RESOURCE }
    public record PipelineStep(PipelineStage stage,long slot,long sequence,int pc,long systemState) {public PipelineStep(PipelineStage s,long t,long id,int pc){this(s,t,id,pc,-1);}}
    public record ResourceUse(String resource,int offset,int length) {
        public ResourceUse {if(offset<0||length<1)throw new IllegalArgumentException("resource interval");}
    }
    /** Register names R0..R15, FR0..FR15, GBR, PR, FPUL, T, FPSCR. Sets are immutable.
     * latency is the issue distance for a dependent instruction, not the SF phase.
     * doubleReads names the even FR of each semantic DR operand. */
    public record PipelineSpec(int pc,int width,Set<String> reads,Set<String> writes,
                               List<ResourceUse> resources,int latency,int resultOffset,
                               boolean fpu,boolean arithmetic,boolean division,boolean doubleArithmetic,
                               boolean fpscrAccess,boolean zeroLatency,int cpuOffset,int executionStates,int sourceHold,Map<String,Integer> registerLatencies,Set<String> doubleReads) {
        public PipelineSpec(int pc,int width,Set<String> reads,Set<String> writes,List<ResourceUse> resources,int latency,int resultOffset,boolean fpu,boolean arithmetic,boolean division,boolean doubleArithmetic,boolean fpscrAccess,boolean zeroLatency,int cpuOffset,int executionStates,int sourceHold){
            this(pc,width,reads,writes,resources,latency,resultOffset,fpu,arithmetic,division,doubleArithmetic,fpscrAccess,zeroLatency,cpuOffset,executionStates,sourceHold,Map.of(),Set.of());
        }
        int latency(String register){return registerLatencies.getOrDefault(register,latency);}
        int readLatency(String register,PipelineSpec consumer){
            // SW8.9.2(1): sticky CS accumulation between CLIPs has no rewrite contention.
            if(register.equals("CS")&&resultOffset==1&&consumer.resultOffset()==1&&consumer.writes().contains("CS"))return 0;
            // SW8.5 p352: the extra SR slot applies to fetching a loaded flag, not WAW.
            if(writes.contains("SR")&&Set.of("T","Q","M","CS").contains(register)&&resources.stream().anyMatch(r->r.resource().equals("MA")))return latency(register)+1;
            // Table 8.1 note 4: a memory-loaded DR has distinct even/odd/DR consumers.
            if(register.startsWith("FR")&&fpu&&!arithmetic&&writes.contains("FR"+(Integer.parseInt(register.substring(2))^1))&&resources.stream().anyMatch(r->r.resource().equals("MA"))){
                int other=Integer.parseInt(register.substring(2))^1;if(consumer.doubleReads().contains("FR"+(other&~1)))return 4;
            }
            return latency(register);
        }
        public PipelineSpec {
            reads=Set.copyOf(reads);writes=Set.copyOf(writes);resources=List.copyOf(resources);registerLatencies=Map.copyOf(registerLatencies);doubleReads=Set.copyOf(doubleReads);
            for(String r:doubleReads)if(!reads.contains(r)||!reads.contains("FR"+(Integer.parseInt(r.substring(2))+1)))throw new IllegalArgumentException("DR source");
            if(!writes.containsAll(registerLatencies.keySet())||registerLatencies.values().stream().anyMatch(x->x<0))throw new IllegalArgumentException("register latency");
            if(latency<0||resultOffset<1||cpuOffset<1||executionStates<1||sourceHold<0)throw new IllegalArgumentException("pipeline timing");
        }
    }
    private record StatusBits(Boolean t,Boolean q,Boolean m,Boolean s,Boolean cs,Boolean bo,Integer mask,Integer raw) {
        static StatusBits of(AbstractCpu c){return new StatusBits(c.t,c.q,c.m,c.saturation,c.cs,c.bankOverflow,c.interruptMask,c.sr);}
        static StatusBits loaded(Integer v){var c=new AbstractCpu();c.writeSr(v);return of(c);}
        void apply(AbstractCpu c){c.t=t;c.q=q;c.m=m;c.saturation=s;c.cs=cs;c.bankOverflow=bo;c.interruptMask=mask;c.sr=raw;}
    }
    public record MemoryDelta(Map<Integer,Byte> bytes,Map<Integer,Integer> writers) {
        public MemoryDelta {bytes=Collections.unmodifiableMap(new HashMap<>(bytes));writers=Map.copyOf(writers);}
        static MemoryDelta between(AbstractCpu a,AbstractCpu b) {
            Map<Integer,Byte> values=new HashMap<>();Map<Integer,Integer> writers=new HashMap<>();
            Set<Integer> addresses=new HashSet<>(a.ramWriters.keySet());addresses.addAll(b.ramWriters.keySet());
            for(int address:addresses)if(!Objects.equals(a.ram.get(address),b.ram.get(address))||!Objects.equals(a.ramWriters.get(address),b.ramWriters.get(address))) {
                values.put(address,b.ram.get(address));if(b.ramWriters.containsKey(address))writers.put(address,b.ramWriters.get(address));
            }
            return new MemoryDelta(values,writers);
        }
    }
    public record Flight(long sequence,PipelineSpec spec,long issued,Map<String,Integer> result,
                         boolean cpuCompleted,boolean resultCommitted,int phase,int remaining,boolean phaseStarted,MemoryDelta memory) {
        public Flight {result=Collections.unmodifiableMap(new LinkedHashMap<>(result));}
    }
    /** One stage engine for real state and forecasts. Numerical execution stays in FirmwareGraph. */
    public static final class Pipeline {
        private record Phase(PipelineStage stage,Set<String> resources,int states) {
            Phase(PipelineStage s,String r,int n){this(s,r==null?Set.of():Set.of(r),n);}
        }
        private record Trace(PipelineStep step,Trace previous) {}
        private long slot,sequence,stateClock,issueFence,fpscrReadFence;
        private int issuedInSlot,advancingStates=1;
        private PipelineSpec preceding;
        private final Map<Long,Integer> durations;
        private final List<Flight> flights=new ArrayList<>();
        private final Map<String,Integer> committed=new LinkedHashMap<>();
        private final Map<Integer,Byte> ram=new HashMap<>();
        private final Map<Integer,Integer> writers=new HashMap<>();
        private final Map<String,Long> used=new HashMap<>();
        private final Map<Long,List<Long>> completedPhases=new HashMap<>();
        private final Set<String> uncertainties=new LinkedHashSet<>();
        private StatusBits status;
        private Integer numericFpscr,lastRetiredPc,lastResumePc;
        private boolean initialized;
        private String blocked;
        private Trace trace;
        public Pipeline(){this(Map.of());}
        public Pipeline(Map<Long,Integer> input){input.forEach((s,n)->{if(s<1||n<1)throw new IllegalArgumentException("slot duration");});durations=Map.copyOf(input);}
        public long slot(){return slot;}
        public long systemState(){return stateClock;}
        public String blocked(){return blocked;}
        public Set<String> uncertainties(){return Set.copyOf(uncertainties);}
        public List<Flight> outstanding(){return List.copyOf(flights);}
        public Map<String,Integer> committed(){return Collections.unmodifiableMap(new LinkedHashMap<>(committed));}
        public List<PipelineStep> steps(){List<PipelineStep> out=new ArrayList<>();for(Trace t=trace;t!=null;t=t.previous())out.add(t.step());Collections.reverse(out);return List.copyOf(out);}
        private void emit(PipelineStage stage,long t,Flight f){emit(stage,t,f.sequence(),f.spec().pc(),-1);}
        private void emit(PipelineStage stage,long t,long id,int pc,long time){
            if(time<0)time=stateClock+(stage==PipelineStage.ISSUE||stage==PipelineStage.CANCELLED?0:
                    stage==PipelineStage.RESULT_COMMIT||stage==PipelineStage.CPU_COMPLETION||stage==PipelineStage.RETIREMENT?advancingStates:1);
            trace=new Trace(new PipelineStep(stage,t,id,pc,time),trace);
        }
        Pipeline copy(){
            Pipeline p=new Pipeline(durations);p.slot=slot;p.sequence=sequence;p.stateClock=stateClock;p.issueFence=issueFence;p.fpscrReadFence=fpscrReadFence;
            p.completedPhases.putAll(completedPhases);p.issuedInSlot=issuedInSlot;p.preceding=preceding;p.flights.addAll(flights);p.committed.putAll(committed);p.ram.putAll(ram);p.writers.putAll(writers);
            p.uncertainties.addAll(uncertainties);p.status=status;p.numericFpscr=numericFpscr;p.lastRetiredPc=lastRetiredPc;p.lastResumePc=lastResumePc;p.initialized=initialized;p.blocked=blocked;p.trace=trace;return p;
        }
        List<Object> key(){return Arrays.asList(slot,sequence,stateClock,issueFence,fpscrReadFence,durations,issuedInSlot,preceding,List.copyOf(flights),flights.stream().map(f->completedPhases.getOrDefault(f.sequence(),List.of())).toList(),new HashMap<>(committed),new HashMap<>(ram),new HashMap<>(writers),status,numericFpscr,Set.copyOf(uncertainties),blocked);}
        void initialize(AbstractCpu c){
            if(initialized)return;initialized=true;status=StatusBits.of(c);numericFpscr=c.fpscr;
            for(int j=0;j<16;j++){committed.put("R"+j,c.r[j]);committed.put("FR"+j,c.fr[j]);}
            for(String r:List.of("PR","GBR","VBR","TBR","FPUL","FPSCR","SZ","T","Q","M","CS","IRQ_WINDOW"))committed.put(r,read(c,r));ram.putAll(c.ram);writers.putAll(c.ramWriters);
        }
        void rebase(AbstractCpu c){if(!flights.isEmpty())throw new IllegalStateException("outstanding rebase");committed.clear();ram.clear();writers.clear();initialized=false;initialize(c);lastRetiredPc=c.lastRetiredPc;lastResumePc=c.lastResumePc;}
        void fence(long until){issueFence=Math.max(issueFence,until);}
        void decodeBoundary(){advance(Math.max(issueFence,issuedInSlot==2?slot+1:slot));}
        Integer decodeFpscr(Integer fallback){return initialized?numericFpscr:fallback;}
        void numericalFpscr(Integer v){numericFpscr=v;}
        void assumeT(boolean v){
            for(int j=flights.size()-1;j>=0;j--){Flight f=flights.get(j);if(f.result().containsKey("T")){
                Map<String,Integer> delta=new LinkedHashMap<>(f.result());delta.put("T",v?1:0);flights.set(j,new Flight(f.sequence(),f.spec(),f.issued(),delta,f.cpuCompleted(),f.resultCommitted(),f.phase(),f.remaining(),f.phaseStarted(),f.memory()));return;}}
            committed.put("T",v?1:0);
        }
        private static void applyMemory(Map<Integer,Byte> ram,Map<Integer,Integer> writers,MemoryDelta d){d.bytes().forEach((a,b)->{if(b==null)ram.remove(a);else ram.put(a,b);});writers.putAll(d.writers());}
        void restoreCommitted(AbstractCpu c){
            if(!initialized)return;status.apply(c);for(var e:committed.entrySet())if(!e.getKey().equals("SR"))write(c,e.getKey(),e.getValue());
            c.ram.clear();c.ram.putAll(ram);c.ramWriters.clear();c.ramWriters.putAll(writers);
            if(flights.stream().noneMatch(f->f.spec().arithmetic()||f.spec().writes().contains("FPSCR")||f.spec().writes().contains("SZ")))c.fpscr=numericFpscr;
            if(lastRetiredPc!=null){c.lastRetiredPc=lastRetiredPc;c.lastResumePc=lastResumePc;}
        }
        void operands(AbstractCpu c){
            restoreCommitted(c);for(Flight f:flights){for(var e:f.result().entrySet())write(c,e.getKey(),e.getValue());applyMemory(c.ram,c.ramWriters,f.memory());}c.fpscr=numericFpscr;
        }
        static Integer read(AbstractCpu c,String r){
            if(r.startsWith("FR"))return c.fr[Integer.parseInt(r.substring(2))];if(r.startsWith("R"))return c.r[Integer.parseInt(r.substring(1))];
            return switch(r){case "GBR"->c.gbr;case "VBR"->c.vbr;case "TBR"->c.tbr;case "PR"->c.pr;case "SR"->c.readSr();case "IRQ_WINDOW"->c.irqMaskChangeWindow;case "MEMORY"->0;case "FPSCR"->c.fpscr;case "SZ"->c.fpscr==null?null:(c.fpscr>>>20)&1;case "FPUL"->c.fpul;case "T"->c.t==null?null:c.t?1:0;case "Q"->c.q==null?null:c.q?1:0;case "M"->c.m==null?null:c.m?1:0;case "CS"->c.cs==null?null:c.cs?1:0;default->throw new IllegalArgumentException(r);};
        }
        static void write(AbstractCpu c,String r,Integer v){
            if(r.startsWith("FR"))c.fr[Integer.parseInt(r.substring(2))]=v;else if(r.startsWith("R"))c.r[Integer.parseInt(r.substring(1))]=v;
            else switch(r){case "GBR"->c.gbr=v;case "VBR"->c.vbr=v;case "TBR"->c.tbr=v;case "PR"->c.pr=v;case "SR"->c.writeSr(v);case "IRQ_WINDOW"->c.irqMaskChangeWindow=v;case "MEMORY"->{}case "FPSCR"->c.fpscr=v;case "SZ"->c.fpscr=c.fpscr==null||v==null?null:(c.fpscr&~FpuSemantics.SZ)|(v<<20);case "FPUL"->c.fpul=v;case "T"->c.t=v==null?null:v!=0;case "Q"->c.q=v==null?null:v!=0;case "M"->c.m=v==null?null:v!=0;case "CS"->c.cs=v==null?null:v!=0;default->throw new IllegalArgumentException(r);}
        }
        private static boolean uses(PipelineSpec p,String r){return p.resources().stream().anyMatch(x->x.resource().equals(r));}
        private static boolean pair(PipelineSpec a,PipelineSpec b){
            if(a==null||a.width()!=2||b.width()!=2||a.executionStates()>1||a.fpscrAccess()||b.fpscrAccess()&&a.fpu())return false;
            if(uses(a,"MA")&&uses(b,"MA")||uses(a,"BRANCH")&&uses(b,"BRANCH"))return false;
            if(uses(a,"CPU_TO_FP")&&(b.writes().contains("MEMORY")||uses(b,"READ_BUS"))||uses(b,"CPU_TO_FP")&&(a.writes().contains("MEMORY")||uses(a,"READ_BUS")))return false;
            if(a.writes().stream().anyMatch(r->b.reads().contains(r)&&!(r.equals("CS")&&b.writes().contains("CS")))&&!a.zeroLatency())return false;
            for(String r:a.writes())if(b.writes().contains(r)&&!r.equals("CS")&&!(a.fpu()&&b.fpu()&&(r.startsWith("FR")||r.equals("FPUL"))))return false;
            for(ResourceUse x:a.resources())for(ResourceUse y:b.resources())if(x.offset()==1&&y.offset()==1&&x.resource().equals(y.resource()))return false;
            return true;
        }
        private static List<Phase> program(PipelineSpec p){
            List<Phase> out=new ArrayList<>();
            if(p.division()){
                out.add(new Phase(PipelineStage.E1_INITIAL,"E1",p.resources().get(0).length()));out.add(new Phase(PipelineStage.ED,"ED",p.resources().get(1).length()));
                out.add(new Phase(PipelineStage.E1_RETURN,"E1",p.resources().get(2).length()));out.add(new Phase(PipelineStage.E2,"E2",1));out.add(new Phase(PipelineStage.SF,"ARITH_SF",1));
            }else if(p.arithmetic()){
                out.add(new Phase(PipelineStage.E1_INITIAL,"E1",p.resources().getFirst().length()));out.add(new Phase(PipelineStage.E2,"E2",1));if(!p.writes().contains("T"))out.add(new Phase(PipelineStage.SF,"ARITH_SF",1));
            }else for(int i=1;i<=p.resultOffset();i++){
                Set<String> rs=new HashSet<>();for(ResourceUse r:p.resources())if(i>=r.offset()&&i<r.offset()+r.length())rs.add(r.resource());
                PipelineStage stage=p.fpu()?(i==1||p.executionStates()==2&&i==2?PipelineStage.FP_EX:i==p.resultOffset()&&i>=3?PipelineStage.SF:PipelineStage.NA):
                        uses(p,"RTE_SEQUENCE")?(i==2||i==3?PipelineStage.MA:PipelineStage.CPU_EX):uses(p,"SR_SEQUENCE")?(rs.contains("MA")?PipelineStage.MA:PipelineStage.CPU_EX):i==1?PipelineStage.CPU_EX:rs.contains("MA")?PipelineStage.MA:PipelineStage.WB;
                out.add(new Phase(stage,rs,1));
            }
            return out;
        }
        private record Prediction(Map<Long,Long> finish,Map<Long,List<Long>> phases) {}
        private Prediction forecast(){
            Pipeline p=copy();p.drain();Map<Long,Long> end=new HashMap<>();
            for(PipelineStep s:p.steps())if(s.stage()==PipelineStage.RESULT_COMMIT)end.put(s.sequence(),s.slot());
            return new Prediction(end,Map.copyOf(p.completedPhases));
        }
        private void completedPhase(Flight f,long tick){
            List<Long> times=new ArrayList<>(completedPhases.getOrDefault(f.sequence(),List.of()));times.add(tick);completedPhases.put(f.sequence(),List.copyOf(times));
        }
        private static long sourceReady(Flight f,String register,int latency,Prediction prediction){
            if(register.equals("MEMORY"))return prediction.finish().get(f.sequence())-f.spec().resultOffset()+latency;
            if(latency==0)return f.issued();
            int elapsed=0,index=0;
            for(Phase stage:program(f.spec())){
                elapsed+=stage.states();if(elapsed>=latency)return prediction.phases().get(f.sequence()).get(index);index++;
            }
            throw new IllegalStateException("NOT_IMPLEMENTED_RESULT_PHASE_"+register);
        }
        private static long executionSlot(Flight f,int states,Prediction prediction){
            if(states==0)return f.issued();
            int elapsed=0,index=0;
            for(Phase phase:program(f.spec())){
                elapsed+=phase.states();
                if(elapsed>=states)return prediction.phases().get(f.sequence()).get(index)-(elapsed-states);
                index++;
            }
            throw new IllegalStateException("NOT_IMPLEMENTED_EXECUTION_PHASE");
        }
        public long ready(PipelineSpec next){
            if(blocked!=null)throw new IllegalStateException(blocked);Pipeline p=copy();
            for(int guard=0;guard<10000;guard++){
                long at=p.slot;
                if(at<p.issueFence||next.fpscrAccess()&&at<p.fpscrReadFence||p.issuedInSlot==2){p.advance(at+1);continue;}
                Prediction prediction=p.forecast();Map<Long,Long> end=prediction.finish();
                boolean lastMulti=p.flights.stream().anyMatch(f->f.spec().executionStates()>1&&at==executionSlot(f,f.spec().executionStates()-1,prediction));
                if(p.issuedInSlot==1&&(lastMulti||!pair(p.preceding,next))){p.advance(at+1);continue;}
                long required=at;
                for(Flight f:p.flights){PipelineSpec old=f.spec();long finish=end.getOrDefault(f.sequence(),at);
                    required=Math.max(required,uses(old,"RTE_SEQUENCE")?finish:executionSlot(f,old.executionStates()-(old.width()==4?0:1),prediction));
                    for(String r:next.reads())if(old.writes().contains(r)){
                        int latency=old.readLatency(r,next);
                        if(old.arithmetic()&&next.writes().contains("MEMORY")&&(r.startsWith("FR")||r.equals("FPUL")))latency=Math.max(0,latency-1);
                        if(r.equals("FPUL")&&old.arithmetic()&&next.fpu()&&!next.arithmetic()&&uses(next,"READ_BUS")&&!next.writes().contains("MEMORY"))latency=Math.max(0,latency-2);
                        if((old.doubleArithmetic()||old.division()&&old.writes().size()==2)&&r.startsWith("FR")&&(Integer.parseInt(r.substring(2))&1)!=0&&!next.arithmetic())latency=Math.max(0,latency-1);
                        if(next.doubleArithmetic()&&latency<=2)latency=2;
                        required=Math.max(required,sourceReady(f,r,latency,prediction));
                    }
                    for(String r:next.writes()){
                        if(old.writes().contains(r)&&!r.equals("CS")){
                            boolean fpTarget=old.fpu()&&(r.startsWith("FR")||r.equals("FPUL"));
                            int n=fpTarget?(old.division()?old.latency()-1:old.latency()-2):old.latency(r);
                            n=Math.max(n,old.resultOffset()-next.resultOffset()+(fpTarget?0:1));required=Math.max(required,finish-old.resultOffset()+Math.max(0,n));
                        }
                        if(old.reads().contains(r))required=Math.max(required,f.issued()+old.sourceHold());
                    }
                    if(next.fpscrAccess()&&old.arithmetic())required=Math.max(required,finish+1);
                }
                if(required>at){p.advance(at+1);continue;}
                Pipeline future=p.copy();future.advance(at+1);boolean busy=false;for(String resource:program(next).getFirst().resources())if(future.used.containsKey(resource))busy=true;
                if(busy){p.advance(at+1);continue;}return at;
            }
            throw new IllegalStateException("NOT_IMPLEMENTED_PIPELINE_PROGRESS_BOUND");
        }
        public long issue(PipelineSpec p,Map<String,Integer> values){return issue(p,values,new MemoryDelta(Map.of(),Map.of()));}
        long issue(PipelineSpec p,Map<String,Integer> values,MemoryDelta memory){
            if(!p.writes().equals(values.keySet()))throw new IllegalArgumentException("write set");
            if(p.writes().equals(Set.of("SZ")))uncertainties.add("UNVERIFIED_FSCHG_PIPELINE_RESOURCE");
            return append(p,values,memory);
        }
        void issueFault(PipelineSpec p){append(p,Map.of(),new MemoryDelta(Map.of(),Map.of()));}
        // Existing abstract delivery-uncertainty counter, NOT an INTC response-clock model.
        private void completeMaskWindow(){Integer window=committed.get("IRQ_WINDOW");if(window!=null&&window>0)committed.put("IRQ_WINDOW",window-1);}
        private long append(PipelineSpec p,Map<String,Integer> values,MemoryDelta memory){
            long at=ready(p);advance(at);long id=++sequence;flights.add(new Flight(id,p,at,values,false,false,0,program(p).getFirst().states(),false,memory));emit(PipelineStage.ISSUE,at,id,p.pc(),stateClock);issuedInSlot++;preceding=p;return id;
        }
        public void advance(long target){
            if(blocked!=null)throw new IllegalStateException(blocked);if(target<slot)throw new IllegalArgumentException("backwards time");
            while(slot<target){
                long tick=slot+1;advancingStates=durations.getOrDefault(tick,1);used.clear();Set<Long> edEligible=new HashSet<>();
                for(Flight f:flights)if(f.phase()<program(f.spec()).size()){
                    Phase phase=program(f.spec()).get(f.phase());if(phase.stage()==PipelineStage.ED)edEligible.add(f.sequence());if(f.phaseStarted())for(String r:phase.resources())used.put(r,f.sequence());
                }
                for(int j=0;j<flights.size();j++){
                    Flight f=flights.get(j);List<Phase> stages=program(f.spec());int phase=f.phase(),remaining=f.remaining();boolean started=f.phaseStarted(),cpu=f.cpuCompleted(),result=f.resultCommitted();
                    if(tick==f.issued()+1)emit(PipelineStage.EXECUTE,tick,f);
                    if(phase<stages.size()){
                        Phase current=stages.get(phase);boolean free=true;for(String r:current.resources())if(used.containsKey(r)&&used.get(r)!=f.sequence())free=false;
                        if(free){for(String r:current.resources())used.put(r,f.sequence());if(!started)emit(current.stage(),tick,f);remaining--;started=true;if(remaining==0){completedPhase(f,tick);phase++;started=false;remaining=phase<stages.size()?stages.get(phase).states():0;}}
                        else {if(current.stage()==PipelineStage.ED||current.stage()==PipelineStage.E1_RETURN)uncertainties.add("UNVERIFIED_ED_E1_HANDOFF_BUFFERING");emit(PipelineStage.WAIT_RESOURCE,tick,f);}
                    }
                    if(!cpu&&(f.spec().fpu()?tick>=f.issued()+f.spec().cpuOffset():phase==stages.size())){cpu=true;lastRetiredPc=f.spec().pc();lastResumePc=f.spec().pc()+f.spec().width();
                        if(!(uses(f.spec(),"SR_SEQUENCE")&&f.result().containsKey("SR")))completeMaskWindow();
                        emit(PipelineStage.CPU_COMPLETION,tick,f);emit(PipelineStage.RETIREMENT,tick,f);}
                    if(!result&&phase==stages.size()){
                        result=true;if(f.spec().arithmetic())fpscrReadFence=Math.max(fpscrReadFence,tick+1);
                        if(f.result().containsKey("SR")){
                            StatusBits loaded=StatusBits.loaded(f.result().get("SR"));
                            if(uses(f.spec(),"SR_SEQUENCE")){
                                if(loaded.mask()!=null&&(status==null||status.mask()==null||loaded.mask()<status.mask())){
                                    committed.put("IRQ_WINDOW",5);uncertainties.add("UNVERIFIED_INTC_MASK_CHANGE_REPORT_SYNC");
                                }else completeMaskWindow();
                            }
                            status=loaded;
                        }
                        committed.putAll(f.result());applyMemory(ram,writers,f.memory());emit(PipelineStage.RESULT_COMMIT,tick,f);
                    }
                    flights.set(j,new Flight(f.sequence(),f.spec(),f.issued(),f.result(),cpu,result,phase,remaining,started,f.memory()));
                }
                for(int sub=1;sub<advancingStates;sub++){
                    used.remove("ED");boolean occupied=false;
                    for(int j=0;j<flights.size();j++){
                        Flight f=flights.get(j);List<Phase> stages=program(f.spec());if(!edEligible.contains(f.sequence())||f.phase()>=stages.size()||stages.get(f.phase()).stage()!=PipelineStage.ED)continue;
                        if(occupied)continue;occupied=true;used.put("ED",f.sequence());int phase=f.phase(),remaining=f.remaining()-1;boolean started=true;
                        if(!f.phaseStarted())emit(PipelineStage.ED,tick,f.sequence(),f.spec().pc(),stateClock+sub+1);
                        if(remaining==0){completedPhase(f,tick);phase++;remaining=stages.get(phase).states();started=false;}
                        flights.set(j,new Flight(f.sequence(),f.spec(),f.issued(),f.result(),f.cpuCompleted(),f.resultCommitted(),phase,remaining,started,f.memory()));
                    }
                }
                stateClock+=advancingStates;flights.removeIf(f->f.cpuCompleted()&&f.resultCommitted());slot=tick;issuedInSlot=0;preceding=null;
            }
        }
        void block(String reason){blocked=reason;}
        void drain(){int guard=0;while(!flights.isEmpty()){if(++guard>10000)throw new IllegalStateException("NOT_IMPLEMENTED_PIPELINE_DRAIN_BOUND");advance(slot+1);}}
        void reset(){completedPhases.clear();for(Flight f:flights)emit(PipelineStage.CANCELLED,slot,f);flights.clear();committed.clear();ram.clear();writers.clear();uncertainties.clear();initialized=false;status=null;numericFpscr=null;issueFence=slot;fpscrReadFence=slot;issuedInSlot=0;preceding=null;blocked=null;lastRetiredPc=lastResumePc=null;}
    }

    /** Normative no-wait profiles. Null means unsupported timing, NEVER one guessed cycle.
     * SW Rev3 §§8.3,8.6,8.8,8.9.8. Memory/branch/multicycle CPU need separate profiles. */
    static PipelineSpec pipelineSpec(Sh2aDecoder.Instruction i,Integer fpscr) {
        Set<String> read=new LinkedHashSet<>(),write=new LinkedHashSet<>();List<ResourceUse> resources=new ArrayList<>();
        Map<String,Integer> registerLatencies=new HashMap<>();Set<String> doubleReads=new HashSet<>();
        int n=i.regN(),m=i.regM(),latency=1,result=1,hold=0,cpu=1,states=1;boolean fp=false,arith=false,div=false,dbl=false,zero=false,fpscrAccess=false;
        String name=i.mnemonic().split(" ")[0];
        switch(i.operation()) {
            case NOP -> {}
            case BRANCH,RETURN -> {
                if(i.regN()>=0)read.add("R"+n);if(i.flow()==Sh2aDecoder.Flow.CONDITIONAL)read.add("T");
                if(i.operation()==Sh2aDecoder.Operation.RETURN)read.add("PR");if(i.flow()==Sh2aDecoder.Flow.CALL)write.add("PR");resources.add(new ResourceUse("BRANCH",1,1));
            }
            case RTE -> {read.addAll(Set.of("R15","MEMORY"));write.addAll(Set.of("R15","SR","T","Q","M","CS"));cpu=6;states=6;latency=5;result=6;resources.add(new ResourceUse("MA",2,2));resources.add(new ResourceUse("RTE_SEQUENCE",1,6));}
            case DIV0U -> write.addAll(Set.of("Q","M","T"));
            case DIV0S -> {read.add("R"+m);read.add("R"+n);write.addAll(Set.of("Q","M","T"));}
            case DIV1 -> {read.add("R"+m);read.add("R"+n);read.addAll(Set.of("Q","M","T"));write.addAll(Set.of("R"+n,"Q","T"));}
            case CLIPS_B,CLIPS_W,CLIPU_B,CLIPU_W -> {read.addAll(Set.of("R"+n,"CS"));write.addAll(Set.of("R"+n,"CS"));}
            case BIT_REG -> {read.add("R"+n);if(m==3)write.add("T");else {write.add("R"+n);if(m==2)read.add("T");}}
            case NOT_REG,NEG_REG -> {read.add("R"+m);write.add("R"+n);}
            case SWAP_B,SWAP_W,EXTS_B,EXTS_W,EXTU_B,EXTU_W -> {read.add("R"+m);write.add("R"+n);resources.add(new ResourceUse("SHIFT",1,1));}
            case XTRCT -> {read.add("R"+m);read.add("R"+n);write.add("R"+n);resources.add(new ResourceUse("SHIFT",1,1));}
            case AND_IMM,OR_IMM,XOR_IMM -> {read.add("R0");write.add("R0");}
            case ADDC_REG,SUBC_REG,NEGC_REG -> {read.add("T");read.add("R"+m);if(i.operation()!=Sh2aDecoder.Operation.NEGC_REG)read.add("R"+n);write.addAll(Set.of("R"+n,"T"));}
            case ADDV_REG,SUBV_REG -> {read.add("R"+n);read.add("R"+m);write.addAll(Set.of("R"+n,"T"));}
            case DT_REG -> {read.add("R"+n);write.addAll(Set.of("R"+n,"T"));}
            case SHLL,SHLR,SHAL,SHAR,ROTL,ROTR,ROTCL,ROTCR,SHAD,SHLD -> {
                read.add("R"+n);write.add("R"+n);resources.add(new ResourceUse("SHIFT",1,1));
                if(i.operation()==Sh2aDecoder.Operation.SHAD||i.operation()==Sh2aDecoder.Operation.SHLD)read.add("R"+m);
                else {write.add("T");if(i.operation()==Sh2aDecoder.Operation.ROTCL||i.operation()==Sh2aDecoder.Operation.ROTCR)read.add("T");}
            }
            case MOV_LOAD,MOV_UNSIGNED_LOAD,MOV_DISP12_LOAD,MOV_PC,MOV_REV_LOAD,MOV_INDEX_LOAD,MOV_GBR_LOAD -> {
                if(i.operation()==Sh2aDecoder.Operation.MOV_GBR_LOAD)read.add("GBR");
                else if(i.operation()!=Sh2aDecoder.Operation.MOV_PC)read.add("R"+m);
                if(i.operation()==Sh2aDecoder.Operation.MOV_INDEX_LOAD)read.add("R0");
                read.add("MEMORY");write.add("R"+n);
                if((i.postIncrement()&&m!=n)||(i.operation()==Sh2aDecoder.Operation.MOV_REV_LOAD&&m!=0))write.add("R"+m);
                latency=2;result=3;cpu=3;resources.add(new ResourceUse("MA",2,1));
            }
            case MOV_STORE,MOV_DISP12_STORE,MOV_REV_STORE,MOV_INDEX_STORE,MOV_GBR_STORE -> {
                if(i.operation()==Sh2aDecoder.Operation.MOV_GBR_STORE)read.add("GBR");else read.add("R"+n);
                read.add("R"+m);if(i.operation()==Sh2aDecoder.Operation.MOV_INDEX_STORE)read.add("R0");
                write.add("MEMORY");latency=0;result=2;cpu=2;
                if(i.preDecrement()||i.operation()==Sh2aDecoder.Operation.MOV_REV_STORE){write.add("R"+n);registerLatencies.put("R"+n,1);}
                resources.add(new ResourceUse("MA",2,1));
            }
            case FPU_MEM_LOAD -> {
                if(fpscr==null)return null;boolean pair=(fpscr&FpuSemantics.SZ)!=0;
                fp=true;read.add("R"+m);if(i.width()==2&&i.imm()==-1)read.add("R0");read.add("MEMORY");write.add("FR"+n);
                if(i.postIncrement()){write.add("R"+m);registerLatencies.put("R"+m,1);}
                latency=2;result=pair?4:3;cpu=pair?3:2;states=pair?2:1;
                if(pair){write.add("FR"+(n+1));registerLatencies.put("FR"+(n+1),3);}
                resources.add(new ResourceUse("FP_LS",1,states));resources.add(new ResourceUse("MA",2,states));
            }
            case FPU_MEM_STORE -> {
                if(fpscr==null)return null;boolean pair=(fpscr&FpuSemantics.SZ)!=0;
                fp=true;read.add("R"+n);if(i.width()==2&&i.imm()==-1)read.add("R0");read.add("FR"+m);write.add("MEMORY");
                if(i.preDecrement()){write.add("R"+n);registerLatencies.put("R"+n,1);}
                latency=0;result=pair?3:2;cpu=result;states=pair?2:1;if(pair){read.add("FR"+(m+1));doubleReads.add("FR"+m);}
                resources.add(new ResourceUse("FP_LS",1,states));resources.add(new ResourceUse("MA",2,states));
            }

            case MOV_REG -> {read.add("R"+m);write.add("R"+n);latency=0;zero=true;}
            case MOV_IMM,MOVI20,MOVI20S,MOVA -> {write.add("R"+n);}
            case LDS_PR -> {read.add("R"+n);write.add("PR");}
            case STS_PR -> {read.add("PR");write.add("R"+n);}
            case LDS_L_PR -> {
                read.addAll(Set.of("R"+n,"MEMORY"));write.addAll(Set.of("R"+n,"PR"));
                latency=2;result=3;cpu=3;resources.add(new ResourceUse("MA",2,1));
            }
            case STS_L_PR -> {
                read.addAll(Set.of("R"+n,"PR"));write.addAll(Set.of("R"+n,"MEMORY"));
                latency=1;result=2;cpu=2;registerLatencies.put("MEMORY",0);resources.add(new ResourceUse("MA",2,1));
            }
            case SYS_REG_TRANSFER -> {
                if(m==8||m==9||m==10||m==13){
                    resources.add(new ResourceUse("SR_SEQUENCE",0,1));
                    if(m==9||m==10){
                        read.add("R"+n);write.addAll(Set.of("SR","T","Q","M","CS"));
                        latency=m==9?2:4;result=m==9?3:5;cpu=result;states=result;
                        if(m==10){read.add("MEMORY");write.add("R"+n);resources.add(new ResourceUse("MA",2,1));}
                    }else {
                        read.addAll(Set.of("SR","T","Q","M","CS"));latency=2;result=m==8?2:3;cpu=result;states=2;
                        if(m==8)write.add("R"+n);
                        else {read.add("R"+n);write.addAll(Set.of("R"+n,"MEMORY"));registerLatencies.put("MEMORY",0);resources.add(new ResourceUse("MA",3,1));}
                    }
                    break;
                }
                String system=switch(m){case 1,5,11,14->"GBR";case 2,6,12,15->"VBR";case 3,7->"TBR";default->null;};
                if(system==null)return null;
                if(m<4){read.add(system);write.add("R"+n);}
                else if(m<8){read.add("R"+n);write.add(system);}
                else {
                    read.add("R"+n);write.add("R"+n);resources.add(new ResourceUse("MA",2,1));
                    if(m<13){read.add("MEMORY");write.add(system);latency=2;result=3;cpu=3;}
                    else {read.add(system);write.add("MEMORY");latency=1;result=2;cpu=2;registerLatencies.put("MEMORY",0);}
                }
            }
            case ADD_IMM -> {read.add("R"+n);write.add("R"+n);}
            case ADD_REG,SUB_REG,AND_REG,OR_REG,XOR_REG -> {read.add("R"+n);read.add("R"+m);write.add("R"+n);}
            case CMP_EQ_REG,CMP_HS,CMP_GE,CMP_HI,CMP_GT,CMP_STR,TST_REG -> {read.add("R"+n);read.add("R"+m);write.add("T");}
            case CMP_EQ_IMM,TST_IMM -> {read.add("R0");write.add("T");}
            case CMP_PL,CMP_PZ -> {read.add("R"+n);write.add("T");}
            case CLRT,SETT -> write.add("T");
            case MOVT,MOVT_INV -> {read.add("T");write.add("R"+n);}
            case NOTT -> {read.add("T");write.add("T");}
            case SHLL2,SHLR2,SHLL8,SHLR8,SHLL16,SHLR16 -> {
                read.add("R"+n);write.add("R"+n);resources.add(new ResourceUse("SHIFT",1,1));
            }
            case FPU_ARITHMETIC,FPU_FMAC,FPU_SQRT,FPU_CONVERT,FPU_COMPARE -> {
                if(fpscr==null)return null;
                fp=true;arith=true;boolean pair=(fpscr&FpuSemantics.PR)!=0;
                div=name.equals("FDIV")||name.equals("FSQRT");
                dbl=pair&&(name.equals("FADD")||name.equals("FSUB")||name.equals("FMUL"));
                if(name.equals("FLOAT")||name.equals("FCNVSD"))read.add("FPUL");
                else {read.add("FR"+n);if(pair)read.add("FR"+(n+1));}
                if(i.operation()==Sh2aDecoder.Operation.FPU_ARITHMETIC||i.operation()==Sh2aDecoder.Operation.FPU_COMPARE||i.operation()==Sh2aDecoder.Operation.FPU_FMAC) {
                    read.add("FR"+m);if(pair)read.add("FR"+(m+1));
                }
                if(i.operation()==Sh2aDecoder.Operation.FPU_FMAC)read.add("FR0");
                if(i.operation()==Sh2aDecoder.Operation.FPU_COMPARE)write.add("T");
                else if(name.equals("FTRC")||name.equals("FCNVDS"))write.add("FPUL");
                else {write.add("FR"+n);if(pair)write.add("FR"+(n+1));}
                if(div) {
                    int init=pair?2:1,ed=name.equals("FDIV")?(pair?18:8):(pair?17:7),back=pair?3:1;
                    resources.add(new ResourceUse("E1",1,init));resources.add(new ResourceUse("ED",1+init,ed));
                    resources.add(new ResourceUse("E1",1+init+ed,back));
                    latency=init+ed+back+2;result=latency;
                } else {
                    int e1=dbl?6:pair?2:1;
                    resources.add(new ResourceUse("E1",1,e1));
                    latency=e1+(i.operation()==Sh2aDecoder.Operation.FPU_COMPARE?1:2);result=latency;
                }
                if(pair)for(String r:read)if(r.startsWith("FR")&&(Integer.parseInt(r.substring(2))&1)==0&&read.contains("FR"+(Integer.parseInt(r.substring(2))+1)))doubleReads.add(r);
                if(dbl)hold=2;
            }
            case FPU_REG_MOVE,FPU_IMMEDIATE,FPU_SIGN -> {
                if(fpscr==null)return null;fp=true;zero=true;latency=0;result=3;
                boolean pair=i.operation()==Sh2aDecoder.Operation.FPU_REG_MOVE&&(fpscr&FpuSemantics.SZ)!=0&&!name.equals("FLDS")&&!name.equals("FSTS");
                if(name.equals("FSTS"))read.add("FPUL");
                else if(i.operation()!=Sh2aDecoder.Operation.FPU_IMMEDIATE){read.add("FR"+(name.equals("FLDS")||i.operation()==Sh2aDecoder.Operation.FPU_SIGN?n:m));if(pair)read.add("FR"+(m+1));}
                if(name.equals("FLDS"))write.add("FPUL");else {write.add("FR"+n);if(pair)write.add("FR"+(n+1));}
                if(pair){doubleReads.add("FR"+m);zero=false;latency=1;result=4;cpu=2;states=2;}
                resources.add(new ResourceUse("FP_LS",1,pair?2:1));
            }
            case FPU_REGISTER_TRANSFER -> {
                fp=true;fpscrAccess=m==0||m==2||m==4||m==6;cpu=2;
                if(m<4){
                    latency=m==2?3:m==3?1:2;result=m>=2?3:2;
                    if(m==0||m==1){read.add(m==0?"FPSCR":"FPUL");write.add("R"+n);resources.add(new ResourceUse("READ_BUS",1,1));}
                    else {read.add("R"+n);write.add(m==2?"FPSCR":"FPUL");resources.add(new ResourceUse("CPU_TO_FP",1,1));}
                } else {
                    read.add("R"+n);write.add("R"+n);resources.add(new ResourceUse("MA",2,1));
                    if(m==4||m==5){read.add(m==4?"FPSCR":"FPUL");write.add("MEMORY");latency=m==4?1:2;result=2;registerLatencies.put("MEMORY",0);}
                    else {read.add("MEMORY");write.add(m==6?"FPSCR":"FPUL");latency=m==6?3:2;result=3;}
                }
                if(m==0||m==4)read.add("SZ");
                if(m==2||m==6)write.add("SZ");
                resources.add(new ResourceUse("FP_LS",1,1));
            }
            case FPU_MODE -> {fp=true;zero=true;latency=0;result=3;read.add("SZ");write.add("SZ");resources.add(new ResourceUse("FP_LS",1,1));}
            default -> {return null;}
        }
        if(fp&&i.operation()!=Sh2aDecoder.Operation.FPU_MODE)read.add("FPSCR");
        if(i.operation()==Sh2aDecoder.Operation.FPU_MEM_LOAD||i.operation()==Sh2aDecoder.Operation.FPU_MEM_STORE||i.operation()==Sh2aDecoder.Operation.FPU_REG_MOVE&&name.startsWith("FMOV"))read.add("SZ");
        if(i.operation()==Sh2aDecoder.Operation.FPU_COMPARE&&(fpscr&FpuSemantics.PR)!=0){cpu=2;states=2;}
        return new PipelineSpec(i.address(),i.width(),read,write,resources,latency,result,fp,arith,div,dbl,fpscrAccess,zero,cpu,states,hold,registerLatencies,doubleReads);
    }

    static boolean interrupt(Kind k) {return switch(k){case NMI,USER_BREAK,IRQ,MEMORY_ERROR,SOFTWARE,PERIPHERAL->true;default->false;};}
    static boolean barredInSlot(Kind k) {return interrupt(k)||k==Kind.CPU_ADDRESS||k==Kind.DMAC_ADDRESS||k==Kind.FPU||k==Kind.BANK_OVERFLOW;}
    private static int group(Kind k) {return switch(k){
        case POWER_ON_RESET->0;case CPU_ADDRESS->1;case DMAC_ADDRESS->2;case FPU->3;
        case DIV_ZERO->4;case DIV_OVERFLOW->5;case BANK_UNDERFLOW->6;case BANK_OVERFLOW->7;
        case NMI,USER_BREAK,IRQ,MEMORY_ERROR,SOFTWARE,PERIPHERAL->8;
        case TRAPA->9;case GENERAL_ILLEGAL->10;case SLOT_ILLEGAL->11;
    };}
    private static final Comparator<Event> ORDER=Comparator.comparingInt((Event e)->group(e.kind()))
            .thenComparingInt(e->interrupt(e.kind())?-e.level():0)
            // Target default priority, table8.4: lower vector first at equal level.
            .thenComparingInt(Event::vectorOffset);
    public static Decision select(List<Event> pending,Integer mask,Boundary boundary) {
        List<Event> eligible=new ArrayList<>();boolean barred=false,unknownMask=false,waiting=false;
        for(Event e:pending) {
            if(e.availability()==Availability.AFTER_ISSUE)continue;
            if(boundary.delaySlot()&&barredInSlot(e.kind())){barred=true;continue;}
            boolean canCancel=boundary.cancellableDivision()&&(interrupt(e.kind())||e.kind()==Kind.CPU_ADDRESS||e.kind()==Kind.DMAC_ADDRESS);
            if(!boundary.instructionCompleted()&&e.kind()!=Kind.POWER_ON_RESET&&!canCancel){waiting=true;continue;}
            if(interrupt(e.kind())&&e.kind()!=Kind.NMI) {
                if(e.level()==0)continue;
                if(mask==null){unknownMask=true;eligible.add(e);continue;}
                if(e.level()<=mask)continue;
            }
            eligible.add(e);
        }
        eligible.sort(ORDER);
        if(eligible.isEmpty())return new Decision(barred?Status.DEFERRED_SLOT:waiting?Status.WAIT_COMPLETION:Status.NONE,null,List.of());
        Event winner=eligible.getFirst();
        if(winner.availability()==Availability.PIPELINE_UNVERIFIED)return new Decision(Status.UNVERIFIED_TIMING,null,eligible);
        if(unknownMask&&interrupt(winner.kind())&&winner.kind()!=Kind.NMI)return new Decision(Status.UNKNOWN_MASK,null,eligible);
        return new Decision(Status.ACCEPT,winner,eligible);
    }
    static Integer savedPc(Event event,int acceptedId) {
        return switch(event.kind()) {
            case POWER_ON_RESET -> null;
            case DIV_ZERO,DIV_OVERFLOW,BANK_UNDERFLOW,GENERAL_ILLEGAL -> event.generatorPc();
            case SLOT_ILLEGAL -> event.savedPcContext();
            case TRAPA -> event.savedPcContext()!=null?event.savedPcContext():event.generatorPc()==null?null:event.generatorPc()+2;
            default -> acceptedId;
        };
    }
    static Kind synchronous(int vector) {return switch(vector){case 0x10->Kind.GENERAL_ILLEGAL;case 0x18->Kind.SLOT_ILLEGAL;
        case 0x24->Kind.CPU_ADDRESS;case 0x28->Kind.DMAC_ADDRESS;case 0x34->Kind.FPU;case 0x3c->Kind.BANK_OVERFLOW;
        case 0x40->Kind.BANK_UNDERFLOW;case 0x44->Kind.DIV_ZERO;case 0x48->Kind.DIV_OVERFLOW;
        default->{if(vector>=0x80&&vector<=0xfc)yield Kind.TRAPA;throw new IllegalArgumentException("target reserved vector "+vector);}};}
}
