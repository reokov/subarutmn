package ecu.independent;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/** Address-independent research candidates; NO automated XML name transfers. */
public final class CompareMain {
    public static void main(String[] args) throws Exception {
        if(args.length!=3) throw new IllegalArgumentException(
            "Usage: CompareMain source.bin target.bin output_directory");
        byte[] source=Files.readAllBytes(Path.of(args[0]));
        byte[] target=Files.readAllBytes(Path.of(args[1]));
        FirmwareGraph analyzer=new FirmwareGraph();
        var src=analyzer.analyze(source,250_000);
        var dst=analyzer.analyze(target,250_000);
        var pairs=new StructuralMatcher().uniqueWindows(src,dst,8);
        Path out=Path.of(args[2]);Files.createDirectories(out);
        String prefix=ReportWriter.romId(source)+"_"+ReportWriter.hash(source).substring(0,16)+"_"+
                ReportWriter.romId(target)+"_"+ReportWriter.hash(target).substring(0,16)+"_";
        String file=prefix+"structural_candidates.csv";
        Path csv=out.resolve(file);
        int index=1;
        while(Files.exists(csv)) csv=out.resolve(prefix+"structural_candidates_"+(index++)+".csv");
        StringBuilder text=new StringBuilder("source_address,target_address,instructions,status,signature\n");
        for(var c:pairs) text.append(String.format("0x%08X,0x%08X,%d,%s,%s%n",
                c.source(),c.target(),c.instructionCount(),c.status(),c.fingerprint()));
        Files.writeString(csv,text,StandardCharsets.UTF_8);
        System.out.println(csv+"; candidates="+pairs.size()+
            "; NO SEMANTIC OR CALIBRATION IDENTITY CLAIMED");
    }
}
