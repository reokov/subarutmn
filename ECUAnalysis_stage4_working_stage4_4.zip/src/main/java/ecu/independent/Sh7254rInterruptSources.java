package ecu.independent;

import java.util.ArrayList;
import java.util.List;

/**
 * VERIFIED PARTIAL static source/vector inventory, not evidence that any
 * source is enabled or fired in a particular ROM. Renesas R01UH0480EJ0400
 * Rev.4.00, table 8.4 pp.143-145 and tables 8.2/8.3. No heuristic scanning.
 */
public final class Sh7254rInterruptSources {
    public record Source(String name,int vector,int fixedPriority,
                         int priorityRegister,int priorityNibble) {}
    private Sh7254rInterruptSources() {}
    public static List<Source> known() {
        List<Source> sources=new ArrayList<>();
        sources.add(new Source("NMI",11,16,0,-1));
        for(int i=0;i<8;i++)sources.add(new Source("IRQ"+i,64+i,-1,
                0xFFFE0818+2*(i/4),3-(i%4)));
        for(int i=1;i<=15;i++)sources.add(new Source("SINT"+i,108-i,i,0,-1));
        for(int i=0;i<8;i++)sources.add(new Source("DMAC"+i+"_DEI",108+i*4,-1,
                0xFFFE0C00+2*(i/4),3-(i%4)));
        sources.add(new Source("CMT_CMI0",140,-1,0xFFFE0C04,3));
        sources.add(new Source("CMT_CMI1",144,-1,0xFFFE0C04,2));
        sources.add(new Source("WDT_ITI",148,-1,0xFFFE0C04,0));
        return List.copyOf(sources);
    }
}
