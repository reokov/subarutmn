package ecu.independent;

import java.util.*;

/** Bounded constant propagation state. Null means UNKNOWN, NEVER zero. */
final class AbstractCpu {
    final Integer[] r = new Integer[16];
    Integer pc; // Architectural instruction address; successor routing updates it.
    boolean sleepRequested;
    String cpuFault; // No fabricated retirement after an unresolved CPU access fault.
    Integer faultAddress;
    final List<SystemExceptionModel.Event> systemPending=new ArrayList<>();
    long nextSystemEventId;
    Integer lastRetiredPc,lastResumePc;
    Integer inFlightPc;
    boolean inFlightDivision;
    Map<Integer,Integer> fpuCompletionBeforePc=Map.of(); // Explicit synthetic/observed input, NOT an inferred latency.
    SystemExceptionModel.FpuResult deferredFpuResult;
    SystemExceptionModel.Pipeline pipeline; // Explicit no-wait execution profile; null for untimed abstract analysis.
    int irqMaskChangeWindow; // Rev4 §3.10.4: acceptance MAY be delayed through next five instructions.
    SystemExceptionModel.Event queueSystem(SystemExceptionModel.Kind kind,Integer generator,Integer data,int vector,int level,String source,SystemExceptionModel.Availability availability) {
        var event=new SystemExceptionModel.Event(++nextSystemEventId,kind,generator,data,vector,level,source,availability);
        systemPending.add(event);return event;
    }
    Integer pr;
    Integer gbr, vbr, tbr;
    Integer mach, macl;
    // SH-2A status register bits relevant to iterative division.
    // Null is unknown; these are not inferred from SR.T alone.
    Boolean q, m, saturation;
    Integer sr;
    Integer interruptMask; // reset I[3:0]=0b1111, remaining SR bits mostly unknown
    Boolean bankOverflow;
    Integer nextBank; // SH7254R IBNR.BN3:0; null if path-join conflicts
    Integer bankEnable; // IBNR.BE=00 reset
    Integer bankPriorityMask; // IBCR reset
    Boolean bankOverflowException;
    // SH7254R STBCR.MSTP1 (R01UH0480EJ0400 §29.3.1): once 1, FPU clock halts irreversibly
    // except by power-on reset; §7.6.1/§7.6.4 make an FPU instruction in this state undefined
    // (illegal). null=UNKNOWN (path-join conflict / after unresolved call), FALSE=running
    // (STBCR resets to H'0000 => MSTP1=0 => FPU runs), TRUE=FPU module standby.
    // The only architectural clears are a power-on reset (modelled by the reset constructor) and
    // hardware standby mode (txt 64875-64876); entering hardware standby is NOT modelled here -
    // SLEEP/STOP halt the path with SLEEP_OR_STOP_REQUIRES_INTERRUPT_MODEL - so within the
    // modelled event space no transition may take TRUE back to FALSE or UNKNOWN.
    Boolean fpuStandby;
    // STBCR.MSTP4/MSTP3/MSTP2/MSTP0 - the module-stop bits OTHER than bit 1, kept in their
    // natural bit positions (mask 0x1D): JTAG TAP reset (bit 4), DMAC clock (bit 3), AUD-II
    // clock (bit 2), UBC clock (bit 0) - R01UH0480EJ0400 §29.3.1 txt 64917-64975. This exists
    // only so that a READ of STBCR can tell WHICH bits it knows instead of inventing H'0000:
    // null = UNKNOWN (reset not yet reached in this abstract state, an unresolved call, a path
    // join, or a write with an unknown data value), otherwise the proven bit values. The reset
    // value is H'0000 (txt 64874-64876) => all zero, and a key-correct word write with a KNOWN
    // value establishes them again. Bits 15:8 (STBCRKEY) and 7:5 (reserved) are NOT stored here:
    // they always read H'00 / 0 (txt 64882-64883, 64914-64916), so they are constants in the
    // read path. No general symbolic-bit machinery is introduced for this one register.
    Integer stbcrOtherMstp;
    final Map<Integer, Integer> bankCells = new HashMap<>(); // 15 banks x 20 slots, unknown when absent
    final Deque<Integer> savedBanks = new ArrayDeque<>();
    final Map<Integer,Integer> intcPriorities = new HashMap<>();
    final Integer[] softwareInterrupts = new Integer[15];
    int softwareClearRequested,softwareClearRead; // HW8.6.1: dummy-read proof before RTE; no fabricated countdown.
    // An unmodelled peripheral write may affect RAM/IRQ/clocks immediately.
    // No successor can be claimed sound after such a side effect.
    boolean unmodeledPeripheralWrite;
    Integer fpul, fpscr;
    final Integer[] fr = new Integer[16];
    Boolean cs;
    Boolean t;
    // Numerical FPU event awaiting CPU report/acceptance. Hardware7.7/table7.10
    // bars the delay slot itself; AFTER_SLOT keeps provenance until target ID,
    // without inserting an unproved additional target-instruction delay.
    static final int FPU_PENDING=1, FPU_PENDING_AFTER_SLOT=2;
    Integer fpuExceptionPending;
    // Only observed known SRAM byte values are tracked, not a fictitious zeroed RAM.
    final Map<Integer, Byte> ram = new HashMap<>();
    final Map<Integer, Integer> ramWriters = new HashMap<>();
    AbstractCpu(int resetSp) {
        r[15] = resetSp;
        vbr = 0;
        interruptMask=15; bankOverflow=false; nextBank=0; bankEnable=0;
        bankPriorityMask=0; bankOverflowException=false;
        // STBCR resets to H'0000 (§29.3.1 txt 64875): MSTP1=0 => FPU clock runs => not standby.
        fpuStandby=false;
        // Same reset value covers the other module-stop bits: MSTP4/3/2/0 = 0 (txt 64874-64876).
        stbcrOtherMstp=0;
        // Software Manual REJ09B0051 Rev.3.00 sec.2.2.2 p.5 / Rev.4.00 R01US0031JJ0400
        // sec.2.2.7 table 2.1 (p.2-7): at reset I=1111, BO=0, CS=0; T,S,Q,M undefined.
        cs=false;
        Sh7254rIntcMmio.initializeReset(this);
        // FPSCR initial value H'00040001: REJ09B0051 sec.2.2.5 (rev.3.00 p.8, rev.4.00 p.2-7).
        fpscr = 0x00040001;
    }
    AbstractCpu() {}
    /**
     * State at a return site whose callee was never analyzed (unresolved JSR/BSR target).
     * An arbitrary ROM body may modify any register, FP state, bank state and RAM, and the
     * SH-2A ISA defines no register-preservation contract for unknown code, so nothing is
     * assumed preserved: every tracked value is UNKNOWN (null) and observed RAM facts are
     * dropped. The path itself stays alive as a conditional hypothesis; only knowledge dies.
     * One fact survives, because it is not knowledge about a register but a hardware one-way
     * transition: STBCR.MSTP1 cannot be cleared by any software write, only by a power-on reset
     * (R01UH0480EJ0400 Rev.4.00 §29.3.1 txt 64960-64967). An opaque callee can only execute
     * software, so it can never end FPU module standby: a proven TRUE is retained (fix #14,
     * previously lost to null, which erased the H'10/H'18 routing after any unresolved call).
     * A non-standby state stays UNKNOWN, since the same callee may set MSTP1 itself.
     * The pending FPU exception flag is a hardware latch (fix #19): an opaque callee cannot
     * clear it - it may only have accepted the exception somewhere in its unmodeled body, which
     * the model cannot exclude, so keeping the flag preserves every possible handler entry
     * (sound union).
     * STBCR.MSTP4/3/2/0 carry no such guarantee and become UNKNOWN (null): an opaque callee may
     * write any of them with the key H'3C (§29.3.1 txt 64878-64880), in either direction.
     */
    AbstractCpu opaqueAfterUnknownCall() {
        AbstractCpu opaque = new AbstractCpu();
        opaque.fpuStandby = Boolean.TRUE.equals(fpuStandby) ? Boolean.TRUE : null;
        opaque.fpuExceptionPending = fpuExceptionPending;
        opaque.nextSystemEventId=nextSystemEventId;
        for(var e:systemPending)opaque.systemPending.add(new SystemExceptionModel.Event(e.id(),e.kind(),e.generatorPc(),e.dataAddress(),e.vectorOffset(),e.level(),e.source(),SystemExceptionModel.Availability.PIPELINE_UNVERIFIED,e.savedPcContext()));
        return opaque;
    }
    /** SH2A SR only has these writable architectural bits (Software Manual sec 2.2.2). */
    static final int SR_MASK = 0x000063F3;
    void writeSr(Integer value) {
        sr=value==null?null:value & SR_MASK;
        if(value == null) {
            t=q=m=saturation=cs=bankOverflow=null;
            interruptMask=null;
            return;
        }
        t=(value&1)!=0;
        saturation=(value&2)!=0;
        interruptMask=(value>>>4)&15;
        q=(value&0x100)!=0;
        m=(value&0x200)!=0;
        cs=(value&0x2000)!=0;
        bankOverflow=(value&0x4000)!=0;
    }
    /** Construct SR only when every architecturally significant bit is known. */
    Integer readSr() {
        if (t==null || q==null || m==null || saturation==null || cs==null ||
                bankOverflow==null || interruptMask==null) return null;
        return (t?1:0)|(saturation?2:0)|(interruptMask<<4)|(q?0x100:0)|
                (m?0x200:0)|(cs?0x2000:0)|(bankOverflow?0x4000:0);
    }
    /** Entry address must have zero upper 16 bits and 2 low alignment bits. */
    Integer readBank(Integer address) {
        if(address == null || (address&0xFFFF0003)!=0) return null;
        int bank=(address>>>7)&0x1FF, entry=(address>>>2)&31;
        if(bank>=15 || entry>=20) return null;
        return bankCells.get(bank*20+entry);
    }
    boolean writeBank(Integer address,Integer value) {
        if(address==null || (address&0xFFFF0003)!=0) return false;
        int bank=(address>>>7)&0x1FF,entry=(address>>>2)&31;
        if(bank>=15 || entry>=20) return false;
        int key=bank*20+entry;
        if(value==null)bankCells.remove(key);else bankCells.put(key,value);
        return true;
    }
    void saveBank(int vectorOffset) {
        if(nextBank==null || nextBank>=15) throw new IllegalStateException("BANK_OVERFLOW_REQUIRES_STACK_OR_EXCEPTION");
        int b=nextBank++;
        for(int i=0;i<15;i++) writeBank((b<<7)|(i<<2),r[i]);
        writeBank((b<<7)|(15<<2),mach);
        writeBank((b<<7)|(16<<2),vectorOffset);
        writeBank((b<<7)|(17<<2),pr);
        writeBank((b<<7)|(18<<2),gbr);
        writeBank((b<<7)|(19<<2),macl);
        savedBanks.addLast(b);
    }
    boolean restoreBank() {
        if(nextBank==null || nextBank<=0 || nextBank>15) return false;
        int b=nextBank-1;
        if(!savedBanks.isEmpty() && savedBanks.peekLast()==b) savedBanks.removeLast();
        nextBank=b;
        for(int i=0;i<15;i++)r[i]=readBank((b<<7)|(i<<2));
        mach=readBank((b<<7)|(15<<2));
        pr=readBank((b<<7)|(17<<2));
        gbr=readBank((b<<7)|(18<<2));
        macl=readBank((b<<7)|(19<<2));
        return true;
    }
    /** SH2A-FPU FPSCR write mask. Renesas REJ09B0051-0300 Rev.3.00 sec. 2.2.5
     * pp.8-9 (initial value H'00040001): bit 22 = QIS, SZ = 20, PR = 19,
     * DN = 18 (always 1), Cause = 17..12, Enable = 11..7, Flag = 6..2, RM = 1..0.
     * Bits 21 and 23..31 are reserved and read as zero. A null write stays unknown.
     */
    void writeFpscr(Integer value) {
        fpscr=value==null?null:(value & 0x005BFFFF) | 0x00040000;
    }
    /** Discard uncommitted instruction effects after an access fault. */
    void restoreFaultState(AbstractCpu before) {
        System.arraycopy(before.r,0,r,0,16);System.arraycopy(before.fr,0,fr,0,16);
        System.arraycopy(before.softwareInterrupts,0,softwareInterrupts,0,15);
        softwareClearRequested=before.softwareClearRequested;softwareClearRead=before.softwareClearRead;
        pc=before.pc;
        sleepRequested=before.sleepRequested;
        cpuFault=before.cpuFault;
        faultAddress=before.faultAddress;
        pr=before.pr;
        gbr=before.gbr;
        vbr=before.vbr;
        tbr=before.tbr;
        mach=before.mach;
        macl=before.macl;
        q=before.q;
        m=before.m;
        saturation=before.saturation;
        sr=before.sr;
        interruptMask=before.interruptMask;
        bankOverflow=before.bankOverflow;
        nextBank=before.nextBank;
        bankEnable=before.bankEnable;
        bankPriorityMask=before.bankPriorityMask;
        bankOverflowException=before.bankOverflowException;
        fpuStandby=before.fpuStandby;
        stbcrOtherMstp=before.stbcrOtherMstp;
        unmodeledPeripheralWrite=before.unmodeledPeripheralWrite;
        fpul=before.fpul;
        fpscr=before.fpscr;
        cs=before.cs;
        t=before.t;
        fpuExceptionPending=before.fpuExceptionPending;
        nextSystemEventId=before.nextSystemEventId;
        lastRetiredPc=before.lastRetiredPc;
        lastResumePc=before.lastResumePc;
        inFlightPc=before.inFlightPc;inFlightDivision=before.inFlightDivision;
        pipeline=before.pipeline==null?null:before.pipeline.copy();
        fpuCompletionBeforePc=before.fpuCompletionBeforePc;deferredFpuResult=before.deferredFpuResult;
        irqMaskChangeWindow=before.irqMaskChangeWindow;
        bankCells.clear();bankCells.putAll(before.bankCells);
        intcPriorities.clear();intcPriorities.putAll(before.intcPriorities);
        ram.clear();ram.putAll(before.ram);
        ramWriters.clear();ramWriters.putAll(before.ramWriters);
        savedBanks.clear();savedBanks.addAll(before.savedBanks);
        systemPending.clear();systemPending.addAll(before.systemPending);
    }
    AbstractCpu copy() {
        AbstractCpu next = new AbstractCpu();
        System.arraycopy(r,0,next.r,0,16);
        System.arraycopy(fr,0,next.fr,0,16);
        next.softwareClearRequested=softwareClearRequested;next.softwareClearRead=softwareClearRead;
        next.sleepRequested=sleepRequested;
        next.pc=pc; next.cpuFault=cpuFault; next.faultAddress=faultAddress;
        next.systemPending.addAll(systemPending);next.nextSystemEventId=nextSystemEventId;
        next.lastRetiredPc=lastRetiredPc;next.lastResumePc=lastResumePc;next.irqMaskChangeWindow=irqMaskChangeWindow;
        next.inFlightPc=inFlightPc;next.inFlightDivision=inFlightDivision;
        next.pipeline=pipeline==null?null:pipeline.copy();
        next.fpuCompletionBeforePc=fpuCompletionBeforePc;next.deferredFpuResult=deferredFpuResult;
        next.pr=pr; next.t=t; next.gbr=gbr;next.vbr=vbr;next.tbr=tbr;next.cs=cs;
        next.mach=mach;next.macl=macl;next.q=q;next.m=m;next.saturation=saturation;
        next.sr=sr;next.interruptMask=interruptMask;next.bankOverflow=bankOverflow;
        next.nextBank=nextBank;next.bankEnable=bankEnable;next.bankPriorityMask=bankPriorityMask;
        next.bankOverflowException=bankOverflowException;
        next.fpuStandby=fpuStandby;
        next.stbcrOtherMstp=stbcrOtherMstp;
        next.bankCells.putAll(bankCells);next.savedBanks.addAll(savedBanks);
        next.intcPriorities.putAll(intcPriorities);
        System.arraycopy(softwareInterrupts,0,next.softwareInterrupts,0,15);
        next.unmodeledPeripheralWrite=unmodeledPeripheralWrite;
        next.fpul=fpul;next.fpscr=fpscr;
        next.fpuExceptionPending=fpuExceptionPending;
        next.ram.putAll(ram); next.ramWriters.putAll(ramWriters);
        return next;
    }
    /** Join states: retain only values known AND identical on every path. */
    boolean joinFrom(AbstractCpu other) {
        boolean changed = false;
        if(!Objects.equals(pipeline==null?null:pipeline.key(),other.pipeline==null?null:other.pipeline.key()))
            throw new IllegalArgumentException("pipeline contexts must be partitioned");
        if(!Objects.equals(deferredFpuResult,other.deferredFpuResult))throw new IllegalArgumentException("FPU completion contexts must be partitioned");
        if(!Objects.equals(inFlightPc,other.inFlightPc)||inFlightDivision!=other.inFlightDivision)
            throw new IllegalArgumentException("in-flight contexts must not join");
        if(!Objects.equals(lastRetiredPc,other.lastRetiredPc)&&lastRetiredPc!=null){lastRetiredPc=null;changed=true;}
        if(!Objects.equals(lastResumePc,other.lastResumePc)&&lastResumePc!=null){lastResumePc=null;changed=true;}
        // Graph keys partition distinct pending sets; never turn MAYBE into a certain event.
        if(!systemPending.equals(other.systemPending))throw new IllegalArgumentException("pending contexts must be partitioned");
        nextSystemEventId=Math.max(nextSystemEventId,other.nextSystemEventId);
        if(!Objects.equals(pc,other.pc) && pc!=null) {pc=null;changed=true;}
        for(int i=0;i<16;i++) {
            if (!Objects.equals(r[i],other.r[i]) && r[i]!=null) { r[i]=null; changed=true; }
            if (!Objects.equals(fr[i],other.fr[i]) && fr[i]!=null) { fr[i]=null; changed=true; }
        }
        if (!Objects.equals(pr, other.pr) && pr != null) { pr=null; changed=true; }
        if (!Objects.equals(t, other.t) && t != null) { t=null; changed=true; }
        if (!Objects.equals(gbr, other.gbr) && gbr != null) {gbr=null;changed=true;}
        if (!Objects.equals(vbr, other.vbr) && vbr != null) {vbr=null;changed=true;}
        if (!Objects.equals(tbr, other.tbr) && tbr != null) {tbr=null;changed=true;}
        if (!Objects.equals(cs, other.cs) && cs != null) {cs=null;changed=true;}
        if (!Objects.equals(q,other.q) && q!=null) {q=null;changed=true;}
        if (!Objects.equals(m,other.m) && m!=null) {m=null;changed=true;}
        if (!Objects.equals(saturation,other.saturation) && saturation!=null) {saturation=null;changed=true;}
        if (!Objects.equals(sr,other.sr) && sr!=null) {sr=null;changed=true;}
        if (!Objects.equals(interruptMask,other.interruptMask) && interruptMask!=null) {interruptMask=null;changed=true;}
        if (!Objects.equals(bankOverflow,other.bankOverflow) && bankOverflow!=null) {bankOverflow=null;changed=true;}
        if (!Objects.equals(bankEnable,other.bankEnable) && bankEnable!=null) {bankEnable=null;changed=true;}
        if (!Objects.equals(bankPriorityMask,other.bankPriorityMask) && bankPriorityMask!=null) {bankPriorityMask=null;changed=true;}
        if (!Objects.equals(bankOverflowException,other.bankOverflowException) && bankOverflowException!=null) {bankOverflowException=null;changed=true;}
        // Join keeps TRUE only when every path is in standby. TRUE vs FALSE becomes UNKNOWN, and
        // that is NOT a loss of the irreversibility rule: MSTP1 is irreversible PER PATH, so a
        // join of a standby path and a running path honestly admits both (the running path can
        // still enter standby later, the standby path can never leave it).
        if (!Objects.equals(fpuStandby,other.fpuStandby) && fpuStandby!=null) {fpuStandby=null;changed=true;}
        // The other module-stop bits follow the same join rule as every other tracked value:
        // differing or unknown counterparts yield UNKNOWN, never a guessed bit pattern.
        if (!Objects.equals(stbcrOtherMstp,other.stbcrOtherMstp) && stbcrOtherMstp!=null)
            {stbcrOtherMstp=null;changed=true;}
        if (!Objects.equals(nextBank,other.nextBank) || !new ArrayList<>(savedBanks).equals(new ArrayList<>(other.savedBanks))) {
            if(nextBank!=null || !savedBanks.isEmpty()) changed=true;
            savedBanks.clear();
            nextBank=null;
        }
        if(Sh7254rIntcMmio.join(this,other))changed=true;
        if(other.unmodeledPeripheralWrite && !unmodeledPeripheralWrite) {
            unmodeledPeripheralWrite=true;changed=true;
        }
        for(var it=bankCells.entrySet().iterator();it.hasNext();) {
            var e=it.next();
            if(!Objects.equals(e.getValue(),other.bankCells.get(e.getKey()))) {it.remove();changed=true;}
        }
        if (!Objects.equals(mach,other.mach) && mach!=null) {mach=null;changed=true;}
        if (!Objects.equals(macl,other.macl) && macl!=null) {macl=null;changed=true;}
        if (!Objects.equals(fpul,other.fpul) && fpul!=null) {fpul=null;changed=true;}
        if (!Objects.equals(fpscr,other.fpscr) && fpscr!=null) {fpscr=null;changed=true;}
        // Pending FPU exception: sticky join - a possible exception is never discarded at a
        // join. Both paths barred (2) keep 2; any mix admitting an acceptance on at least one
        // path collapses to 1 (union of worlds); a proven pending on one side is retained
        // when the other side has none.
        if (!Objects.equals(fpuExceptionPending,other.fpuExceptionPending)) {
            if (fpuExceptionPending==null) fpuExceptionPending=other.fpuExceptionPending;
            else if (other.fpuExceptionPending!=null) fpuExceptionPending=FPU_PENDING;
            changed=true;
        }
        for (var it=ram.entrySet().iterator(); it.hasNext();) {
            var e=it.next();
            if (!Objects.equals(e.getValue(), other.ram.get(e.getKey()))) {it.remove();changed=true;}
        }
        for (var it=ramWriters.entrySet().iterator(); it.hasNext();) {
            var e=it.next();
            if (!Objects.equals(e.getValue(),other.ramWriters.get(e.getKey()))) {
                it.remove();changed=true;
            }
        }
        return changed;
    }
    void writeRam(int address, int bytes, Integer value, int writerPc) {
        long u = Integer.toUnsignedLong(address);
        if (u < Sh7254rMemoryMap.SRAM_START || u + bytes > Sh7254rMemoryMap.SRAM_END_EXCLUSIVE) return;
        // The physical SRAM range bounds this map; no arbitrary loss of known bytes.
        for (int i=0;i<bytes;i++) {
            int a=address+i;
            ramWriters.put(a,writerPc);
            if (value == null) ram.remove(a);
            else ram.put(a,(byte)(value >>> (8*(bytes-1-i))));
        }
    }
    Integer readRam(int address, int bytes) {
        long u = Integer.toUnsignedLong(address);
        if (u < Sh7254rMemoryMap.SRAM_START || u + bytes > Sh7254rMemoryMap.SRAM_END_EXCLUSIVE) return null;
        int result=0;
        for (int i=0;i<bytes;i++) {
            Byte b = ram.get(address+i);
            if (b==null) return null;
            result=result<<8 | (b&255);
        }
        return result;
    }
    Integer writerOf(int address,int bytes) {
        if (bytes<1) return null;
        Integer writer=ramWriters.get(address);
        if(writer==null) return null;
        for(int i=1;i<bytes;i++) {
            if(!Objects.equals(writer,ramWriters.get(address+i))) return null;
        }
        return writer;
    }
}
