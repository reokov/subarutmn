package ecu.independent;

import static ecu.independent.Sh2aDecoder.*;

/**
 * Additional Renesas SH-2A opcode families.
 * Instruction encodings: REJ09B0051-0300, sections 5.1.1-5.1.7.
 * Recognized-but-unverified instructions are opaque and STOP the graph traversal.
 * DO NOT turn them into NOP or assume a valid fallthrough.
 * No code or runtime dependency from SLEIGH, Ghidra, QEMU or GNU opcode tables.
 */
final class Sh2aOpcodeExtensions {
    private Sh2aOpcodeExtensions() {}
    static Instruction opaque(int pc,int encoding,int width,String name,boolean delay) {
        // A defined SH-2A-FPU opcode whose semantics this analyzer has not implemented:
        // valid encoding, NOT hardware-illegal, NOT executed. Halts traversal (no edge).
        return new Instruction(pc,width,encoding,name,Flow.UNKNOWN,null,delay,
                Status.UNSUPPORTED_IMPLEMENTATION,Operation.OPAQUE,-1,-1,0,0,null,false,false);
    }
    private static Instruction reg(int a,int w,String op,Operation operation,int n,int m) {
        return simple(a,w,op,Flow.NEXT,null,false,operation,n,m,0);
    }
    private static Instruction uni(int a,int w,String op,Operation operation,int n) {
        return reg(a,w,op+" R"+n,operation,n,-1);
    }
    static Instruction decode32(int a,int w,int second,int n,int m) {
        int packed = (w<<16)|second;
        int type = second>>>12;
        int displacement=second&0xFFF;
        // Renesas REJ09B0051-0300, section 6.3.15:
        // ALL disp12 FMOV variants use first halfword 0011nnnnmmmm0001.
        // The following halfword selects mode 0011 (store) or 0111 (load).
        // Displacement is scaled by FPSCR.SZ (4/8), so keep the RAW disp12.
        if ((w & 0xF00F) == 0x3001) {
            if (type == 7) return make(a,packed,4,"FMOV.S @(disp12,R"+m+"),FR"+n,
                    Flow.NEXT,null,false,Operation.FPU_MEM_LOAD,n,m,displacement,0,null,false,false);
            if (type == 3) return make(a,packed,4,"FMOV.S FR"+m+",@(disp12,R"+n+")",
                    Flow.NEXT,null,false,Operation.FPU_MEM_STORE,n,m,displacement,0,null,false,false);
            // RENESAS 5.3: 0011nnnnmmmm0001 + [operation nibble][disp12].
            // Register fields and base sense differ for LOAD and STORE.
            if(type>=0 && type<=2) {
                int width=1<<type;
                return make(a,packed,4,"MOV."+(width==1?"B":width==2?"W":"L")+
                        " R"+m+",@(disp12,R"+n+")",Flow.NEXT,null,false,
                        Operation.MOV_DISP12_STORE,n,m,displacement*width,width,null,false,false);
            }
            if(type>=4 && type<=6) {
                int width=1<<(type-4);
                return make(a,packed,4,"MOV."+(width==1?"B":width==2?"W":"L")+
                        " @(disp12,R"+m+"),R"+n,Flow.NEXT,null,false,
                        Operation.MOV_DISP12_LOAD,n,m,displacement*width,width,null,false,false);
            }
            if(type==8 || type==9) {
                int width=type==8?1:2;
                return make(a,packed,4,"MOVU."+(width==1?"B":"W")+
                        " @(disp12,R"+m+"),R"+n,Flow.NEXT,null,false,
                        Operation.MOV_UNSIGNED_LOAD,n,m,displacement*width,width,null,false,false);
            }
            return unknown(a,packed,4,"RESERVED_32BIT_DISP12_MODE");
        }
        if ((w & 0xF08F)==0x3009) {
            // Renesas 5.11: first halfword 0011nnnn0iii1001,
            // second halfword [operation nibble][disp12].
            String name=switch(type) {
                case 0 -> "BCLR.B"; case 1 -> "BSET.B"; case 2 -> "BST.B";
                case 3 -> "BLD.B"; case 4 -> "BAND.B"; case 5 -> "BOR.B";
                case 6 -> "BXOR.B";case 11 -> "BLDNOT.B";
                case 12 -> "BANDNOT.B";case 13 -> "BORNOT.B";
                default -> null;
            };
            if (name==null) return unknown(a,packed,4,"RESERVED_SH2A_MEMORY_BIT_OP");
            int bit=(w>>>4)&7;
            return make(a,packed,4,name+" #"+bit+",@(disp12,R"+n+")",
                    Flow.NEXT,null,false,Operation.BIT_MEMORY,n,type,(bit<<12)|displacement,
                    1,null,false,false);
        }
        return null;
    }
    static Instruction decode16(int a,int w,int n,int m) {
        int low = w&15;
        // New SH-2A control transfer opcodes (Software Manual section 5.1.5).
        if ((w&0xFF00)==0x8600 || (w&0xFF00)==0x8700) {
            int targetReg=(w>>>4)&15, bit=w&7;
            int action=(w>>>8)==0x86 ? ((w&8)==0?0:1) : ((w&8)==0?2:3);
            String name=switch(action){case 0->"BCLR";case 1->"BSET";
                case 2->"BST";default->"BLD";};
            return simple(a,w,name+" #"+bit+",R"+targetReg,Flow.NEXT,null,
                    false,Operation.BIT_REG,targetReg,action,bit);
        }
        if ((w&0xFF00)==0x8300) return simple(a,w,"JSR/N @@(disp8,TBR)",
                Flow.CALL,null,false,Operation.TBR_CALL,-1,-1,(w&255)*4);
        if ((w&0xF0FF)==0x007B) return simple(a,w,"RTV/N R"+n,
                Flow.RETURN,null,false,Operation.RTV_N,n,-1,0);
        if ((w&0xF0FF)==0x0039) return uni(a,w,"MOVRT",Operation.MOVT_INV,n);
        if (w==0x0068) return simple(a,w,"NOTT",Flow.NEXT,null,false,Operation.NOTT,-1,-1,0);
        // Stack multiple-register transfers: section 5.3 MOVML/MOVMU.
        if ((w&0xF0FF)==0x40F1) return uni(a,w,"MOVML.L PUSH THROUGH",Operation.MOVML_PUSH,n);
        if ((w&0xF0FF)==0x40F5) return uni(a,w,"MOVML.L POP THROUGH",Operation.MOVML_POP,n);
        if ((w&0xF0FF)==0x40F0) return uni(a,w,"MOVMU.L PUSH FROM",Operation.MOVMU_PUSH,n);
        if ((w&0xF0FF)==0x40F4) return uni(a,w,"MOVMU.L POP FROM",Operation.MOVMU_POP,n);
        // Addressing: MOV.B/W/L @ (R0,Rm) and reverse-stack primitives.
        if ((w&0xF00F)==0x0004 || (w&0xF00F)==0x0005 || (w&0xF00F)==0x0006)
            return mem(a,w,"MOV indexed STORE",Operation.MOV_INDEX_STORE,n,m,1<< (low-4),0,false,false);
        if ((w&0xF00F)==0x000C || (w&0xF00F)==0x000D || (w&0xF00F)==0x000E)
            return mem(a,w,"MOV indexed LOAD",Operation.MOV_INDEX_LOAD,n,m,1<< (low-12),0,false,false);
        if ((w&0xF0FF)==0x408B || (w&0xF0FF)==0x409B || (w&0xF0FF)==0x40AB)
            return mem(a,w,"MOV reverse STORE",Operation.MOV_REV_STORE,n,0,
                    1<<((w>>>4&15)-8),0,true,false);
        if ((w&0xF0FF)==0x40CB || (w&0xF0FF)==0x40DB || (w&0xF0FF)==0x40EB)
            return mem(a,w,"MOV reverse LOAD",Operation.MOV_REV_LOAD,0,n,
                    1<<((w>>>4&15)-12),0,false,true);
        if ((w&0xFF00)>=0xC000 && (w&0xFF00)<=0xC200)
            return make(a,w,2,"MOV GBR STORE",Flow.NEXT,null,false,Operation.MOV_GBR_STORE,
                    -1,0,(w&255)*(1<<((w>>>8)&3)),1<<((w>>>8)&3),null,false,false);
        if ((w&0xFF00)>=0xC400 && (w&0xFF00)<=0xC600) {
            int bytes=1<<(((w>>>8)&3)-4+4);
            return make(a,w,2,"MOV GBR LOAD",Flow.NEXT,null,false,Operation.MOV_GBR_LOAD,
                    0,-1,(w&255)*bytes,bytes,null,false,false);
        }
        if ((w&0xF000)==0x8000) {
            int nib=(w>>>8)&15,base=(w>>>4)&15,disp=w&15;
            if(nib==0||nib==1) return mem(a,w,"MOV disp4 STORE",Operation.MOV_STORE,base,0,
                    nib==0?1:2,disp*(nib==0?1:2),false,false);
            if(nib==4||nib==5) return mem(a,w,"MOV disp4 LOAD",Operation.MOV_LOAD,0,base,
                    nib==4?1:2,disp*(nib==4?1:2),false,false);
        }
        // Renesas 5.4: arithmetic/logic with register operands.
        if ((w&0xF00F)==0x300E) return reg(a,w,"ADDC",Operation.ADDC_REG,n,m);
        if ((w&0xF00F)==0x300F) return reg(a,w,"ADDV",Operation.ADDV_REG,n,m);
        if ((w&0xF00F)==0x300A) return reg(a,w,"SUBC",Operation.SUBC_REG,n,m);
        if ((w&0xF00F)==0x300B) return reg(a,w,"SUBV",Operation.SUBV_REG,n,m);
        if ((w&0xF00F)==0x200C) return reg(a,w,"CMP/STR",Operation.CMP_STR,n,m);
        if ((w&0xF00F)==0x6007) return reg(a,w,"NOT",Operation.NOT_REG,n,m);
        if ((w&0xF00F)==0x600A) return reg(a,w,"NEGC",Operation.NEGC_REG,n,m);
        if ((w&0xF00F)==0x600B) return reg(a,w,"NEG",Operation.NEG_REG,n,m);
        if ((w&0xF00F)==0x6008) return reg(a,w,"SWAP.B",Operation.SWAP_B,n,m);
        if ((w&0xF00F)==0x6009) return reg(a,w,"SWAP.W",Operation.SWAP_W,n,m);
        if ((w&0xF00F)==0x200D) return reg(a,w,"XTRCT",Operation.XTRCT,n,m);
        if ((w&0xF00F)==0x600C) return reg(a,w,"EXTU.B",Operation.EXTU_B,n,m);
        if ((w&0xF00F)==0x600D) return reg(a,w,"EXTU.W",Operation.EXTU_W,n,m);
        if ((w&0xF00F)==0x600E) return reg(a,w,"EXTS.B",Operation.EXTS_B,n,m);
        if ((w&0xF00F)==0x600F) return reg(a,w,"EXTS.W",Operation.EXTS_W,n,m);
        if ((w&0xF0FF)==0x4091) return uni(a,w,"CLIPS.B",Operation.CLIPS_B,n);
        if ((w&0xF0FF)==0x4095) return uni(a,w,"CLIPS.W",Operation.CLIPS_W,n);
        if ((w&0xF0FF)==0x4081) return uni(a,w,"CLIPU.B",Operation.CLIPU_B,n);
        if ((w&0xF0FF)==0x4085) return uni(a,w,"CLIPU.W",Operation.CLIPU_W,n);
        if ((w&0xF0FF)==0x4080) return uni(a,w,"MULR R0,",Operation.MULR,n);
        if ((w&0xF0FF)==0x4094) return uni(a,w,"DIVS R0,",Operation.DIVS,n);
        if ((w&0xF0FF)==0x4084) return uni(a,w,"DIVU R0,",Operation.DIVU,n);
        if ((w&0xF0FF)==0x4010) return uni(a,w,"DT",Operation.DT_REG,n);
        // REJ09B0051-0300 table 5.5; hardware-visible MAC registers.
        if (w==0x0028) return simple(a,w,"CLRMAC",Flow.NEXT,null,false,Operation.CLRMAC,-1,-1,0);
        if ((w&0xF00F)==0x3004) return reg(a,w,"DIV1",Operation.DIV1,n,m);
        if ((w&0xF00F)==0x300D) return reg(a,w,"DMULS.L",Operation.DMULS_L,n,m);
        if ((w&0xF00F)==0x3005) return reg(a,w,"DMULU.L",Operation.DMULU_L,n,m);
        if ((w&0xF00F)==0x0007) return reg(a,w,"MUL.L",Operation.MUL_L,n,m);
        if ((w&0xF00F)==0x200F) return reg(a,w,"MULS.W",Operation.MULS_W,n,m);
        if ((w&0xF00F)==0x200E) return reg(a,w,"MULU.W",Operation.MULU_W,n,m);
        if ((w&0xF00F)==0x000F) return reg(a,w,"MAC.L",Operation.MAC_L,n,m);
        if ((w&0xF00F)==0x400F) return reg(a,w,"MAC.W",Operation.MAC_W,n,m);
        // MAC register transfers: subcode 0/1 MACH/MACL, 2/3 LDS, 4/5 STS.L, 6/7 LDS.L.
        if ((w&0xF0FF)==0x000A) return reg(a,w,"STS MACH",Operation.MAC_REGISTER_TRANSFER,n,0);
        if ((w&0xF0FF)==0x001A) return reg(a,w,"STS MACL",Operation.MAC_REGISTER_TRANSFER,n,1);
        if ((w&0xF0FF)==0x400A) return reg(a,w,"LDS MACH",Operation.MAC_REGISTER_TRANSFER,n,2);
        if ((w&0xF0FF)==0x401A) return reg(a,w,"LDS MACL",Operation.MAC_REGISTER_TRANSFER,n,3);
        if ((w&0xF0FF)==0x4002) return reg(a,w,"STS.L MACH",Operation.MAC_REGISTER_TRANSFER,n,4);
        if ((w&0xF0FF)==0x4012) return reg(a,w,"STS.L MACL",Operation.MAC_REGISTER_TRANSFER,n,5);
        if ((w&0xF0FF)==0x4006) return reg(a,w,"LDS.L MACH",Operation.MAC_REGISTER_TRANSFER,n,6);
        if ((w&0xF0FF)==0x4016) return reg(a,w,"LDS.L MACL",Operation.MAC_REGISTER_TRANSFER,n,7);
        if ((w&0xF0FF)==0x0002) return reg(a,w,"STC SR",Operation.SYS_REG_TRANSFER,n,8);
        // Floating-point CPU register transfers, table 5.10. These are bitwise moves.
        if ((w&0xF0FF)==0x006A) return reg(a,w,"STS FPSCR",Operation.FPU_REGISTER_TRANSFER,n,0);
        if ((w&0xF0FF)==0x005A) return reg(a,w,"STS FPUL",Operation.FPU_REGISTER_TRANSFER,n,1);
        if ((w&0xF0FF)==0x406A) return reg(a,w,"LDS FPSCR",Operation.FPU_REGISTER_TRANSFER,n,2);
        if ((w&0xF0FF)==0x405A) return reg(a,w,"LDS FPUL",Operation.FPU_REGISTER_TRANSFER,n,3);
        if ((w&0xF0FF)==0x4062) return reg(a,w,"STS.L FPSCR",Operation.FPU_REGISTER_TRANSFER,n,4);
        if ((w&0xF0FF)==0x4052) return reg(a,w,"STS.L FPUL",Operation.FPU_REGISTER_TRANSFER,n,5);
        if ((w&0xF0FF)==0x4066) return reg(a,w,"LDS.L FPSCR",Operation.FPU_REGISTER_TRANSFER,n,6);
        if ((w&0xF0FF)==0x4056) return reg(a,w,"LDS.L FPUL",Operation.FPU_REGISTER_TRANSFER,n,7);
        if ((w&0xF0FF)==0x4004) return uni(a,w,"ROTL",Operation.ROTL,n);
        if ((w&0xF0FF)==0x4005) return uni(a,w,"ROTR",Operation.ROTR,n);
        if ((w&0xF0FF)==0x4024) return uni(a,w,"ROTCL",Operation.ROTCL,n);
        if ((w&0xF0FF)==0x4025) return uni(a,w,"ROTCR",Operation.ROTCR,n);
        if ((w&0xF00F)==0x400C) return reg(a,w,"SHAD",Operation.SHAD,n,m);
        if ((w&0xF00F)==0x400D) return reg(a,w,"SHLD",Operation.SHLD,n,m);
        if ((w&0xFF00)==0xC800) return simple(a,w,"TST #imm,R0",Flow.NEXT,null,false,Operation.TST_IMM,0,-1,w&255);
        if ((w&0xFF00)==0xC900) return simple(a,w,"AND #imm,R0",Flow.NEXT,null,false,Operation.AND_IMM,0,-1,w&255);
        if ((w&0xFF00)==0xCA00) return simple(a,w,"XOR #imm,R0",Flow.NEXT,null,false,Operation.XOR_IMM,0,-1,w&255);
        if ((w&0xFF00)==0xCB00) return simple(a,w,"OR #imm,R0",Flow.NEXT,null,false,Operation.OR_IMM,0,-1,w&255);
        if ((w&0xFF00)>=0xCC00 && (w&0xFF00)<=0xCF00)
            return simple(a,w,"GBR MEMORY LOGIC",Flow.NEXT,null,false,
                    Operation.GBR_BYTE_LOGIC,-1,(w>>>8)&3,w&255);
        if ((w&0xF0FF)==0x401B) return uni(a,w,"TAS.B @",Operation.TAS_B,n);
        // System register transfers have architectural side effects. This abstract model
        // tracks only SR.T/GBR/VBR/TBR; unmodelled privilege/banks STOP.
        if ((w&0xF0FF)==0x0012) return reg(a,w,"STC GBR",Operation.SYS_REG_TRANSFER,n,1);
        if ((w&0xF0FF)==0x0022) return reg(a,w,"STC VBR",Operation.SYS_REG_TRANSFER,n,2);
        if ((w&0xF0FF)==0x004A) return reg(a,w,"STC TBR",Operation.SYS_REG_TRANSFER,n,3);
        if ((w&0xF0FF)==0x401E) return reg(a,w,"LDC GBR",Operation.SYS_REG_TRANSFER,n,5);
        if ((w&0xF0FF)==0x402E) return reg(a,w,"LDC VBR",Operation.SYS_REG_TRANSFER,n,6);
        if ((w&0xF0FF)==0x404A) return reg(a,w,"LDC TBR",Operation.SYS_REG_TRANSFER,n,7);
        if (w==0x0019) return simple(a,w,"DIV0U",Flow.NEXT,null,false,Operation.DIV0U,-1,-1,0);
        if ((w&0xF00F)==0x2007) return reg(a,w,"DIV0S",Operation.DIV0S,n,m);
        // Nontrivial special-register, multiply/accumulate, bank and exception
        // instructions: recognizable, but not yet correctly executable here.
        if(w==0x005B) return simple(a,w,"RESBANK",Flow.NEXT,null,false,Operation.RESBANK,-1,-1,0);
        if((w&0xF0FF)==0x40E5) return uni(a,w,"LDBANK @Rn,R0",Operation.LDBANK,n);
        if((w&0xF0FF)==0x40E1) return uni(a,w,"STBANK R0,@Rn",Operation.STBANK,n);
        if ((w&0xF0FF)==0x400E) return reg(a,w,"LDC Rn,SR",Operation.SYS_REG_TRANSFER,n,9);
        if ((w&0xF0FF)==0x4007) return reg(a,w,"LDC.L @Rn+,SR",Operation.SYS_REG_TRANSFER,n,10);
        if ((w&0xF0FF)==0x4017) return reg(a,w,"LDC.L @Rn+,GBR",Operation.SYS_REG_TRANSFER,n,11);
        if ((w&0xF0FF)==0x4027) return reg(a,w,"LDC.L @Rn+,VBR",Operation.SYS_REG_TRANSFER,n,12);
        if ((w&0xF0FF)==0x4003) return reg(a,w,"STC.L SR,@-Rn",Operation.SYS_REG_TRANSFER,n,13);
        if ((w&0xF0FF)==0x4013) return reg(a,w,"STC.L GBR,@-Rn",Operation.SYS_REG_TRANSFER,n,14);
        if ((w&0xF0FF)==0x4023) return reg(a,w,"STC.L VBR,@-Rn",Operation.SYS_REG_TRANSFER,n,15);
        if ((w&0xFF00)==0xC300)
            return simple(a,w,"TRAPA #"+(w&255),Flow.EXCEPTION,null,false,Operation.TRAPA,-1,-1,w&255);
        if ((w&0xF0FF)==0x0083) return new Instruction(a,2,w,"PREF @R"+n,
                Flow.NEXT,null,false,Status.VALID,Operation.OPAQUE,
                n,-1,0,0,null,false,false);
        if ((w&0xF000)==0xF000) return fpu(a,w,n,m);
        return null;
    }
    private static Instruction fpu(int a,int w,int n,int m) {
        if (w==0xF3FD) return simple(a,w,"FSCHG",Flow.NEXT,null,false,Operation.FPU_MODE,-1,-1,0);
        if((w&0xF00F)==0xF000) return reg(a,w,"FADD",Operation.FPU_ARITHMETIC,n,m);
        if((w&0xF00F)==0xF001) return reg(a,w,"FSUB",Operation.FPU_ARITHMETIC,n,m);
        if((w&0xF00F)==0xF002) return reg(a,w,"FMUL",Operation.FPU_ARITHMETIC,n,m);
        if((w&0xF00F)==0xF003) return reg(a,w,"FDIV",Operation.FPU_ARITHMETIC,n,m);
        if((w&0xF00F)==0xF004) return reg(a,w,"FCMP/EQ",Operation.FPU_COMPARE,n,m);
        if((w&0xF00F)==0xF005) return reg(a,w,"FCMP/GT",Operation.FPU_COMPARE,n,m);
        if((w&0xF00F)==0xF00E) return reg(a,w,"FMAC",Operation.FPU_FMAC,n,m);
        if((w&0xF0FF)==0xF02D) return uni(a,w,"FLOAT",Operation.FPU_CONVERT,n);
        if((w&0xF0FF)==0xF03D) return uni(a,w,"FTRC",Operation.FPU_CONVERT,n);
        // FCNVSD/FCNVDS use DR (double-precision pair) operand only: REJ09B0051-0300
        // Rev.3.00 Table 5.9 p.65 (txt 8405,8417; clean layout p.65) shows FCNVSD
        // FPUL,DRn=1111nnn010101101 and FCNVDS DRm,FPUL=1111mmm010111101; bit8=0
        // selects DR pair base — NOT an FR register bit and NOT free.  Mask 0xF1FF
        // enforces the DR pair base; the full device inventory has no odd-pair form.
        if((w&0xF1FF)==0xF0AD) return uni(a,w,"FCNVSD",Operation.FPU_CONVERT,n);
        if((w&0xF1FF)==0xF0BD) return uni(a,w,"FCNVDS",Operation.FPU_CONVERT,n);
        if((w&0xF0FF)==0xF06D) return uni(a,w,"FSQRT",Operation.FPU_SQRT,n);
        // SH-2A does not implement SH4 FRCHG/FIPR/FTRV; do not alias them.
        if (w==0xFBFD || (w&0xF0FF)==0xF0ED) return unknown(a,w,2,"SH4_ONLY_OR_RESERVED_FPU");
        if ((w&0xF0FF)==0xF08D) return uni(a,w,"FLDI0",Operation.FPU_IMMEDIATE,n);
        if ((w&0xF0FF)==0xF09D) return uni(a,w,"FLDI1",Operation.FPU_IMMEDIATE,n);
        if ((w&0xF0FF)==0xF04D) return uni(a,w,"FNEG",Operation.FPU_SIGN,n);
        if ((w&0xF0FF)==0xF05D) return uni(a,w,"FABS",Operation.FPU_SIGN,n);
        if ((w&0xF0FF)==0xF00D) return uni(a,w,"FSTS FPUL,FR",Operation.FPU_REG_MOVE,n);
        if ((w&0xF0FF)==0xF01D) return uni(a,w,"FLDS FR,FPUL",Operation.FPU_REG_MOVE,n);
        if ((w&0xF00F)==0xF00C) return reg(a,w,"FMOV FRm,FRn",Operation.FPU_REG_MOVE,n,m);
        if ((w&0xF00F)==0xF006) return make(a,w,2,"FMOV.S @(R0,Rm),FRn",Flow.NEXT,null,
                false,Operation.FPU_MEM_LOAD,n,m,-1,4,null,false,false);
        if ((w&0xF00F)==0xF008) return mem(a,w,"FMOV.S @Rm,FRn",Operation.FPU_MEM_LOAD,n,m,4,0,false,false);
        if ((w&0xF00F)==0xF009) return mem(a,w,"FMOV.S @Rm+,FRn",Operation.FPU_MEM_LOAD,n,m,4,0,true,false);
        if ((w&0xF00F)==0xF007) return make(a,w,2,"FMOV.S FRm,@(R0,Rn)",Flow.NEXT,null,
                false,Operation.FPU_MEM_STORE,n,m,-1,4,null,false,false);
        if ((w&0xF00F)==0xF00A) return mem(a,w,"FMOV.S FRm,@Rn",Operation.FPU_MEM_STORE,n,m,4,0,false,false);
        if ((w&0xF00F)==0xF00B) return mem(a,w,"FMOV.S FRm,@-Rn",Operation.FPU_MEM_STORE,n,m,4,0,false,true);
        // Complete cross-checked device inventory and sec6.1 exclude all remaining
        // patterns (including SH4 XD/FRCHG/FIPR/FTRV), not a single-table inference.
        return unknown(a,w,2,"SH2A_FPU_NOT_LISTED_IN_TABLE_5_9");
    }
}
