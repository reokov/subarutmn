package ecu.independent;

import java.nio.file.*;
import java.util.*;

/** Read-only command line research mode; never runs hardware or writes to ROM. */
public final class StandaloneMain {
    public static void main(String[] args) throws Exception {
        if(args.length<2) throw new IllegalArgumentException(
                "Usage: StandaloneMain firmware.bin output_directory [--entry 0xADDRESS] ... "
                + "[--trace observed_pc.txt] [--limit NUMBER]");
        Path romFile=Path.of(args[0]),folder=Path.of(args[1]);
        int limit=250_000;
        List<Integer> extra=new ArrayList<>();
        Path traceFile=null;
        for(int i=2;i<args.length;i++) {
            if(args[i].equals("--entry") && i+1<args.length)
                extra.add((int)Long.decode(args[++i]).longValue());
            else if(args[i].equals("--trace") && i+1<args.length)
                traceFile=Path.of(args[++i]);
            else if(args[i].equals("--limit") && i+1<args.length)
                limit=Integer.parseInt(args[++i]);
            else throw new IllegalArgumentException("Unknown or incomplete argument: "+args[i]);
        }
        byte[] rom=Files.readAllBytes(romFile);
        FirmwareGraph graph=new FirmwareGraph();
        var result=graph.analyze(rom,limit,extra);
        if(traceFile!=null) {
            // Observed PCs are operator-supplied evidence (ICE/log/simulator), not decoded facts.
            List<Integer> pcs=new ArrayList<>();
            for(String line:Files.readAllLines(traceFile)) {
                String token=line.trim();
                if(token.isEmpty()||token.startsWith("#")) continue;
                int separator=token.indexOf(',');
                if(separator>=0) token=token.substring(0,separator).trim();
                pcs.add((int)Long.decode(token).longValue());
            }
            graph.applyObservedTrace(pcs,"TRACE_FILE:"+traceFile.getFileName());
            result=graph.report();
            System.out.println("observed_trace_points="+pcs.size()
                    +" source="+traceFile.getFileName());
        }
        System.out.println(ReportWriter.write(result,rom,folder));
        System.out.println("reachable_candidates="+result.instructions().size()+
                " memory_references="+result.dataReferences().size()+
                " issues="+result.issues().size()+" truncated="+result.truncated());
    }
}
