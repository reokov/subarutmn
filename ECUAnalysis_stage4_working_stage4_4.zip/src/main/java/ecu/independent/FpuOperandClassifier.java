package ecu.independent;

/**
 * Bit-level IEEE-754 operand classification, independent of host float math.
 * Classification does not implement SH-2A NaN propagation, FPSCR flags,
 * rounding or exceptions. The bit-level sign is preserved for +/-0 and NaNs.
 */
final class FpuOperandClassifier {
    enum Kind { ZERO, SUBNORMAL, NORMAL, INFINITY, NAN, UNKNOWN }
    record Value(Kind kind, boolean negative) {}
    private FpuOperandClassifier() {}

    static Value binary32(Integer bits) {
        if(bits==null)return new Value(Kind.UNKNOWN,false);
        int exp=(bits>>>23)&0xFF;
        int fraction=bits&0x7FFFFF;
        Kind kind=exp==0?(fraction==0?Kind.ZERO:Kind.SUBNORMAL):
                exp==0xFF?(fraction==0?Kind.INFINITY:Kind.NAN):Kind.NORMAL;
        return new Value(kind,bits<0);
    }
    static Value binary64(Integer high,Integer low) {
        if(high==null||low==null)return new Value(Kind.UNKNOWN,false);
        int exp=(high>>>20)&0x7FF;
        long fraction=((long)(high&0xFFFFF)<<32)|Integer.toUnsignedLong(low);
        Kind kind=exp==0?(fraction==0?Kind.ZERO:Kind.SUBNORMAL):
                exp==0x7FF?(fraction==0?Kind.INFINITY:Kind.NAN):Kind.NORMAL;
        return new Value(kind,high<0);
    }
    static Value register(AbstractCpu state,int index,boolean doublePrecision) {
        if(index<0||index>=state.fr.length)return new Value(Kind.UNKNOWN,false);
        if(!doublePrecision)return binary32(state.fr[index]);
        if((index&1)!=0 || index+1>=state.fr.length)
            return new Value(Kind.UNKNOWN,false);
        return binary64(state.fr[index],state.fr[index+1]);
    }
}
