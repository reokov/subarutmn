# Исправление Ghidra headless import, 2026-11-09

## Симптом

`java.lang.IllegalArgumentException: Path element starting with '.' is not permitted` при вызове `./scripts/headless-import.sh firmware/LF9F000R.bin`.

## Причина

В исходном скрипте путь проекта Ghidra был `$ROOT/.ghidra-projects`. Ghidra 12.2 отклоняет элемент пути, начинающийся с точки. Ошибка появляется на этапе создания `ProjectLocator` до импорта BIN.

Вторая обнаруженная ошибка: `-loader-baseAddr 0x0`. Документация Ghidra требует для BinaryLoader шестнадцатеричный адрес **без префикса** `0x`. Используется `-loader-baseAddr 0`.

## Исправление

- `PROJECT_HOME="$ROOT/ghidra-projects"`
- `-loader-baseAddr 0`
- `.gitignore` исключает новый каталог и сохраняет исключение для старого `.ghidra-projects/`.
- Старую скрытую папку скрипт не перемещает и не удаляет.

## Как применить без перезаписи своих изменений

Из каталога `~/work/ECUAnalysis`:

```bash
# Патч можно проверить перед применением
# (при наличии файла ECUAnalysis_headless_import_fix.patch)
git apply --check ~/Downloads/ECUAnalysis_headless_import_fix.patch
git apply ~/Downloads/ECUAnalysis_headless_import_fix.patch
./scripts/headless-import.sh firmware/LF9F000R.bin
```

Либо замените только две строки в существующем скрипте, сохранив другие локальные изменения.

Проверяйте результат по новым файлам `ghidra-projects/ECU_*.gpr` и журналу `reports/*_headless.log` с сообщениями `Import`/`ECU_INVENTORY`.

## Границы проверки

Синтаксис скрипта и формат аргументов сверены статически. Фактический запуск Ghidra в среде подготовки не выполнялся. Код декодера, модель CPU и ELF/RAW анализ не изменялись.

## Источник

Ghidra 12.2 Headless Analyzer README: https://www.ghidradocs.com/12.2_PUBLIC/support/analyzeHeadlessREADME.html (параметры `project_location`, `-noanalysis`, `-loader BinaryLoader`, `-loader-baseAddr`).
