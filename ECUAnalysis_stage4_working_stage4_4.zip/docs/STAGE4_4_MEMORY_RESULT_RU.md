# Этап4.4 — memory profiles, продолжение a967

IN_PROGRESS / RELEASE_BLOCKED. Snapshot определяется SOURCE_SHA256.txt и SNAPSHOT.json.
Исходные73/73 source SHA a967 подтверждены до правок.

Production изменения: SystemExceptionModel.java, FirmwareGraph.java.
CPU postincrement/predecrement/reverse/indexed/GBR memory; scalar FMOV update;
double FMOV memory, per-register and consumer latency. Один существующий executor.
Numerical CPU/FPU/decoder kernels не менялись.
Эталоны SW Rev3 table8.1 pp366–367,374,376; §§8.5,8.9.1(4–7),8.9.8(10–13).
Сначала FAIL отсутствующего6326, затем FAIL отсутствующегоf428 в double mode.
Target PASS57 сценариев/119 assertions; compilation release21 Xlint all PASS;
extension build PASS. Полный функциональный протокол и review — в SNAPSHOT.json.
Наличие172 из253 profiles — inventory, не полнота функционального покрытия;81 отсутствует.

Незакрытые: multiple memory, system memory transfers/FPSCR, FSCHG, MUL/DIV/MAC,
system/bank/TRAPA/SLEEP, полная consumer/dependency matrix, staged exception entry
and general outstanding cancellation/resume.
UNVERIFIED: ED/E1 handoff buffering/backpressure; physical H24/H34 reports/acceptance PC.
Architectural address writes до конца profile не утверждаются только на основании latency.
Полные20 критериев: docs/STAGE4_CRITERIA_RU.md; только16,17,20 подтверждены
в существующей проверенной области, остальные частичны или не выполнены.
Следующее действие: устранить доказанные замечания current review, затем memory
FPU system-register transfer profiles и FSCHG. Реальные ROM/Ghidra BIN/ECU NOT_RUN.

Внутреннее ревью32aad: FAIL, M1/M2. Исходники73/73 неизменны в ходе review.
Оба дефекта воспроизведены и исправлены; плюс прежний SHIFT gap.
Независимые RED-пробы reviewer проходят на новых исходниках; это developer rerun,
а не новый reviewer verdict. Повторное ревью нового snapshot обязательно.
