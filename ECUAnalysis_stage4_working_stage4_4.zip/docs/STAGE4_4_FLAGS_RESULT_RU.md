# Этап4.4: register flags / bit profiles

12.11.2026. IN_PROGRESS / RELEASE_BLOCKED.
Parent ec8b8407ef1e saved+retrieved+73bytes verified before independentPASS.
Новые11форм:4CLIP, DIV0U/DIV0S/DIV1, BCLR/BSET/BLD/BST registers.
203PROFILE_PRESENT /50NOT_IMPLEMENTED /253; наличиепрофиля неPASSполноты.

ProductionJava: SystemExceptionModel.java. TestJava: PipelineStage44Acceptance.java.
NumericalCPU/FPU/decoder unchanged. Q/M/CS shadow, RTE flagsync, stickyCS bypass.
Дополнительно EXT*.SHIFT: доказанныйRED632c → минимальнаяresourceправка → currentprobe.
Pre-EXT build/full logs являются прежнейверсией, не currentacceptance.
Свежие functional.log/extension.log/target-green.log/inventory.log иSNAPSHOT authoritative.

Проверки: CLIP literalbounds/stickyfalse/true, parallelCSaccumulation безstall;
DIV0S same-registeralias,5DIV1literalnormvectors,Q/M/Tdependencies, DIV0U→DIV1,
4BIT_REG×8bits×T0/T1; unknownflags/copy, RTE restoringQ/M/CS/T; EXT/SHLLresource.
Ошибки первоначальных тестовыхожиданий исправлены поprimary: DIV1oldQ1/M0
безcarry даётQ0/T1 (§6.4.18p189); GBRload наблюдаетсяпослеWB, не доWB.
Это не исправлениячисленногокода.

Незакрыто:50profiles (точныйinventory); multiple-memorycompletionboundary,
SR/MAC/MUL/DIV/system/bank/TRAPA/SLEEP/memorybit groups, полная2ILPmatrix,
generalexceptionentry/cancel/retirement/resume. Physical H24/H34 report/savedPC,
EDbuffering/capacity иFSCHGresourceclass UNVERIFIED. ExternalreviewNOT_RUN.
РеальныеROM/ECU/GhidraimportNOT_RUN. SYSTEM_EXCEPTIONS_COMPLETE не достигнут.
Следующаянезависимаягруппа: SRcontrolprofiles с целымиSR и IRQmaskchangeboundary;
не выводить аппаратныйreport timing изчисла выполненныхJavaопераций.
