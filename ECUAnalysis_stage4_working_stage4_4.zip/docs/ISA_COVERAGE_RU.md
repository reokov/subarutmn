# Текущее покрытие ISA/FPU

**Обновление этапа3, 11.11.2026:** текущий FPU-контракт и полная матрица56 форм — [FPU_CONTRACT_RU.md](FPU_CONTRACT_RU.md), [fpu-execution-coverage.csv](requirements/fpu-execution-coverage.csv). Численная/битовая реализация и новые синтетические проверки выполнены; старые ограничения normal-only ниже относятся к предыдущей контрольной точке. Итог FPU_SEMANTICS_COMPLETE: сборка актуального Ghidra extension PASS на Java25/Ghidra12.2; повторные функциональные наборы21/21 PASS. Общий RELEASE_BLOCKED. [Протокол](../drafts/verification/fpu-stage3/RESULT_RU.md).

11.11.2026. **Декодер: DECODER_COMPLETE, 253/253 форм (100%). CPU_COMPLETE в области этапа 2 (205/205 форм); FPU/IEEE-754 и аппаратные зависимости остаются незавершёнными.**

Нормативная матрица, границы и интерфейс: [контракт декодера](DECODER_CONTRACT_RU.md).
Полная историческая матрица и журнал наблюдений сохранены
[в снимке](../drafts/history/ISA_COVERAGE_before_20261111.md).

| Область | Реализовано и проверено в текущей сессии | Граница |
|---|---|---|
| Сборка FPU dispatch | Исправлены два недопустимых Java arrow-return, ядро компилируется | Синтаксическое исправление не подтверждает всю frozen-семантику |
| PC-relative MOV.W/MOV.L/MOVA в delay slot | Цель+2, затем longword alignment и disp8 scaling; 28 синтетических сценариев | BRA/BSR/JMP/RTS, taken BT/S; неизвестная цель/T и nontaken conditional остановлены. RTE/BRAF/BSRF новым набором не подтверждены |
| FPU normal-result traps | O/U/I для арифметики и FCNVDS; I для FSQRT; I только PR0 для FLOAT. Cause отражает фактический результат, включая 0, sticky flags сохранены | Это normal finite-result пути. Overflow/underflow и все специальные результаты не закрыты |
| FDIV zero/zero | V при V enable, консервативный останов без него; Z не фабрикуется | Disabled-invalid qNaN результат пока не реализован |
| FSQRT ±0 | Сохранение raw bits без normal-path I trap | Остальные special cases не закрыты |
| FCNVSD/FCNVDS ±0 | Сохранение знака при RM0/1; FCNVDS O/U/I normal trap | NaN/Inf и FCNVDS subnormal/overflow не закрыты |
| FCNVSD subnormal | DN1 → signed zero; DN0 → явный останов | E/denormal исключение DN0 не реализовано |
| FPU standby/STBCR | Восемь существующих end-to-end сценариев PASS | Не полная модель всех модулей/standby/reset |
| Прочие ISA/CPU/FPU | Существующие acceptance-группы PASS, включая 47 ограниченных semantics checks и length/decode sweeps | Sweep не является независимым доказательством полноты/арифметической эквивалентности |

Нормативные основания новых изменений: REJ09B0051-0300 Rev.3.00 §§6.4.31
с.219–221, 6.4.34 с.228, 6.4.49 с.246–247; §§6.5.2/4/6/10/11/13/16/18,
общие check_single/double_exception с.83–84. STBCR: R01UH0480EJ0400 Rev.4.00
§§29.3.1–29.3.2. Точные связи с Java и проверками —
[протокол](../drafts/verification/20261111/SESSION_RU.md).

На этапе декодера нормативный каталог закрыт по обоим руководствам Renesas.
Для исполнения не закрыты: все режимы SR/FPSCR,
банки/overflow, адресные ошибки и pipeline, NaN/Inf/subnormal/все округления.
requirements/isa-encodings.csv содержит 253 применимые формы; прежний реестр сохранён
в drafts/history/isa-encodings_before_decoder_stage1.csv. Нормативные decoder-проверки
отделены от структурных sweeps и не подтверждают полноту исполнения.
