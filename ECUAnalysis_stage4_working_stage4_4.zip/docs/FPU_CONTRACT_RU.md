# Текущий интерфейс FPU для этапа 4

11.11.2026. **Этап 3: FPU_SEMANTICS_COMPLETE. Общий RELEASE_BLOCKED.**
Этап3 закрыт после установки JDK25/Ghidra12.2, успешной сборки расширения и повторной приёмки21/21. [Протокол снятия блокера](../drafts/verification/fpu-stage3/java25-ghidra12.2/RESULT_RU.md). Документ фиксирует контракт для этапа4; системная обработка исключений не объявлена завершённой.

## Объём и маршрут

Знаменатель неизменен: 48 форм таблицы 5.9 и 8 связанных CPU-передач таблицы 5.10
REJ09B0051-0300 Rev.3.00, с.66–68. Все 56 имеют исполняемый путь и выполненную
синтетическую проверку нормального исполнения из ROM и SRAM. Численная и битовая семантика всех 56 реализована; независимые наборы конечны и не являются исчерпывающим перебором всех битов.
Матрица: `requirements/fpu-execution-coverage.csv`; протокол: `../drafts/verification/fpu-stage3/RESULT_RU.md`.

Обычный маршрут: `fetch/decode → Sh2aDecoder.fpuContext → FirmwareGraph.execute →
FpuSemantics.apply → numerical/transfer → AbstractCpu → CpuSnapshot`.
Контекстная проверка повторно использует правила завершённого декодера; она нужна
также для SRAM и delay slot. Ранее основной исполнитель пропускал, например,
FSCHG при PR1. Контекстные запреты теперь проходят существующий illegal route.

Численная часть `FpuBinary` использует BigInteger-рациональные значения. Деление
не ограничено десятичной точностью. FSQRT округляется точным сравнением квадратов,
а не приближённым sqrt хостовой double. RN: nearest/ties-even; RZ: toward zero.
Знаки нулей и raw NaN не проходят хостовые преобразования. FMAC normal вычисляет
точное произведение и сумму до единственного округления. Перемещения сохраняют raw bits.

Memory adapter предоставляет `aligned(address,width)`, `load(address)` и
`store(address,value)` для отдельных big-endian longwords существующей модели.
64-битная передача требует выравнивания 8; preflight выполняется до изменения
адресного регистра, FR, FPUL, FPSCR или SRAM. Та же проверка действует в pending interval.
Ошибка создаёт CpuBoundary H'24 без выдуманного сохранённого PC; принятие — этап 4.

## FPSCR

По §2.2.5 с.8–10 и Hardware §2.2.5 с.39–40:

- DN аппаратно всегда 1. LDS фиксирует DN1; искусственный DN0 численной части
  возвращает `FPSCR_DN0_RESERVED`, а не PASS поддержки denormal arithmetic.
- RM0/RM1 допустимы; RM2/RM3 — reserved. Эти ограничения не мешают raw transfer/sign.
- PR выбирает FR/DR, SZ независимо задаёт размер FMOV. DR — чётная база FR, high word первым.
- QIS при V-enable добавляет invalid для qNaN/±infinity в источнике операции.
- SH-2A NaN: старший бит fraction=0 означает quiet, =1 signaling. Canonical qNaN:
  `7fbfffff`, `7ff7ffffffffffff`; sNaN вызывает V (§6.2, с.79,85–86).
- Арифметика/сравнения/преобразования очищают Cause; Flag sticky. Sign, move,
  immediate, FSCHG не очищают Cause. LDS программно заменяет поля через существующую маску.
- Subnormal input рассматривается как signed zero без изменения отдельного источника.
  Ненулевой subnormal output flush-to-zero устанавливает U/I; tiny inexact zero — U/I.
- O/U/I-enable на normal arithmetic/FCNVDS вызывает событие даже при exact result;
  у normal FSQRT/FLOAT(PR0) — только I-enable. Специальные ветви следуют таблицам
  и helper-путям §6.5; в частности sqrt signed zero сохраняется без normal trap.
- FTRC всегда truncation; NaN→MIN, +/-infinity→MAX/MIN при отключённом V.
  binary64 −2147483648.5 допустимо, −2147483649 вызывает V (§6.5.19, с.318–320).

## Генерация события и pending

При генерации: Cause/Flag обновлены, результат назначения не записывается,
`fpuExceptionPending=FPU_PENDING`. `apply` возвращает `FPU_EXCEPTION_GENERATED_*`.
Это успешная генерация события, а не отсутствие реализации и не факт принятия H'34.

`FirmwareGraph.fpuEvents()` возвращает неизменяемый список
`FpuExceptionEvent(instructionPc,cause,flags,enable,fpscr)`. Здесь instructionPc —
адрес генератора; cause — поле 17..12; flags — sticky 6..2; enable — 11..7;
fpscr — состояние после генерации. Нулевой Cause допустим при unconditional enable trap.
Список описывает абстрактно наблюдённые события, не физическую тактовую трассу.

`CpuSnapshot` дополнен FR/FPUL/FPSCR/pending для наблюдаемой приёмки. Существующие
CPU-поля сохранены. Это добавление компонентов record меняет его конструктор;
все исходные потребители проекта перекомпилированы, внешняя бинарная ABI не обещается.

Логика №19 сохранена: FPU-часть pending-интервала заморожена, FCMP меняет T без
нового Cause/Flag/event; разрешённые CPU-side memory/address effects сохраняются.
Потенциальное принятие исследуется существующим графом; ни одна такая ветвь
не становится доказательством точной pipeline latency. Генерация в delay slot
использует существующий FPU_PENDING_AFTER_SLOT.

В текущем незавершённом этапе 4 реализованы общий арбитр, вход H'34/H'24 и снятие
pending для явно заданного report-ID/относительного поступления события.
Физический момент ID-stage принятия и точный saved PC при перекрытии CPU/FPU
ещё не подтверждены. Потенциальные ветви этого не доказывают; численный FPU-блок
не задаёт latency. Текущая граница зафиксирована в
[SYSTEM_EXCEPTIONS_CONTRACT_RU.md](SYSTEM_EXCEPTIONS_CONTRACT_RU.md).

## Разрешение противоречий FMAC

REJ09B0051-0300 Rev.3.00 §6.5.11 с.299–302 содержит противоречивые знаки нулей
и поведение infinite FR0. Официальная японская редакция
[R01US0031JJ0400 Rev.4.00, 22.02.2011](https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual?language=ja&r=1054896)
в списке исправлений (PDF physical p.7, zero-based index6) **явно** заменяет эти правила;
исправленный §6.5.11, printed6-205..207 (PDFp275..277), подтверждает их.

Применён приоритет явного исправления revision list и исправленного псевдокода
над оставшимися старыми ячейками special-case table на printed6-208:

- Нулевое произведение плюс нулевой аккумулятор: sign(result)=sign(product) AND sign(accumulator).
- Infinite product плюс противоположная infinity аккумулятора: invalid; иначе знак
  результата определяется произведением, без XOR с конечным аккумулятором.

Это уточнение общей SH-2A/SH2A-FPU-семантики, не расширение ISA и не перенос правила
другой архитектуры. Старые конфликтные UNVERIFIED удалены только после получения
этого первичного свидетельства; независимый ревьювер проверил оригинальные страницы.
Literal FMAC oracle следует указанным исправлениям, а не старой таблице.
Сборка актуального Ghidra-расширения на Java25/Ghidra12.2 выполнена; полнота этапа3 зафиксирована отдельно от общего RELEASE_BLOCKED.
