# ECUAnalysis — невыпущенная разработка и результаты проверки

Дата: 2026-11-09. Основа: чистая ECUAnalysis 0.6.0 плюс исправления 0.6.0_unreleased_correctness. Нового релиза НЕТ.

## Что изменено в исходниках

1. `Sh2aDecoder.java` и `Sh2aOpcodeExtensions.java`: исправлена длина `0x3nm2` (CMP/HS — 16 бит) и формы 32-битного `FMOV` с `disp12` (0x3nm1); сохранён правильный масштаб ×4/×8. Это исправление из прежнего невыпущенного патча включено в совокупный патч.
2. `Sh7254rSoftwareInterruptScheduler.java`: новый отдельный селектор `SINT1–SINT15`. Приоритет SINTn фиксирован и равен n (Renesas R01UH0480EJ0400, таблица 7.8); номер вектора `108-n`, смещение в байтах `(108-n)*4`. `SR.I` маскирует меньшие/равные приоритеты; неопределённые биты запроса приводят к состоянию неопределённости, а не фиктивному прерыванию.
3. `FirmwareGraph.java`: селектор применяется на границе завершения инструкции. Для delayed branch — после инструкции слота. При подтверждённом запросе используется `Sh7254rInterruptController.enter()`; записывается событие `SINTn_ACCEPTED_AFTER_INSTRUCTION`; состояние обработчика не делится между альтернативными CFG-ветвями. После неподтверждённого MMIO STORE дальнейший CFG не строится.
4. `AbstractCpu.java`: переносится признак неизвестного побочного эффекта MMIO при копировании/объединении состояний. Ручной точке входа больше не приписывается достоверное состояние reset, даже если reset-вектор корректен.
5. `FpuOperandClassifier.java`: классификация исходных IEEE-754 битовых шаблонов binary32/binary64 (нуль, subnormal, normal, infinity, NaN) с сохранением знака. Применена к диагностике недоказанных особых FPU-операндов; не заменяет арифметику и исключения.
6. `tools/FpuClassificationAcceptance.java`: 11 проверок классификации входных шаблонов, без притязания на IEEE-754 arithmetic oracle.
7. `tools/SoftwareInterruptBoundaryAcceptance.java`: синтетическая проверка приоритета, маски, неопределённого запроса, `BRA`/delay slot/SINT/RTE и банкового сохранения/восстановления.
8. `tools/PeripheralFailClosedAcceptance.java`: синтетическая проверка остановки CFG после записи в неизвестный MMIO-регистр.
9. `tools/FullCoverageReleaseGate.java`: явный запрет выпуска при отсутствии полных независимых доказательств ISA, системных механизмов, периферии, сборки Ghidra и совпадения аппаратных трасс.

## Выполненные проверки

- `javac -Xlint:all`: PASS (автономное ядро и инструменты).
- `SemanticsAcceptance`: PASS 47 выборочных проверок.
- `InstructionLengthAcceptance`: PASS 65 536 первых полуслов (только длина).
- `FmovDisplacementAcceptance`: PASS синтетические single/double, load/store.
- `DecodeSweep`: 327 680 пар первых/вторых полуслов, без структурных ошибок.
- `FpuClassificationAcceptance`: PASS, 11 битовых образцов; без числовой/исключительной семантики.
- `SoftwareInterruptBoundaryAcceptance`: PASS, синтетический цикл SINT1/RTE и банковый контекст.
- `PeripheralFailClosedAcceptance`: PASS, остановка после неописанной MMIO записи.
- `FullCoverageReleaseGate`: RELEASE_BLOCKED (завершение с кодом 2 — ожидаемое).
- Сборка Ghidra 12.2: NOT_RUN (отсутствуют библиотеки Ghidra).
- Renesas Simulator, физический ECU и реальный ROM: NOT_RUN.

## Строго не завершено

### ISA / FPU: FAIL
- Не выполнено независимое попарное сравнение семантики всех корректных 16/32-битных кодировок; полный набор 32-битных продолжений не исчерпан.
- Нет полного IEEE-754 binary32/binary64: `FPSCR` enable/cause/flag, NaN, qNaN/sNaN, infinity, denormal/subnormal, округление, signed zero и полноценный FPU trap вектора 0x34.
- Отсутствует эталонная аппаратная/симуляторная трасса.

### Системное исполнение: FAIL
- Смоделировано только архитектурное принятие **программных SINT** на границе инструкции (при достаточном конкретном состоянии CPU), а не цикл-точный INTC.
- Нет полного арбитража NMI/IRQ/ADC/CAN/DMA/CMT/WDT и прочих внешних/периферийных запросов, задержек периферийных/CPU-тактов, всех вложенных/синхронных исключений, overflow fallback и детерминированного BO/CS/IBNR в каждом случае.
- Нельзя трактовать присутствие обработчика в графе как доказательство появления аппаратного запроса на реальном ECU.

### ECU периферия: FAIL
- Модель регистров INTC неполная, другие регистры ADC, CAN RCAN-TL1, DMA/A-DMAC, ATU-III/CMT, CPG, WDT не реализованы.
- Отсутствуют аппаратные тайминги, сигналы двигателя, CAN frame input/output, DMA memory mutations, reset/standby и clock gating.
- Неизвестная MMIO запись теперь прекращает соответствующую ветвь анализа, но это НЕ эмуляция регистра.

## Авторитетные источники

- Renesas `SH7254R Group User's Manual: Hardware`, R01UH0480EJ0400 Rev.4.00, разделы 7–19: https://www.renesas.com/en/document/mah/sh7254r-group-users-manual-hardware
- Renesas `SH-2A, SH2A-FPU Software Manual`, REJ09B0051-0300 Rev.3.00, разделы 3, 5, 6, 7: https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual
- Независимая таблица распознавания 32-битных префиксов (проверка длины): https://codebrowser.dev/linux/linux/arch/sh/kernel/cpu/sh2a/opcode_helper.c.html

**Решение:** RELEASE_BLOCKED. Это исследовательский невыпущенный патч, а не новая версия с полным покрытием SH7254R.
