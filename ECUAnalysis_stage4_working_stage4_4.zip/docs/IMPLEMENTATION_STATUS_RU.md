# Текущее состояние ECUAnalysis

11.11.2026, невыпущенное дерево на основе 0.6.0. **IN_PROGRESS / RELEASE_BLOCKED**.
Это частичный независимый абстрактный анализатор, не полный аппаратный эмулятор.

| Компонент | Состояние |
|---|---|
| ISA/CPU | Декодер DECODER_COMPLETE: 253/253 форм. CPU_COMPLETE в области этапа 2: 205/205 форм, базовая и граничная приёмка; внешние зависимости сохранены. Исправлены DIV0/overflow successor, TRAPA/SRAM и известный SRAM-fetch. [Контракт CPU](CPU_CONTRACT_RU.md), [матрица](requirements/cpu-execution-coverage.csv) |
| FPU | Этап3 FPU_SEMANTICS_COMPLETE; обе сборки PASS на Java25/Ghidra12.2. Реализованы 48 FPU +8 передач; точная рациональная арифметика, Renesas NaN, signedzero, O/U/I, FPSCR и событие генерации. Независимая приёмка 2 146 238 +6388 проверок PASS; reviewer PASS реализации. [Текущий контракт](FPU_CONTRACT_RU.md), [результат](../drafts/verification/fpu-stage3/RESULT_RU.md). Повторная приёмка на Java25:21/21 PASS |
| События/INTC | Частичный INTC/SINT и синхронные исключения. FPU pending/приём имеет потенциальные альтернативы; точный момент pipeline не доказан |
| SRAM/MMIO/STBCR | Наблюдаемые SRAM-байты, INTC, keyed word STBCR; существующие 8 STBCR сценариев прошли decode→execute→loadState→loadStbcr→CPU. Большинство периферийных эффектов не моделируется |
| Аппаратные модули | Полные таймеры/WDT/CPG/ATU/ADC/DMA/A-DMAC/RCAN отсутствуют; не приравнивать адресный каталог к реализации |
| CFG/калибровки/XML | Частичный CFG и структурные кандидаты; доказанный универсальный поиск калибровок и генерация XML не завершены |
| CLI | Собранный JAR проверен на сгенерированном образе, с сохранением двух отчётов и неизменностью входа |
| Ghidra 12.2 | Установлена Ghidra12.2, Java25.0.5.0.2, Gradle9.8.0; актуальное FPU-дерево собрано как extension, BUILD SUCCESSFUL. Runtime GUI/ROM не проверялись |

**Актуальные проверки CPU:** [результат этапа 2](../drafts/verification/cpu-stage2/RESULT_RU.md).
Актуальная сборка расширения на Java25/Ghidra12.2 PASS; аппаратные зависимости и точный pipeline-приём исключений остаются незавершёнными. Общий RELEASE_BLOCKED.
[Исторический результат этапа 1](../drafts/verification/decoder-stage1/RESULT_RU.md).
Реальные BIN, Ghidra с ROM, ECU, внешние симуляторы не запускались.

[Протокол и следующая задача](../drafts/verification/20261111/SESSION_RU.md) ·
[Матрица ISA/FPU](ISA_COVERAGE_RU.md) · [Release gate](FULL_COVERAGE_RELEASE_GATE_RU.md).

Прежний документ с историческими оценками сохранён
[отдельно](../drafts/history/IMPLEMENTATION_STATUS_before_20261111.md).
