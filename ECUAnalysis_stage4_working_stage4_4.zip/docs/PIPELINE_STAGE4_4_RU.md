# Pipeline4.4: новый restart из подтверждённой базы

12.11.2026. IN_PROGRESS / RELEASE_BLOCKED. Точное восстановление утраченного
stage4_4-20261111-59c7ff9175af: RESTORE_BLOCKED. Текущий код — новая реализация
из подтверждённого архива f599f87f7d7c91ae3d4c3e87f4e70f3d428cf65f688710bb77f0b6ce266ad895,
а не восстановленные bytes59c7. Исторические PASS не относятся к новому snapshot.

## Исполняемая механика

Один Pipeline в SystemExceptionModel/AbstractCpu/FirmwareGraph. Flight хранит phase,
remaining states, CPU completion и отдельные register/SRAM deltas. Прогноз ready()
продвигает изолированную копию того же stage engine; он не изменяет реальную flight.
Запись результата допускается только после фактической финальной стадии.

| Profiles/механизм | Стадии и правило | Основание |
|---|---|---|
| FDIV/FSQRT PR0/PR1 | E1 init, ED states, E1 return, E2, SF; resource waits сохраняют job | SW8.6(1–4),8.9.8(16–17) |
| Занятый E1 | текущий owner не прерывается будущим return; ready16 не переносится на23; SF следует actual return | SW8.6(2–3) |
| Занятый ED | stage waiting вместо переноса всей DF/CPU completion; независимые jobs могут завершаться | SW8.6(4); buffering условен ниже |
| Long slots | ED идёт по system states, остальные стадии по slots; длительности только явный вход | SW8.2 |
| Memory basic SRAM/ROM | CPU EX/MA/WB load, EX/MA store; отдельный SRAM commit и executor operands | SW8.5,8.8,8.9.1 |
| Scalar FPU memory | EX/NA/SF load или EX/NA store | SW8.9.8(10–13) |
| FPSCR register access | LDS stall3, STS после arithmetic completion+1; numeric context отдельно от committed | SW8.3.6,8.6 figs8.38–41,8.9.8(1–6) |
| Double FMOV register | EX/EX/NA/SF, CPU2; source latency1 | SW8.9.8(8) |
| Branch/slot | delayed slotID2, targetID3; taken non-delayed targetID3; unknown T paths partitioned | SW8.3.7 fig8.32,8.9.5 |
| RTE | EX/MA/MA/EX/EX/EX, slotID6; SP/SR/T deltas, nullable committed SR | SW8.9.6(12) p437 |

2-ILP учитывает width32, preceding multicycle, register dependencies и ресурсы.
LDS FPUL + CPU memory READ разрешён (fig8.11), со STORE запрещён (fig8.9).
Copy/rollback/reset сохраняют изолированное состояние; initial restore до initialize
ничего не стирает. После принятого empty-flight exception frame committed shadow
пересобирается; already-reported IRQ после slot ждёт known decode fence.
Untimed BF/BT не получают нового T-refinement. Unknown callee не переводит pipeline
молча в untimed executor.

## Не завершено — NOT_IMPLEMENTED

Инвентаризация всех253 ISA rows: profile-inventory.tsv. PROFILE_PRESENT не является
PASS всех нормативных сценариев. Нет полной consumer-specific матрицы.
Реализованы address-update/indexed/GBR/reverse и scalar/double FPU memory profiles.
Остаются multiple memory, прочие CPU memory control transfers, MUL/DIV/MAC/system/bank/TRAPA/
SLEEP profiles, весь набор multicycle/32-bit 2-ILP исключений и general exception entry/
cancel/retirement/resume. Эти пробелы нельзя объяснять отсутствием аппаратного эталона.

## Неподтверждённые аппаратные условия — UNVERIFIED

SW8.6 задаёт resource exclusivity, но не все ёмкости latch/queue, release и backpressure
при ED completion, ожидающем return E1, или нескольких initialized divides.
Текущий executable buffering policy допускает сохранение операций между стадиями и
освобождает завершённый ресурс. При WAIT_ED/return выдаётся runtime
UNVERIFIED_ED_E1_HANDOFF_BUFFERING. Это условное расписание, не единственный hardware oracle.
Тесты SF27/второго divide проверяют этот stage policy и resource constraints.

Физический condition→CPU-report H24/H34 не назначен. При outstanding сохраняются jobs
и report, но нет guessed physical saved PC. Bus/wait/clock параметры без явных inputs
также UNVERIFIED. withNoWaitPipeline() и withPipelineSlotStates(map) задают условия
анализа, а не выводят такты из CFG/ROM.

SYSTEM_EXCEPTIONS_COMPLETE не достигнут; переход к этапу5 запрещён.
Ревью допускается только после сохранённой и сверенной пары архивов текущего snapshot.

## Исправленный domain-specific WAW

SW8.6 p358 reduced overwrite относится только к FR/FPUL. T и CPU Rn, даже если
producer — FPU instruction (FCMP/STS), используют обычную CPU WAW boundary.
Прежний FAIL0d76 и повторный PASSa967 сохранены раздельно в evidence.

## Address-update memory iteration (после a967)

SW Rev3 table8.1 pp366–367,374,376 (notes3/4); §8.5 p352;
§8.9.1(4–7) pp381–385; §8.9.8(10–13) pp457–463.
CPU load EX/MA/WB, latency2; store EX/MA, data latency0, updated address1.
CPU postincrement/reverse-load conservatively follows published load latency2 for both writes;
no shorter undocumented CPU address latency is asserted. No separate EX architectural
write is inferred from latency alone. Architectural deltas commit at profile end;
forwarding overlays are used only after readiness admits the consumer.
Scalar FMOV address latency1 (if updated) / FR2. Double FMOV load: CPU address1,
even-FR consumer2, odd-FR consumer3, DR consumer4; EX/EX/NA/SF, CPU EX/MA/MA.
Double store EX/EX/NA with MA/MA and updated address1.
An independent FP_LS consumer waits for both EX slots; independent arithmetic may advance.
Indexed address reads R0 plus base; GBR is included in committed shadow/copy.
Predecrement effective address is checked before numerical execution; update/source alias
uses existing numerical CPU semantics. No external bus wait interval is invented.
Target acceptance includes width/source alias, update suppression, per-register readiness,
RAW/WAR/MA pairing, shadow/forwarding separation, copy/reset and H24 rollback.
Profile presence remains an inventory, not proof of every consumer or exception combination.

## Исправления review32aad

M1: явные DR-source группы, а не вывод из двух соседних FR в read-set.
SW table8.1 note4 p377: single FADD FR4,FR5 требует max(2,3)=3, не DR4=4.
M2: completedPhases записывает реальные окончания стадий, включая ED substate.
RAW берёт конкретную стадию в прогнозе того же stage engine; задержка более поздней
MA/SF не переносит уже доступное значение EX/E2. Committed/forwardable раздельны.
CPU predec store ID1/EX2/MA4 при конфликте MA3: адрес ready2, commit4.
Прогноз/копия используют immutable phase lists, reset их очищает, key включает
completed phase history только outstanding flights. MEMORY ordering marker остаётся
отдельным ограничением; полная memory ordering/consumer matrix ещё не доказана.
SW8.9.1(3) p380: SWAP.B/W и XTRCT теперь резервируют SHIFT, как SHLL2.

## FPUL/FPSCR memory и FSCHG (продолжение e87)

Пять новых форм: STS.L FPUL,@-Rn; STS.L FPSCR,@-Rn; LDS.L @Rn+,FPUL;
LDS.L @Rn+,FPSCR; FSCHG. SW Rev3 table8.1 p373, §8.9.8(1–6,9) pp448–456.
Memory transfer: FP_LS EX1, MA2; load завершает SF3, store NA2.
Published latency: LDS.L FPUL2/FPSCR3, STS.L FPUL2/FPSCR1.
Address writes следуют опубликованной общей latency, без выдуманного раннего commit.
FPUL arithmetic forwarding: memory −1, CPU STS −2, без суммирования reductions.
FSCHG имеет отдельный SZ read/write; whole FPSCR accesses зависят и от SZ.
Нормативное основание FSCHG: подробный §8.9.8(9) p456 задаёт FP_LS и отсутствие
contention у следующего reader. Table8.1 p374 обозначает latency1/arithmetic pipeline;
Appendix A pp479–480 также относит FSCHG к FP. Независимое review28d5
подтвердило противоречие. FP_LS выбран как условный профиль подробного раздела,
а не доказанное исправление Renesas. Runtime регистрирует
UNVERIFIED_FSCHG_PIPELINE_RESOURCE; uncertainty сохраняется в copy и очищается reset.
Новый scheduler или численная семантика FPU не вводились.

## PR transfers и MOVA

SW Rev3 table8.1 pp365,371–372; §8.9.1(3) p380; §8.9.6(1,4,6) pp422,425,427.
MOVA и LDS/STS PR — CPU EX1, latency1. LDS.L PR — EX/MA/WB, latency2,
STS.L PR — EX/MA, updated Rn latency1, memory marker0. Нет выдуманного
раннего architectural commit. PR forwarding применяется через тот же stage engine.
SRAM/ROM profile guard проверяет effective address перед numerical execution.

## Non-SR control transfers

10форм LDC/STC GBR/VBR/TBR и LDC.L/STC.L GBR/VBR: SWtable8.1pp371–372,
§8.9.6(1,4,6)pp422,425,427. CPU EX1 для registers; EX/MA/WB load3,
latency2; EX/MA store2, address latency1. VBR/TBR добавлены в committed
shadow, copy/reset и operand overlay. SR forms реализованы следующей итерацией; INTC report synchronization остаётся UNVERIFIED.
Diagnostic исправление cf3FAIL: issue сообщает фактическую uncertainty.
FSCHG-only больше не объявляет ED/E1 handoff.

MOVML/MOVMU пока NOT_IMPLEMENTED. §8.9.1(6,9) и fig8.24/25 требуют
различать старые outstanding и preceding из той же issue-пары.
Норма не установила, относится ли ожидание к CPU-complete/FP-outstanding.
Это точная неопределённость, а не обоснование исключить эти4формы из253.

## Register flags / bit profiles

11форм:4CLIP, DIV0U/DIV0S/DIV1 и4BIT_REG. SW8.9.2(1)pp390–391,
8.9.3(5)p408, table8.1pp368/370. CPU EX1, latency1. Q/M/CS имеют
committedshadow и nullablecopy/restore. RTE записывает этифлаги вместе сSR/T,
чтобы старыйshadow не перекрывал loadedSR. StickyCS междуCLIP имеет специальный
bypass и не вызывает rewritecontention, как требуетp391/fig8.22.
DIV1numeric unchanged; literalvectors сверены с6.4.18pp188–189.
Обнаружен и воспроизведён resourcegap EXT*. SW8.9.2(1)p391 требуетSHIFTER;
EXTS.B/W,EXTU.B/W теперь резервируютсуществующийSHIFT какSWAP.

## Whole SR profiles и issue capacity

4формы SR: SW8.9.6(2,3,5,7)pp423–428; table8.1pp371–372.
LDC Rm,SR:EX/EX/EX,states3,latency2; STC SR,Rn:EX/EX,states2,latency2.
LDC.L SR:EX/MA/EX/EX/EX,states5,latency4; STC.L SR:EX/EX/MA,states2,latency2.
SR_SEQUENCE(offset0) — описание стадий, а не новый физический ресурс/таймер.
SW8.5p352: additionalslot5 для чтения загруженного T/Q/M/CS через readLatency;
WAW использует исходную latency4. SR/status/flagshadow обновляются вместе.

Диаграммы визуально сверены. Следующий independentID:2/1/4/1 соответственно.
Добавленная при первичном чтении text extraction лишняя задержка удалена ДОsnapshot.
Последний multicycle step занимает одну issue lane (8.3.4): можно выдать одну
новую инструкцию, не две.32bitmulticycle запрещает pairing следующей инструкции
в finalslot (8.3.4(6),8.3.5(4)); исключения memory-Tbit ещё не реализованы.

IRQ_WINDOW — существующий диагностический счётчик неопределённости доставки, не
аппаратная задержка INTC. Теперь он является committedshadow и уменьшается при
CPU completion. При LDC, снижающей mask, значение5 устанавливается при SRcommit,
не при Javaevaluation. UNVERIFIED_INTC_MASK_CHANGE_REPORT_SYNC сохраняется явно.
HWRev4table8.5 задаёт Icyc/Bcyc/Pcyc зависимости; счётчик5 не доказывает этиcycles
и не используется как доказанный physicalCPU-report. Прежняя untimedpolicy сохранена.

## Исправление HIGH review2369: actual execution boundary

Issued+executionStates непригодно при MAwait. ready() теперь берёт last execution
slot и width32fence из actual-phase prediction того же stageengine.
executionSlot() учитывает partialmulti-slotphase: два состоянияE1 не округляются
к концуE1, если нужен первыйslot. Finalissuelane также следует actualprogress.
RTE ждет actualcompletionsequence, не fixed6 при добавленном MAwait.
STC.L SR сохраняет различие: поздняя MA после двухexecutionstates не переносит
уже завершённуюEX-boundary. Это проверено явнымsyntheticMAownershipinterval,
который не объявляется latency какой-либо аппаратнойинструкции.
ProductionFMOV.D→LDC.LSR: actualMA4/EX5/6/7, followingNOP_ID6, SRcommit7.
