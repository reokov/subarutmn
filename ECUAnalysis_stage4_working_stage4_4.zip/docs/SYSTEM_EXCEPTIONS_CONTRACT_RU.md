> 12.11.2026: актуальный новый restart этапа4.4 — `PIPELINE_STAGE4_4_RU.md`. Utраченный59c7 RESTORE_BLOCKED; старые результаты ниже исторические. Текущий snapshot и проверки см. drafts/verification/stage4_4-memory/CHECKPOINT_RU.md.

# Контракт системных исключений SH7254R

11.11.2026. Этап 4: **IN_PROGRESS**, реализация незавершена. Общий статус **RELEASE_BLOCKED**.
Численная семантика этапа 3 сохраняет `FPU_SEMANTICS_COMPLETE` (56/56 форм).

## Источники и область

Основной источник — R01UH0480EJ0400 Rev.4.00, §§7–8, локальный
`inputs/SH7254R Group User’s Manual%3A Hardware.pdf`. REJ09B0051-0300 Rev.3.00
§8.9.7 применяется для порядка ID/исполнения при отсутствии противоречия целевому Hardware.
R01US0031JJ0400 Rev.4.00 §3.10.4 уточняет возможную задержку после снижения SR.I через LDC.

Manual reset не создаётся: H'08/H'0C зарезервированы. H'14 не является RAM-error
исключением, H'38 не является H-UDI исключением данного MCU. RAME (вектор 79) и FIFE
(82) поступают как аппаратные прерывания уровня 15, отдельно от H'24/H'28.
Таблица 8.4 содержит 273 назначенных interrupt-вектора; независимая TSV-фикстура
извлекается из Hardware, а не из Java. Reserved holes запрещены для interrupt events.
TRAPA сохраняет существующую операцию чтения указателя по imm8 (§7.6.2); это не
создаёт самостоятельного источника manual reset или иного reserved exception.

## Событие и состояние

`SystemExceptionModel.Event` хранит id, kind, generatorPc, dataAddress, vectorOffset,
level, source, availability, savedPcContext, reportAfterIssuePc. `generatorPc` не
подменяет saved PC. Для отдельного bank-overflow report обязателен исходный IRQ level 1..15.

- `PIPELINE_UNVERIFIED`: источник/условие известно, момент CPU report неизвестен.
- `REPORTED_ID`: сценарий явно утверждает доступность report на данной границе ID.
- `AFTER_ISSUE`: явный относительный вход сценария; report становится доступным
  после issue инструкции с указанным PC. Разрешён для reset, IRQ-класса, address
  errors и FPU; запрещён для впервые декодируемых illegal/TRAPA/DIV exceptions.
  Численная FPU-семантика автоматически такой момент не назначает.

`AbstractCpu.systemPending` переносится в copy/rollback и разделяет ключи worklist.
Разные pending-наборы не сливаются в достоверное одно событие.
`FirmwareGraph.systemEvents()` возвращает generation/pending/arbitration/acceptance/
transition/blocked. `CpuSnapshot` содержит pending и последние retirement/resume PC.
`executionSteps()` отдельно возвращает ISSUE/COMPLETE/CANCELLED. Это относительные
наблюдения абстрактного исполнения, не временная трасса аппаратуры.

## Принятие

Общий арбитр использует Hardware tables7.1/8.4: core exceptions прежде IRQ,
затем уровень IRQ, затем default vector priority. Маскируемые IRQ требуют level > SR.I;
NMI не маскируется. Неизвестные маска/момент report не превращаются в гарантированный переход.
Взаимные timing-варианты сохраняются как потенциальные пути.

Перед исполняемыми datapath/control/slot инструкциями устанавливается in-flight;
арбитр вызывается из этого маршрута. IRQ/H'24/H'28 могут отменить DIVS/DIVU до
записи quotient. RTE возобновляет отменённый DIV с его PC. Остальные инструкции
заканчивают исполнение перед принятием этих report. FPU report не отменяет DIV.
Reset отменяет in-flight без стека. Delay-slot bar применяется к самому слоту;
дополнительный запрет на первую инструкцию target удалён (Hardware7.7/table7.10).

Saved PC: general illegal, DIV0/overflow, bank underflow — адрес источника;
slot illegal — target ветвления; TRAPA — следующая инструкция; H'24/H'28/H'34
и IRQ — следующий PC после последней завершённой инструкции на выбранном ID.
SR записывается перед PC; после входа SP указывает на PC, SR находится по SP+4.
RTE восстанавливает PC/SR/SP и исполняет разрешённый delay slot.

Для известного report H'34 вход снимает typed event и legacy FPU latch, включая
последующую H'24 из-за stacking. FPSCR Cause/Flag/Enable при входе не переписываются.
Логика №19 (FP freeze, FCMP.T, допустимые CPU-side effects) сохранена.

Bank enable учитывает только реально используемые настройки: BE00 игнорирует IBCR,
BE01 не требует priority mask, BOVE нужен при BN15. BOVE1 даёт H'3C с исходным SR.I;
BOVE0 выполняет нормативный spill и устанавливает BO. Обычная обработка и RESBANK
проверяются существующей CPU-приёмкой и новыми сценариями.

Невыровненный SP при входе: обе записи и decrement выполняются, данные стека UNKNOWN;
после первой exception sequence выполняется H'24. Ошибка собственного stacking H'24
не принимается повторно (Hardware7.9.3). При недоступном SP/VBR/handler не выдумывается
успешный frame. UNKNOWN SR допускает неизвестные байты SR в стеке при известной маске.

## Оставшиеся границы — обязательны следующему продолжению

1. **Реализован ограниченный scheduler:** `FirmwareGraph.withNoWaitPipeline()` включает
   тот же production-путь с `AbstractCpu.pipeline`, без отдельного исполнителя. Профиль:
   fetch уже завершён, каждый слот равен одному системному состоянию, bus waits отсутствуют
   (SW8.2). Поддержаны MOV/часть ALU/сдвиги/сравнения/T, scalar FP register moves/sign/immediate,
   FPUL register transfers, STS FPSCR, arithmetic/convert/compare/FDIV/FSQRT в PR0/PR1.
   Реализованы RAW/WAR/WAW, разрешённый zero-latency и FPUL/odd-half forwarding,
   2-ILP для этих форм, структурные E1/ED/FP_LS/SHIFT/READ_BUS/CPU_TO_FP конфликты,
   раздельные ISSUE/EXECUTE/CPU_COMPLETION/RETIREMENT/RESULT_COMMIT/CANCELLED.
   Несколько outstanding jobs и FR/FPUL/T/GPR deltas хранятся независимо; численный FPU kernel
   неизменен. CPU completion не записывает FP result. Copy/rollback/worklist key сохраняют scheduler.
   FPSCR при outstanding arithmetic в архитектурном snapshot UNKNOWN: точка cause/flags не выдумана.
   **NOT_IMPLEMENTED:** общий scheduler всех CPU/FPU форм, memory/bus/variable-slot execution,
   полный branch/delay-slot/RTE/exception pipeline, FPSCR write ordering, раздельный stall до ED
   и динамический возврат FDIV в занятый E1. Unsupported instruction останавливает precise path
   с `PIPELINE_UNVERIFIED_TIMING_*`, не выполняется как NOP и не получает единичную задержку.
   ED занят → `UNVERIFIED_ED_BUSY_STAGE_STALL`; пересечение будущего возврата в E1 с
   уже начинаемой независимой операцией → `UNVERIFIED_E1_RETURN_CROSSES_ACTIVE_OPERATION`.
   Это ограничения реализации, не отсутствие таблиц в руководстве. Обычный CFG остаётся untimed.
2. **UNVERIFIED:** автоматический condition → physical CPU-ID report для каждого H'24/H'34.
   Численная генерация FPU остаётся `PIPELINE_UNVERIFIED`; потенциальный вход не является
   доказательством фактического accepted ID и saved PC.
3. H'24 после access fault имеет отдельно помеченный `POTENTIAL_COMPLETION_ID` путь:
   первый возможный ID после условного completion. Его RTE/stack проверены, но выбор
   физически последней завершённой инструкции в перекрывающемся pipeline не подтверждён.
   RTE/TBR с fault и неизвестным control target фиксируют генерацию и границу без guessed PC.
4. **UNVERIFIED:** конкретные bus-wait/clock/arbiter параметры и моменты внешних источников;
   повторный fetch address-error при незавершённом bus cycle (§7.3.2 note) не тактуется.
   SINTR пока предоставляет абстрактную гипотезу delivery. После снижения SR.I через
   LDC учитывается окно MAY-delay до пяти следующих инструкций, а не обязательные пять.
5. Новое независимое ревью и результаты проверок относятся к manifest в
   `drafts/verification/system-stage4/continuation/`. Старые PASS 929/1164 и22/22
   подтверждают только прежний снимок. Новый scheduler не означает полноту этапа.
6. **Реализован causal-протокол отзыва SINT:** SINTRn=0 не удаляет доставленный report.
   Завершённый byte-read0 после clear отмечает подтверждение; при последующем RTE
   снимается только SOFTWARE report этого источника, если source всё ещё0.
   Повторная запись и reassert сбрасывают read-proof, unrelated reports сохраняются.
   Основание HW8.6.1 note/table8.5; численный таймер не вводится.
   **UNVERIFIED:** распространение снятия сигнала без этого протокола и произвольные
   асинхронные clock/bus условия. Они не подменены немедленным отзывом на write0.

Это контракт незавершённого этапа 4 для его продолжения, а не разрешение переходить
к периферии/XML/другому этапу. `SYSTEM_EXCEPTIONS_COMPLETE` не присвоен.


## Исправления повторного ревью и normal FP completion

H'24 generation использует общий cpuFetchAddressError: odd, on-chip I/O,
последние10байтов SRAM (Hardware7.3.1 table7.6 note1). Он вызывается для обычной
цели, reset/frontier, TBR, handler pointer и inline delay-slot fetch. Ошибочная
slot-выборка не исполняет слот; fetch fault не объявляет его retired.

TRAPA сохраняет in-flight до своего exception transition. Reports после issue
ждут завершения TRAPA, затем конкурируют на первом handler ID. Два frame и два
RTE проверены. Проигравший доставленный SINT сохраняется в systemPending; подписи
рёбер формируются по реальному победителю, а не по вызвавшему арбитраж адаптеру.

AbstractCpu.fpuCompletionBeforePc — явный вход ограниченного normal-сценария,
не расчёт latency. Один arithmetic/sqrt/FMAC/convert producer без trap вычисляет
числа прежним kernel. Его FR/FPUL delta хранится отдельно в deferredFpuResult;
CPU-instructions могут завершаться до FP commit. completeFpuAt вызывается перед
обычным PC и slot PC, коммитит только FR-mask/FPUL, не меняет lastRetiredPc или CPU/SRAM.
ExecutionStage.FPU_RESULT отличен от CPU COMPLETE. CpuSnapshot содержит job; FPSCR
в snapshot UNKNOWN до completion, поскольку его физическая временная точка не доказана.

До explicit boundary второй FPU producer/consumer блокируется с диагностикой
UNVERIFIED, а не получает принудительный SF. FCMP/T, forwarding, ресурсы и несколько
outstanding jobs этим subset не реализованы. FPU report при такой normal-job
тоже явно ограничен: его порядок относительно normal commit не выдумывается.
Без явного input продолжается прежнее абстрактное исполнение с логическими значениями;
оно не становится физической SF-трассой. Job не задаёт H'34-report deadline.

SW Rev3 p447 содержит противоречие six/seven стадий entry. Официальная японская
R01US0031JJ0400 Rev4, §8.9.7(4), printed8-66 (PDFp371 zero-based), подтверждает
семь: IF/ID/EX/EX/MA/MA/MA. Это entry после принятия, не detect→report latency.
Руководство: https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual?language=ja&r=1054896
