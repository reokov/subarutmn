# Реестр доказательств — 09.11.2026

Классы: `BIN_VERIFIED` (прямые байты), `CSV_VERIFIED` (экспорт Ghidra), `XML_VERIFIED` (структура XML), `CODE_STATIC` (исходники), `MANUAL_VERIFIED` (Renesas), `USER_REPORTED` (оператор), `UNVERIFIED`/`HYPOTHESIS` (нет самостоятельного подтверждения). Результаты без источника и метода в этом документе не считаются доказательствами.

| ID | Утверждение | Статус | Доказательство / ограничение |
|---|---|---|---|
| EV-001 | 43R = 2 МиБ Flash, 44R = 2,5 МиБ Flash | MANUAL_VERIFIED | Renesas HW Rev.4, §1 |
| EV-002 | SRAM `FFF80000–FFF9FFFF`, I/O `FFFC0000–FFFFFFFF` | MANUAL_VERIFIED | Renesas HW Rev.4, §5, стр.94–97 |
| EV-003 | Четыре ROM имеют заявленные размеры и SHA | BIN_VERIFIED | Сырые 4 BIN, SHA-256 в `SOURCES.md` |
| EV-004 | Во всех четырёх ROM reset PC=`0xE8`, SP=`0xFFFA0000` | BIN_VERIFIED | Big-endian U32 по `0x0`, `0x4` |
| EV-005 | LF9F000R ID расположен по `0x3B802`; LF79101K по `0x37C51` | BIN_VERIFIED | Поиск ASCII ROM ID по полному BIN |
| EV-006 | LF9C100P/LF9C001N ID по `0x38035`; рядом `2.0 TURBO` | BIN_VERIFIED | Поиск ASCII в BIN |
| EV-007 | В LF9C100P по `0xD1A` загружается литерал `0x1F0000`, затем запись VBR | BIN_VERIFIED + MANUAL_VERIFIED | Опкоды `D22D`, `422E`, литерал `0xDD0`; и аппаратная ISA |
| EV-008 | 44 кандидата нестандартных handler-пойнтеров в таблице VBR=`0x1F0000` | BIN_VERIFIED | Чтение 489 BE U32, фильтр ROM-range/alignment; назначение ISR не подтверждено |
| EV-009 | 505 слов векторных таблиц совпадают с экспортом Ghidra | BIN_VERIFIED + CSV_VERIFIED | Сверены 505 адресов `ghidra_vector_candidates.csv` и LF9C100P.bin |
| EV-010 | По `0x1DC` находится `0x482B` (`JMP @R8`), экспорт ошибочно пишет `CALL` к `0xCA0` | BIN_VERIFIED + CSV_VERIFIED + MANUAL_VERIFIED | Renesas SH-2A `JMP @Rm` `0100mmmm00101011` и строка `ghidra_function_edges.csv` |
| EV-011 | Выпал переход `0xE8 → 0x14E` | BIN_VERIFIED + CSV_VERIFIED | Инструкция в `0x14C` не завершает управление; в CSV нет ребра |
| EV-012 | BFS по исходному Ghidra CSV: из `0xE8` = 1 функция, из `0x14E` = 873 | CSV_VERIFIED | Пересчитан BFS по функциям и edge CSV; `873` нельзя без оговорки называть графом «от reset» |
| EV-013 | Экспорт: 7686 функций, 15821 рёбер, 15777 между размеченными функциями, 16 unresolved | CSV_VERIFIED | Повторный подсчёт 6 CSV из `ghidra_export.zip` |
| EV-014 | 3867 видов shape hash, 3216 однократно встречающихся функций | CSV_VERIFIED | Пересчёт частот в 7686 `LF9C100P_portable_profiles.csv` |
| EV-015 | 22 исходных XML в архиве DTC побайтно равны XML из исходного ZIP | XML_VERIFIED | Сверка пар по именам и полным байтам |
| EV-016 | 4 группы DTC, 103 строки, 97 общих строк, 64/231 одинаковых пар | XML_VERIFIED | Повторный разбор 22 XML по позициям `+N:bN` |
| EV-017 | `P2195/P2196` переставлены; `P0191` изменяет позицию в LV9 | XML_VERIFIED | `+85:b3/b4`, `+100:b7` → `+101:b2`; истинность подписей ECU не доказана |
| EV-018 | DITBASE содержит 270 scaling без конфликтов, 57 917 разрешённых ссылок | XML_VERIFIED | 22 исходных XML + DITBASE; сравнение всех атрибутов и ссылок |
| EV-019 | Замена scaling на include не изменила другие XML-поддеревья | XML_VERIFIED | Структурное сравнение 22 пар с нормализацией незначащих пробелов |
| EV-020 | Include и формулы корректны в приложении EcuFlash | UNVERIFIED | Прикладной EcuFlash не запускался; математические edge-case формул не проверены |
| EV-021 | 0.8.0 имеет SSA-движок и 3 вызывающих оркестратора | CODE_STATIC | Прочитаны Java в исходном ZIP; функциональный результат не проверен |
| EV-022 | 0.6.0/unreleased является отдельной независимой веткой | CODE_STATIC | Классы `ecu.independent`, отсутствие эквивалентной Ghidra SSA-цепочки, отдельный выпуск |
| EV-023 | LF9C001N — WRX CVT, ручной XML MT ошибочен | USER_REPORTED | Сообщение оператора; независимая проверка трансмиссии в BIN не завершена |
| EV-024 | Регион определяется кодами 0–15 в конфигурации ECU | HYPOTHESIS | Нужны XREF и семантика конфигурационного чтения |
| EV-025 | Найдены физически подтверждённые IAM/DAM и карта зависимости wastegate | UNVERIFIED | Надёжные адреса и цепочки по BIN в доступном сводном аудите не получены |
| EV-026 | Полный исполнимый CFG и финальный XML получены | **НЕ ПОДТВЕРЖДЕНО** | Есть computed/unmapped, неопределённые IRQ и отсутствие полностью доказанных scaling/семантик |

При переносе в другую прошивку **не копировать статус** EV-007…EV-014 без перепроверки SHA, местоположения кода, аппаратного режима и ROM XREF. В `verification_metrics.json` сохранены полные расчётные показатели для воспроизводимой сверки.
