# Исходные материалы и контрольные суммы

Хэши получены независимым SHA-256 прочитанных файлов **9 ноября 2026 года**. Для надёжной повторной проверки требуется тот же байтовый файл.

## BIN

| Исходный файл | Размер (байт) | SHA-256 |
|---|---:|---|
| `LF79101K.bin` | 2097152 | `441c293bd907d23761119a1850fa9e39820e15363c5f1c39f0195747e29584d4` |
| `LF9C100P.bin` | 2097152 | `a8774543cd8be2eda80a37bca5c00c97f4bc2a2bd770c02059f46b6239825a64` |
| `LF9F000R_CD01A04007-20221003-235357.bin` | 2621440 | `550d6c3d4b04a0b8b821e5e0adb2e7835b8f683ae738d73d349e41730dbee49d` |
| `WRX_LF9C001N_B229A05007(1).bin` | 2097152 | `aec49c49140e62ce417fc135fcbd6539f4d5dadf6d22d5d0678de769ae04434e` |

## Аналитические ZIP и отчёты

| Исходный файл | SHA-256 |
|---|---|
| `DITBASE_EcuFlash_verified.zip` | `a03adf975f6c0fef05c5506ba0f17991e3ed4ac48abc4da82309b22f38b9cef4` |
| `DTC_FailSafe_XML_comparison.zip` | `130ab52a9af6462e89538d76cbc37a1c7981b748207ed40fe823310c1dbd6b5f` |
| `ECUAnalysis_0.8.0.zip` | `65f6287b35f7430f6cd95e8aacd9927de1bd131728e804c4d395571fe928511d` |
| `ECUAnalysis_OpenCode_Consolidated_ghidra12_2_ctor_fixed.zip` | `b277ba2b25d196ec7bb7e7c5bb576bdc36c531cda621a2b66afe8c5ddbd078e6` |
| `ECUAnalysis_system_coverage_audit_20261109_RU.md` | `a69faa1eeffb1d8d8c8616128cfb34713f923d013cd81f2158f173fe0faa062e` |
| `ECUResearch_structural_graph_bundle.zip` | `19cb50eb47a1035759877c1dfa0cb9f2ecca049c2e85d275651cce15587067ee` |
| `LF9C100P_Ghidra_graph_audit_RU.md` | `15b4d6443b346a6848a033a4fe717f398f3d56dcc7cfbfd2b82b4034a7a1c377` |
| `Renesas_SH2A_SH7254R_Hardware_Reference_RU.md` | `c47b408e32bc9714852684844292b2f1368cfa932fc483e97cd5bc3f6e35f8cf` |
| `ghidra_export.zip` | `496a09f347122654dd2dd67ef255bded6db603906c13a793c60cb97a521276f6` |
| `subaru-dit-defs-main.zip` | `960ee676321b333041fcf6759f46478aca763fc6585a318117557d9b09378acc` |

## Внешние первичные источники

- Renesas, **SH7254R Group User's Manual: Hardware**, R01UH0480EJ0400, Rev.4.00 (01.04.2014), §1, §5, страницы 9, 94–97: https://www.renesas.cn/zh/document/mah/sh7254r-group-users-manual-hardware?r=1054941
- Renesas, **SH-2A / SH2A-FPU Software Manual**, Rev.4.00, R01US0031JJ0400, таблицы и коды JMP/JSR, §5.1.5 и §6.4.24: https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual?language=ja
- Renesas, **SH-2A, SH2A-FPU Software Manual**, Rev.3.00 REJ09B0051-0300 (2005), та же архитектурная линия (сверять отличия ревизий): https://www.renesas.com/en/products/sh7206
- Jengacat, **subaru-dit-defs**, фиксированный commit `8abec2d85bfffbe31fc400b23527f885155396fb`: https://github.com/Jengacat/subaru-dit-defs/tree/8abec2d85bfffbe31fc400b23527f885155396fb/definitions/ecuflash
- morluto/rea — **только методологический ориентир**, не аппаратный источник SH-2A: https://github.com/morluto/rea

## Правила происхождения

1. Зафиксированный SHA-256 идентифицирует конкретные байты файла, не доказывает достоверность описаний внутри файла.
2. Отчёты Ghidra получены из аннотированной Program: их числа перепроверены, но полнота дизассемблирования не следует из статистики.
3. Репозиторные XML являются сторонними описаниями калибровок и DTC, а не независимым доказательством ECU-кода.
4. Исходные прошивки и сторонние XML не вложены в этот небольшой архив: их не следует бесконтрольно распространять; для повторной проверки достаточно иметь исходники с указанными хэшами.
5. Не копировать пароли, токены, персональные данные в технический архив.
