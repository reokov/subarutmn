# Этап4.4: FPUL/FPSCR memory и FSCHG

Дата: 12.11.2026. IN_PROGRESS / RELEASE_BLOCKED.
Подтверждённая база: stage4_4-20261112-e87c1b136568; SHA source manifest
`e87c1b13656871060126339356f64f559c6b74c4e28b7e894e68faf67eb0a759`.
Указанный в исходном задании a967 относится к предшествующей версии; пользователь
подтвердил продолжение приложенного e87. Потерянный59c7 не восстанавливался.

Изменены production Java: SystemExceptionModel.java, FirmwareGraph.java.
Тесты: PipelineStage44Acceptance.java. Packaging: export-stage4-checkpoint.py.
Пять новых execution profiles, numerical semantics неизменны.
RED до реализации: отсутствовал4252 (fp-control-red.log).
Текущие фактические результаты приведены в functional.log, fp-control-green.log,
inventory.log, extension.log. Эти результаты относятся к source manifest snapshot.

Новые checks: 4 transfers ×3 address registers ×4 modes, SRAM bits, address update,
FPSCR mask, RESULT_COMMIT, arithmetic FPUL forwarding to CPU/memory, SZ forwarding,
FSCHG while FDIV outstanding, copy/reset и misalignment H24 without normal issue.
25 mandatory groups включают decoder253/253, CPU205/205, FPU56/56.
PROFILE_PRESENT — только inventory, не заявление всей нормативной корректности.

Review текущего snapshot: NOT_RUN до постоянной backup verification.
Исторический review32aad_FAIL не является review текущей версии.
External review: NOT_RUN. SYSTEM_EXCEPTIONS_COMPLETE не заявляется.

Следующая группа: multiple memory / оставшиеся CPU memory control profiles.
Полная consumer/memory ordering matrix, общие exception entry/retirement/cancel,
условия physical H24/H34 reporting, ED buffering/backpressure остаются незакрыты.
Реальные ROM, оборудование и Ghidra import NOT_RUN.
