# Этап4.4: Whole SR / завершение CPU-результата / issue rules

12.11.2026. IN_PROGRESS / RELEASE_BLOCKED. Parent e29e38de2ba5 saved/retrieved/
73sourceverified перед reviewPASS. ТекущееreviewNOT_RUN доновойpersistentпары.

ProductionJava:SystemExceptionModel.java. TestJava:PipelineStage44Acceptance.java.
Добавлены4SRprofiles. WholeSR иT/Q/M/CS обновляются согласованно.
IRQ_WINDOW перенесён вcommittedshadow, arm/decrement связаны сCPUcompletion/
SRcommit. Это прежний abstract uncertaintycounter, не физический INTCтаймер;
runtime UNVERIFIED_INTC_MASK_CHANGE_REPORT_SYNC. NumericalCPU/FPU/decoderunchanged.

207PROFILE_PRESENT /46NOT_IMPLEMENTED /253. Profilepresence не означаетполноту.
Новые проверки SR:4формы×3GPR×4SRзначения, memory/address/flags, H24,
отсутствие ранней mask/window записи; flagRAW extra slot отдельно отWAW;
ID2/1/4/1 по визуально проверенным диаграммам; finalstepissuecapacity;
32bitmulticycle FMOVSZ0/SZ1;64изолированныеBIT_REGвключены вштатнуюacceptance.

RED→fix→GREEN: SRprofile420e; ошибочный кандидатSRextraID (fence-red);
отсутствующая finalstepissue lane(last-lane-red); 32bitmulticyclewide-red;
неверная SRflag additionallatency дляWAW(sr-waw-red).
Предварительные pre-visual/pre-waw журналы не являются текущимPASS.
Свежие full/target/build/inventory вlogs иSNAPSHOT.

Незакрыто:46forms, включая multiplememory, memoryRMW/bit, MUL/DIV/MAC,
bank/system/TRAPA/SLEEP; полная2ILP/consumer/exceptionmatrix.
Generalexceptionentry/cancel/retirement иphysicalH24/H34report/savedPC подoverlap
не завершены. FSCHGresourceиEDbuffering/capacityUNVERIFIED. Externalreview,
реальныеROM/ECU/GhidraimportNOT_RUN. SYSTEM_EXCEPTIONS_COMPLETE не достигнут.
Следующаянезависимаягруппа: memorylogical/bitRMWprofiles исвязанные32bitpairing exceptions.
