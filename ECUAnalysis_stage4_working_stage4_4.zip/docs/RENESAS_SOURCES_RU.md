# Первичные источники Renesas для разработки

Документы в данный ZIP не вложены: они принадлежат Renesas; OpenCode должен получать их из официального источника на машине оператора. Нельзя заменять спецификацию SH72543R инструкциями SH4.

1. **SH7254R Group User's Manual: Hardware**, Rev. 4.00, R01UH0480EJ0400: https://www.renesas.com/en/document/mah/sh7254r-group-users-manual-hardware
   - Память, reset/standby, банковые регистры, INTC/IRQ, ATU-III, CMT, RCAN-TL1, ADC, DMA/A-DMA, WDT, CPG, MMIO.
2. **SH-2A/SH2A-FPU Software Manual**, Rev. 3.00, REJ09B0051-0300: https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual
   - Кодировки, длины 16/32 бит, регистры, delay slots, ISA/FPU, FPSCR, исключения и банковые операции.
3. **SH Compiler Application Note — Compiler Use Guide for SH-2A/SH2A-FPU**: https://www.renesas.com/en/document/apn/sh-compiler-application-note-2-compiler-use-guide-sh-2ash2a-fpu
   - Компиляторные паттерны функций, calling conventions и оптимизации; не является заменой Software Manual.

Дополнительные независимые источники:
- Linux SH2A instruction length helper (только перекрёстная проверка): https://codebrowser.dev/linux/linux/arch/sh/kernel/cpu/sh2a/opcode_helper.c.html
- Ghidra 12.2 API и headless reference: https://github.com/NationalSecurityAgency/ghidra

Сопоставление инженерных формул EcuFlash требует одновременно endian, storage type/width/signedness, `toexpr` и `frexpr`. Автоматический перенос названий из ручных XML — гипотеза, а не доказательство назначения карты.
