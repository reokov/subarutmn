# Первичные источники

Ссылки ведут на страницы Renesas. Скачайте соответствующие PDF напрямую, проверьте полное имя и ревизию, приложите к заданию. PDF не перепакованы в этот комплект.

1. SH7254R Group User's Manual: Hardware
   https://www.renesas.com/en/document/mah/sh7254r-group-users-manual-hardware
2. SH-2A/SH2A-FPU Software Manual, REJ09B0051-0300, Rev. 3.00
   https://www.renesas.com/en/document/mah/sh-2a-sh2a-fpu-software-manual
3. Product information SH72543R (проверка конфигураций MCU)
   https://www.renesas.com/en/products/sh7254r/part-details/r5f72543rkbgv
4. Ghidra repository (использовать документацию именно релиза 12.2)
   https://github.com/NationalSecurityAgency/ghidra
5. Ghidra Getting Started (ветка релиза должна быть зафиксирована)
   https://github.com/NationalSecurityAgency/ghidra/blob/master/GhidraDocs/GettingStarted.md

Обязательно отдельно найти и проверить официальные errata/technical updates по конкретным ревизиям MCU. Не подменять их руководствами другого семейства SH.

Поля для фиксации каждого источника: `document_id`, `revision`, `publication_date`, `SHA256`, `section`, `page`, `requirements_covered`.
