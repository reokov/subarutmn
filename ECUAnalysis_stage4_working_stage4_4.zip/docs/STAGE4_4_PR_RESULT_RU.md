# Этап4.4: PR transfers / MOVA и уточнение FSCHG

12.11.2026. IN_PROGRESS / RELEASE_BLOCKED.
Parent source28d5e0efda14 сохранён и повторно получен до независимого review.
PARENT_BACKUP_VERIFIED.json содержит точные IDs/SHA; PARENT_REVIEW_RU.md — вывод.

Изменены production: SystemExceptionModel.java, FirmwareGraph.java.
Acceptance: PipelineStage44Acceptance.java. Exporter теперь принимает название группы.
Новые5форм: MOVA, LDS/STS PR, LDS.L/STS.L PR; всего182/253PROFILE_PRESENT,71NOT_IMPLEMENTED.
Красная проба до реализации: red.log (c700). Текущие compile/target/full/extension
результаты находятся в logs; прошедшая предыдущая версия не считается currentPASS.

FSCHG runtime uncertainty теперь явно отражает противоречие §8.9.8(9)p456
vs table8.1p374/AppendixA pp479–480. Численное ядро неизменно.
Тесты PR: R0/R2/R15, оба направления память/регистр, точные32bits, addressupdate,
RESULT_COMMIT, CPU overlap, dependencies/MA, H24; MOVA scaled alignedPC.

Незакрыто: multiple memory, остальные system/MAC/bit/2ILP forms, общая exception
entry/cancel/retirement/resume; ED buffering/backpressure/capacity, physical H24/H34
report timing и некоторые savedPC UNVERIFIED. External review NOT_RUN.
Следующее требование: multiple-memory profiles и оставшиеся non-FPU control transfers.
SYSTEM_EXCEPTIONS_COMPLETE не достигнут.
