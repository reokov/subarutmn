# ECUAnalysis — итог сохранённой итерации4.4

12.11.2026. **IN_PROGRESS / RELEASE_BLOCKED**.
Snapshot: **stage4_4-20261112-a96749fd281b**.
SYSTEM_EXCEPTIONS_COMPLETE не присвоен. Внешнее независимое ревью: NOT_RUN.

## Восстановление и сохранность

Утраченный stage4_4-20261111-59c7ff9175af восстановить не удалось: RESTORE_BLOCKED.
Для его точного восстановления требуется рабочий архив именно59c7 с source manifest.
По явному поручению начать заново использован последний подтверждённый архив
ECUAnalysis_stage4_working (2).zip, SHA256
`f599f87f7d7c91ae3d4c3e87f4e70f3d428cf65f688710bb77f0b6ce266ad895`.
Потеря прежних несохранённых изменений явно зафиксирована. Текущий результат — новая
реализация, а не восстановленные bytes59c7. Исторические PASS не перенесены на новый код.

Перед обоими внутренними review были созданы, сверены и постоянно сохранены
рабочий и предварительный evidence ZIP. Receipt текущего pre-review snapshot
находится в BACKUP_RECEIPT.json, исторические копии выделены отдельно.
После review основная область и все73 source bytes повторно проверены: потери нет.
Итоговые архивы добавляют документы/протоколы; Java и тесты после review не менялись.

## Production Java и исполняемая семантика

Изменены `src/main/java/ecu/independent/SystemExceptionModel.java` и
`src/main/java/ecu/independent/FirmwareGraph.java`. Existing AbstractCpu.pipeline
copy/rollback/merge hooks используются без нового исполнителя. Decoder/CPU/FPU kernel
и AbstractCpu.java не перерабатывались.

Реализовано в существующем execution route:

- Flight хранит actual phase/remaining/start, CPU completion и отдельный result commit.
- E1/ED/return/E2/SF и WAIT_RESOURCE. Future return не отодвигает независимый ready16
  на23; результат не переносится простым изменением deadline и не записывается до SF.
- Несколько outstanding операций; буферизованное ожидание ED и return E1;
  независимая операция может завершиться раньше старого divide.
- Раздельные slot/system-state clocks. ED продвигается внутри длинного slot,
  остальные стадии по slots. Длительности задаются явно, не выводятся из ROM/CFG.
- Basic CPU/scalar FPU SRAM/ROM memory profiles и собственные SRAM deltas с commit
  на стадии памяти. Operand forwarding отделён от архитектурного состояния.
- FPSCR register write/read dependencies, numerical context отдельно от committed;
  PR1 применяется при decode/execute только с соответствующей зависимостью.
- Double FMOV register profile EX/EX/NA/SF и multicycle issue restriction.
- Branch/conditional branch, delay-slot/target fences, call/return PR;
  unknown-T partition только для pipeline и прежнего delayed-branch маршрута.
- RTE EX/MA/MA/EX/EX/EX, SP/SR/T deltas, частично известные SR bits,
  accepted-frame rebase перед handler RTE. Initial restore не стирает исходную память.
- Явный already-reported IRQ после слота принимается после known decode fence,
  когда slot job завершён; physical report из этого не выводится.
- H34 numerical condition сохраняет normal/faulted outstanding jobs без обычного
  result commit и без выдуманного physical report или saved PC.

Нормативные references и ограничения каждой группы: PIPELINE_STAGE4_4_RU.md.

## Исправление по внутреннему FAIL

Первое review snapshot0d76 обнаружило WAW domain defect: FR/FPUL latency reduction
применялась к T/Rn, если producer был FPU instruction. Независимая RED-проба:
FCMP→SETT и STS FPUL,Rn→MOV Rn выдавались наslot1 вместоCPU boundary2.

В a967 reduced rule применяется только к FR/FPUL; CPU T/Rn используют обычную
latency и commit-order bound. Та же независимая проба повторно GREEN(2,2).
Old FAIL/RED хранится в historical_review_0d76_FAIL, текущий review — current_review_A967.

## Фактически выполненные проверки

| Проверка | Результат |
|---|---|
| Full verify-functional.sh |25/25 mandatory PASS, exit0|
| PipelineStage44Acceptance |23 сценария /51 assertion PASS|
| SystemExceptionsAcceptance |962 сценария /1241 checks PASS|
| Core/tools fresh javac |JDK21, --release21 -Xlint:all PASS|
| Ghidra extension |JDK25/Ghidra12.2/Gradle9.8 BUILD SUCCESSFUL|
| Extension source bytes |Все Java внутри source ZIP совпали; ECU BIN/configs исключены|
| Reviewer CPU extra |1582 случая /18524 assertions PASS|
| Reviewer own probes |24 сценария /49 assertions PASS, плюс WAW GREEN|
| SOURCE_SHA256 |73/73 до и после review; source_changed_during_run=[]|
| Внешнее независимое ревью |NOT_RUN|
| Реальные ROM/BIN, physical ECU, Ghidra с BIN |NOT_RUN|

Полный25-suite PASS не доказывает полноту pipeline. Часть stage schedules условна
относительно interstage buffering. Такие тесты не объявляются hardware timing oracle.
Inventory253 строк:138 PROFILE_PRESENT,115 NOT_IMPLEMENTED. Это инвентаризация,
не знаменатель независимой функциональной приёмки и не процент завершения.

## Результат sh7254r-reviewer

Повторное внутреннее review: **PASS проверенного среза / FAIL полноты этапа4**.
Reviewer независимо сверил source manifest/архив, заново скомпилировал core/tools,
повторил target/system/CPU-extra и свои пробы. Production/docs/tests им не менялись.
Полный25-suite run и extension build выполнены основным агентом и не приписаны reviewer.
Внешнему агенту ещё предстоит отдельный независимый анализ сохранённых архивов.

## Все20 критериев

|№|Критерий|Итог|
|---:|---|---|
|1|Полный нормативный перечень|Частично; scenario/profile matrix не закрыта|
|2|Generation/acceptance|Частично; physical H24/H34 report не завершён|
|3|Арбитраж/приоритеты|Проверен subset; полнота не доказана|
|4|Маски/вложенность|Частично; general async delivery/withdrawal не закрыты|
|5|Saved PC по исполнению|Explicit slot/fence проверен; general physical overlap не закрыт|
|6|Delay slots|Representative branch/RTE cases PASS; не вся матрица|
|7|Точка H34|Physical automatic report UNVERIFIED|
|8|H24 и side effects|Частично; general bus/completion order не закрыт|
|9|Pending|Preservation/causal SINT cases PASS; общая полнота не доказана|
|10|Handler entry|Atomic known frame; staged entry не завершён|
|11|Возврат|RTE profile PASS в subset; общий in-flight resume не закрыт|
|12|Достаточный pipeline|Не выполнен;115 profiles отсутствуют|
|13|Нет NOT_IMPLEMENTED|Не выполнен|
|14|Нет блокирующих UNVERIFIED|Не выполнен|
|15|Вся нормативная приёмка|25 existing suites PASS; всей матрицы нет|
|16|Нет регрессий1–3|PASS текущих обязательных наборов|
|17|Core/extension builds|PASS|
|18|Ревью полноты без blocker|PASS внутреннего subset / FAIL полноты; внешнее NOT_RUN|
|19|Норма каждого обязательного правила|Частично; см. контракт|
|20|Нет фиктивной точности|PASS: inputs/условность/ограничения явно обозначены|

Полностью подтверждены в проверенной области16,17,20. Знаменатель20 не уменьшался.

## Незакрытое и точное продолжение

NOT_IMPLEMENTED: address-update/indexed/GBR/reverse/multiple memory profiles,
double FPU memory, memory control transfers, FSCHG/полные FPSCR dependencies,
MUL/DIV/MAC/system/bank/TRAPA/SLEEP profiles, полная32-bit/multicycle2-ILP matrix,
general exception entry/cancel/retirement/resume.

UNVERIFIED: interstage latch/queue capacity, ED-result holding/backpressure при
занятомreturnE1; physical condition→CPU-report H24/H34; bus/wait/clock условия
без явных inputs. Runtime UNVERIFIED_ED_E1_HANDOFF_BUFFERING не скрывает115
недописанных profiles: они отдельно отмечены NOT_IMPLEMENTED.

Следующая независимая задача внутри4.4: address-update memory profiles с раздельной
готовностью данных и адресного регистра, затем остальные memory/control forms.
Перед следующим reviewer обязательна новая постоянно сохранённая резервная пара.

## Идентичность и восстановление

Source manifest SHA256:
`a96749fd281b71403771cee98da4cf0efddfacf1f1e964e9cb8600a98a230e16`.
Рабочий и evidence ZIP имеют общий SNAPSHOT.json и source manifest. Проверка каждого
MANIFEST.sha256 и всех73 source bytes в рабочем ZIP обязательна перед продолжением.

Итоговые имена:
ECUAnalysis_stage4_working_stage4_4-20261112-a96749fd281b.zip
и ECUAnalysis_stage4_review_evidence_stage4_4-20261112-a96749fd281b.zip.
Подтверждение постоянного сохранения и скачиваемые ссылки предоставлены оператору.
