# Этап4.4: non-SR control transfers / исправление diagnostics

12.11.2026. IN_PROGRESS / RELEASE_BLOCKED.
Parent snapshot stage4_4-20261112T021015Z-cf3e84eab11b сохранён и повторно
получен до независимого review; receipt и parentFAIL включены отдельно.

Java production: SystemExceptionModel.java, FirmwareGraph.java.
Acceptance: PipelineStage44Acceptance.java. Exporter сохраняет currentcounts.
Добавлены10форм GBR/VBR/TBR (6register +4memory), новые committedshadow
VBR/TBR, зависимости, effectiveaddressguard. Numerical ядро неизменно.
Inventory:192PROFILE_PRESENT /61NOT_IMPLEMENTED /253. Наличиепрофиля неPASSполноты.
Target176scenarios371assertions; итог full/build фиксируют свежиеlogs иSNAPSHOT.
Предыдущие результаты не подменяют текущие проверки.

cf3MEDIUM diagnostics закрыт: actualmarker вместо фиксированногоED.
RED на точном priorJava из savedcf3, GREEN на новом коде; probe сохранена.
Для новыхcontrols RED312 до реализации. Tests:3GPR ×10forms, rawbits,
SRAM/addressupdate, GBR effectiveaddress forwarding, отсутствие раннегоWB,
UNKNOWN, VBRcopy/reset, H24 и FSCHG diagnosticlabel.

| Требование | Состояние |
|---|---|
| Scalar/double/address-update/indexed/GBR/reverse memory | PROFILE_PRESENT; полнаяconsumer/exceptionmatrix незавершена |
| FPUL/FPSCR memory +PR +non-SRcontrols | PROFILE_PRESENT; текущая приёмка вlogs |
| FSCHG resource/pairing | UNVERIFIED: конфликт §8.9.8(9)p456 vs table8.1p374/AppendixA |
| MOVML/MOVMU | NOT_IMPLEMENTED; FPUoutstanding completion boundary невыведена |
| SR/MAC/MUL/DIV/bit/system/bank/TRAPA/SLEEP profiles | NOT_IMPLEMENTED remaininginventory |
| Полная32bit/multicycle/2ILP matrix | NOT_IMPLEMENTED |
| Generalexception entry/cancel/retirement/resume | NOT_IMPLEMENTED |
| Physical H24/H34 report/savedPC underoverlap | UNVERIFIED |
| EDholding/backpressure/capacity | UNVERIFIED |
| Externalreview /realROM/hardware/Ghidraimport | NOT_RUN |

Следующее независимо определённое требование: SRcontrol и оставшиеся memory bit/MAC forms;
не подменять их готовность текущимконтрольнымсрезом. SYSTEM_EXCEPTIONS_COMPLETE нет.
