# ECUAnalysis — продолжение этапа 4

11.11.2026. **IN_PROGRESS / RELEASE_BLOCKED**. `SYSTEM_EXCEPTIONS_COMPLETE` не достигнут.
Изменения реализованы в текущем дереве проекта; отдельная рабочая копия не создавалась.

## Результат

Добавлен действующий ограниченный readiness/resource scheduler в существующие
`SystemExceptionModel`, `AbstractCpu` и `FirmwareGraph`, с тем же numerical executor.
Исправлен отзыв доставленного SINT по протоколу clear → completed read0 → RTE.
Этап остаётся незавершённым: общий pipeline всех форм и маршрутизация исключений
при перекрытии не реализованы полностью. Следующий этап не начинался.

Включение явного execution profile: `new FirmwareGraph().withNoWaitPipeline()`.
Этот профиль предполагает завершённые instruction fetch, отсутствие bus waits
и одно системное состояние на slot (SW8.2). Обычный анализ остаётся untimed;
новый scheduler не включён по умолчанию и не превращает CFG в аппаратную трассу.

## Согласованность входа

Пять production Java исходного рабочего ZIP побайтно соответствуют SHA-256
позднего приложенного ревью: **5/5 совпадений**. Подробности —
`drafts/verification/system-stage4/continuation/INPUT_INTEGRITY.json`.
Ни один файл не заменялся неизвестной или старой версией.

Сохраняются H24 fetch I/O/SRAM-end, однократное TRAPA при IRQ, typed pending
проигравшего SINT, отдельный normal FP commit, включая slot boundary.
Эти пробы повторно входят в текущий `SystemExceptionsAcceptance`.
Исторические 904/1104 и929/1164 не используются как текущие результаты.

## Изменённые Java

| Файл | Изменение |
|---|---|
| `src/main/java/ecu/independent/SystemExceptionModel.java` | PipelineSpec/Flight, scoreboard, resource reservations, фазы и частичные нормативные profiles |
| `src/main/java/ecu/independent/AbstractCpu.java` | Copy/rollback/key-partition scheduler; causal proof снятия SINT |
| `src/main/java/ecu/independent/FirmwareGraph.java` | Подключение scheduler к production executor, delta commit, snapshots/stops, reset profile preservation, RTE withdrawal |
| `src/main/java/ecu/independent/Sh7254rIntcMmio.java` | Разделение source clear/read-proof и delivered report; отзыв только при последующем RTE |
| `tools/SystemExceptionsAcceptance.java` | Новые scheduler/withdrawal/double-FCMP проверки |

`Sh7254rMemoryMap`, `Sh7254rInterruptController`, decoder и numerical FPU не изменялись.
Дополнительно обновлены контракт и `scripts/verify-functional.sh`: scheduler и withdrawal
включены отдельными обязательными наборами. В `build.gradle` исключены входные
архивы из `upload/` и `review-input/` при упаковке расширения.

## Реализованный pipeline

- RAW readiness, double-source WAR hold, CPU/FPU WAW и порядок одинаковых SF writes.
- Zero-latency MOV-register/FMOV bypass, FPUL→CPU и odd-half double-result forwarding.
  MOV-immediate имеет latency1, не получает MOV-register bypass.
- Максимум две issue за slot; исключения width32, preceding multicycle double-FCMP,
  FPSCR-access, RAW/WAW и общие ресурсы учитываются в реализованных profiles.
- E1/ED, FP_LS, SHIFT, READ_BUS, CPU_TO_FP resource use; несколько outstanding jobs.
- Отдельные ISSUE, EXECUTE, CPU_COMPLETION, RETIREMENT, RESULT_COMMIT и CANCELLED.
- FDIV/FSQRT latency12/11 в PR0 и25/24 в PR1 в однотактном профиле;
  независимая FADD может завершиться, пока старый divide outstanding.
- FR/FPUL/GPR/T deltas отделены от CPU completion; поздний commit не откатывает
  чужие регистры/память. Bypass и architectural committed values хранятся отдельно.
- STS FPSCR ждёт завершения arithmetic +1 slot; FPSCR в snapshot при outstanding
  arithmetic UNKNOWN, физический момент Cause/Flag не объявлен доказанным.
- H34 condition создаёт pending/generation и сохраняет job без обычного результата;
  дальнейший precise path останавливается, не придумывая CPU report phase.
- Power reset отменяет outstanding и сохраняет выбранный profile. Copy/rollback
  не разделяют изменяемое scheduler-состояние; различающиеся jobs не сливаются.

Поддержаны MOV/часть ALU/сдвиги/сравнения/T, scalar FP register moves/sign/immediate,
FPUL register transfer, STS FPSCR, arithmetic/convert/compare/FDIV/FSQRT.
Это **не полный набор CPU/FPU pipeline profiles**.

## Исправления по независимому ревью

| Дефект | Red | Исправление/текущий результат |
|---|---|---|
| Double FCMP coissue и CPU completion | `reviewer/double-fcmp-red.log` | CPU EX/EX, following NOP earliest+1; GREEN |
| Odd-half double FDIV/FSQRT forwarding | `reviewer/div-odd-red.log` | 24/23; GREEN |
| Потеря scheduler после power reset | `reviewer/reset-profile-red.log` | Profile сохраняется; GREEN |
| Лишний FR WAW stall при zero-latency FMOV | `reviewer/fpu-waw-red.log` | Same-slot issue, SF в issue-order; GREEN |
| Недоказанный перенос ready16→23 при будущем E1 return | `reviewer/future-e1-red.log` | Точный UNVERIFIED; **исполнение ещё не реализовано** |
| Перенос всей DF второго FDIV при занятом ED | Независимый анализ §8.6(4) | Точный UNVERIFIED; **stage-stall ещё не реализован** |
| Stale SINT после clear/read0/RTE | `withdrawal-red.log` | Causal withdrawal; GREEN; clear без read не удаляет report |

В первой exploratory-пробе scheduler были ошибочные oracle inputs: E1 request
смешивался с предшествующим DF, а zero/zero использовал Enable Z вместо Enable V.
Они исправлены по руководству и **не представлены как production red/green**.
Собственные независимые probes reviewer находятся рядом с его журналами.

## Выполненные проверки

| Проверка | Фактический результат |
|---|---|
| `verify-functional.sh` | **24/24 mandatory PASS**, exit0 |
| SystemExceptionsAcceptance | **962 сценария /1239 assertions PASS** |
| Отдельный scheduler | **27 сценариев /64 assertions PASS** |
| Отдельный SINT withdrawal | **5 сценариев /8 assertions PASS** |
| Отдельный double FCMP | **1 сценарий /3 assertions PASS** |
| Decoder | 253/253, 50 647 552 checks PASS |
| CPU | 205/205, 37 992 checks PASS |
| CPU boundary | 2992 случая /9634 assertions PASS |
| FPU forms | 56/56, 6388 checks PASS |
| FPU exact/special corpus | 2 146 238 checks PASS |
| Core/CLI | JDK21.0.2, `--release21 -Xlint:all`, PASS |
| Ghidra extension | Ghidra12.2, Temurin25+36, Gradle9.8, BUILD SUCCESSFUL |
| Реальные ROM, Ghidra с BIN, физический ECU | NOT_RUN |

Отдельные scheduler/withdrawal/double-FCMP числа входят в962/1239 и не суммируются
повторно. PASS проверок остановки на UNVERIFIED не означает исполнение этих случаев.
Полный functional run: UTC `20261111T175415Z`.

## Все 20 критериев

Строго полностью закрыты №16,17,20. Остальные17 не объявляются выполненными
по результатам ограниченных probes. Знаменатель —20.

| № | Критерий исходного задания | Итог |
|---:|---|---|
| 1 | Полный нормативный перечень | Частично: types/vectors есть, весь сценарный знаменатель не закрыт |
| 2 | Generation и acceptance в Java | Частично: explicit ID; physical report H24/H34 не завершён |
| 3 | Арбитраж и приоритеты | Проверенный explicit-ID срез PASS; полнота не доказана |
| 4 | Маскирование и вложенность | Частично: SR.I/nesting/LDC и causal SINT; общая доставка не завершена |
| 5 | Нормативный saved PC | Частично; physical overlap acceptance не реализован |
| 6 | Delay slots | Известные cases PASS; общий pipeline slot-path не реализован |
| 7 | Правильная точка H34 | Не выполнен для automatic report |
| 8 | H24 и побочные эффекты | Частично: fetch/access/stacking; overlap/bus order не завершён |
| 9 | Корректный pending | Preservation и causal withdrawal PASS; произвольная асинхронная доставка/отзыв не закрыты |
| 10 | Переходы к handler | PASS известных frame/vector условий; общий pipeline entry не завершён |
| 11 | Возврат | Известные RTE cases PASS; общий in-flight/RTE не реализован |
| 12 | Достаточная pipeline-модель | Не выполнен: реализован ограниченный scheduler |
| 13 | Нет NOT_IMPLEMENTED | Не выполнен |
| 14 | Нет блокирующих UNVERIFIED | Не выполнен |
| 15 | Вся обязательная нормативная приёмка |24 существующих mandatory PASS; вся нормативная область не покрыта |
| 16 | Нет регрессий этапов1–3 | PASS выполненных обязательных наборов |
| 17 | Сборки ядра/расширения | PASS на текущем исходнике |
| 18 | Независимое ревью полноты без blocker | PASS среза / FAIL полноты |
| 19 | Норма каждого обязательного правила | Частично; полный scheduler не реализован |
| 20 | Нет фиктивной тактовой точности | PASS: профиль/входы/UNVERIFIED явно разделены |

## Независимое sh7254r-reviewer

**PASS проверенного среза; FAIL полноты этапа4.** Reviewer независимо перечитал
исходники/норму, скомпилировал Java, выполнил962/1239,27/64,5/8 и собственные probes.
Новых доказанных дефектов проверенного subset не найдено. Полный24-suite run и сборка
расширения выполнены основным агентом, не приписываются reviewer.
Его неизменённый отчёт: `reviewer/FINAL_REVIEW_RU.md` внутри evidence-каталога.

## SHA-256

Текущий manifest Java+check script: **48/48 совпадений**, повторная сверка после сборок.
SHA-256 `JAVA_AND_CHECKS_SHA256.txt`:
`25296f380b94b0670ba4269d017ecaabe94846dc5a6ec2ddef797a151c32c539`.

`EVIDENCE_SHA256.txt` связывает текущие протоколы, fixtures/probes и независимый отчёт;
его fingerprint записан в `SNAPSHOT.json`. Корневой `MANIFEST.sha256` сформирован заново
по итоговой поставке. Проверено совпадение manifest и фактических bytes внутри рабочего ZIP.

## Что осталось

**NOT_IMPLEMENTED:** полный набор CPU/FPU profiles, memory/branch/delay-slot/RTE,
FPSCR writes, variable slots/independent ED progression, удержание перед занятым ED,
динамический возврат в занятый E1, общий in-flight exception entry/cancel/resume.
Эти части нельзя объяснять отсутствием аппаратного timing-эталона.

**UNVERIFIED:** condition→physical CPU report H24/H34 для всех applicable условий;
bus waits/clock ratios и внешняя доставка/отзыв IRQ вне completed-read протокола;
конкретный accepted ID/saved PC при таком overlap. Необходимое дополнительное
свидетельство — применимые правила detection/report/стадий и входные bus/clock условия;
адрес следующей инструкции CFG таким свидетельством не является.

Для busy ED и crossing E1 точные UNVERIFIED имена отражают ещё недописанный
stage scheduler, а не доказанное отсутствие нормативной возможности.
`SYSTEM_EXCEPTIONS_COMPLETE` и разрешение перехода к этапу5 не выдаются.
